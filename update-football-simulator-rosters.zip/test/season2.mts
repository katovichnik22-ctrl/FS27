const store = new Map<string,string>();
(globalThis as any).localStorage = { getItem:(k:string)=>store.get(k)??null, setItem:(k:string,v:string)=>store.set(k,v), removeItem:(k:string)=>store.delete(k) };
const { MAIN_DB } = await import("../src/data/db");
const { createSlot, saveSlot } = await import("../src/engine/storage");
const { advanceToEndOfSeason } = await import("../src/engine/season");
const { finishSeason, ratingsToCsv } = await import("../src/engine/ratings");
const { simulateMatch } = await import("../src/engine/match");

const mainBefore = JSON.stringify(MAIN_DB);
const slot = createSlot({ leagues: ["PL","LL"] });
const totalPlayers = Object.values(slot.teams).filter(t=>t.league && slot.selectedLeagues.includes(t.league)).reduce((a,t)=>a+t.players.length,0);
const t0 = Date.now();
advanceToEndOfSeason(slot);
const rep = finishSeason(slot);
console.log(`1) Сезон 2 лиг за ${((Date.now()-t0)/1000).toFixed(1)}с; игроков в лигах ${totalPlayers}, обновлено ${rep.all.length} →`, rep.all.length === totalPlayers ? "OK" : "FAIL");

const d = rep.all.map(c=>c.delta);
const dist: Record<string,number> = {};
for (const x of d) dist[x] = (dist[x]??0)+1;
const keys = Object.keys(dist).map(Number).sort((a,b)=>a-b);
console.log(`2) Распределение дельт: ${keys.map(k=>`${k>0?"+":""}${k}:${dist[k]}`).join(" ")}`);
console.log(`   диапазон ${Math.min(...d)}…${Math.max(...d)}, ненулевых ${d.filter(x=>x!==0).length} (${(d.filter(x=>x!==0).length/d.length*100).toFixed(0)}%) →`,
  Math.max(...d)>=3 && Math.min(...d)<=-2 && d.some(x=>x===0) ? "OK" : "FAIL");

// возрастные лимиты
// гарантированные бонусы (8.0+ рейтинг, 15+ сухих) сознательно перебивают возрастной лимит
const guaranteed = (c: any) => {
  const p = slot.teams[c.teamId].players.find((x:any)=>x.id===c.playerId)!;
  return (p.position==="GK"&&p.stats.cleanSheets>=15) || (c.apps>=5&&c.avgRating>8.0) || (p.position==="DF"&&p.stats.cleanSheets>=14);
};
const bad = rep.all.filter(c => !guaranteed(c) && ((c.age<23 && (c.delta>5||c.delta<-4)) || (c.age>=24&&c.age<=29&&(c.delta>3||c.delta<-4)) || (c.age>=30&&c.age<=33&&(c.delta>2||c.delta<-3)) || (c.age>=34&&(c.delta>1||c.delta<-3))));
console.log(`3) Возрастные лимиты соблюдены:`, bad.length?`FAIL (${bad.length})`:"OK");
const low = rep.all.filter(c=>c.apps>=5 && c.avgRating<5.5);
console.log(`   avgRating<5.5 → минус (${low.length} игроков):`, !low.length || low.every(c=>c.delta<=-1)?"OK":"FAIL");
const high = rep.all.filter(c=>c.apps>=5 && c.avgRating>8.0);
console.log(`   avgRating>8.0 → плюс (${high.length} игроков):`, !high.length || high.every(c=>c.delta>=2)?"OK":"FAIL");
const gks = rep.all.filter(c=>{const t=slot.teams[c.teamId];const p=t.players.find(x=>x.id===c.playerId)!;return p.position==="GK"&&p.stats.cleanSheets>=15;});
console.log(`   вратари 15+ сухих (${gks.length}):`, !gks.length || gks.every(c=>c.delta>=2)?"OK":"FAIL");
console.log(`   клубы с изменениями: ${new Set(rep.all.map(c=>c.teamId)).size} (все ${Object.values(slot.teams).filter(t=>t.league&&slot.selectedLeagues.includes(t.league)).length})`);
const outsiders = rep.all.filter(c=>["hull","coventry","ipswich","malaga","racing"].includes(c.teamId));
console.log(`4) Аутсайдеры тоже обновлены: ${outsiders.length} игроков, дельты ${Math.min(...outsiders.map(c=>c.delta))}…${Math.max(...outsiders.map(c=>c.delta))} →`, outsiders.length?"OK":"FAIL");
console.log(`5) CSV: ${ratingsToCsv(rep.all).split("\n").length-1} строк`);

// редактор влияет на симуляцию: сравниваем Hull с attacker=72 и с attacker=99
const tBase = JSON.parse(JSON.stringify({ hull: slot.teams["hull"], arsenal: slot.teams["arsenal"] }));
const tEdit = JSON.parse(JSON.stringify(tBase));
const ed = tEdit.hull.players.find((x:any)=>x.position==="FW");
const attackerId = ed.id;
tEdit.hull.players.find((x:any)=>x.id===attackerId).attack = 99;
tEdit.hull.players.find((x:any)=>x.id===attackerId).overall = 99;
let gb=0, ga=0, ownB=0, ownA=0;
for(let i=0;i<300;i++){
  gb += simulateMatch(tBase.hull, tBase.arsenal, {seed:100+i}).homeScore;
  ga += simulateMatch(tEdit.hull, tEdit.arsenal, {seed:100+i}).homeScore;
  ownB += (simulateMatch(tBase.hull, tBase.arsenal, {seed:100+i}).playerMatchStats[attackerId]?.goals ?? 0);
  ownA += (simulateMatch(tEdit.hull, tEdit.arsenal, {seed:100+i}).playerMatchStats[attackerId]?.goals ?? 0);
}
console.log(`6) Редактор: Hull до ${gb} / после правки attack=99 → ${ga} гола (${((ga/gb-1)*100).toFixed(0)}%); игрок: ${ownB} → ${ownA} →`,
  ga > gb * 1.1 ? "OK" : "FAIL");
console.log("7) MAIN_DB не изменилась:", JSON.stringify(MAIN_DB)===mainBefore?"OK":"FAIL");
