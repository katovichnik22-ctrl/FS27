// ─── Слоты сохранений: создание сезона (без выбора клуба) и список ──────────
import { useMemo, useRef, useState } from "react";
import {
  ArrowLeft, CalendarPlus, Download, Upload, Trash2, FolderOpen, Database, Check, AlertTriangle,
} from "lucide-react";
import { buildWorld, createSlot, listSlots, deleteSlot, exportSlot, importSlot } from "../engine/storage";
import { MAIN_DB } from "../data/db";
import { LEAGUE_CFG } from "../engine/season";
import { EuroSetup } from "./EuroSetup";
import { LeagueLinkStep, BudgetStep } from "./LeagueSetup";
import type { LeagueId, LeagueLink, Slot, Team } from "../types";
import { Panel, Btn, PanelHead } from "./bits";
import { cn } from "../utils/cn";

const fmtDate = (iso: string) =>
  new Date(iso).toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" });

function downloadSlot(slotId: string, label: string) {
  const json = exportSlot(slotId);
  if (!json) return;
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `fs26_${label}_${slotId.slice(-4)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Создание сезона ─────────────────────────────────────────────────────────

const LEAGUE_UI: { id: LeagueId; flag: string; name: string; country: string; note: string }[] = [
  { id: "PL", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", name: "Premier League", country: "Англия", note: "20 клубов · 38 туров · FA Cup + EFL Cup" },
  { id: "CHA", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", name: "EFL Championship", country: "Англия · 2-й дивизион", note: "24 клуба · 46 туров · без еврокубков" },
  { id: "LL", flag: "🇪🇸", name: "La Liga", country: "Испания", note: "20 клубов · 38 туров · Copa del Rey" },
  { id: "FL1", flag: "🇫🇷", name: "Ligue 1", country: "Франция", note: "18 клубов · 34 тура · Coupe de France" },
  { id: "BL", flag: "🇩🇪", name: "Bundesliga", country: "Германия", note: "18 клубов · 34 тура · DFB-Pokal" },
  { id: "SA", flag: "🇮🇹", name: "Serie A", country: "Италия", note: "20 клубов · 38 туров · Coppa Italia" },
  { id: "PT", flag: "🇵🇹", name: "Liga Portugal", country: "Португалия", note: "18 клубов · 34 тура · Кубок Португалии" },
  { id: "SPL", flag: "🇸🇦", name: "Saudi Pro League", country: "Сауд. Аравия", note: "18 клубов · 34 тура · Кубок короля" },
  { id: "TUR", flag: "🇹🇷", name: "Süper Lig", country: "Турция", note: "18 клубов · 34 тура · Кубок Турции" },
  { id: "BEL", flag: "🇧🇪", name: "Belgian Pro League", country: "Бельгия", note: "18 клубов · 34 тура · Кубок Бельгии" },
  { id: "NED", flag: "🇳🇱", name: "Eredivisie", country: "Нидерланды", note: "18 клубов · 34 тура · Кубок Нидерландов" },
  { id: "GRE", flag: "🇬🇷", name: "Super League Greece", country: "Греция", note: "14 клубов · 26 туров · Кубок Греции" },
  { id: "UKR", flag: "🇺🇦", name: "Ukrainian Premier League", country: "Украина", note: "16 клубов · 30 туров · Кубок Украины" },
  { id: "POL", flag: "🇵🇱", name: "Ekstraklasa", country: "Польша", note: "18 клубов · 34 тура · Кубок Польши" },
  { id: "SCO", flag: "🏴󠁧󠁢󠁳󠁣󠁴󠁿", name: "Scottish Premiership", country: "Шотландия", note: "12 клубов · 22 тура · Кубок Шотландии" },
  { id: "SUI", flag: "🇨🇭", name: "Swiss Super League", country: "Швейцария", note: "12 клубов · 22 тура · Кубок Швейцарии" },
];

export function NewSeason({ onCreated, onBack }: { onCreated: (slot: Slot) => void; onBack: () => void }) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [picked, setPicked] = useState<LeagueId[]>(["PL", "LL", "FL1", "BL", "SA", "PT"]);
  const [euroAuto, setEuroAuto] = useState(true);
  const [links, setLinks] = useState<LeagueLink[]>([]);
  const [playoff, setPlayoff] = useState(true);
  const [budgets, setBudgets] = useState<Record<string, number>>({});
  const [creating, setCreating] = useState(false);
  const [manual, setManual] = useState<{ ucl: string[]; uel: string[]; uecl: string[] } | null>(null);
  const [world, setWorld] = useState<Record<string, Team> | null>(null);

  // Бюджеты редактируются до создания слота, поэтому список команд берём
  // напрямую из неизменяемой MAIN_DB. Раньше он зависел от `world`, который
  // создавался только на следующем шаге ручной настройки еврокубков — из-за
  // этого редактор бюджетов был пустым и казался неработающим.
  const budgetTeams = useMemo(
    () => Object.values(MAIN_DB)
      .filter((t) => t.league && picked.includes(t.league))
      .sort((a, b) => picked.indexOf(a.league!) - picked.indexOf(b.league!) || b.reputation - a.reputation),
    [picked]
  );

  const toggle = (id: LeagueId) =>
    setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  const create = (opts?: { ucl: string[]; uel: string[]; uecl: string[] }) => {
    setCreating(true);
    setTimeout(() => onCreated(createSlot({
      leagues: picked,
      uclTeams: opts?.ucl,
      uelTeams: opts?.uel,
      ueclTeams: opts?.uecl,
      euroAuto,
      linkedLeagues: links,
      promotionPlayoff: playoff,
      budgets,
    })), 40);
  };

  // шаг 3: ручной редактор еврокубков (мир строится заранее)
  if (step === 3 && world) {
    return (
      <EuroSetup
        teams={world}
        leagues={picked}
        seasonLabel="Еврокубки сезона 2026/27"
        autoDefault={false}
        showPromotion={false}
        confirmLabel="Создать сезон"
        onCancel={() => setStep(2)}
        initialUcl={manual?.ucl}
        initialUel={manual?.uel}
        initialUecl={manual?.uecl}
        onConfirm={({ ucl, uel, uecl }) => { setManual({ ucl, uel, uecl }); create({ ucl, uel, uecl }); }}
      />
    );
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-6">
      <Btn onClick={onBack} icon={<ArrowLeft size={14} />}>В меню</Btn>
      <div className="mt-3">
        <Panel>
          <div className="mb-3 flex items-center gap-2">
            {([1, 2] as const).map((n) => (
              <div key={n} className="flex items-center gap-2">
                <span className={cn("flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-bold",
                  step >= n ? "bg-[#3b82f6] text-white" : "bg-[#232b36] text-[#6b7280]")}>{n}</span>
                <span className={cn("text-[12.5px]", step >= n ? "text-[#e5e7eb]" : "text-[#6b7280]")}>
                  {n === 1 ? "Выбор лиг" : "Связи, бюджеты и еврокубки"}
                </span>
                {n === 1 && <span className="mx-1 h-px w-8 bg-[#2a3140]" />}
              </div>
            ))}
          </div>

          {step === 1 && (
            <>
              <PanelHead title="Выберите лиги для симуляции" right={
                <span className="text-[11px] text-[#6b7280]">выбрано: {picked.length}</span>} />
              <div className="space-y-1.5">
                {LEAGUE_UI.map((lg) => {
                  const on = picked.includes(lg.id);
                  return (
                    <button
                      key={lg.id}
                      onClick={() => toggle(lg.id)}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-lg border px-3 py-2.5 text-left transition-colors",
                        on ? "border-[#4ade80]/60 bg-[#4ade80]/8" : "border-[#2a3140] bg-[#182029] hover:border-[#2f3847]"
                      )}
                    >
                      <span className={cn(
                        "flex h-5 w-5 shrink-0 items-center justify-center rounded border-2 transition-colors",
                        on ? "border-[#4ade80] bg-[#4ade80] text-[#06281a]" : "border-[#3f4859]"
                      )}>
                        {on && <Check size={13} strokeWidth={3} />}
                      </span>
                      <span className="text-xl leading-none">{lg.flag}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-[13.5px] font-semibold">{lg.name} <span className="text-[11px] font-normal text-[#6b7280]">({lg.country})</span></span>
                        <span className="block text-[11px] text-[#9ca3af]">{lg.note}</span>
                      </span>
                    </button>
                  );
                })}
              </div>
              {!picked.length && (
                <p className="mt-2 flex items-center gap-1.5 text-[11.5px] text-[#f87171]">
                  <AlertTriangle size={12} /> Выберите минимум одну лигу
                </p>
              )}
              <p className="mt-2 text-[11px] leading-relaxed text-[#6b7280]">
                Невыбранные лиги не симулируются: их матчей нет в календаре, таблицах и фильтрах.
                Еврокубки формируются из топ-клубов выбранных лиг и добираются клубами мирового пула до 36 команд.
              </p>
              <div className="mt-3 flex justify-end">
                <Btn variant="primary" disabled={!picked.length} onClick={() => setStep(2)}>Далее →</Btn>
              </div>
            </>
          )}

          {step === 2 && (
            <>
              <LeagueLinkStep
                picked={picked}
                links={links}
                setLinks={setLinks}
                playoff={playoff}
                setPlayoff={setPlayoff}
              />

              <div className="mt-3">
                <BudgetStep
                  teams={budgetTeams}
                  budgets={budgets}
                  setBudgets={setBudgets}
                />
              </div>

              <Panel className="mt-3">
              <PanelHead title="Настройки еврокубков" />
              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-[#2a3140] bg-[#182029] px-3 py-2.5 text-[12.5px]">
                <input type="checkbox" checked={euroAuto} onChange={(e) => setEuroAuto(e.target.checked)} className="h-4 w-4 accent-[#4ade80]" />
                Автоматический выбор участников Лиги чемпионов и Лиги Европы
              </label>
              <p className="mt-2 text-[11px] leading-relaxed text-[#9ca3af]">
                {euroAuto
                  ? "По топ-местам выбранных лиг + добор из мирового пула (Bayern, Porto, Ajax, Benfica, Celtic и др.)."
                  : "Откроется редактор 36 слотов для каждого турнира — можно заменить любой клуб вручную."}
              </p>
              </Panel>

              <div className="mt-3 flex flex-wrap justify-between gap-2">
                <Btn onClick={() => setStep(1)}>← Назад</Btn>
                {euroAuto ? (
                  <Btn variant="primary" disabled={creating} icon={<CalendarPlus size={15} />} onClick={() => create()}>
                    {creating ? "Жеребьёвка и календарь…" : "Создать сезон"}
                  </Btn>
                ) : (
                  <Btn variant="blue" onClick={() => {
                    // Для редактора еврокубков нужны только выбранные лиги и
                    // мировой европейский пул, а не все клубы проекта.
                    setWorld(buildWorld(Date.now() & 0x7fffffff, picked));
                    setStep(3);
                  }}>
                    Настроить участников →
                  </Btn>
                )}
              </div>
              <div className="mt-3 rounded-lg border border-[#2a3140] bg-[#182029] p-2.5 text-[11px] text-[#9ca3af]">
                Будет создано: {picked.map((p) => LEAGUE_UI.find((l) => l.id === p)!.name).join(", ")}{links.length ? ` · со связью ${links.map((l) => `${LEAGUE_CFG[l.upper].short}↔${LEAGUE_CFG[l.lower].short}`).join(", ")}` : ""} ·
                Лига чемпионов и Лига Европы (36 команд, Swiss) · национальные кубки выбранных стран.
              </div>
            </>
          )}
        </Panel>
      </div>
    </div>
  );
}

// ─── Список слотов ───────────────────────────────────────────────────────────

export function SavesList({ onOpen, onBack }: { onOpen: (slotId: string) => void; onBack: () => void }) {
  const [metas, setMetas] = useState(listSlots());
  const [confirmDel, setConfirmDel] = useState<string | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [showPaste, setShowPaste] = useState(false);
  const [pasteValue, setPasteValue] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const refresh = () => setMetas(listSlots());

  const doImport = (text: string) => {
    try {
      const slot = importSlot(text);
      setImportError(null);
      setShowPaste(false);
      setPasteValue("");
      refresh();
      onOpen(slot.slotId);
    } catch (e) {
      setImportError(e instanceof Error ? e.message : "Ошибка импорта");
    }
  };

  return (
    <div className="mx-auto w-full max-w-2xl px-4 py-8">
      <Btn onClick={onBack} icon={<ArrowLeft size={15} />}>В меню</Btn>
      <div className="mt-4 space-y-4">
        <Panel>
          <PanelHead title="Сохранённые сезоны" />

          {metas.length === 0 && (
            <div className="rounded-xl border border-dashed border-[#2f3847] p-8 text-center">
              <FolderOpen size={28} className="mx-auto mb-2 text-[#4b5563]" />
              <p className="text-sm text-[#9ca3af]">Слотов пока нет</p>
              <p className="mt-1 text-xs text-[#6b7280]">Создайте сезон из главного меню — он появится здесь</p>
            </div>
          )}

          <div className="space-y-2">
            {metas.map((m) => {
              const pct = m.matchesTotal ? Math.round((m.matchesPlayed / m.matchesTotal) * 100) : 0;
              return (
                <div key={m.slotId} className="rounded-xl border border-[#2a3140] bg-[#182029] px-4 py-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold text-white">
                        Сезон №{m.seasonNumber}
                        {m.finished && <span className="ml-2 rounded bg-[#4ade80]/15 px-1.5 py-0.5 text-[10px] text-[#4ade80]">завершён</span>}
                      </div>
                      <div className="text-[11px] text-[#6b7280]">
                        {(m.leagues ?? []).join(" · ") || "все лиги"} · {m.currentDate} · сыграно {m.matchesPlayed}/{m.matchesTotal} · создан {fmtDate(m.createdAt)}
                      </div>
                    </div>
                    {confirmDel === m.slotId ? (
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-[#f87171]">Удалить?</span>
                        <Btn variant="danger" onClick={() => { deleteSlot(m.slotId); setConfirmDel(null); refresh(); }}>Да</Btn>
                        <Btn onClick={() => setConfirmDel(null)}>Нет</Btn>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5">
                        <Btn variant="primary" onClick={() => onOpen(m.slotId)}>Загрузить</Btn>
                        <Btn onClick={() => downloadSlot(m.slotId, `season${m.seasonNumber}`)} icon={<Download size={14} />} title="Экспорт в JSON" />
                        <Btn onClick={() => setConfirmDel(m.slotId)} icon={<Trash2 size={14} />} title="Удалить" />
                      </div>
                    )}
                  </div>
                  <div className="mt-2 h-1 overflow-hidden rounded-full bg-[#0f1419]">
                    <div className={cn("h-full rounded-full bg-[#4ade80] transition-all")} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </Panel>

        <Panel>
          <PanelHead title="Импорт" />
          <input
            ref={fileRef}
            type="file"
            accept=".json,application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) f.text().then(doImport);
              e.target.value = "";
            }}
          />
          <div className="flex flex-wrap gap-2">
            <Btn variant="blue" icon={<Upload size={16} />} onClick={() => fileRef.current?.click()} className="px-6 py-3 text-[14px]">
              📂 Выбрать файл сезона (.json)
            </Btn>
            <Btn onClick={() => setShowPaste((v) => !v)} icon={<Database size={15} />}>
              Вставить JSON вручную
            </Btn>
          </div>
          {showPaste && (
            <div className="mt-3">
              <textarea
                value={pasteValue}
                onChange={(e) => setPasteValue(e.target.value)}
                rows={5}
                placeholder='{"slotId":"slot_...","teams":{...},...}'
                className="w-full rounded-xl border border-[#2f3847] bg-[#0f1419] p-3 font-mono text-xs text-[#e5e7eb] outline-none focus:border-[#4ade80]"
              />
              <Btn variant="primary" className="mt-2" disabled={!pasteValue.trim()} onClick={() => doImport(pasteValue)}>
                Импортировать
              </Btn>
            </div>
          )}
          {importError && <p className="mt-2 text-xs text-[#f87171]">Ошибка: {importError}</p>}
        </Panel>
      </div>
    </div>
  );
}
