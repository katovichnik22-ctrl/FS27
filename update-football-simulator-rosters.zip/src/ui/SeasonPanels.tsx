// ─── Разделы сезона: Матчи, Таблицы, Обзор, Статистика, Состав ──────────────
import { useEffect, useMemo, useState } from "react";
import { Trophy, Star, Goal, Handshake, ShieldCheck, Wand2 } from "lucide-react";
import type { Competition, Fixture, LeagueId, Slot, TableRow } from "../types";
import {
  buildTable, COMP_NAME, COMP_SHORT, fmtDay, leaderboard, LEAGUE_CFG, LEAGUE_IDS,
  stageLabel, STAGE_NAME, type CupComp,
} from "../engine/season";
import { Btn, Crest, FormBox, Panel, PanelHead, PosBadge, ratingClass, Select, Tabs } from "./bits";
import { copyText, matchdayText, tableText, fmtMin } from "../utils/copy";
import { loadSettings } from "../engine/storage";
import { Check, Copy } from "lucide-react";
import { cn } from "../utils/cn";

export const leagueIdsOf = (slot: Slot, league: LeagueId) =>
  Object.values(slot.teams).filter((t) => t.league === league).map((t) => t.id);
export const plIdsOf = (slot: Slot) => leagueIdsOf(slot, "PL");

/** Короткая дата "12.09" для табло тура */
function fmtDayShort(date: string): string {
  return `${date.slice(8, 10)}.${date.slice(5, 7)}`;
}

export const COMP_COLOR: Record<Competition, string> = {
  PL: "text-[#4ade80] bg-[#4ade80]/10",
  LL: "text-[#fbbf24] bg-[#fbbf24]/10",
  FL1: "text-[#60a5fa] bg-[#3b82f6]/10",
  BL: "text-[#f87171] bg-[#ef4444]/10",
  SA: "text-[#34d399] bg-[#34d399]/10",
  DFB: "text-[#fca5a5] bg-[#ef4444]/8",
  CIT: "text-[#86efac] bg-[#4ade80]/8",
  UCL: "text-[#a78bfa] bg-[#a78bfa]/10",
  UEL: "text-[#fb923c] bg-[#fb923c]/10",
  UECL: "text-[#34d399] bg-[#34d399]/10",
  PT: "text-[#4ade80] bg-[#008751]/15",
  SPL: "text-[#6ee7b7] bg-[#008751]/12",
  CHA: "text-[#c4b5fd] bg-[#a78bfa]/12",
  TUR: "text-[#fca5a5] bg-[#E30613]/12",
  BEL: "text-[#fdba74] bg-[#ea580c]/12",
  TUC: "text-[#fca5a5] bg-[#E30613]/10",
  NED: "text-[#fb923c] bg-[#ED1C24]/12",
  GRE: "text-[#7dd3fc] bg-[#008000]/12",
  UKR: "text-[#fde047] bg-[#0055A5]/15",
  DTC: "text-[#fb923c] bg-[#ED1C24]/10",
  GRC: "text-[#7dd3fc] bg-[#008000]/10",
  UKC: "text-[#fde047] bg-[#0055A5]/12",
  POL: "text-[#f87171] bg-[#E30613]/10",
  SCO: "text-[#66d9ef] bg-[#008000]/12",
  SUI: "text-[#fbbf24] bg-[#E30613]/12",
  PLC: "text-[#f87171] bg-[#E30613]/8",
  SCC: "text-[#66d9ef] bg-[#008000]/8",
  SWC: "text-[#fbbf24] bg-[#E30613]/8",
  BCB: "text-[#fdba74] bg-[#ea580c]/10",
  TCP: "text-[#86efac] bg-[#008751]/10",
  KSC: "text-[#fde68a] bg-[#FFD700]/10",
  FA: "text-[#f472b6] bg-[#f472b6]/10",
  EFL: "text-[#22d3ee] bg-[#22d3ee]/10",
  CDR: "text-[#fca5a5] bg-[#ef4444]/10",
  CDF: "text-[#93c5fd] bg-[#3b82f6]/10",
  FR: "text-[#9ca3af] bg-[#9ca3af]/10",
};

export function CompBadge({ comp }: { comp: Competition }) {
  return (
    <span className={cn("inline-block w-11 shrink-0 rounded px-1 py-0.5 text-center text-[9px] font-bold", COMP_COLOR[comp])}>
      {COMP_SHORT[comp]}
    </span>
  );
}

// ─── Турнирные таблицы ───────────────────────────────────────────────────────

export function LeagueTable({
  slot, league, compact, onClub,
}: { slot: Slot; league: LeagueId; compact?: boolean; onClub?: (id: string) => void }) {
  const cfg = LEAGUE_CFG[league];
  const rows: TableRow[] = useMemo(
    () => buildTable(slot.season.fixtures, leagueIdsOf(slot, league), cfg.comp),
    [slot, league, cfg.comp, slot.currentDate]
  );
  const [copiedTable, setCopiedTable] = useState(false);
  const copyTable = async () => {
    const settings = loadSettings();
    const title = league === "PL" ? settings.leagueName : cfg.name;
    const text = tableText(rows, slot, title);
    if (await copyText(text)) {
      setCopiedTable(true);
      setTimeout(() => setCopiedTable(false), 1400);
    }
  };
  const total = rows.length;
  const zone = (i: number) =>
    i < cfg.ucl ? "#4ade80"
    : i < cfg.ucl + cfg.uel ? "#3b82f6"
    : i < cfg.ucl + cfg.uel + cfg.uecl ? "#34d399"
    : i >= total - cfg.drop ? "#ef4444" : "transparent";

  return (
    <div className="overflow-x-auto">
      <table className="dense">
        <thead>
          <tr>
            <th className="w-7">#</th>
            <th>Клуб</th>
            <th className="w-7 text-center">И</th>
            <th className="w-7 text-center">В</th>
            <th className="w-7 text-center">Н</th>
            <th className="w-7 text-center">П</th>
            {!compact && <th className="m-hide w-8 text-center">ГЗ</th>}
            {!compact && <th className="m-hide w-8 text-center">ГП</th>}
            <th className="w-9 text-center">РГ</th>
            <th className="w-8 text-center">О</th>
            {!compact && <th className="m-hide w-[112px]">Форма</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => {
            const t = slot.teams[r.teamId];
            return (
              <tr key={r.teamId} className="cursor-pointer" onClick={() => onClub?.(r.teamId)}>
                <td className="relative pl-2.5 font-mono text-[11px] text-[#9ca3af]">
                  <span className="absolute left-0 top-1/2 h-[22px] w-[3px] -translate-y-1/2 rounded-r" style={{ background: zone(i) }} />
                  {i + 1}
                </td>
                <td>
                  <span className="flex items-center gap-1.5">
                    <Crest name={t.name} color={t.color} size={16} />
                    <span className="truncate">{compact ? t.shortName : t.name}</span>
                  </span>
                </td>
                <td className="text-center font-mono text-[11.5px]">{r.p}</td>
                <td className="text-center font-mono text-[11.5px]">{r.w}</td>
                <td className="text-center font-mono text-[11.5px]">{r.d}</td>
                <td className="text-center font-mono text-[11.5px]">{r.l}</td>
                {!compact && <td className="m-hide text-center font-mono text-[11.5px] text-[#9ca3af]">{r.gf}</td>}
                {!compact && <td className="m-hide text-center font-mono text-[11.5px] text-[#9ca3af]">{r.ga}</td>}
                <td className={cn("text-center font-mono text-[11.5px]", r.gd > 0 ? "text-[#4ade80]" : r.gd < 0 ? "text-[#f87171]" : "text-[#9ca3af]")}>
                  {r.gd > 0 ? "+" : ""}{r.gd}
                </td>
                <td className="text-center font-mono text-[12.5px] font-bold">{r.pts}</td>
                {!compact && (
                  <td className="m-hide">
                    <span className="flex gap-0.5">{r.form.map((f, k) => <FormBox key={k} r={f} />)}</span>
                  </td>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
      {!compact && (
        <>
          <div className="mt-2 flex flex-wrap items-center gap-3 text-[10.5px] text-[#9ca3af]">
            <span className="flex items-center gap-1"><i className="h-2.5 w-[3px] rounded bg-[#4ade80]" /> Лига чемпионов</span>
            <span className="flex items-center gap-1"><i className="h-2.5 w-[3px] rounded bg-[#3b82f6]" /> Лига Европы</span>
            <span className="flex items-center gap-1"><i className="h-2.5 w-[3px] rounded bg-[#34d399]" /> Лига конференций</span>
            <span className="flex items-center gap-1"><i className="h-2.5 w-[3px] rounded bg-[#ef4444]" /> Вылет</span>
            <Btn
              sm
              className="ml-auto"
              onClick={copyTable}
              icon={copiedTable ? <Check size={11} className="text-[#4ade80]" /> : <Copy size={11} />}
            >
              {copiedTable ? "Скопировано" : "Скопировать таблицу"}
            </Btn>
          </div>
        </>
      )}
    </div>
  );
}

// ─── Еврокубковая таблица и сетка ────────────────────────────────────────────

export function EuroView({ slot, comp, onClub }: { slot: Slot; comp: "UCL" | "UEL" | "UECL"; onClub?: (id: string) => void }) {
  const st = comp === "UCL" ? slot.season.ucl : comp === "UEL" ? slot.season.uel : slot.season.uecl;
  const [view, setView] = useState<"table" | "bracket">("table");
  const rows = useMemo(
    () => buildTable(slot.season.fixtures, st.participants, comp, "LP"),
    [slot, comp, st.participants, slot.currentDate]
  );
  const fixtures = slot.season.fixtures;

  return (
    <div>
      <Tabs
        className="mb-2"
        value={view}
        onChange={setView}
        items={[{ id: "table" as const, label: "Общий этап" }, { id: "bracket" as const, label: "Плей-офф" }]}
      />
      {view === "table" ? (
        <div className="overflow-x-auto">
          <table className="dense">
            <thead>
              <tr>
                <th className="w-7">#</th><th>Клуб</th><th className="w-8 text-center">И</th>
                <th className="w-7 text-center">В</th><th className="w-7 text-center">Н</th><th className="w-7 text-center">П</th>
                <th className="w-9 text-center">РГ</th><th className="w-8 text-center">О</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => {
                const t = slot.teams[r.teamId];
                const zone = i < 8 ? "#4ade80" : i < 24 ? "#3b82f6" : "#ef4444";
                return (
                  <tr key={r.teamId} className="cursor-pointer" onClick={() => onClub?.(r.teamId)}>
                    <td className="relative pl-2.5 font-mono text-[11px] text-[#9ca3af]">
                      <span className="absolute left-0 top-1/2 h-[22px] w-[3px] -translate-y-1/2 rounded-r" style={{ background: zone }} />
                      {i + 1}
                    </td>
                    <td>
                      <span className="flex items-center gap-1.5">
                        <Crest name={t?.name ?? "?"} color={t?.color ?? "#555"} size={16} />
                        <span className="truncate">{t?.name}</span>
                        <span className="text-[10px] text-[#6b7280]">{t?.country}</span>
                      </span>
                    </td>
                    <td className="text-center font-mono text-[11.5px]">{r.p}</td>
                    <td className="text-center font-mono text-[11.5px]">{r.w}</td>
                    <td className="text-center font-mono text-[11.5px]">{r.d}</td>
                    <td className="text-center font-mono text-[11.5px]">{r.l}</td>
                    <td className="text-center font-mono text-[11.5px] text-[#9ca3af]">{r.gd > 0 ? "+" : ""}{r.gd}</td>
                    <td className="text-center font-mono text-[12.5px] font-bold">{r.pts}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <div className="mt-2 flex flex-wrap gap-3 text-[10.5px] text-[#9ca3af]">
            <span className="flex items-center gap-1"><i className="h-2.5 w-[3px] rounded bg-[#4ade80]" /> 1–8 → 1/8 финала</span>
            <span className="flex items-center gap-1"><i className="h-2.5 w-[3px] rounded bg-[#3b82f6]" /> 9–24 → плей-офф</span>
            <span className="flex items-center gap-1"><i className="h-2.5 w-[3px] rounded bg-[#ef4444]" /> 25–36 вылет</span>
          </div>
        </div>
      ) : (
        <div className="space-y-2">
          {st.winner && (
            <div className="flex items-center justify-center gap-2 rounded-md border border-[#4ade80]/40 bg-[#4ade80]/10 py-2 text-[13px]">
              <Trophy size={14} className="text-[#4ade80]" />
              <b>{slot.teams[st.winner]?.name}</b> — победитель {COMP_NAME[comp]}
            </div>
          )}
          {["PO", "R16", "QF", "SF", "F"].map((stage) => {
            const ties = st.ties.filter((t) => t.stage === stage);
            if (!ties.length) return null;
            return (
              <div key={stage}>
                <div className="mb-1 text-[10.5px] font-bold uppercase tracking-wider text-[#9ca3af]">{STAGE_NAME[stage]}</div>
                <div className="rounded-md border border-[#2a3140] bg-[#182029]">
                  {ties.map((tie) => {
                    const legs = tie.legs.map((id) => fixtures.find((f) => f.id === id)!).filter(Boolean);
                    return (
                      <div key={tie.id} className="border-b border-[#232b36] px-2 py-1.5 last:border-0">
                        <div className="flex items-center gap-2 text-[12.5px]">
                          <span className={cn("flex min-w-0 flex-1 items-center justify-end gap-1.5", tie.winnerId === tie.aId && "font-semibold text-[#4ade80]")}>
                            <span className="truncate">{slot.teams[tie.aId]?.name}</span>
                            <Crest name={slot.teams[tie.aId]?.name ?? "?"} color={slot.teams[tie.aId]?.color ?? "#555"} size={14} />
                          </span>
                          <span className="w-12 shrink-0 text-center font-mono text-[11.5px] font-bold">
                            {tie.aggA !== undefined ? `${tie.aggA}:${tie.aggB}` : "—:—"}
                          </span>
                          <span className={cn("flex min-w-0 flex-1 items-center gap-1.5", tie.winnerId === tie.bId && "font-semibold text-[#4ade80]")}>
                            <Crest name={slot.teams[tie.bId]?.name ?? "?"} color={slot.teams[tie.bId]?.color ?? "#555"} size={14} />
                            <span className="truncate">{slot.teams[tie.bId]?.name}</span>
                          </span>
                        </div>
                        <div className="text-center text-[10px] text-[#6b7280]">
                          {legs.map((l) => (l.result ? `${l.result.h}:${l.result.a}` : "—")).join(" · ")}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
          {!st.ties.length && <p className="py-6 text-center text-[12px] text-[#6b7280]">Плей-офф начнётся после общего этапа</p>}
        </div>
      )}
    </div>
  );
}

// ─── Кубки ───────────────────────────────────────────────────────────────────

export function CupView({ slot, comp, onMatch, onEditScore }: { slot: Slot; comp: CupComp; onMatch?: (f: Fixture) => void; onEditScore?: (f: Fixture) => void }) {
  const cupMap: Record<string, typeof slot.season.fa> = {
    FA: slot.season.fa, EFL: slot.season.efl, CDR: slot.season.cdr,
    CDF: slot.season.cdf, DFB: slot.season.dfb, CIT: slot.season.cit,
    TCP: slot.season.tcp, KSC: slot.season.ksc, TUC: slot.season.tuc, BCB: slot.season.bcb,
    DTC: slot.season.dtc, GRC: slot.season.grc, UKC: slot.season.ukc,
    PLC: slot.season.plc, SCC: slot.season.scc, SWC: slot.season.swc,
  };
  const cup = cupMap[comp];
  const fixtures = slot.season.fixtures;
  if (!cup) return <p className="py-6 text-center text-[12px] text-[#6b7280]">Турнир не найден</p>;
  return (
    <div className="space-y-2">
      {cup.winner && (
        <div className="flex items-center justify-center gap-2 rounded-md border border-[#4ade80]/40 bg-[#4ade80]/10 py-2 text-[13px]">
          <Trophy size={14} className="text-[#4ade80]" />
          <b>{slot.teams[cup.winner]?.name}</b> — обладатель {COMP_NAME[comp]}
        </div>
      )}
      {[...cup.rounds].reverse().map((round) => (
        <div key={round.stage}>
          <div className="mb-1 flex items-center justify-between">
            <span className="text-[10.5px] font-bold uppercase tracking-wider text-[#9ca3af]">{STAGE_NAME[round.stage] ?? round.stage}</span>
            <span className="text-[10px] text-[#6b7280]">{round.fixtureIds.length} матч.</span>
          </div>
          <div className="rounded-md border border-[#2a3140] bg-[#182029]">
            {round.fixtureIds.map((id) => {
              const f = fixtures.find((x) => x.id === id);
              if (!f) return null;
              return <MatchRow key={id} slot={slot} f={f} onClick={onMatch} showDate onEditScore={onEditScore} />;
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Строка матча ────────────────────────────────────────────────────────────

export function MatchRow({
  slot, f, onClick, showDate, showComp, onEditScore,
}: { slot: Slot; f: Fixture; onClick?: (f: Fixture) => void; showDate?: boolean; showComp?: boolean; onEditScore?: (f: Fixture) => void }) {
  const h = slot.teams[f.homeId];
  const a = slot.teams[f.awayId];
  const r = f.result;
  const scoreCls = !r
    ? "text-[#6b7280]"
    : r.h === r.a ? "text-[#fbbf24]" : "text-[#e5e7eb]";
  return (
    <div
      onClick={() => onClick?.(f)}
      className={cn(
        "flex items-center gap-2 border-b border-[#232b36] px-2 text-[12.5px] last:border-0",
        onClick && "cursor-pointer hover:bg-[#3b82f6]/8"
      )}
      style={{ height: 30 }}
    >
      {showDate && <span className="hidden w-16 shrink-0 text-[10.5px] text-[#6b7280] sm:block">{fmtDay(f.date)}</span>}
      {showComp && <CompBadge comp={f.comp} />}
      <span className={cn("flex min-w-0 flex-1 items-center justify-end gap-1.5", r && r.h > r.a && "font-semibold")}>
        <span className="truncate">{h?.name ?? "?"}</span>
        <Crest name={h?.name ?? "?"} color={h?.color ?? "#555"} size={15} />
      </span>
      <span className={cn("w-14 shrink-0 text-center font-mono text-[12.5px] font-bold tabular-nums", scoreCls)}>
        {r ? `${r.h}:${r.a}` : "—:—"}
        {r?.pensH !== undefined && <span className="ml-0.5 text-[8.5px] text-[#fbbf24]">п{r.pensH}:{r.pensA}</span>}
        {r?.manual && <span className="ml-0.5 text-[8.5px] text-[#a78bfa]" title="счёт задан вручную">✎</span>}
      </span>
      <span className={cn("flex min-w-0 flex-1 items-center gap-1.5", r && r.a > r.h && "font-semibold")}>
        <Crest name={a?.name ?? "?"} color={a?.color ?? "#555"} size={15} />
        <span className="truncate">{a?.name ?? "?"}</span>
      </span>
      <span className="m-hide hidden w-20 shrink-0 truncate text-right text-[10px] text-[#6b7280] lg:block">{stageLabel(f)}</span>
      {onEditScore && (
        <button
          onClick={(e) => { e.stopPropagation(); onEditScore(f); }}
          title="Задать счёт вручную"
          className="shrink-0 rounded p-0.5 text-[#4b5563] transition-colors hover:bg-[#232b36] hover:text-[#a78bfa]"
        >
          <Wand2 size={12} />
        </button>
      )}
    </div>
  );
}

// ─── Раздел «Матчи» ──────────────────────────────────────────────────────────

/** Турниры, реально присутствующие в слоте (по выбранным лигам) */
export function slotComps(slot: Slot): Competition[] {
  const has = new Set(slot.season.fixtures.map((f) => f.comp));
  const order: Competition[] = ["PL", "CHA", "LL", "FL1", "BL", "SA", "PT", "SPL", "TUR", "BEL", "NED", "GRE", "UKR", "POL", "SCO", "SUI", "UCL", "UEL", "UECL", "FA", "EFL", "CDR", "CDF", "DFB", "CIT", "TCP", "KSC", "FR"];
  return order.filter((c) => has.has(c));
}

export const slotLeagues = (slot: Slot): LeagueId[] =>
  (slot.selectedLeagues?.length ? slot.selectedLeagues : LEAGUE_IDS).filter((l) => slot.teams && Object.values(slot.teams).some((t) => t.league === l));

/** Кубки, доступные в слоте */
export function slotCups(slot: Slot): CupComp[] {
  const all = ["FA", "EFL", "CDR", "CDF", "DFB", "CIT", "TCP", "KSC", "TUC", "BCB", "DTC", "GRC", "UKC", "PLC", "SCC", "SWC"] as const;
  return all.filter((c) => slot.season.fixtures.some((f) => f.comp === c));
}

// ─── Табло одного тура (стиль BBC Sport) ─────────────────────────────────────

function MatchdayView({ slot, onMatch }: { slot: Slot; onMatch: (f: Fixture) => void }) {
  const [comp, setComp] = useState<Competition>("PL");
  const [matchday, setMatchday] = useState(1);
  const [copied, setCopied] = useState(false);

  const leagueComps = slotComps(slot).filter((c) =>
    ["PL", "LL", "FL1", "BL", "SA", "PT", "SPL", "TUR", "BEL", "NED", "GRE", "UKR", "POL", "SCO", "SUI", "CHA"].includes(c)
  );

  const maxMds = useMemo(() => {
    const all = slot.season.fixtures.filter((f) => f.comp === comp);
    return all.length ? Math.max(...all.map((f) => f.matchday)) : 1;
  }, [slot, comp]);

  useEffect(() => { if (matchday > maxMds) setMatchday(1); }, [comp, maxMds]);

  const fixtures = useMemo(
    () => slot.season.fixtures.filter((f) => f.comp === comp && f.matchday === matchday)
      .sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0)),
    [slot, comp, matchday, slot.currentDate]
  );

  const copyAll = async () => {
    const settings = loadSettings();
    const text = matchdayText(fixtures, slot, settings);
    if (await copyText(text)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    }
  };

  return (
    <div>
      <div className="mb-2 flex flex-wrap items-center gap-1.5">
        <Select value={comp} onChange={(e) => setComp(e.target.value as Competition)}>
          {leagueComps.map((c) => (
            <option key={c} value={c}>{COMP_NAME[c]}</option>
          ))}
        </Select>
        <Select value={matchday} onChange={(e) => setMatchday(Number(e.target.value))}>
          {Array.from({ length: maxMds }, (_, i) => i + 1).map((md) => (
            <option key={md} value={md}>Тур {md}</option>
          ))}
        </Select>
        <Btn
          className="ml-auto"
          onClick={copyAll}
          disabled={!fixtures.length}
          icon={copied ? <Check size={13} className="text-[#4ade80]" /> : <Copy size={13} />}
        >
          {copied ? "Скопировано" : "Скопировать тур"}
        </Btn>
      </div>

      <div className="rounded-md border border-[#2a3140] bg-[#182029]">
        {!fixtures.length && (
          <p className="px-3 py-8 text-center text-[12px] text-[#6b7280]">В этом туре матчей нет</p>
        )}
        {fixtures.map((f) => (
          <button
            key={f.id}
            onClick={() => onMatch(f)}
            className="w-full border-b border-[#232b36] px-2.5 py-2 text-left transition-colors last:border-0 hover:bg-[#2a3140]"
          >
            <div className="flex items-center gap-2 text-[13px]">
              <span className="w-11 shrink-0 text-[10.5px] text-[#6b7280]">
                {f.result ? `${f.result.h}:${f.result.a}` : "—:—"}
              </span>
              <span className="flex min-w-0 flex-1 items-center justify-end gap-1.5 truncate">
                <Crest name={slot.teams[f.homeId]?.name ?? "?"} color={slot.teams[f.homeId]?.color ?? "#555"} size={13} />
                <span className={cn("truncate", f.result && f.result.h > f.result.a && "font-semibold")}>
                  {slot.teams[f.homeId]?.shortName}
                </span>
              </span>
              <span className="w-14 shrink-0 text-center text-[9px] text-[#6b7280]">{fmtDayShort(f.date)}</span>
              <span className="flex min-w-0 flex-1 items-center gap-1.5 truncate">
                <Crest name={slot.teams[f.awayId]?.name ?? "?"} color={slot.teams[f.awayId]?.color ?? "#555"} size={13} />
                <span className={cn("truncate", f.result && f.result.a > f.result.h && "font-semibold")}>
                  {slot.teams[f.awayId]?.shortName}
                </span>
              </span>
            </div>
            {!!f.result?.scorers?.length && (
              <div className="mt-1 truncate pl-[52px] text-[10.5px] leading-relaxed text-[#9ca3af]">
                {f.result.scorers.map((s, i) => {
                  const pl = slot.teams[s.t]?.players.find((p) => p.id === s.p);
                  if (!pl) return null;
                  return (
                    <span key={i}>
                      {i > 0 && " · "}
                      {pl.name.split(" ").pop()} {fmtMin(s.m)}
                    </span>
                  );
                })}
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
}

export function MatchesView({ slot, onMatch, onClub, onEditScore }: { slot: Slot; onMatch: (f: Fixture) => void; onClub?: (id: string) => void; onEditScore?: (f: Fixture) => void }) {
  const [comp, setComp] = useState<Competition | "ALL">("ALL");
  const [club, setClub] = useState("ALL");
  const [when, setWhen] = useState<"past" | "next" | "all">("all");
  const [date, setDate] = useState("");
  const [tab, setTab] = useState<"past" | "next" | "all" | "md">("all");

  const list = useMemo(() => {
    let l = slot.season.fixtures.filter((f) => (comp === "ALL" ? true : f.comp === comp));
    if (club !== "ALL") l = l.filter((f) => f.homeId === club || f.awayId === club);
    if (when === "past") l = l.filter((f) => f.played);
    if (when === "next") l = l.filter((f) => !f.played);
    if (date) l = l.filter((f) => f.date === date);
    l = [...l].sort((x, y) => (x.date < y.date ? -1 : x.date > y.date ? 1 : 0));
    if (when === "past") l.reverse();
    if (when === "all" && !date && club === "ALL") {
      const idx = l.findIndex((f) => f.date >= slot.currentDate);
      const from = Math.max(0, (idx === -1 ? l.length : idx) - 20);
      l = l.slice(from, from + 90);
    }
    return l.slice(0, 260);
  }, [slot, comp, club, when, date, slot.currentDate]);

  const byDate = useMemo(() => {
    const m = new Map<string, Fixture[]>();
    for (const f of list) {
      if (!m.has(f.date)) m.set(f.date, []);
      m.get(f.date)!.push(f);
    }
    return [...m.entries()];
  }, [list]);

  const clubs = useMemo(
    () => Object.values(slot.teams).filter((t) => t.league).sort((a, b) => a.name.localeCompare(b.name)),
    [slot]
  );

  return (
    <div>
      <div className="mb-2 flex flex-wrap items-center gap-1.5">
        <Tabs
          value={tab}
          onChange={(v) => setTab(v as "past" | "next" | "all" | "md")}
          items={[
            { id: "md" as const, label: "По турам" },
            { id: "ALL" as const, label: "Все" },
          ]}
        />
      </div>
      {tab === "md" ? (
        <MatchdayView slot={slot} onMatch={onMatch} />
      ) : (
      <>
      <div className="mb-2 flex flex-wrap items-center gap-1.5">
        <Tabs
          value={comp}
          onChange={(v) => setComp(v as Competition | "ALL")}
          items={[{ id: "ALL" as const, label: "Все" }, ...slotComps(slot).map((c) => ({ id: c, label: COMP_SHORT[c] }))]}
        />
        <Select value={club} onChange={(e) => setClub(e.target.value)} className="max-w-[190px]">
          <option value="ALL">Все клубы</option>
          {clubs.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
        </Select>
        <Select value={when} onChange={(e) => setWhen(e.target.value as "past" | "next" | "all")}>
          <option value="all">Все</option>
          <option value="past">Прошедшие</option>
          <option value="next">Предстоящие</option>
        </Select>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="rounded-md border border-[#2f3847] bg-[#0f1419] px-2 py-1.5 text-[12px] outline-none focus:border-[#3b82f6]"
        />
        {date && <Btn sm onClick={() => setDate("")}>Сброс даты</Btn>}
        <span className="ml-auto text-[11px] text-[#6b7280]">{list.length} матч(ей)</span>
      </div>

      <div className="max-h-[calc(100vh-215px)] space-y-2 overflow-y-auto pr-1">
        {!byDate.length && <p className="py-8 text-center text-[12px] text-[#6b7280]">Матчей не найдено</p>}
        {byDate.map(([d, fxs]) => (
          <div key={d}>
            <div className={cn(
              "mb-0.5 flex items-center gap-2 px-1 text-[10.5px] font-bold uppercase tracking-wider",
              d === slot.currentDate ? "text-[#4ade80]" : "text-[#6b7280]"
            )}>
              {fmtDay(d)}
              {d === slot.currentDate && <span className="rounded bg-[#4ade80]/15 px-1">сегодня</span>}
              <span className="ml-auto font-normal normal-case text-[#4b5563]">{fxs.length}</span>
            </div>
            <div className="rounded-md border border-[#2a3140] bg-[#182029]">
              {fxs.map((f) => (
                <MatchRow key={f.id} slot={slot} f={f} onClick={onMatch} showComp onEditScore={onEditScore} />
              ))}
            </div>
          </div>
        ))}
      </div>
      {onClub && <span className="hidden" />}
      </>
      )}
    </div>
  );
}

// ─── Обзор ───────────────────────────────────────────────────────────────────

export function OverviewView({
  slot, onMatch, onClub, onEditScore,
}: { slot: Slot; onMatch: (f: Fixture) => void; onClub: (id: string) => void; onEditScore?: (f: Fixture) => void }) {
  const recent = useMemo(() => slot.season.fixtures.filter((f) => f.played).slice(-5).reverse(), [slot, slot.currentDate]);
  const upcoming = useMemo(() => slot.season.fixtures.filter((f) => !f.played).slice(0, 5), [slot, slot.currentDate]);
  const scorers = leaderboard(slot, "goals", "ALL", 5);
  const assists = leaderboard(slot, "assists", "ALL", 5);

  return (
    <div className="space-y-2">
      <div className="m-stack grid gap-2 lg:grid-cols-3">
        <Panel>
          <PanelHead title="Последние результаты" icon={<Goal size={12} />} />
          {!recent.length && <p className="py-4 text-center text-[12px] text-[#6b7280]">Сезон ещё не начался</p>}
          {recent.map((f) => <MatchRow key={f.id} slot={slot} f={f} onClick={onMatch} showComp onEditScore={onEditScore} />)}
        </Panel>
        <Panel>
          <PanelHead title="Ближайшие матчи" icon={<Star size={12} />} />
          {!upcoming.length && <p className="py-4 text-center text-[12px] text-[#6b7280]">Все матчи сыграны</p>}
          {upcoming.map((f) => (
            <div key={f.id} className="flex items-center gap-2 border-b border-[#232b36] py-1 text-[12px] last:border-0">
              <span className="w-14 shrink-0 text-[10.5px] text-[#6b7280]">{fmtDay(f.date)}</span>
              <CompBadge comp={f.comp} />
              <span className="min-w-0 flex-1 truncate">
                {slot.teams[f.homeId]?.shortName} — {slot.teams[f.awayId]?.shortName}
              </span>
            </div>
          ))}
        </Panel>
        <Panel>
          <PanelHead title="Бомбардиры / ассистенты" icon={<Handshake size={12} />} />
          <div className="grid grid-cols-2 gap-2">
            <div>
              <div className="mb-0.5 text-[9.5px] font-bold uppercase tracking-wider text-[#4ade80]">Голы</div>
              {scorers.map((r, i) => (
                <div key={r.playerId} className="flex items-center gap-1 py-0.5 text-[11.5px]">
                  <span className="w-3 text-[10px] text-[#6b7280]">{i + 1}</span>
                  <Crest name={slot.teams[r.teamId].name} color={slot.teams[r.teamId].color} size={12} />
                  <span className="min-w-0 flex-1 truncate">{r.name}</span>
                  <b className="font-mono text-[#4ade80]">{r.value}</b>
                </div>
              ))}
              {!scorers.length && <p className="text-[11px] text-[#6b7280]">—</p>}
            </div>
            <div>
              <div className="mb-0.5 text-[9.5px] font-bold uppercase tracking-wider text-[#3b82f6]">Пасы</div>
              {assists.map((r, i) => (
                <div key={r.playerId} className="flex items-center gap-1 py-0.5 text-[11.5px]">
                  <span className="w-3 text-[10px] text-[#6b7280]">{i + 1}</span>
                  <Crest name={slot.teams[r.teamId].name} color={slot.teams[r.teamId].color} size={12} />
                  <span className="min-w-0 flex-1 truncate">{r.name}</span>
                  <b className="font-mono text-[#60a5fa]">{r.value}</b>
                </div>
              ))}
              {!assists.length && <p className="text-[11px] text-[#6b7280]">—</p>}
            </div>
          </div>
        </Panel>
      </div>

      <div className={cn("m-stack grid gap-2", slotLeagues(slot).length > 2 ? "lg:grid-cols-3" : "lg:grid-cols-2")}>
        {slotLeagues(slot).map((lid) => (
          <Panel key={lid}>
            <PanelHead title={LEAGUE_CFG[lid].name} icon={<Trophy size={12} />} />
            <MiniTable slot={slot} league={lid} onClub={onClub} />
          </Panel>
        ))}
      </div>
    </div>
  );
}

function MiniTable({ slot, league, onClub }: { slot: Slot; league: LeagueId; onClub: (id: string) => void }) {
  const rows = useMemo(
    () => buildTable(slot.season.fixtures, leagueIdsOf(slot, league), LEAGUE_CFG[league].comp).slice(0, 6),
    [slot, league, slot.currentDate]
  );
  return (
    <table className="dense">
      <tbody>
        {rows.map((r, i) => (
          <tr key={r.teamId} className="cursor-pointer" onClick={() => onClub(r.teamId)}>
            <td className="w-5 font-mono text-[10.5px] text-[#6b7280]">{i + 1}</td>
            <td>
              <span className="flex items-center gap-1.5">
                <Crest name={slot.teams[r.teamId].name} color={slot.teams[r.teamId].color} size={14} />
                <span className="truncate text-[12px]">{slot.teams[r.teamId].name}</span>
              </span>
            </td>
            <td className="w-7 text-center font-mono text-[11px] text-[#9ca3af]">{r.p}</td>
            <td className="w-7 text-center font-mono text-[12px] font-bold">{r.pts}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// ─── Статистика ──────────────────────────────────────────────────────────────

export function StatsView({ slot, onClub }: { slot: Slot; onClub?: (id: string) => void }) {
  const [league, setLeague] = useState<LeagueId | "ALL">("ALL");
  const boards = [
    { key: "goals" as const, title: "Бомбардиры", color: "text-[#4ade80]" },
    { key: "assists" as const, title: "Ассистенты", color: "text-[#60a5fa]" },
    { key: "cleanSheets" as const, title: "Сухие матчи (вратари)", color: "text-[#fbbf24]" },
    { key: "rating" as const, title: "Средний рейтинг", color: "text-[#f472b6]" },
  ];
  return (
    <div>
      <Tabs
        className="mb-2 w-fit"
        value={league}
        onChange={setLeague}
        items={[{ id: "ALL" as const, label: "Все лиги" }, ...slotLeagues(slot).map((l) => ({ id: l, label: LEAGUE_CFG[l].short }))]}
      />
      <div className="m-stack grid gap-2 md:grid-cols-2">
        {boards.map((b) => {
          const rows = leaderboard(slot, b.key, league, 12);
          return (
            <Panel key={b.key}>
              <PanelHead title={<span className={b.color}>{b.title}</span>} />
              {!rows.length && <p className="py-3 text-center text-[11.5px] text-[#6b7280]">Нет данных</p>}
              <table className="dense">
                <tbody>
                  {rows.map((r, i) => (
                    <tr key={r.playerId} className="cursor-pointer" onClick={() => onClub?.(r.teamId)}>
                      <td className="w-5 font-mono text-[10.5px] text-[#6b7280]">{i + 1}</td>
                      <td className="w-5"><Crest name={slot.teams[r.teamId].name} color={slot.teams[r.teamId].color} size={14} /></td>
                      <td className="truncate">{r.name}</td>
                      <td className="w-12 truncate text-[10.5px] text-[#6b7280]">{slot.teams[r.teamId].shortName}</td>
                      <td className="w-9 text-center font-mono text-[11px] text-[#9ca3af]">{r.apps}</td>
                      <td className="w-11 text-right">
                        <span className={cn("rounded px-1.5 py-0.5 font-mono text-[11.5px] font-bold",
                          b.key === "rating" ? ratingClass(r.value) : "bg-[#232b36]")}>
                          {b.key === "rating" ? r.value.toFixed(2) : r.value}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}

// ─── Состав клуба (таблица) ──────────────────────────────────────────────────

export function SquadTable({ slot, teamId }: { slot: Slot; teamId: string }) {
  const team = slot.teams[teamId];
  const players = [...team.players].sort((a, b) => b.stats.apps - a.stats.apps || b.overall - a.overall);
  return (
    <div className="overflow-x-auto">
      <table className="dense">
        <thead>
          <tr>
            <th className="w-7">Поз</th><th>Игрок</th><th className="w-8 text-center">Воз</th>
            <th className="w-9 text-center">OVR</th><th className="w-8 text-center">И</th>
            <th className="w-8 text-center">Г</th><th className="w-8 text-center">П</th>
            <th className="w-8 text-center">СМ</th><th className="w-11 text-center">Рейт</th>
            <th className="m-hide w-12 text-center">Форма</th><th className="w-14 text-center">Свеж.</th>
          </tr>
        </thead>
        <tbody>
          {players.map((p) => (
            <tr key={p.id}>
              <td><PosBadge pos={p.position} /></td>
              <td className="truncate">
                {p.name} <span className="text-[10px] text-[#6b7280]">{p.nationality}</span>
              </td>
              <td className="m-hide text-center font-mono text-[11px] text-[#9ca3af]">{p.age}</td>
              <td className="text-center font-mono text-[12.5px] font-bold text-[#4ade80]">{p.overall}</td>
              <td className="text-center font-mono text-[11px]">{p.stats.apps || "–"}</td>
              <td className="text-center font-mono text-[11px]">{p.stats.goals || "–"}</td>
              <td className="text-center font-mono text-[11px]">{p.stats.assists || "–"}</td>
              <td className="text-center font-mono text-[11px]">{p.stats.cleanSheets || "–"}</td>
              <td className="text-center">
                {p.stats.apps
                  ? <span className={cn("rounded px-1 py-0.5 font-mono text-[11px] font-bold", ratingClass(p.stats.avgRating))}>{p.stats.avgRating.toFixed(2)}</span>
                  : <span className="text-[11px] text-[#6b7280]">–</span>}
              </td>
              <td className="m-hide text-center font-mono text-[11px]">
                <span className={p.form >= 1.04 ? "text-[#4ade80]" : p.form <= 0.96 ? "text-[#f87171]" : "text-[#9ca3af]"}>
                  {(p.form * 100).toFixed(0)}%
                </span>
              </td>
              <td>
                <div className="mx-auto h-1.5 w-11 overflow-hidden rounded-full bg-[#0f1419]">
                  <div
                    className={cn("h-full", p.fitness > 75 ? "bg-[#4ade80]" : p.fitness > 50 ? "bg-[#fbbf24]" : "bg-[#ef4444]")}
                    style={{ width: `${p.fitness}%` }}
                  />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export { ShieldCheck };
