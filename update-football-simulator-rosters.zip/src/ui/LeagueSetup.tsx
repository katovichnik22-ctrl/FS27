// ─── Шаг 1.5 визарда: связанные лиги и бюджеты клубов ───────────────────────
import { useMemo, useState } from "react";
import { Link2, Trophy, Wallet, Check, RotateCcw, Search, TrendingUp } from "lucide-react";
import type { LeagueId, LeagueLink, Team } from "../types";
import { LEAGUE_CFG, LEAGUE_IDS } from "../engine/season";
import { Btn, Crest, Input, Panel, PanelHead, Tabs } from "./bits";
import { cn } from "../utils/cn";

/** Пары лиг одной страны, которые можно связать по повышению */
export const LINKABLE: { upper: LeagueId; lower: LeagueId; label: string }[] = [
  { upper: "PL", lower: "CHA", label: "АПЛ ↔ Чемпионшип" },
];

export function LeagueLinkStep({
  picked, links, setLinks, playoff, setPlayoff,
}: {
  picked: LeagueId[];
  links: LeagueLink[];
  setLinks: (l: LeagueLink[]) => void;
  playoff: boolean;
  setPlayoff: (v: boolean) => void;
}) {
  const available = LINKABLE.filter((l) => picked.includes(l.upper) && picked.includes(l.lower));
  const isOn = (u: LeagueId) => links.some((l) => l.upper === u);

  if (!available.length) return null;

  const toggle = (a: LeagueId, b: LeagueId) => {
    const exists = links.some((l) => l.upper === a && l.lower === b);
    setLinks(exists ? links.filter((l) => !(l.upper === a && l.lower === b)) : [...links, { upper: a, lower: b }]);
  };

  return (
    <Panel className="border-[#a78bfa]/30 bg-[#a78bfa]/5">
      <PanelHead
        title={<span className="flex items-center gap-1.5 text-[#a78bfa]"><Link2 size={12} /> Связанные лиги</span>}
      />
      <p className="mb-2 text-[11.5px] leading-relaxed text-[#9ca3af]">
        Вы выбрали лиги одной страны. Свяжите их — и появится настоящее повышение и вылет:
        из верхней лиги вылетают 3 клуба, 2 лучших нижней поднимаются напрямую,
        а места 3–6 разыгрывают третью путёвку в плей-офф. Без связи составы лиг
        не меняются между сезонами.
      </p>

      {available.map((l) => {
        const on = isOn(l.upper);
        return (
          <div key={l.upper} className={cn(
            "rounded-md border p-2 transition-colors",
            on ? "border-[#a78bfa]/60 bg-[#a78bfa]/10" : "border-[#2a3140] bg-[#182029]"
          )}>
            <div className="flex items-center gap-2">
              <button
                onClick={() => toggle(l.upper, l.lower)}
                className={cn(
                  "flex items-center gap-2 rounded px-2 py-1.5 text-[12.5px] transition-colors",
                  on ? "font-semibold text-[#a78bfa]" : "text-[#9ca3af] hover:text-[#e5e7eb]"
                )}
              >
                <span className={cn(
                  "flex h-4 w-4 shrink-0 items-center justify-center rounded border-2",
                  on ? "border-[#a78bfa] bg-[#a78bfa] text-[#0f1419]" : "border-[#3f4859]"
                )}>
                  {on && <Check size={11} strokeWidth={3} />}
                </span>
                {l.label}
              </button>
              {on && (
                <span className="ml-auto flex items-center gap-1 text-[10.5px] text-[#4ade80]">
                  <TrendingUp size={11} /> повышение активно
                </span>
              )}
            </div>

            {on && (
              <label className="mt-1.5 flex cursor-pointer items-center gap-2 pl-8 text-[11.5px] text-[#c9c9c9]">
                <input
                  type="checkbox"
                  checked={playoff}
                  onChange={(e) => setPlayoff(e.target.checked)}
                  className="h-3.5 w-3.5 accent-[#fbbf24]"
                />
                <span className="flex items-center gap-1">
                  <Trophy size={11} className="text-[#fbbf24]" />
                  Плей-офф повышения (3–6 места разыгрывают третью путёвку)
                </span>
              </label>
            )}
          </div>
        );
      })}
    </Panel>
  );
}

// ─── Редактор бюджетов ───────────────────────────────────────────────────────

export function BudgetStep({
  teams, budgets, setBudgets,
}: {
  teams: Team[];
  budgets: Record<string, number>;
  setBudgets: (b: Record<string, number>) => void;
}) {
  const [tab, setTab] = useState<LeagueId | "ALL">("ALL");
  const [q, setQ] = useState("");
  const leagues = useMemo(() => [...new Set(teams.map((t) => t.league!))].filter((l) => LEAGUE_IDS.includes(l)), [teams]);
  const edited = Object.keys(budgets).length;

  const list = useMemo(() => teams
    .filter((t) => (tab === "ALL" ? true : t.league === tab))
    .filter((t) => t.name.toLowerCase().includes(q.trim().toLowerCase()))
    .sort((a, b) => (budgets[b.id] ?? b.budget) - (budgets[a.id] ?? a.budget)),
  [teams, tab, q, budgets]);

  const setValue = (id: string, v: number) => {
    const next = { ...budgets };
    if (!v && v !== 0) delete next[id];
    else next[id] = v;
    setBudgets(next);
  };

  const bumpAll = (delta: number) => {
    const next: Record<string, number> = {};
    for (const t of teams) next[t.id] = Math.max(0, (budgets[t.id] ?? t.budget) + delta);
    setBudgets(next);
  };

  return (
    <Panel>
      <PanelHead
        title={<span className="flex items-center gap-1.5"><Wallet size={12} /> Бюджеты клубов · {teams.length}</span>}
        right={
          <>
            <Btn sm onClick={() => bumpAll(10)} title="Всем +10">+10</Btn>
            <Btn sm onClick={() => bumpAll(-10)} title="Всем −10">−10</Btn>
            <Btn sm icon={<RotateCcw size={11} />} onClick={() => setBudgets({})}
              disabled={!edited}>Сбросить</Btn>
          </>
        }
      />
      <p className="mb-2 text-[11.5px] leading-relaxed text-[#9ca3af]">
        Нажмите на число в правой колонке и введите новый бюджет в млн £. Можно
        оставить всё как есть — исходные бюджеты сохранятся. От суммы зависит
        покупательная способность клубов в трансферах.
        {edited > 0 && <span className="ml-1 font-semibold text-[#fbbf24]">Изменено: {edited}</span>}
      </p>

      <div className="mb-1.5 flex flex-wrap items-center gap-1.5">
        <Tabs value={tab} onChange={setTab} items={[
          { id: "ALL" as const, label: "Все лиги" },
          ...leagues.map((l) => ({ id: l, label: LEAGUE_CFG[l].short })),
        ]} />
        <div className="ml-auto flex items-center gap-1.5 rounded-md border border-[#2f3847] bg-[#0f1419] px-2 py-1">
          <Search size={12} className="text-[#6b7280]" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск клуба…"
            className="w-28 bg-transparent text-[12px] outline-none placeholder:text-[#4b5563]" />
        </div>
      </div>

      <div className="max-h-64 overflow-y-auto rounded-md border border-[#2a3140] bg-[#182029]">
        {list.map((t) => {
          const cur = budgets[t.id] ?? t.budget;
          const changed = budgets[t.id] !== undefined && budgets[t.id] !== t.budget;
          return (
            <div key={t.id} className="flex items-center gap-2 border-b border-[#232b36] px-2 py-1.5 text-[12.5px] last:border-0">
              <Crest name={t.name} color={t.color} size={14} />
              <span className="min-w-0 flex-1 truncate">{t.name}</span>
              <span className="m-hide hidden w-14 text-[9.5px] text-[#4b5563] lg:block">{LEAGUE_CFG[t.league!].short}</span>
              <span className="w-14 shrink-0 text-right font-mono text-[10.5px] text-[#4b5563]">£{t.budget}M</span>
              <Input
                type="number" min={0} value={cur}
                onChange={(e) => setValue(t.id, Math.max(0, Number(e.target.value) || 0))}
                aria-label={`Бюджет ${t.name}, миллионов фунтов`}
                className={cn("w-20 shrink-0 text-center font-mono", changed && "border-[#fbbf24]/60 text-[#fbbf24]")}
              />
              {changed ? (
                <Check size={12} className="shrink-0 text-[#fbbf24]" />
              ) : (
                <span className="w-3 shrink-0" />
              )}
            </div>
          );
        })}
        {!list.length && <p className="py-6 text-center text-[12px] text-[#6b7280]">Не найдено</p>}
      </div>
    </Panel>
  );
}
