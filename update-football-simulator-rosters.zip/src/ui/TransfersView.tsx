// ─── Вкладка «Трансферы»: поиск игрока по имени → выбор нового клуба ─────────
import { useMemo, useState } from "react";
import {
  ArrowLeftRight, AlertTriangle, Lock, History, UserPlus, Wallet, Search, X, Wand2,
} from "lucide-react";
import type { Player, Slot } from "../types";
import {
  executeTransfer, isWindowOpen, marketValue, validateTransfer, windowLabel, type TransferPlan,
} from "../engine/transfers";
import { fmtDay, LEAGUE_CFG } from "../engine/season";
import { Btn, Crest, Input, Panel, PanelHead, PosBadge, Select, Tabs, ratingClass } from "./bits";
import { cn } from "../utils/cn";

const FREE = "__free__";

interface Found {
  player: Player;
  teamId: string | null;      // null = свободный агент
  teamName: string;
  teamShort: string;
  teamColor: string;
  league: string;
}

export function TransfersView({ slot, onChanged }: { slot: Slot; onChanged: () => void }) {
  const [tab, setTab] = useState<"deal" | "history">("deal");
  const [query, setQuery] = useState("");
  const [posFilter, setPosFilter] = useState<"ALL" | "GK" | "DF" | "MF" | "FW">("ALL");
  const [picked, setPicked] = useState<Found | null>(null);
  const [toId, setToId] = useState("");
  const [fee, setFee] = useState(0);
  const [flash, setFlash] = useState<string | null>(null);

  const clubs = useMemo(
    () => Object.values(slot.teams)
      .filter((t) => t.league)
      .sort((a, b) => (a.league! < b.league! ? -1 : a.league! > b.league! ? 1 : b.reputation - a.reputation)),
    [slot]
  );

  // ── Поиск игрока по имени/фамилии среди всех клубов и свободных агентов ──
  const results = useMemo<Found[]>(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return [];
    const out: Found[] = [];
    const match = (name: string) => {
      const n = name.toLowerCase();
      // совпадение по началу имени, фамилии или любой части
      return n.includes(q) || n.split(/[\s-]/).some((part) => part.startsWith(q));
    };
    for (const t of Object.values(slot.teams)) {
      if (!t.league) continue;
      for (const p of t.players) {
        if (!match(p.name)) continue;
        if (posFilter !== "ALL" && p.position !== posFilter) continue;
        out.push({
          player: p, teamId: t.id, teamName: t.name, teamShort: t.shortName,
          teamColor: t.color, league: LEAGUE_CFG[t.league!].short,
        });
      }
    }
    for (const p of slot.freeAgents) {
      if (!match(p.name)) continue;
      if (posFilter !== "ALL" && p.position !== posFilter) continue;
      out.push({
        player: p, teamId: null, teamName: "Свободный агент", teamShort: "СА",
        teamColor: "#4b5563", league: "—",
      });
    }
    // сортируем: точное начало имени выше, затем по классу
    return out
      .sort((a, b) => {
        const aStart = a.player.name.toLowerCase().startsWith(q) ? 0 : 1;
        const bStart = b.player.name.toLowerCase().startsWith(q) ? 0 : 1;
        return aStart - bStart || b.player.overall - a.player.overall;
      })
      .slice(0, 40);
  }, [query, posFilter, slot]);

  const say = (m: string) => { setFlash(m); setTimeout(() => setFlash(null), 2600); };

  const plan: TransferPlan | null = picked && toId
    ? { fromId: picked.teamId, toId, playersOut: [picked.player.id], playersBack: [], fee }
    : null;
  const check = plan ? validateTransfer(slot, plan) : null;
  const windowOpen = isWindowOpen(slot.currentDate);
  const target = toId ? slot.teams[toId] : null;

  const choose = (f: Found) => {
    setPicked(f);
    setToId("");
    setFee(Math.round(marketValue(f.player) * 10) / 10);
  };

  const doTransfer = () => {
    if (!plan) return;
    try {
      const rec = executeTransfer(slot, plan);
      const name = rec.playerNames.join(", ");
      const to = slot.teams[plan.toId]?.name;
      setPicked(null);
      setToId("");
      setFee(0);
      setQuery("");
      onChanged();
      say(`${name} → ${to}`);
    } catch (e) {
      say(e instanceof Error ? e.message : "Ошибка");
    }
  };

  return (
    <div>
      <div className="mb-2 flex flex-wrap items-center gap-1.5">
        <Tabs value={tab} onChange={setTab} items={[
          { id: "deal" as const, label: "Трансфер" },
          { id: "history" as const, label: "История", count: slot.transfers.length },
        ]} />
        <span className={cn(
          "ml-auto flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-medium",
          windowOpen ? "bg-[#4ade80]/15 text-[#4ade80]" : "bg-[#fbbf24]/15 text-[#fbbf24]"
        )}>
          {windowOpen ? <UserPlus size={12} /> : <Lock size={12} />}
          {windowLabel(slot.currentDate)}
        </span>
      </div>

      {tab === "history" ? (
        <div className="max-h-[calc(100vh-215px)] overflow-y-auto">
          {!slot.transfers.length && <p className="py-8 text-center text-[12px] text-[#6b7280]">Сделок пока нет</p>}
          {slot.transfers.map((t) => (
            <div key={t.id} className="flex flex-wrap items-center gap-2 border-b border-[#232b36] py-2 text-[12.5px]">
              <span className="w-20 shrink-0 text-[11px] text-[#6b7280]">{fmtDay(t.date)}</span>
              <span className={cn(
                "rounded px-1.5 py-0.5 text-[9px] font-bold",
                t.kind === "swap" ? "bg-[#60a5fa]/15 text-[#60a5fa]"
                : t.kind === "free" ? "bg-[#fbbf24]/15 text-[#fbbf24]" : "bg-[#4ade80]/15 text-[#4ade80]"
              )}>
                {t.kind === "swap" ? "ОБМЕН" : t.kind === "free" ? "СВОБ." : "ТРАНСФЕР"}
              </span>
              <span className="min-w-0 flex-1 truncate font-medium">{t.playerNames.join(", ")}</span>
              <span className="flex items-center gap-1.5 text-[11.5px] text-[#9ca3af]">
                {t.fromId ? slot.teams[t.fromId]?.shortName ?? "—" : "Св. агенты"}
                <ArrowLeftRight size={11} className="text-[#6b7280]" />
                {t.toId === "free_agents" ? "Св. агенты" : slot.teams[t.toId]?.shortName}
              </span>
              <span className="w-16 text-right font-mono text-[11.5px] text-[#4ade80]">
                {t.fee ? `£${t.fee}M` : "—"}
              </span>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid gap-2 lg:grid-cols-[1.1fr_1fr]">
          {/* ── Шаг 1: поиск игрока ── */}
          <Panel>
            <PanelHead
              title={<span className="flex items-center gap-1.5"><Search size={12} /> Шаг 1 · найдите игрока</span>}
              right={<span className="text-[10.5px] text-[#6b7280]">{results.length ? `${results.length} совпад.` : ""}</span>}
            />
            <div className="mb-1.5 flex items-center gap-1.5 rounded-md border border-[#2f3847] bg-[#0f1419] px-2 py-1.5">
              <Search size={14} className="shrink-0 text-[#6b7280]" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Имя или фамилия — например «Холанд», «Saka», «Мбаппе»…"
                autoFocus
                className="w-full bg-transparent text-[13px] outline-none placeholder:text-[#4b5563]"
              />
              {query && (
                <button onClick={() => setQuery("")} className="shrink-0 rounded p-0.5 text-[#6b7280] hover:text-[#e5e7eb]">
                  <X size={13} />
                </button>
              )}
            </div>
            <Tabs
              className="mb-1.5"
              value={posFilter}
              onChange={setPosFilter}
              items={[
                { id: "ALL" as const, label: "Все" }, { id: "GK" as const, label: "ВР" },
                { id: "DF" as const, label: "ЗЩ" }, { id: "MF" as const, label: "ПЗ" }, { id: "FW" as const, label: "НП" },
              ]}
            />

            <div className="max-h-[calc(100vh-330px)] min-h-[160px] overflow-y-auto rounded-md border border-[#2a3140] bg-[#182029]">
              {query.trim().length < 2 && (
                <p className="px-3 py-8 text-center text-[12px] leading-relaxed text-[#6b7280]">
                  Начните вводить имя игрока.<br />
                  Поиск идёт по всем клубам всех лиг и по свободным агентам.
                </p>
              )}
              {query.trim().length >= 2 && !results.length && (
                <p className="px-3 py-8 text-center text-[12px] text-[#6b7280]">Игрок не найден</p>
              )}
              {results.map((f) => {
                const on = picked?.player.id === f.player.id;
                return (
                  <button
                    key={f.player.id}
                    onClick={() => choose(f)}
                    className={cn(
                      "flex w-full items-center gap-2 border-b border-[#232b36] px-2 py-1.5 text-left text-[12.5px] transition-colors last:border-0",
                      on ? "bg-[#4ade80]/15" : "hover:bg-[#2a3140]"
                    )}
                  >
                    <PosBadge pos={f.player.position} />
                    <span className="min-w-0 flex-1 truncate font-medium">
                      {f.player.name}
                      {f.player.injury && <span title={`${f.player.injury.label}, ${f.player.injury.daysLeft} дн.`}> 🚑</span>}
                    </span>
                    <span className="hidden w-7 shrink-0 text-center font-mono text-[10.5px] text-[#6b7280] sm:block">
                      {f.player.age}
                    </span>
                    <Crest name={f.teamName} color={f.teamColor} size={14} />
                    <span className="w-14 shrink-0 truncate text-[10.5px] text-[#9ca3af]">{f.teamShort}</span>
                    <span className="m-hide hidden w-12 shrink-0 text-[9.5px] text-[#4b5563] lg:block">{f.league}</span>
                    <span className="w-8 shrink-0 text-center font-mono text-[12px] font-bold text-[#4ade80]">
                      {f.player.overall}
                    </span>
                    <span className="w-12 shrink-0 text-right font-mono text-[10.5px] text-[#9ca3af]">
                      £{marketValue(f.player)}M
                    </span>
                  </button>
                );
              })}
            </div>
          </Panel>

          {/* ── Шаг 2: новый клуб ── */}
          <Panel>
            <PanelHead title={<span className="flex items-center gap-1.5"><ArrowLeftRight size={12} /> Шаг 2 · новый клуб</span>} />

            {!picked ? (
              <div className="flex h-40 flex-col items-center justify-center gap-2 text-center text-[12px] text-[#6b7280]">
                <UserPlus size={22} className="text-[#2f3847]" />
                Сначала выберите игрока в списке слева
              </div>
            ) : (
              <>
                {/* карточка выбранного */}
                <div className="mb-2 rounded-md border border-[#2a3140] bg-[#182029] p-2.5">
                  <div className="flex items-center gap-2">
                    <PosBadge pos={picked.player.position} />
                    <span className="min-w-0 flex-1 truncate text-[14px] font-bold">{picked.player.name}</span>
                    <span className="rounded bg-[#4ade80]/15 px-1.5 py-0.5 font-mono text-[12px] font-bold text-[#4ade80]">
                      {picked.player.overall}
                    </span>
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-[#9ca3af]">
                    <span className="flex items-center gap-1">
                      <Crest name={picked.teamName} color={picked.teamColor} size={12} /> {picked.teamName}
                    </span>
                    <span>{picked.player.age} лет</span>
                    <span>{picked.player.nationality}</span>
                    {picked.player.stats.apps > 0 && (
                      <span className={cn("rounded px-1 font-mono", ratingClass(picked.player.stats.avgRating))}>
                        {picked.player.stats.avgRating.toFixed(2)}
                      </span>
                    )}
                    <span>{picked.player.stats.goals}г {picked.player.stats.assists}п</span>
                  </div>
                </div>

                <label className="mb-1 block text-[11px] text-[#9ca3af]">Куда переходит</label>
                <Select value={toId} onChange={(e) => setToId(e.target.value)} className="w-full">
                  <option value="">— выберите клуб —</option>
                  {picked.teamId && <option value={FREE} disabled>──────────</option>}
                  {clubs.filter((t) => t.id !== picked.teamId).map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} · {LEAGUE_CFG[t.league!].short}
                    </option>
                  ))}
                </Select>

                {target && (
                  <div className="mt-1.5 flex items-center gap-2 rounded-md border border-[#2a3140] bg-[#182029] px-2 py-1.5 text-[11px] text-[#9ca3af]">
                    <Crest name={target.name} color={target.color} size={14} />
                    <span className="min-w-0 flex-1 truncate">{target.name}</span>
                    <span className="flex items-center gap-1"><Wallet size={11} /> £{target.budget}M</span>
                    <span>{target.players.length} игр.</span>
                  </div>
                )}

                <div className="mt-2 flex items-end gap-1.5">
                  <label className="flex-1">
                    <span className="mb-1 block text-[11px] text-[#9ca3af]">Сумма сделки, £M</span>
                    <Input
                      type="number" step={0.5} value={fee}
                      onChange={(e) => setFee(Number(e.target.value) || 0)}
                      className="w-full text-center font-mono"
                    />
                  </label>
                  <Btn onClick={() => setFee(Math.round(marketValue(picked.player) * 10) / 10)} icon={<Wand2 size={12} />}>
                    По рынку
                  </Btn>
                  <Btn onClick={() => setFee(0)}>Бесплатно</Btn>
                </div>

                {check && !!check.errors.length && (
                  <ul className="mt-2 space-y-1">
                    {check.errors.map((e, i) => (
                      <li key={i} className="flex items-center gap-1.5 text-[11.5px] text-[#f87171]">
                        <AlertTriangle size={12} /> {e}
                      </li>
                    ))}
                  </ul>
                )}
                {check && !!check.warnings.length && (
                  <ul className="mt-1 space-y-1">
                    {check.warnings.map((w, i) => (
                      <li key={i} className="flex items-center gap-1.5 text-[11.5px] text-[#fbbf24]">
                        <AlertTriangle size={12} /> {w}
                      </li>
                    ))}
                  </ul>
                )}

                <div className="mt-2 flex items-center gap-2">
                  <Btn variant="primary" className="flex-1" disabled={!check?.ok} onClick={doTransfer} icon={<ArrowLeftRight size={14} />}>
                    {toId ? `Перевести в ${slot.teams[toId]?.shortName ?? "клуб"}` : "Выберите клуб"}
                  </Btn>
                  <Btn onClick={() => { setPicked(null); setToId(""); }}>Отмена</Btn>
                </div>

                <p className="mt-2 flex items-center gap-1.5 text-[10.5px] leading-relaxed text-[#4b5563]">
                  <History size={11} className="shrink-0" />
                  Проверки: минимум 11 игроков у прежнего клуба, бюджет покупателя, трансферное окно.
                  Составы и тактики обеих команд обновятся автоматически.
                </p>
              </>
            )}
          </Panel>
        </div>
      )}

      {flash && (
        <div className="fixed bottom-16 left-1/2 z-50 -translate-x-1/2 rounded-md border border-[#4ade80]/40 bg-[#1e2530] px-3 py-1.5 text-[12.5px] shadow-xl md:bottom-5">
          {flash}
        </div>
      )}
    </div>
  );
}
