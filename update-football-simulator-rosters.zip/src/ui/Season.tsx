// ─── Экран сезона: сайдбар + шапка + разделы ───────────────────────────────
import { useCallback, useEffect, useRef, useState } from "react";
import {
  LayoutDashboard, CalendarDays, Table2, Users, ArrowLeftRight, CalendarClock,
  ClipboardList, BarChart3, Medal, Play, Trophy, Save, Download,
  Zap, LayoutGrid, UserCog, Home, Menu as MenuIcon,
  TrendingUp, TrendingDown,
} from "lucide-react";
import type { Fixture, LeagueId, MatchResult, SeasonReport, Slot } from "../types";
import type { CupComp } from "../engine/season";
import { Btn, Crest, Panel, PanelHead, Tabs } from "./bits";
import { cn } from "../utils/cn";
import {
  advanceDay, advanceToEndOfSeason, applyResult,
  COMP_NAME, fmtDay, LEAGUE_CFG, simulateFixture,
} from "../engine/season";
import { finishSeason } from "../engine/ratings";
import { exportSlot, loadSlot, saveSlot } from "../engine/storage";
import { MatchView } from "./MatchView";
import {
  CupView, EuroView, LeagueTable, MatchesView, OverviewView, StatsView, slotCups, slotLeagues,
} from "./SeasonPanels";
import { ClubCard, ClubsView, TacticsView } from "./ClubsView";
import { TransfersView } from "./TransfersView";
import { ScheduleView } from "./ScheduleView";
import { SimPanel } from "./SimPanel";
import { RoundView } from "./RoundView";
import { PlayerEditor } from "./PlayerEditor";
import { copyText } from "../utils/copy";

type Section = "overview" | "sim" | "round" | "matches" | "tables" | "clubs" | "transfers" | "editor" | "tactics" | "stats" | "cups" | "schedule";

const NAV: { id: Section; label: string; icon: typeof LayoutDashboard; key: string }[] = [
  { id: "overview", label: "Обзор", icon: LayoutDashboard, key: "1" },
  { id: "sim", label: "Симуляция", icon: Zap, key: "2" },
  { id: "round", label: "Тур", icon: LayoutGrid, key: "3" },
  { id: "matches", label: "Матчи", icon: CalendarDays, key: "4" },
  { id: "tables", label: "Таблицы", icon: Table2, key: "5" },
  { id: "clubs", label: "Клубы", icon: Users, key: "6" },
  { id: "transfers", label: "Трансферы", icon: ArrowLeftRight, key: "7" },
  { id: "editor", label: "Редактор игроков", icon: UserCog, key: "8" },
  { id: "tactics", label: "Тактики", icon: ClipboardList, key: "9" },
  { id: "stats", label: "Статистика", icon: BarChart3, key: "0" },
  { id: "cups", label: "Кубки", icon: Medal, key: "-" },
  { id: "schedule", label: "Календарь", icon: CalendarClock, key: "=" },
];

export function SeasonScreen({ slotId, onExit }: { slotId: string; onExit: () => void }) {
  const slotRef = useRef<Slot | null>(loadSlot(slotId));
  const [, force] = useState(0);
  const rerender = useCallback(() => force((n) => n + 1), []);
  const [sec, setSec] = useState<Section>("overview");
  const [live, setLive] = useState<{ fixture: Fixture; result: MatchResult } | null>(null);
  const [review, setReview] = useState<{ fixture: Fixture; result: MatchResult } | null>(null);
  const [report, setReport] = useState<SeasonReport | null>(null);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [tableTab, setTableTab] = useState<LeagueId | "UCL" | "UEL" | "UECL">("PL");
  const [cupTab, setCupTab] = useState<CupComp>("FA");
  const [openClub, setOpenClub] = useState<string | null>(null);
  const [simTo, setSimTo] = useState("");
  const [navOpen, setNavOpen] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [exportJson, setExportJson] = useState("");

  const slot = slotRef.current;

  useEffect(() => {
    if (!slot) return;
    if (slot.season.finished && slot.history.length && slot.history[slot.history.length - 1].seasonNumber === slot.seasonNumber)
      setReport(slot.history[slot.history.length - 1]);
    if (!simTo) setSimTo(slot.currentDate);
  }, [slot, simTo]);

  const commit = useCallback(() => {
    if (!slot) return;
    saveSlot(slot);
    rerender();
  }, [slot, rerender]);

  const flash = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const run = useCallback((fn: () => void) => {
    setBusy(true);
    setTimeout(() => { fn(); commit(); setBusy(false); }, 10);
  }, [commit]);

  const simDay = useCallback(() => {
    if (!slot) return;
    run(() => { const d = advanceDay(slot); flash(d.fixtures.length ? `Сыграно матчей: ${d.fixtures.length}` : "Матчей не было"); });
  }, [slot, run]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
      if (e.key === "Escape") { setReview(null); setNavOpen(false); return; }
      if (live || review || report) return;
      if (e.code === "Space") { e.preventDefault(); simDay(); return; }
      const nav = NAV.find((n) => n.key === e.key);
      if (nav) { setSec(nav.id); setOpenClub(null); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [simDay, live, review, report]);

  if (!slot) {
    return (
      <div className="mx-auto max-w-lg p-6">
        <Btn onClick={onExit} icon={<Home size={14} />}>В меню</Btn>
        <Panel className="mt-3 text-center text-[12.5px] text-[#9ca3af]">Слот не найден.</Panel>
      </div>
    );
  }

  const seasonOver = slot.season.finished;
  const leagues = slotLeagues(slot);
  const cups = slotCups(slot);

  const watchMatch = (f: Fixture) => {
    if (f.played) { setReview({ fixture: f, result: simulateFixture(slot, f) }); return; }
    setBusy(true);
    setTimeout(() => {
      const res = simulateFixture(slot, f);
      applyResult(slot, f, res);
      saveSlot(slot);
      setLive({ fixture: f, result: res });
      setBusy(false);
    }, 10);
  };

  const closeLive = () => { setLive(null); saveSlot(slot); rerender(); };

  const doExport = () => {
    try {
      const json = exportSlot(slot.slotId);
      if (!json) { flash("Слот не найден"); return; }
      const name = `fs26_season${slot.seasonNumber}_${slot.slotId.slice(-4)}.json`;
      const mb = (json.length / 1024 / 1024).toFixed(1);
      const blob = new Blob([json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = name; a.target = "_self"; a.rel = "noopener";
      document.body.appendChild(a); a.click();
      setTimeout(() => { try { document.body.removeChild(a); } catch { /* */ } URL.revokeObjectURL(url); }, 5000);
      setExportJson(json);
      flash(`Скачивание «${name}» (${mb} МБ)`);
      setTimeout(() => setShowExport(true), 1500);
    } catch (e) { flash(`Ошибка: ${e instanceof Error ? e.message : "неизвестная"}`); setExportJson(""); setShowExport(true); }
  };

  if (live) {
    return (
      <MatchView
        result={live.result} teams={slot.teams} onClose={closeLive} closeLabel="Продолжить сезон"
        fixture={live.fixture} slot={slot}
        standings={<LeagueTable slot={slot} league={(slot.teams[live.fixture.homeId].league ?? "PL") as LeagueId} compact />}
      />
    );
  }
  if (review) {
    return (
      <MatchView result={review.result} teams={slot.teams} instant onClose={() => setReview(null)}
        closeLabel="Закрыть" overlay manual={!!review.fixture.result?.manual} fixture={review.fixture} slot={slot}
        onEditScore={() => { const f = review.fixture; setReview(null); setSec("matches"); void f; }} />
    );
  }
  if (report) {
    return <ReportScreen slot={slot} report={report}
      onNextSeason={() => { setReport(null); setSec("sim"); }}
      onExit={() => { saveSlot(slot); onExit(); }} />;
  }

  const Nav = (
    <nav className="flex flex-col gap-0.5">
      {NAV.map((n) => (
        <button key={n.id} onClick={() => { setSec(n.id); setOpenClub(null); setNavOpen(false); }}
          className={cn("group relative flex items-center gap-2.5 rounded-md px-2.5 py-[7px] text-left text-[12.5px] transition-colors",
            sec === n.id ? "bg-[#3b82f6]/12 font-semibold text-[#60a5fa]" : "text-[#9ca3af] hover:bg-[#232b36] hover:text-[#e5e7eb]")}
          title={`${n.label} (${n.key})`}>
          {sec === n.id && <span className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r bg-[#3b82f6]" />}
          <n.icon size={15} className="shrink-0" />
          <span className="hidden truncate lg:inline">{n.label}</span>
        </button>
      ))}
    </nav>
  );

  return (
    <div className="min-h-dvh bg-[#0f1419] text-[#e5e7eb] antialiased">
      {/* Шапка */}
      <header className="sticky top-0 z-30 border-b border-[#2a3140] bg-[#1a1f2e]/95 backdrop-blur">
        <div className="flex flex-wrap items-center gap-2 px-2.5 py-1.5">
          <button className="rounded p-1 text-[#9ca3af] hover:bg-[#232b36] md:hidden" onClick={() => setNavOpen((v) => !v)}><MenuIcon size={17} /></button>
          <button onClick={() => { saveSlot(slot); onExit(); }} className="flex items-center gap-1.5 text-[14px] font-black tracking-tight"><span>⚽</span><span>FS<span className="text-[#4ade80]">26</span></span></button>
          <div className="mx-auto flex items-center gap-2 rounded-md border border-[#2a3140] bg-[#0f1419] px-2.5 py-1">
            <CalendarDays size={13} className="text-[#3b82f6]" />
            <span className="font-mono text-[12.5px]">{fmtDay(slot.currentDate)}</span>
          </div>
          {seasonOver ? (
            <Btn variant="warn" onClick={() => run(() => setReport(finishSeason(slot)))} icon={<Trophy size={13} />} disabled={busy}>Итоги</Btn>
          ) : (
            <>
              <Btn variant="primary" onClick={simDay} disabled={busy} icon={<Play size={12} />}>День</Btn>
              <Btn variant="danger" disabled={busy} icon={<Trophy size={12} />} onClick={() => run(() => { advanceToEndOfSeason(slot); flash("Сезон сыгран"); })}>До конца</Btn>
            </>
          )}
        </div>
      </header>

      {/* Панель быстрых действий */}
      <div className="sticky top-[42px] z-[19] flex flex-wrap items-center gap-1.5 border-b border-[#2a3140] bg-[#1a1f2e] px-2.5 py-1.5">
        <Btn sm onClick={() => { saveSlot(slot); flash("Сохранено"); }} icon={<Save size={12} />}>Сохранить</Btn>
        <Btn sm variant="blue" onClick={doExport} icon={<Download size={12} />}>📥 Скачать сезон</Btn>
      </div>

      <div className="flex">
        <aside className="fs-sidebar sticky top-[76px] z-20 hidden h-[calc(100dvh-76px)] w-[52px] shrink-0 border-r border-[#2a3140] bg-[#1a1f2e] p-1.5 md:block lg:w-[200px] lg:p-2">{Nav}</aside>
        {navOpen && (<div className="fixed inset-0 z-40 bg-black/60 lg:hidden" onClick={() => setNavOpen(false)}><div className="w-56 bg-[#1a1f2e] p-2 pt-3" onClick={(e) => e.stopPropagation()}>{Nav}</div></div>)}

        <main className="fs-fade min-w-0 flex-1 p-2 pb-16 md:pb-2">
          {sec === "overview" && <OverviewView slot={slot} onMatch={watchMatch} onClub={(id) => { setSec("clubs"); setOpenClub(id); }} />}
          {sec === "sim" && <SimPanel slot={slot} onChanged={commit} onFlash={flash} busy={busy} setBusy={setBusy} />}
          {sec === "round" && <RoundView slot={slot} onMatch={watchMatch} />}
          {sec === "matches" && <MatchesView slot={slot} onMatch={watchMatch} />}
          {sec === "tables" && (
            <Panel>
              <Tabs className="mb-2 w-fit" value={tableTab} onChange={setTableTab}
                items={[...leagues.map((l) => ({ id: l, label: LEAGUE_CFG[l].name })), { id: "UCL" as const, label: "UCL" }, { id: "UEL" as const, label: "UEL" }, { id: "UECL" as const, label: "UECL" }]} />
              {tableTab === "UCL" || tableTab === "UEL" || tableTab === "UECL"
                ? <EuroView slot={slot} comp={tableTab} onClub={(id) => { setSec("clubs"); setOpenClub(id); }} />
                : <LeagueTable slot={slot} league={tableTab} onClub={(id) => { setSec("clubs"); setOpenClub(id); }} />}
            </Panel>
          )}
          {sec === "clubs" && (<Panel>{openClub ? <ClubCard slot={slot} teamId={openClub} onBack={() => setOpenClub(null)} onChanged={commit} /> : <ClubsView slot={slot} onOpen={setOpenClub} />}</Panel>)}
          {sec === "transfers" && <Panel><TransfersView slot={slot} onChanged={commit} /></Panel>}
          {sec === "editor" && <PlayerEditor slot={slot} onChanged={commit} />}
          {sec === "tactics" && <Panel><TacticsView slot={slot} onChanged={commit} onOpenClub={(id) => { setSec("clubs"); setOpenClub(id); }} /></Panel>}
          {sec === "stats" && <StatsView slot={slot} />}
          {sec === "cups" && (<Panel>
            <Tabs className="mb-2 w-fit" value={cupTab} onChange={setCupTab} items={cups.map((id) => ({ id, label: COMP_NAME[id] }))} />
            {cups.length > 0 && <CupView slot={slot} comp={cups.includes(cupTab) ? cupTab : cups[0]} onMatch={watchMatch} />}
          </Panel>)}
          {sec === "schedule" && <Panel><ScheduleView slot={slot} onChanged={commit} /></Panel>}
        </main>
      </div>

      {/* Модалка экспорта */}
      {showExport && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-4" onClick={() => setShowExport(false)}>
          <div className="fs-fade w-full max-w-md rounded-lg border border-[#2a3140] bg-[#1e2530] p-4 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-2 flex items-center gap-2"><Download size={16} className="text-[#60a5fa]" /><h3 className="text-[14px] font-bold">Файл сезона</h3>
              <button onClick={() => setShowExport(false)} className="ml-auto rounded px-2 py-1 text-[#9ca3af] hover:bg-[#232b36]">✕</button></div>
            <p className="mb-3 text-[12px] leading-relaxed text-[#9ca3af]">Если скачивание не началось — скопируйте данные и отправьте другу.</p>
            <div className="mb-3 rounded-md border border-[#2f3847] bg-[#0f1419] p-3 text-center font-mono text-[12px] text-[#9ca3af]">
              📋 JSON готов ({(exportJson.length / 1024 / 1024).toFixed(1)} МБ)
            </div>
            <div className="flex justify-center gap-2">
              <Btn variant="primary" onClick={async () => { if (exportJson && await copyText(exportJson)) { flash("Скопировано"); setShowExport(false); } }} icon={<Download size={14} />}>Скопировать</Btn>
              <Btn onClick={() => setShowExport(false)}>Закрыть</Btn>
            </div>
          </div>
        </div>
      )}

      {toast && (<div className="fixed bottom-16 left-1/2 z-50 -translate-x-1/2 rounded-md border border-[#4ade80]/40 bg-[#1e2530] px-3 py-1.5 text-[12px] shadow-xl md:bottom-5">{toast}</div>)}
    </div>
  );
}

// ─── Итоги сезона ────────────────────────────────────────────────────────────
function ReportScreen({ slot, report, onNextSeason, onExit }: { slot: Slot; report: SeasonReport; onNextSeason: () => void; onExit: () => void }) {
  const rLeagues = report.leagues?.length ? report.leagues : [];
  const [tab, setTab] = useState<LeagueId>(rLeagues[0] ?? "PL");
  const cupList = (["UCL", "UEL", "UECL", "FA", "EFL", "CDR", "CDF", "DFB", "CIT", "TCP", "KSC", "TUC", "BCB", "DTC", "GRC", "UKC", "PLC", "SCC", "SWC"] as const).filter((c) => report.champions[c]);
  const awards = report.awardsByLeague?.[tab] ?? report.awards;

  return (
    <div className="mx-auto max-w-4xl p-3">
      <div className="mb-3 text-center">
        <div className="text-[10.5px] uppercase tracking-widest text-[#6b7280]">Итоги сезона {report.seasonNumber}</div>
        <h1 className="text-2xl font-black">2026/27</h1>
      </div>
      <div className="grid gap-2 md:grid-cols-2">
        <Panel><PanelHead title="Чемпионы лиг" icon={<Trophy size={12} />} />
          {rLeagues.map((lid) => (<div key={lid} className="flex items-center justify-between border-b border-[#232b36] py-1 text-[12.5px] last:border-0"><span className="text-[#9ca3a3]">{LEAGUE_CFG[lid].name}</span><span className="flex items-center gap-1.5 font-semibold">{report.champions[LEAGUE_CFG[lid].comp] && <Crest name={slot.teams[report.champions[LEAGUE_CFG[lid].comp]!]?.name ?? "?"} color={slot.teams[report.champions[LEAGUE_CFG[lid].comp]!]?.color ?? "#555"} size={14} />}{slot.teams[report.champions[LEAGUE_CFG[lid].comp]!]?.name ?? "—"}</span></div>))}
        </Panel>
        <Panel><PanelHead title="Кубковые трофеи" icon={<Medal size={12} />} />
          {cupList.map((c) => (<div key={c} className="flex items-center justify-between border-b border-[#232b36] py-1 text-[12.5px] last:border-0"><span className="text-[#9ca3af]">{COMP_NAME[c]}</span><span className="font-semibold">{slot.teams[report.champions[c]!]?.name ?? "—"}</span></div>))}
        </Panel>
        <Panel className="md:col-span-2">
          <Tabs className="mb-2 w-fit" value={tab} onChange={setTab} items={rLeagues.map((l) => ({ id: l, label: LEAGUE_CFG[l].name }))} />
          <div className="grid gap-3 md:grid-cols-2">
            <div><PanelHead title="Личные награды" />
              {([["Golden Boot", awards?.goldenBoot], ["Playmaker", awards?.playmaker], ["Golden Glove", awards?.goldenGlove]] as const).map(([label, a]) => (
                <div key={label} className="flex items-center justify-between border-b border-[#232b36] py-1 text-[12.5px] last:border-0"><span className="text-[#fbbf24]">{label}</span><span className="min-w-0 flex-1 truncate px-2 text-right">{a?.name ?? "—"}</span><b className="font-mono text-[#4ade80]">{a ? `${a.value}` : ""}</b></div>))}
            </div>
            <div><PanelHead title="Итоговая таблица" />
              <div className="max-h-52 overflow-y-auto">{(report.finalTables?.[tab] ?? report.finalTable ?? []).map((r) => (<div key={r.teamId} className="flex items-center gap-1.5 border-b border-[#232b36] py-0.5 text-[12px]"><span className="w-5 font-mono text-[10.5px] text-[#6b7280]">{r.pos}</span><Crest name={slot.teams[r.teamId]?.name ?? "?"} color={slot.teams[r.teamId]?.color ?? "#555"} size={13} /><span className="min-w-0 flex-1 truncate">{slot.teams[r.teamId]?.name}</span><b className="font-mono">{r.pts}</b></div>))}</div>
            </div>
          </div>
        </Panel>
        <Panel><PanelHead title={<span className="text-[#4ade80]">Прогресс рейтингов</span>} icon={<TrendingUp size={12} />} />
          {report.improved.map((c) => (<div key={c.playerId} className="flex items-center gap-1.5 border-b border-[#232b36] py-1 text-[12px]"><Crest name={slot.teams[c.teamId]?.name ?? "?"} color={slot.teams[c.teamId]?.color ?? "#555"} size={13} /><span className="min-w-0 flex-1 truncate">{c.name}</span><span className="font-mono text-[11.5px]">{c.oldOverall}→<b className="text-[#4ade80]">{c.newOverall}</b></span><span className="w-7 text-right font-mono text-[11px] font-bold text-[#4ade80]">+{c.delta}</span></div>))}
        </Panel>
        <Panel><PanelHead title={<span className="text-[#f87171]">Регресс рейтингов</span>} icon={<TrendingDown size={12} />} />
          {report.declined.map((c) => (<div key={c.playerId} className="flex items-center gap-1.5 border-b border-[#232b36] py-1 text-[12px]"><Crest name={slot.teams[c.teamId]?.name ?? "?"} color={slot.teams[c.teamId]?.color ?? "#555"} size={13} /><span className="min-w-0 flex-1 truncate">{c.name}</span><span className="font-mono text-[11.5px]">{c.oldOverall}→<b className="text-[#f87171]">{c.newOverall}</b></span><span className="w-7 text-right font-mono text-[11px] font-bold text-[#f87171]">{c.delta}</span></div>))}
        </Panel>
      </div>
      <div className="mt-3 flex flex-wrap justify-center gap-2">
        <Btn variant="primary" onClick={onNextSeason} icon={<Play size={14} />}>Новый сезон</Btn>
        <Btn variant="outline" onClick={onExit} icon={<Save size={14} />}>Сохранить и выйти</Btn>
      </div>
    </div>
  );
}
