// ─── Трансферы: конструктор обменов между любыми клубами ─────────────────────
// Пользователь — наблюдатель лиги: он может передвинуть любого игрока
// в любой клуб (в рамках трансферного окна и проверок состава).

import type { Player, Slot, TransferRecord } from "../types";
import { sanitizeTactics } from "./tactics";

export const MIN_SQUAD = 11;

/** Трансферные окна: 1 июля – 31 августа и 1 – 31 января */
export function isWindowOpen(date: string): boolean {
  const m = Number(date.slice(5, 7));
  return m === 7 || m === 8 || m === 1;
}

export function windowLabel(date: string): string {
  const m = Number(date.slice(5, 7));
  if (m === 7 || m === 8) return "Летнее окно открыто (1 июля – 31 августа)";
  if (m === 1) return "Зимнее окно открыто (1 – 31 января)";
  return "Окно закрыто · ближайшее: 1 января";
}

/**
 * Оценочная стоимость игрока (млн £).
 * Калибровано по реальным данным Transfermarkt 2026:
 * ovr 70 ≈ £2M, 75 ≈ £8M, 80 ≈ £20M, 85 ≈ £45M, 90 ≈ £90M, 95 ≈ £165M.
 * Возраст: молодые дороже, после 30 стоимость быстро падает.
 */
export function marketValue(p: Player): number {
  const base = Math.pow(Math.max(56, p.overall) - 55, 4.5) / 98500;
  const ageK =
    p.age <= 21 ? 1.3
    : p.age <= 26 ? 1.15
    : p.age <= 29 ? 1.0
    : p.age <= 32 ? 0.6
    : p.age <= 35 ? 0.3
    : 0.12;
  const v = base * ageK;
  const rounded = v >= 20 ? Math.round(v) : v >= 2 ? Math.round(v * 2) / 2 : Math.round(v * 10) / 10;
  return Math.max(0.2, Math.min(250, rounded));
}

export interface TransferPlan {
  fromId: string | null; // null = свободные агенты
  toId: string;
  playersOut: string[]; // id игроков, уходящих из fromId в toId
  playersBack: string[]; // id игроков, уходящих из toId в fromId (обмен)
  fee: number; // млн £, платит toId клубу fromId (может быть отрицательной)
}

export interface ValidationResult {
  ok: boolean;
  errors: string[];
  warnings: string[];
}

export function validateTransfer(slot: Slot, plan: TransferPlan): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const to = slot.teams[plan.toId];
  const from = plan.fromId ? slot.teams[plan.fromId] : null;

  if (!to) errors.push("Не выбран клуб-покупатель");
  if (plan.fromId && !from) errors.push("Клуб-продавец не найден");
  if (plan.fromId === plan.toId) errors.push("Нельзя совершить трансфер внутри одного клуба");
  if (!plan.playersOut.length && !plan.playersBack.length) errors.push("Не выбрано ни одного игрока");
  if (!isWindowOpen(slot.currentDate)) errors.push("Трансферное окно закрыто");

  if (to && from) {
    const fromAfter = from.players.length - plan.playersOut.length + plan.playersBack.length;
    const toAfter = to.players.length - plan.playersBack.length + plan.playersOut.length;
    if (fromAfter < MIN_SQUAD) errors.push(`У «${from.name}» останется ${fromAfter} игроков (минимум ${MIN_SQUAD})`);
    if (toAfter < MIN_SQUAD) errors.push(`У «${to.name}» останется ${toAfter} игроков (минимум ${MIN_SQUAD})`);
    // дубли
    for (const id of plan.playersOut) if (to.players.some((p) => p.id === id)) errors.push("Игрок уже есть в клубе-покупателе");
    for (const id of plan.playersBack) if (from.players.some((p) => p.id === id)) errors.push("Игрок уже есть в клубе-продавце");
  }
  if (to && !from) {
    const toAfter = to.players.length + plan.playersOut.length;
    if (toAfter < MIN_SQUAD) errors.push(`У «${to.name}» останется ${toAfter} игроков (минимум ${MIN_SQUAD})`);
  }

  if (to && plan.fee > 0) {
    if (plan.fee > to.budget) errors.push(`Бюджет «${to.name}» (£${to.budget}M) меньше суммы сделки £${plan.fee}M`);
    else if (plan.fee > to.budget * 0.75) warnings.push(`Сделка съест большую часть бюджета «${to.name}»`);
  }
  if (from && plan.fee < 0 && Math.abs(plan.fee) > from.budget) {
    errors.push(`Бюджет «${from.name}» не позволяет доплату £${Math.abs(plan.fee)}M`);
  }

  // подсказка по рыночной стоимости
  if (to && plan.playersOut.length) {
    const pool = from ? from.players : slot.freeAgents;
    const worth = plan.playersOut.reduce((s, id) => s + (pool.find((p) => p.id === id) ? marketValue(pool.find((p) => p.id === id)!) : 0), 0);
    const back = plan.playersBack.reduce((s, id) => s + (to.players.find((p) => p.id === id) ? marketValue(to.players.find((p) => p.id === id)!) : 0), 0);
    const fair = worth - back;
    if (plan.fee < fair * 0.4 && fair > 3) warnings.push(`Рыночная оценка сделки ≈ £${fair.toFixed(1)}M — сумма занижена`);
  }

  return { ok: errors.length === 0, errors, warnings };
}

/** Совершает трансфер: перемещает игроков, двигает бюджеты, чинит составы */
export function executeTransfer(slot: Slot, plan: TransferPlan): TransferRecord {
  const v = validateTransfer(slot, plan);
  if (!v.ok) throw new Error(v.errors[0]);

  const to = slot.teams[plan.toId];
  const from = plan.fromId ? slot.teams[plan.fromId] : null;
  const names: string[] = [];

  const move = (ids: string[], src: Player[], dst: Player[]) => {
    for (const id of ids) {
      const idx = src.findIndex((p) => p.id === id);
      if (idx === -1) continue;
      const [p] = src.splice(idx, 1);
      names.push(p.name);
      dst.push(p);
    }
  };

  if (from) {
    move(plan.playersOut, from.players, to.players);
    move(plan.playersBack, to.players, from.players);
    from.budget = Math.round((from.budget + plan.fee) * 10) / 10;
    to.budget = Math.round((to.budget - plan.fee) * 10) / 10;
  } else {
    move(plan.playersOut, slot.freeAgents, to.players);
    to.budget = Math.round((to.budget - Math.max(0, plan.fee)) * 10) / 10;
  }

  // состав и тактика клубов приводятся в порядок
  for (const t of [to, from].filter(Boolean) as (typeof to)[]) {
    slot.tactics[t.id] = sanitizeTactics(t, slot.tactics[t.id]);
    // клубные рейтинги пересчитываются под новый состав
    const byPos = (pos: string) => t.players.filter((p) => p.position === pos).sort((a, b) => b.overall - a.overall);
    const avg = (arr: Player[], n: number) =>
      arr.length ? Math.round(arr.slice(0, n).reduce((s, p) => s + p.overall, 0) / Math.min(n, arr.length)) : 70;
    t.attack = avg(byPos("FW"), 3);
    t.midfield = avg(byPos("MF"), 3);
    t.defense = avg(byPos("DF"), 4);
    t.goalkeeping = avg(byPos("GK"), 1);
  }

  const rec: TransferRecord = {
    id: `tr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
    date: slot.currentDate,
    fromId: plan.fromId,
    toId: plan.toId,
    playerIds: [...plan.playersOut, ...plan.playersBack],
    playerNames: names,
    fee: plan.fee,
    kind: !plan.fromId ? "free" : plan.playersBack.length ? "swap" : "transfer",
  };
  slot.transfers.unshift(rec);
  return rec;
}

/** Отправить игрока в свободные агенты (освободить) */
export function releasePlayer(slot: Slot, teamId: string, playerId: string): boolean {
  const team = slot.teams[teamId];
  if (!team || team.players.length <= MIN_SQUAD) return false;
  const idx = team.players.findIndex((p) => p.id === playerId);
  if (idx === -1) return false;
  const [p] = team.players.splice(idx, 1);
  slot.freeAgents.push(p);
  slot.tactics[teamId] = sanitizeTactics(team, slot.tactics[teamId]);
  slot.transfers.unshift({
    id: `tr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
    date: slot.currentDate,
    fromId: teamId,
    toId: "free_agents",
    playerIds: [p.id],
    playerNames: [p.name],
    fee: 0,
    kind: "free",
  });
  return true;
}
