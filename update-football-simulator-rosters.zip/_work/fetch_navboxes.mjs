// Скачивает навигационные шаблоны составов (Template:<Клуб> squad) — это самый
// аккуратный источник актуального первого состава на Википедии.
import fs from "node:fs";

const CLUBS = JSON.parse(fs.readFileSync("_work/clubs.json", "utf8"));
const UA = { "User-Agent": "Mozilla/5.0 SquadCheckBot/1.0 (contact: research@example.org)" };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function fetchWt(id, title) {
  const cf = `_work/cache/${id}.txt`;
  fs.mkdirSync("_work/cache", { recursive: true });
  if (fs.existsSync(cf)) return fs.readFileSync(cf, "utf8");
  const url = "https://en.wikipedia.org/w/api.php?action=parse&page=" + encodeURIComponent(title) +
    "&prop=wikitext&format=json&redirects=1&formatversion=2";
  for (let a = 0; a < 6; a++) {
    const res = await fetch(url, { headers: UA });
    const txt = await res.text();
    if (txt.startsWith("{")) {
      const j = JSON.parse(txt);
      if (j.parse) { fs.writeFileSync(cf, j.parse.wikitext); return j.parse.wikitext; }
      return null;
    }
    console.log("  RL wait", a + 1);
    await sleep(15000 + a * 10000);
  }
  return null;
}

const stripParen = (s) => (s || "").replace(/\s*\([^)]*\)\s*$/, "").trim();

function fullName(target, display) {
  let t = stripParen(target || "");
  if (t) return t;
  return stripParen(display || "");
}

function parseNavbox(wt0) {
  let cleaned = wt0.replace(/<!--[\s\S]*?-->/g, "");        // убираем закомментированных (аренды)
  // раскрываем {{Abbr|сокр.|Полное имя}} -> Полное имя (чтобы не ломать шаблон игрока)
  cleaned = cleaned.replace(/\{\{\s*(?:abbr|Abbr|ABR|abr|Abbrlink)\s*\|([^|}]+)\|([^|}]+)\}\}/g, "$2");
  const out = [];
  const re = /\{\{football squad2 player\s*\|([^}]*)\}\}/gi;
  let m;
  while ((m = re.exec(cleaned))) {
    const body = m[1];
    const numm = body.match(/(?:^|\|)\s*no\s*=\s*([^|}]*)/);
    const namem = body.match(/(?:^|\|)\s*name\s*=\s*(\[\[[^\]]*\]\]|[^|}]*)/);
    const raw = (namem ? namem[1] : "").trim();
    const lm = raw.match(/\[\[([^\]]+)\]\]/);
    let target = "", rawTarget = "", display = raw;
    if (lm) { const inner = lm[1]; target = inner.split("|")[0].trim(); rawTarget = target; display = inner.includes("|") ? inner.split("|").pop().trim() : target; }
    else {
      // шаблоны вида {{abbr|K. Kesler|Kaine Kesler-Hayden}}
      const am = raw.match(/\{\{(?:abbr|Abbr|ABR|abr)\|([^|}]*)\|([^|}]*)\}\}/);
      if (am) { display = am[2].trim(); }
    }
    display = display.replace(/\{\{[^}]*\}\}/g, "").replace(/\[\[|\]\]/g, "").trim();
    const name = fullName(target, display);
    if (!name) continue;
    out.push({ name, target: stripParen(target), rawTarget: rawTarget || stripParen(target), display: stripParen(display), no: (numm ? numm[1] : "").trim() });
  }
  return out;
}

const result = {};
for (const [id, title] of Object.entries(CLUBS)) {
  const tnames = [`Template:${title} squad`];
  let wt = await fetchWt(id, tnames[0]);
  if (wt && !wt.includes("football squad2 player")) wt = null;
  if (!wt || wt.length < 200) { result[id] = { error: "no template" }; console.log("FAIL", id); continue; }
  const squad = parseNavbox(wt);
  result[id] = { template: tnames[0], squad };
  console.log(id.padEnd(18), String(squad.length).padStart(3), "players");
}
fs.writeFileSync("_work/nav_squads.json", JSON.stringify(result, null, 1));
console.log("SAVED");
