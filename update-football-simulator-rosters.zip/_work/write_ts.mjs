// Переписывает src/data/teamsA.ts, teamsB.ts, championship.ts обновлёнными составами
import fs from "node:fs";

const teams = JSON.parse(fs.readFileSync("_work/final_teams.json", "utf8"));

const A_ORDER = ["arsenal", "aston_villa", "bournemouth", "brentford", "brighton", "chelsea", "crystal_palace", "everton", "fulham", "leeds", "liverpool"];
const B_ORDER = ["man_city", "man_utd", "newcastle", "nottingham", "sunderland", "tottenham", "hull", "coventry", "ipswich"];
const CHA_ORDER = ["west_ham", "wolves", "southampton", "burnley", "norwich", "middlesbrough", "sheffield_united", "west_brom", "swansea", "stoke", "bristol_city", "qpr", "millwall", "birmingham", "watford", "blackburn", "charlton", "wrexham", "portsmouth", "cardiff", "bolton", "derby", "preston", "lincoln"];

const S = (v) => JSON.stringify(v);

function teamBlock(id) {
  const t = teams[id];
  const rows = t.players.map(r => "      [" + r.map(S).join(", ") + "],").join("\n");
  return `  {
    id: ${S(id)}, name: ${S(t.name)}, short: ${S(t.short)}, color: ${S(t.color)},
    att: ${t.att}, mid: ${t.mid}, def: ${t.def}, gk: ${t.gk}, rep: ${t.rep}, budget: ${t.budget}, stadium: ${S(t.stadium)},
    players: [
${rows}
    ],
  }`;
}

const HDR_A = `// ─── База данных АПЛ 2026/27 — команды A–L ───────────────────────────────────
// Составы сверены с актуальными (Википедия: страницы клубов + навшаблоны
// «Template:<Клуб> squad», страницы игроков — возраст/позиция) на 20.09.2026.
// Формат игрока: [имя, позиция, возраст (на сент. 2026), нац., атака, защита, overall, gk?]
import type { Position } from "../types";

export type PRow = [string, Position, number, string, number, number, number, number?];

export interface TeamRow {
  id: string; name: string; short: string; color: string;
  att: number; mid: number; def: number; gk: number;
  rep: number; budget: number; stadium: string;
  players: PRow[];
}

export const TEAMS_A: TeamRow[] = [
`;

const HDR_B = `// ─── База данных АПЛ 2026/27 — команды M–I ───────────────────────────────────
// Составы сверены с актуальными (Википедия, навшаблоны составов) на 20.09.2026.
import type { TeamRow } from "./teamsA";

export const TEAMS_B: TeamRow[] = [
`;

const HDR_CHA = `// ─── EFL Championship 2026/27 (24 клуба) ─────────────────────────────────────
// Составы сверены с актуальными (Википедия: страницы клубов + навшаблоны
// «Template:<Клуб> squad», страницы игроков — возраст/позиция) на 20.09.2026.
// Из АПЛ вылетели: West Ham, Burnley, Wolves. Из Лиги 1 поднялись:
// Lincoln City, Cardiff City, Bolton Wanderers. В АПЛ поднялись: Hull City,
// Coventry City, Ipswich Town.
import type { TeamRow } from "./teamsA";

export const TEAMS_CHA: TeamRow[] = [
`;

fs.writeFileSync("src/data/teamsA.ts", HDR_A + A_ORDER.map(teamBlock).join(",\n") + "\n];\n");
fs.writeFileSync("src/data/teamsB.ts", HDR_B + B_ORDER.map(teamBlock).join(",\n") + "\n];\n");
fs.writeFileSync("src/data/championship.ts", HDR_CHA + CHA_ORDER.map(teamBlock).join(",\n") + "\n];\n");
console.log("written", A_ORDER.length + B_ORDER.length + CHA_ORDER.length, "teams");
