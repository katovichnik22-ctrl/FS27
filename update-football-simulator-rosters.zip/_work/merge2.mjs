// Финальное сравнение: navbox = истина по составу; секция = поз/нац; проект = рейтинги
import fs from "node:fs";

const nav = JSON.parse(fs.readFileSync("_work/nav_squads.json", "utf8"));
const sec = JSON.parse(fs.readFileSync("_work/wiki_squads.json", "utf8"));
const proj = JSON.parse(fs.readFileSync("_work/project_players.json", "utf8"));

const norm = (s) => (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
  .replace(/[.'’()\[\]-]/g, " ").replace(/\s+/g, " ").trim();
const lastN = (s) => { const p = norm(s).split(" ").filter(Boolean); return p[p.length - 1] || ""; };
const firstN = (s) => { const p = norm(s).split(" ").filter(Boolean); return p[0] || ""; };

function lev(a, b) {
  const m = a.length, n = b.length;
  if (!m) return n; if (!n) return m;
  const d = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
  for (let j = 1; j <= n; j++) d[0][j] = j;
  for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++)
    d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[m][n];
}

// универсальный матчер имени к списку кандидатов {name,target,display}
function matchIdx(name, cand, used) {
  const n = norm(name);
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const cs = [norm(cand[i].name), norm(cand[i].target), norm(cand[i].display)];
    if (cs.includes(n)) return i;
  }
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const c = norm(cand[i].name || cand[i].target);
    if (!c) continue;
    if (c.startsWith(n + " ") || c.endsWith(" " + n) || n.startsWith(c + " ") || n.endsWith(" " + c)) return i;
  }
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const c = norm(cand[i].name || cand[i].target);
    if (c && lastN(c) === lastN(n) && firstN(c)[0] === firstN(n)[0]) return i;
  }
  // близкое написание фамилии (Satpaev ~ Satpayev) + совпадение имени
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const c = norm(cand[i].name || cand[i].target);
    if (!c) continue;
    if (firstN(c) === firstN(n) && lev(lastN(c), lastN(n)) <= 2) return i;
    if (lev(firstN(c), firstN(n)) <= 1 && lastN(c) === lastN(n)) return i;
  }
  return -1;
}

const report = {};
const allTargets = []; // для дозапроса ДР/позиций
for (const id of Object.keys(nav)) {
  const n = nav[id];
  const s = sec[id] || { squad: [] };
  if (n.error) { report[id] = { error: n.error }; continue; }
  const secUsed = new Set();
  const real = n.squad.map(p => {
    const j = matchIdx(p.name, s.squad, secUsed);
    let pos = "", nat = "";
    if (j >= 0) { secUsed.add(j); pos = s.squad[j].pos; nat = s.squad[j].nat; }
    const entry = { name: p.name, target: p.target, rawTarget: p.rawTarget || p.target, pos, nat, no: p.no };
    return entry;
  });
  const projPlayers = proj[id]?.players || [];
  const used = new Set();
  const kept = [], left = [];
  for (const p of projPlayers) {
    const i = matchIdx(p.name, real, used);
    if (i === -1) left.push(p);
    else { used.add(i); kept.push({ proj: p, wiki: real[i] }); }
  }
  const added = real.filter((_, i) => !used.has(i));
  for (const k of kept) allTargets.push({ club: id, who: k.proj.name, rawTarget: k.wiki.rawTarget, needMeta: false });
  for (const a of added) allTargets.push({ club: id, who: a.name, rawTarget: a.rawTarget, needMeta: !a.pos || !a.nat, pos: a.pos, nat: a.nat });
  report[id] = {
    club: proj[id]?.name, projCount: projPlayers.length, realCount: real.length, kept: kept.length,
    left: left.map(p => ({ name: p.name, pos: p.pos, ovr: p.ovr })),
    added: added.map(a => ({ name: a.name, pos: a.pos, nat: a.nat, rawTarget: a.rawTarget })),
    keptList: kept.map(k => ({ name: k.proj.name, as: k.wiki.name })),
  };
}
fs.writeFileSync("_work/diff3.json", JSON.stringify(report, null, 1));
fs.writeFileSync("_work/targets.json", JSON.stringify(allTargets, null, 1));
let tl = 0, ta = 0;
for (const [id, r] of Object.entries(report)) {
  tl += (r.left || []).length; ta += (r.added || []).length;
  console.log(`${id.padEnd(18)} proj=${String(r.projCount).padStart(3)} real=${String(r.realCount).padStart(3)} kept=${String(r.kept).padStart(3)} left=${(r.left || []).length} add=${(r.added || []).length}`);
}
console.log("TOTAL LEFT", tl, "ADD", ta, "targets to fetch:", allTargets.length);
