import { TEAMS_A } from "../src/data/teamsA";
import { TEAMS_B } from "../src/data/teamsB";
import { TEAMS_CHA } from "../src/data/championship";
import fs from "node:fs";

const all: Record<string, any> = {};
for (const t of [...TEAMS_A, ...TEAMS_B, ...TEAMS_CHA]) {
  all[t.id] = {
    name: t.name, short: t.short, color: t.color,
    att: t.att, mid: t.mid, def: t.def, gk: t.gk, rep: t.rep, budget: t.budget, stadium: t.stadium,
    players: t.players.map(p => ({ name: p[0], pos: p[1], age: p[2], nat: p[3], att: p[4], def: p[5], ovr: p[6], gk: p[7] })),
  };
}
fs.writeFileSync("_work/project_players.json", JSON.stringify(all, null, 1));
console.log("teams:", Object.keys(all).length, "players:", Object.values(all).reduce((s, t) => s + t.players.length, 0));
