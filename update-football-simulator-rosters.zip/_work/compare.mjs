// Сравнивает составы проекта с актуальными (Википедия, ~сентябрь 2026)
import fs from "node:fs";

const wiki = JSON.parse(fs.readFileSync("_work/wiki_squads.json", "utf8"));

// Парсим TS-данные проекта
function parseTs(file) {
  const txt = fs.readFileSync(file, "utf8");
  const teams = {};
  const teamRe = /id: "([^"]+)"[\s\S]*?players: \[([\s\S]*?)\n    \],/g;
  let m;
  while ((m = teamRe.exec(txt))) {
    const id = m[1];
    const players = [];
    const prow = /\["([^"]+)", "([A-Z]{2})", (\d+), "([A-Z]{2,3})", (\d+), (\d+), (\d+)(?:, (\d+))?\]/g;
    let pm;
    while ((pm = prow.exec(m[2]))) {
      players.push({ name: pm[1], pos: pm[2], age: +pm[3], nat: pm[4], att: +pm[5], def: +pm[6], ovr: +pm[7] });
    }
    teams[id] = players;
  }
  return teams;
}

const project = {
  ...parseTs("src/data/teamsA.ts"),
  ...parseTs("src/data/teamsB.ts"),
  ...parseTs("src/data/championship.ts"),
};

const norm = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
  .replace(/[.'-]/g, " ").replace(/\s+/g, " ").trim();

function lastName(s) { const p = norm(s).split(" "); return p[p.length - 1]; }

function findMatch(name, candidates, used) {
  const n = norm(name);
  // 1) точное совпадение
  for (let i = 0; i < candidates.length; i++) {
    if (used.has(i)) continue;
    if (norm(candidates[i].name) === n) return i;
  }
  // 2) одно имя содержит другое (мононимы типа "Kepa" vs "Kepa Arrizabalaga")
  for (let i = 0; i < candidates.length; i++) {
    if (used.has(i)) continue;
    const c = norm(candidates[i].name);
    if (c === n || c.startsWith(n + " ") || c.endsWith(" " + n) || n.startsWith(c + " ") || n.endsWith(" " + c)) return i;
  }
  // 3) фамилия + первая буква имени
  for (let i = 0; i < candidates.length; i++) {
    if (used.has(i)) continue;
    const c = norm(candidates[i].name);
    if (lastName(c) === lastName(n) && c[0] === n[0]) return i;
  }
  return -1;
}

const report = [];
for (const id of Object.keys(wiki)) {
  const w = wiki[id];
  if (w.error) { report.push({ id, error: w.error }); continue; }
  const proj = project[id] || [];
  const wikiReal = w.squad.filter(p => !/on loan from/i.test(p.other) ? true : true); // аренды В клуб — это актуальные игроки
  const used = new Set();
  const matches = [];
  const left = [];   // есть в проекте, нет в реальности
  for (const p of proj) {
    const idx = findMatch(p.name, wikiReal, used);
    if (idx === -1) left.push(p.name);
    else { used.add(idx); matches.push({ proj: p.name, wiki: wikiReal[idx].name }); }
  }
  const added = wikiReal.filter((_, i) => !used.has(i)); // есть в реальности, нет в проекте
  report.push({
    id, title: w.title,
    projCount: proj.length, wikiCount: wikiReal.length,
    left, added: added.map(a => ({ name: a.name, pos: a.pos, nat: a.nat, target: a.target, other: a.other })),
    nameDiffs: matches.filter(m => norm(m.proj) !== norm(m.wiki)),
  });
}

fs.writeFileSync("_work/diff.json", JSON.stringify(report, null, 1));
let totL = 0, totA = 0;
for (const r of report) {
  totL += (r.left || []).length; totA += (r.added || []).length;
  console.log(`\n### ${r.id} (${r.title}) proj=${r.projCount} wiki=${r.wikiCount}`);
  if (r.left?.length) console.log("  УШЛИ:", r.left.join(" | "));
  if (r.added?.length) console.log("  ПРИШЛИ:", r.added.map(a => `${a.name} (${a.pos})`).join(" | "));
  if (r.nameDiffs?.length) console.log("  РАЗНОЧТЕНИЯ:", r.nameDiffs.map(d => `${d.proj} ~ ${d.wiki}`).join(" | "));
}
console.log("\nTOTAL LEFT:", totL, "TOTAL ADDED:", totA);
