// Батчами скачивает страницы игроков и извлекает ДР / позицию / национальность
import fs from "node:fs";

const targets = JSON.parse(fs.readFileSync("_work/targets.json", "utf8"));
const uniq = [...new Set(targets.map(t => (t.rawTarget || "").trim()).filter(Boolean))];
console.log("unique titles:", uniq.length);

const UA = { "User-Agent": "Mozilla/5.0 SquadCheckBot/1.0 (contact: research@example.org)" };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function fetchBatch(titles) {
  const url = "https://en.wikipedia.org/w/api.php?action=query&prop=revisions&rvslots=main&rvprop=content" +
    "&format=json&formatversion=2&redirects=1&titles=" + encodeURIComponent(titles.join("|"));
  for (let a = 0; a < 5; a++) {
    const res = await fetch(url, { headers: UA });
    const txt = await res.text();
    if (txt.startsWith("{")) return JSON.parse(txt);
    console.log("  RL wait", a + 1);
    await sleep(12000 + a * 8000);
  }
  return null;
}

function posMap(s) {
  const t = (s || "").toLowerCase();
  if (/goalkeeper/.test(t)) return "GK";
  if (/winger|striker|forward|centre-forward|second striker/.test(t)) return "FW";
  if (/back|defender|defence/.test(t)) return "DF";
  if (/midfield/.test(t)) return "MF";
  return "";
}

const COUNTRY = {
  england: "ENG", scotland: "SCO", wales: "WAL", "northern ireland": "NIR", ireland: "IRL", "republic of ireland": "IRL",
  france: "FRA", germany: "GER", spain: "ESP", italy: "ITA", portugal: "POR", netherlands: "NED", belgium: "BEL",
  brazil: "BRA", argentina: "ARG", uruguay: "URU", colombia: "COL", chile: "CHI", peru: "PER", venezuela: "VEN", ecuador: "ECU", paraguay: "PAR",
  nigeria: "NGA", ghana: "GHA", senegal: "SEN", cameroon: "CMR", morocco: "MAR", algeria: "ALG", egypt: "EGY", mali: "MLI",
  "ivory coast": "CIV", "burkina faso": "BFA", guinea: "GUI", togo: "TOG", benin: "BEN", gabon: "GAB", congo: "CGO",
  "democratic republic of the congo": "COD", "dr congo": "COD", "south africa": "RSA", zimbabwe: "ZIM", zambia: "ZAM", kenya: "KEN", tanzania: "TAN", uganda: "UGA",
  usa: "USA", "united states": "USA", canada: "CAN", mexico: "MEX", jamaica: "JAM", "trinidad and tobago": "TRI", "costa rica": "CRC", honduras: "HON", panama: "PAN",
  japan: "JPN", "south korea": "KOR", korea: "KOR", australia: "AUS", "new zealand": "NZL", china: "CHN", "saudi arabia": "KSA",
  croatia: "CRO", serbia: "SRB", bosnia: "BIH", "bosnia and herzegovina": "BIH", slovenia: "SVN", slovakia: "SVK", czechia: "CZE", "czech republic": "CZE",
  poland: "POL", ukraine: "UKR", russia: "RUS", hungary: "HUN", romania: "ROU", bulgaria: "BUL", greece: "GRE", turkey: "TUR",
  austria: "AUT", switzerland: "SUI", denmark: "DEN", sweden: "SWE", norway: "NOR", finland: "FIN", iceland: "ISL",
  albania: "ALB", kosovo: "KVX", "north macedonia": "MKD", macedonia: "MKD", montenegro: "MNE", georgia: "GEO", armenia: "ARM", azerbaijan: "AZE",
  kazakhstan: "KAZ", israel: "ISR", cyprus: "CYP", malta: "MLT", belarus: "BLR", latvia: "LAT", lithuania: "LTU", estonia: "EST", moldova: "MDA",
  tunisia: "TUN", libya: "LBY", sudan: "SUD", ethiopia: "ETH", somalia: "SOM", eritrea: "ERI", angola: "ANG", mozambique: "MOZ",
  madagascar: "MAD", "cape verde": "CPV", "sierra leone": "SLE", liberia: "LBR", gambia: "GAM", "guinea-bissau": "GNB",
  "equatorial guinea": "EQG", "central african republic": "CTA", chad: "CHA", niger: "NIG", mauritania: "MTN", comoros: "COM",
  philippines: "PHI", indonesia: "IDN", malaysia: "MAS", singapore: "SGP", thailand: "THA", vietnam: "VIE", india: "IND", iran: "IRN", iraq: "IRQ",
  qatar: "QAT", "united arab emirates": "UAE", uzbekistan: "UZB", suriname: "SUR", curacao: "CUW", "curaçao": "CUW", haiti: "HAI",
  grenada: "GRN", barbados: "BRB", "saint lucia": "LCA", bermuda: "BER", fiji: "FIJ", luxembourg: "LUX", liechtenstein: "LIE",
  portugal: "POR", angola: "ANG", scandinavia: "", martinique: "MTQ", guadeloupe: "GLP", "french guiana": "GUF", reunion: "REU",
};

function natFromWt(wt) {
  // {{fb|ENG}} / {{fbu|21|FRA}} / {{fbw|...}}
  let m = wt.match(/nationalteam1\s*=\s*\{\{(?:fb|fbu|fbw|fb-big|fswu)\|(?:\d+\|)?([A-Za-z]{2,4})/);
  if (m) return m[1].toUpperCase().slice(0, 3);
  m = wt.match(/nationalteam1\s*=\s*\[\[([^\]|]+)/);
  if (m) {
    const c = COUNTRY[m[1].replace(/national.*$/i, "").trim().toLowerCase()];
    if (c) return c;
  }
  // birth_place = [[City]], [[Country]]
  m = wt.match(/birth_place\s*=\s*[^\n]*/);
  if (m) {
    const line = m[0];
    const links = [...line.matchAll(/\[\[([^\]|]+)(?:\|[^\]]*)?\]\]/g)].map(x => x[1].toLowerCase());
    for (let i = links.length - 1; i >= 0; i--) {
      if (COUNTRY[links[i]]) return COUNTRY[links[i]];
    }
  }
  // категории: English men's footballers
  m = wt.match(/Category:(\w[\w -]*?) (?:men's|footballers|international)/i);
  const DEM = { english: "ENG", scottish: "SCO", welsh: "WAL", french: "FRA", german: "GER", spanish: "ESP", italian: "ITA", portuguese: "POR", dutch: "NED", belgian: "BEL", brazilian: "BRA", argentine: "ARG", nigerian: "NGA", ghanaian: "GHA", irish: "IRL" };
  if (m && DEM[m[1].toLowerCase()]) return DEM[m[1].toLowerCase()];
  return "";
}

function dobFromWt(wt) {
  let m = wt.match(/birth[_ ]date\s*=\s*\{\{[^}|]*\|(?:df=[a-z]+\|)?(\d{4})\|(\d{1,2})\|(\d{1,2})/i);
  if (m) return { y: +m[1], m: +m[2], d: +m[3] };
  m = wt.match(/birth[_ ]date\s*=\s*(?:\{\{[^}]*\}\}\s*)?(\d{1,2})\s+(\w+)\s+(\d{4})/i);
  if (m) {
    const months = { january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
    const mm = months[m[2].toLowerCase()];
    if (mm) return { y: +m[3], m: mm, d: +m[1] };
  }
  return null;
}

const meta = {};
const missing = [];
for (let i = 0; i < uniq.length; i += 40) {
  const batch = uniq.slice(i, i + 40);
  await sleep(2000);
  const j = await fetchBatch(batch);
  if (!j || !j.query) { missing.push(...batch); continue; }
  for (const p of j.query.pages) {
    if (p.missing) { continue; }
    const wt = p.revisions?.[0]?.slots?.main?.content || "";
    if (!wt) continue;
    meta[p.title] = {
      dob: dobFromWt(wt),
      pos: posMap((wt.match(/\|\s*position\s*=([^\n]*)/) || [])[1] || ""),
      nat: natFromWt(wt),
    };
  }
  process.stdout.write(`\r${i + batch.length}/${uniq.length}`);
}
// мапим обратно на исходные rawTarget через redirects/normalized
fs.writeFileSync("_work/player_meta.json", JSON.stringify({ meta, missing }, null, 1));
console.log("\nmeta:", Object.keys(meta).length, "missing:", missing.length);
