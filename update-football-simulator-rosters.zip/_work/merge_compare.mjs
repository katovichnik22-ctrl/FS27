// Объединяет navbox (кто в составе) + секцию клуба (позиция/нац.) и сравнивает с проектом
import fs from "node:fs";

const nav = JSON.parse(fs.readFileSync("_work/nav_squads.json", "utf8"));
const sec = JSON.parse(fs.readFileSync("_work/wiki_squads.json", "utf8"));
const proj = JSON.parse(fs.readFileSync("_work/project_players.json", "utf8"));

const norm = (s) => (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
  .replace(/[.'’()-]/g, " ").replace(/\s+/g, " ").trim();
const lastN = (s) => { const p = norm(s).split(" "); return p[p.length - 1] || ""; };

function matchIdx(name, cand, used) {
  const n = norm(name);
  const keys = [n];
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const cands = [norm(cand[i].name), norm(cand[i].target), norm(cand[i].display)];
    if (cands.some(c => c && keys.includes(c))) return i;
  }
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const c = norm(cand[i].name || cand[i].target);
    if (!c) continue;
    if (c === n || c.startsWith(n + " ") || c.endsWith(" " + n) || n.startsWith(c + " ") || n.endsWith(" " + c)) return i;
  }
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const c = norm(cand[i].name || cand[i].target);
    if (c && lastN(c) === lastN(n) && c[0] === n[0]) return i;
  }
  return -1;
}

const report = {};
for (const id of Object.keys(nav)) {
  const n = nav[id];
  const s = sec[id] || { squad: [] };
  if (n.error) { report[id] = { error: n.error }; continue; }
  // реальные игроки: navbox как источник истины + поз/нац из секции
  const secUsed = new Set();
  const real = n.squad.map(p => {
    const idx = matchIdx(p.name, s.squad, secUsed) >= 0 ? matchIdx(p.target, s.squad, secUsed) : matchIdx(p.target, s.squad, secUsed);
    let pos = "", nat = "";
    const j = matchIdx(p.target || p.name, s.squad, secUsed);
    if (j >= 0) { secUsed.add(j); pos = s.squad[j].pos; nat = s.squad[j].nat; }
    return { name: p.name, target: p.target, pos, nat, no: p.no };
  });
  // сравнение с проектом
  const projPlayers = proj[id]?.players || [];
  const used = new Set();
  const kept = [], left = [];
  for (const p of projPlayers) {
    const i = matchIdx(p.name, real, used);
    if (i === -1) left.push(p);
    else { used.add(i); kept.push({ proj: p, wiki: real[i] }); }
  }
  const added = real.filter((_, i) => !used.has(i));
  report[id] = {
    club: proj[id]?.name, projCount: projPlayers.length, realCount: real.length,
    kept: kept.length, left: left.map(p => p.name),
    added, missingMeta: added.filter(a => !a.pos || !a.nat).map(a => a.target || a.name),
  };
}
fs.writeFileSync("_work/diff2.json", JSON.stringify(report, null, 1));
let tl = 0, ta = 0;
for (const [id, r] of Object.entries(report)) {
  tl += (r.left || []).length; ta += (r.added || []).length;
  console.log(`\n## ${id} proj=${r.projCount} real=${r.realCount} kept=${r.kept}`);
  if (r.left?.length) console.log(" LEFT :", r.left.join(" | "));
  if (r.added?.length) console.log(" ADD  :", r.added.map(a => `${a.name}${a.pos ? "(" + a.pos + ")" : "(pos?)${a.nat}"}`).join(" | ").replace(/\$\{a.nat\}/g, ""));
  if (r.missingMeta?.length) console.log(" META?:", r.missingMeta.join(" | "));
}
console.log("\nTOTAL LEFT", tl, "ADD", ta);
