// Генерирует обновлённые составы АПЛ и Чемпионшипа и переписывает data-файлы проекта
import fs from "node:fs";

const nav = JSON.parse(fs.readFileSync("_work/nav_squads.json", "utf8"));
const sec = JSON.parse(fs.readFileSync("_work/wiki_squads.json", "utf8"));
const proj = JSON.parse(fs.readFileSync("_work/project_players.json", "utf8"));
const { meta } = JSON.parse(fs.readFileSync("_work/player_meta.json", "utf8"));

const norm = (s) => (s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
  .replace(/[.'’()\[\]-]/g, " ").replace(/\s+/g, " ").trim();
const lastN = (s) => { const p = norm(s).split(" ").filter(Boolean); return p[p.length - 1] || ""; };
const firstN = (s) => { const p = norm(s).split(" ").filter(Boolean); return p[0] || ""; };

function lev(a, b) {
  const m = a.length, n = b.length;
  if (!m) return n; if (!n) return m;
  const d = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
  for (let j = 1; j <= n; j++) d[0][j] = j;
  for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++)
    d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[m][n];
}

function matchIdx(name, cand, used) {
  const n = norm(name);
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const cs = [norm(cand[i].name), norm(cand[i].target), norm(cand[i].display)];
    if (cs.includes(n)) return i;
  }
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const c = norm(cand[i].name || cand[i].target);
    if (!c) continue;
    if (c.startsWith(n + " ") || c.endsWith(" " + n) || n.startsWith(c + " ") || n.endsWith(" " + c)) return i;
  }
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const c = norm(cand[i].name || cand[i].target);
    if (c && lastN(c) === lastN(n) && firstN(c)[0] === firstN(n)[0]) return i;
  }
  for (let i = 0; i < cand.length; i++) {
    if (used.has(i)) continue;
    const c = norm(cand[i].name || cand[i].target);
    if (!c) continue;
    if (firstN(c) === firstN(n) && lev(lastN(c), lastN(n)) <= 2) return i;
  }
  return -1;
}

// индекс метаданных: нормализованный title (+ версия без скобок)
const metaByKey = new Map();
for (const [title, m2] of Object.entries(meta)) {
  metaByKey.set(norm(title), m2);
  metaByKey.set(norm(title.replace(/\s*\([^)]*\)\s*/g, "")), m2);
}
function metaFor(w) {
  const keys = [norm(w.rawTarget), norm(w.target), norm(w.name)]
    .map(k => k.replace(/\s*\([^)]*\)\s*/g, " ").replace(/\s+/g, " ").trim());
  for (const k of keys) if (metaByKey.has(k)) return metaByKey.get(k);
  for (const [, mx] of metaByKey) { /* skip global fuzzy for speed */ }
  return null;
}

const ageOn2026 = (dob) => {
  let a = 2026 - dob.y;
  if (dob.m > 9 || (dob.m === 9 && dob.d > 20)) a -= 1;
  return a;
};

const hashJit = (s, span) => { // детерминированный «джиттер» -span..span
  let h = 0; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return (h % (2 * span + 1)) - span;
};

const VALID_POS = new Set(["GK", "DF", "MF", "FW"]);
const changelog = {};

function estimateRatings(pos, ovr, name) {
  ovr = Math.max(55, Math.min(90, ovr));
  if (pos === "GK") return { att: 12 + ((14 + hashJit(name, 6)) % 18), def: 45, ovr, gk: ovr };
  if (pos === "DF") return { att: Math.max(34, Math.min(62, 40 + hashJit(name, 9))), def: ovr, ovr, gk: undefined };
  if (pos === "MF") return { att: Math.max(48, ovr - 8 + hashJit(name, 2)), def: Math.max(45, ovr - 8 + hashJit(name + "d", 2)), ovr, gk: undefined };
  return { att: Math.min(92, ovr + 1), def: 38 + hashJit(name, 6) + 6, ovr, gk: undefined };
}

const teams = {}; // id -> final payload
for (const id of Object.keys(nav)) {
  if (nav[id].error) continue;
  const pClub = proj[id];
  const sClub = sec[id] || { squad: [] };
  const realRaw = nav[id].squad;
  // позиция/нация из секции клуба
  const secUsed = new Set();
  const real = realRaw.map(w => {
    const j = matchIdx(w.name, sClub.squad, secUsed);
    let spos = "", snat = "";
    if (j >= 0) { secUsed.add(j); spos = sClub.squad[j].pos; snat = sClub.squad[j].nat; }
    return { ...w, spos, snat };
  });
  // матчинг к игрокам проекта (оставляем рейтинги)
  const projPlayers = pClub.players;
  const usedP = new Set();
  const bindings = real.map(w => {
    const j = matchIdx(w.name, projPlayers, usedP);
    if (j >= 0) { usedP.add(j); return projPlayers[j]; }
    return null;
  });
  // базовые линии для оценки новичков
  const baseByPos = { GK: [], DF: [], MF: [], FW: [] };
  projPlayers.forEach((p, i) => { if (usedP.has(i)) baseByPos[p.pos]?.push(p.ovr); });
  const fallbackAvg = projPlayers.filter((p, i) => usedP.has(i)).reduce((s, p, _, a) => s + p.ovr / a.length, 0);
  const base = (pos) => (baseByPos[pos]?.length ? baseByPos[pos].reduce((s, x) => s + x, 0) / baseByPos[pos].length : (fallbackAvg || 74));

  const finalRows = [];
  const usedNames = new Set();
  real.forEach((w, i) => {
    const mp = bindings[i];
    const m2 = metaFor(w);
    let pos = VALID_POS.has(w.spos) ? w.spos : (m2 && VALID_POS.has(m2.pos) ? m2.pos : (mp?.pos || "MF"));
    let nat = /^[A-Z]{3}$/.test(w.snat) ? w.snat : (/^[A-Z]{3}$/.test(m2?.nat || "") ? m2.nat : (mp?.nat || "ENG"));
    let age = mp?.age ?? 24;
    if (m2?.dob) age = ageOn2026(m2.dob); else if (!mp) age = 22;
    let name = w.name.replace(/\s+/g, " ").trim();
    if (usedNames.has(norm(name))) name = `${name} ${i + 1}`; // страховка от дублей
    usedNames.add(norm(name));
    let row;
    if (mp) {
      row = [name, pos, age, nat, mp.att, mp.def, mp.ovr];
      if (pos === "GK") row.push(mp.gk ?? mp.ovr);
    } else {
      let ovr = Math.round(base(pos) - 2 + hashJit(name, 2));
      if (age <= 19) ovr -= 2; if (age <= 17) ovr -= 1;
      const r = estimateRatings(pos, ovr, name);
      row = [name, pos, age, nat, r.att, r.def, r.ovr];
      if (pos === "GK") row.push(r.gk);
    }
    finalRows.push(row);
  });

  // пересчёт рейтингов команды: 55% старое + 45% топ-линии
  const line = (pos, k) => {
    const arr = finalRows.filter(r => r[1] === pos).map(r => r[6]).sort((a, b) => b - a).slice(0, k);
    return arr.length ? arr.reduce((s, x) => s + x, 0) / arr.length : 70;
  };
  const gkTop = Math.max(...finalRows.filter(r => r[1] === "GK").map(r => r[7] ?? r[6]), 70);
  const mix = (oldV, newV) => Math.max(60, Math.min(92, Math.round(0.55 * oldV + 0.45 * newV)));
  teams[id] = {
    ...{ name: pClub.name, short: pClub.short, color: pClub.color, rep: pClub.rep, budget: pClub.budget, stadium: pClub.stadium },
    att: mix(pClub.att, line("FW", 5) + 2),
    mid: mix(pClub.mid, (line("MF", 5) + line("FW", 3)) / 2),
    def: mix(pClub.def, (line("DF", 5) + gkTop) / 2),
    gk: mix(pClub.gk, gkTop),
    players: finalRows,
  };
  changelog[id] = {
    club: pClub.name, before: projPlayers.length, after: finalRows.length,
    left: projPlayers.filter((p, i) => !usedP.has(i)).map(p => p.name),
    added: real.filter((w, i) => !bindings[i]).map(w => w.name),
  };
}
fs.writeFileSync("_work/final_teams.json", JSON.stringify(teams, null, 1));
fs.writeFileSync("_work/changelog.json", JSON.stringify(changelog, null, 1));
let tl = 0, ta = 0;
for (const [id, c] of Object.entries(changelog)) { tl += c.left.length; ta += c.added.length; }
console.log("teams:", Object.keys(teams).length, "players:", Object.values(teams).reduce((s, t) => s + t.players.length, 0), "left:", tl, "added:", ta);
