// Скачивает актуальные составы 44 клубов (АПЛ + Чемпионшип 2026/27) из Википедии
import fs from "node:fs";

const CLUBS = JSON.parse(fs.readFileSync("_work/clubs.json", "utf8"));
const UA = { "User-Agent": "Mozilla/5.0 SquadCheckBot/1.0 (contact: research@example.org)" };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function fetchWikitext(title) {
  const url = "https://en.wikipedia.org/w/api.php?action=parse&page=" + encodeURIComponent(title) +
    "&prop=wikitext&format=json&redirects=1&formatversion=2";
  for (let attempt = 0; attempt < 6; attempt++) {
    const res = await fetch(url, { headers: UA });
    const txt = await res.text();
    if (txt.startsWith("{")) {
      const j = JSON.parse(txt);
      if (j.parse) return j.parse.wikitext;
      return null;
    }
    console.log("  rate-limited, waiting... attempt", attempt + 1);
    await sleep(15000 + attempt * 10000);
  }
  return null;
}

function cleanName(raw) {
  if (!raw) return "";
  let s = raw.trim();
  const sm = s.match(/\{\{sortname\|([^|}]+)\|([^|}]+)/i);
  if (sm) s = sm[1] + " " + sm[2];
  const nat = s.match(/\{\{(?:nat[fs]?|flag[a-z]*)\|[^}]*\}\}/i);
  if (nat) s = s.replace(nat[0], "");
  const lm = s.match(/\[\[([^\]]+)\]\]/);
  if (lm) {
    const inner = lm[1];
    s = inner.includes("|") ? inner.split("|").pop() : inner;
  }
  s = s.replace(/\{\{[^}]*\}\}/g, "").replace(/\[\[|\]\]/g, "").replace(/''/g, "").replace(/<[^>]+>/g, "").trim();
  return s;
}

function linkTarget(raw) {
  const lm = raw && raw.match(/\[\[([^\]]+)\]\]/);
  if (!lm) return "";
  return lm[1].split("|")[0].trim();
}

function section(wt, re) {
  const m = wt.match(re);
  if (!m) return "";
  const start = m.index + m[0].length;
  const rest = wt.slice(start);
  const end = rest.search(/\n===[^=]/);
  return end === -1 ? rest : rest.slice(0, end);
}

function parsePlayers(text) {
  const out = [];
  const re = /\{\{(?:fs|football squad) player\s*\|([^}]*)\}\}/gi;
  let m;
  while ((m = re.exec(text))) {
    const params = {};
    for (const part of m[1].split("|")) {
      const kv = part.split("=");
      if (kv.length >= 2) params[kv[0].trim().toLowerCase()] = kv.slice(1).join("=").trim();
    }
    const name = cleanName(params.name || "");
    if (!name) continue;
    out.push({
      name,
      target: linkTarget(params.name || ""),
      pos: (params.pos || "").toUpperCase(),
      nat: (params.nat || "").toUpperCase(),
      other: (params.other || "").replace(/\[\[([^\]|]*\|)?([^\]]*)\]\]/g, "$2"),
      no: params.no || "",
    });
  }
  return out;
}

function splitLoans(secText) {
  // Разрезаем секцию на основную часть и ====Out on loan====
  const m = secText.match(/\n={3,4}\s*Out on loan\s*={3,4}/i);
  const main = m ? secText.slice(0, m.index) : secText;
  const loans = m ? secText.slice(m.index + m[0].length) : "";
  return { main, loans };
}

const result = {};
let done = 0;
for (const [id, title] of Object.entries(CLUBS)) {
  await sleep(2500);
  const wt = await fetchWikitext(title);
  done++;
  if (!wt) { result[id] = { error: "no page", title }; console.log("FAIL", id, title); continue; }
  const re = /\n===\s*(Current squad|First[- ]team squad|First team squad|Men's squad|Playing squad|Senior squad|Current first-team squad|Current first team squad|First-team|First team)\s*===/i;
  let sec = section(wt, re);
  let squad, loans = [], mode = "section";
  if (!sec) {
    const { main, loans: ls } = splitLoans(wt);
    squad = parsePlayers(main);
    loans = parsePlayers(ls);
    mode = "whole-page";
  } else {
    const { main, loans: ls } = splitLoans(sec);
    squad = parsePlayers(main);
    loans = parsePlayers(ls);
  }
  result[id] = { title, mode, squad, outOnLoan: loans };
  console.log(String(done).padStart(2), id.padEnd(18), "squad:", String(squad.length).padStart(3), "loans:", String(loans.length).padStart(2), mode);
}
fs.writeFileSync("_work/wiki_squads.json", JSON.stringify(result, null, 1));
console.log("SAVED");
