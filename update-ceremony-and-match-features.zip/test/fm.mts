import { MAIN_DB, deepClone } from "../src/data/db";
import { simulateMatch } from "../src/engine/match";
import { defaultTactics } from "../src/engine/tactics";
import type { Team } from "../src/types";
const teams = deepClone(MAIN_DB) as Record<string, Team>;
const tac: Record<string,any> = {}; for (const t of Object.values(teams)) tac[t.id] = defaultTactics(t);

const r = simulateMatch(teams["arsenal"], teams["liverpool"], { seed: 42, homeTactics: tac.arsenal, awayTactics: tac.liverpool });
console.log(`1) ${r.homeName} ${r.homeScore}:${r.awayScore} ${r.awayName} · погода ${r.weather} · ${r.totalMinutes}'`);
const s = r.stats;
console.log(`   владение ${s.possessionH}/${s.possessionA} · удары ${s.shotsH}/${s.shotsA} (в створ ${s.sotH}/${s.sotA}) · xG ${s.xgH}/${s.xgA}`);
console.log(`   пасы ${s.passesH}/${s.passesA} точность ${s.passAccH}%/${s.passAccA}% · угловые ${s.cornersH}/${s.cornersA} · офсайды ${s.offsidesH}/${s.offsidesA}`);
console.log(`   фолы ${s.foulsH}/${s.foulsA} · ЖК ${s.yellowH}/${s.yellowA} · КК ${s.redH}/${s.redA} · сейвы ${s.savesH}/${s.savesA} · пен ${s.penaltiesH}/${s.penaltiesA} · big chances ${s.bigChancesH}/${s.bigChancesA}`);
const types = new Map<string,number>(); for (const e of r.events) types.set(e.type,(types.get(e.type)??0)+1);
console.log(`2) События: ${[...types].map(([k,v])=>`${k}:${v}`).join(" ")}`);
const top = r.topPerformers.map(t=>{const p=[...Object.values(teams)].flatMap(x=>x.players).find(p=>p.id===t.playerId)!;return `${p.name} ${t.rating}`;});
console.log(`3) Топ-3: ${top.join(" | ")}`);
const ex = Object.entries(r.playerMatchStats).sort((a,b)=>b[1].rating-a[1].rating)[0];
const exP = Object.values(teams).flatMap(t=>t.players).find(p=>p.id===ex[0])!;
console.log(`   ${exP.name}: ${ex[1].minutes}' голы ${ex[1].goals} пасы ${ex[1].assists} удары ${ex[1].shots}/${ex[1].shotsOnTarget} xG ${ex[1].xg} кл.пас ${ex[1].keyPasses} отборы ${ex[1].tackles} перехв ${ex[1].interceptions} дриблинг ${ex[1].dribbles} точн.пас ${ex[1].passesOk}/${ex[1].passes} рейтинг ${ex[1].rating}`);

// воспроизводимость
const r2 = simulateMatch(teams["arsenal"], teams["liverpool"], { seed: 42, homeTactics: tac.arsenal, awayTactics: tac.liverpool });
console.log(`4) Seed-воспроизводимость:`, JSON.stringify(r)===JSON.stringify(r2)?"OK":"FAIL");

// лига целиком
let g=0,n=0,pen=0,red=0,inj=0,xg=0,poss=0, sot=0, sh=0;
const ids=Object.values(teams).filter(t=>t.league==="PL").map(t=>t.id);
let seed=1;
for (const h of ids) for (const a of ids) { if(h===a) continue;
  const m = simulateMatch(teams[h],teams[a],{seed:seed++,homeTactics:tac[h],awayTactics:tac[a]});
  g+=m.homeScore+m.awayScore; n++; pen+=m.stats.penaltiesH+m.stats.penaltiesA;
  red+=m.stats.redH+m.stats.redA; inj+=m.injuries.length; xg+=m.stats.xgH+m.stats.xgA;
  poss+=m.stats.possessionH; sot+=m.stats.sotH+m.stats.sotA; sh+=m.stats.shotsH+m.stats.shotsA;
}
console.log(`5) 380 матчей: голов/матч ${(g/n).toFixed(2)} · xG/матч ${(xg/n).toFixed(2)} · ударов ${(sh/n).toFixed(1)} · в створ ${(sot/n).toFixed(1)}`);
console.log(`   пенальти ${(pen/n).toFixed(2)}/матч · КК ${(red/n).toFixed(3)}/матч · травм ${(inj/n).toFixed(3)}/матч · владение дома ${(poss/n).toFixed(1)}%`);

// усталость за 5 матчей
const t2 = deepClone(MAIN_DB) as Record<string,Team>;
const { applyResult } = await import("../src/engine/season");
const fakeSlot: any = { teams: t2, tactics: tac, selectedLeagues:["PL"], season:{fixtures:[]} };
let fit0 = t2["arsenal"].players[0].fitness;
for (let i=0;i<5;i++) {
  const m = simulateMatch(t2["arsenal"], t2["chelsea"], { seed: 900+i, homeTactics: tac.arsenal, awayTactics: tac.chelsea });
  applyResult(fakeSlot, { id:`f${i}`, comp:"PL", stage:"MD1", matchday:1, date:"2026-08-15", homeId:"arsenal", awayId:"chelsea", neutral:false, played:false, result:null } as any, m);
}
const starters = t2["arsenal"].players.filter(p=>p.stats.apps>=4);
console.log(`6) После 5 матчей: игроков с 4+ матчами ${starters.length}, свежесть ${Math.min(...starters.map(p=>p.fitness)).toFixed(0)}–${Math.max(...starters.map(p=>p.fitness)).toFixed(0)} (было ${fit0})`);
const inj2 = Object.values(t2).flatMap(t=>t.players).filter(p=>p.injury);
console.log(`   травмированы: ${inj2.length ? inj2.map(p=>`${p.name} (${p.injury!.label}, ${p.injury!.daysLeft}д)`).join(", ") : "нет"}`);
const forms = starters.map(p=>p.form);
console.log(`   форма ${Math.min(...forms).toFixed(2)}–${Math.max(...forms).toFixed(2)} · мораль ${Math.min(...starters.map(p=>p.morale)).toFixed(0)}–${Math.max(...starters.map(p=>p.morale)).toFixed(0)}`);
console.log("7) MAIN_DB не изменилась:", MAIN_DB["arsenal"].players[0].fitness===100?"OK":"FAIL");
