// Интеграционный тест режима наблюдателя лиги (после фикса архитектуры)
const store = new Map<string, string>();
(globalThis as any).localStorage = {
  getItem: (k: string) => store.get(k) ?? null,
  setItem: (k: string, v: string) => store.set(k, v),
  removeItem: (k: string) => store.delete(k),
};

const { MAIN_DB } = await import("../src/data/db");
const { createSlot, saveSlot, loadSlot, listSlots, exportSlot, importSlot, deleteSlot, startNextSeason } =
  await import("../src/engine/storage");
const {
  advanceDay, advanceMatchday, advanceToDate, advanceToEndOfSeason, buildTable, leaderboard,
  moveFixture, addFriendly, shiftMatchday, validateSchedule, regenerateLeague, nextMatchDate,
  skipToNextMatchDay, LEAGUE_CFG, LEAGUE_IDS,
} = await import("../src/engine/season");
const { finishSeason } = await import("../src/engine/ratings");
const { executeTransfer, validateTransfer, isWindowOpen, releasePlayer } = await import("../src/engine/transfers");
const { autoStarters, FORMATIONS, STYLES } = await import("../src/engine/tactics");
const { simulateMatch } = await import("../src/engine/match");

const mainBefore = JSON.stringify(MAIN_DB);

// 1. Создание сезона БЕЗ выбора клуба
const t0 = Date.now();
const slot = createSlot({ leagues: ["PL", "LL", "FL1"] });
console.log(`1) createSlot() без аргументов: ${Date.now() - t0}мс, клубов ${Object.keys(slot.teams).length}, матчей ${slot.season.fixtures.length}, тактик ${Object.keys(slot.tactics).length}, св. агентов ${slot.freeAgents.length}`);
console.log(`   playerTeamId отсутствует в слоте:`, !("playerTeamId" in slot) ? "OK" : "FAIL");
console.log(`   Тактика есть у каждого клуба:`, Object.keys(slot.tactics).length === Object.keys(slot.teams).length ? "OK" : "FAIL");
const xiOk = Object.entries(slot.tactics).every(([, t]) => t.starters.length === 11 && t.captain && t.penaltyTaker);
console.log(`   У всех по 11 стартовых + роли:`, xiOk ? "OK" : "FAIL");

// 2. Клубы АПЛ
const plIds = Object.values(slot.teams).filter(t => t.league === "PL").map(t => t.id);
console.log(`2) Клубов АПЛ: ${plIds.length} →`, plIds.length === 20 ? "OK" : "FAIL");

// 3-4. Смена схемы Arsenal
const before = slot.tactics["arsenal"].formation;
slot.tactics["arsenal"] = { ...slot.tactics["arsenal"], formation: "4-4-2", starters: autoStarters(slot.teams["arsenal"], "4-4-2") };
saveSlot(slot);
const reloaded = loadSlot(slot.slotId)!;
const ars = reloaded.tactics["arsenal"];
const arsPlayers = ars.starters.map(id => reloaded.teams["arsenal"].players.find(p => p.id === id)!);
const shape = { DF: arsPlayers.filter(p => p.position === "DF").length, MF: arsPlayers.filter(p => p.position === "MF").length, FW: arsPlayers.filter(p => p.position === "FW").length };
console.log(`3-4) Arsenal ${before} → ${ars.formation}, состав ${shape.DF}-${shape.MF}-${shape.FW} →`,
  ars.formation === "4-4-2" && shape.DF === 4 && shape.MF === 4 && shape.FW === 2 ? "OK" : "FAIL");

// 5. Трансфер Chelsea → Arsenal
const palmer = slot.teams["chelsea"].players.find(p => p.name === "Cole Palmer")!;
const cheBefore = slot.teams["chelsea"].players.length;
const arsBefore = slot.teams["arsenal"].players.length;
const arsBudget = slot.teams["arsenal"].budget;
console.log(`5) Окно на ${slot.currentDate} открыто:`, isWindowOpen(slot.currentDate) ? "OK" : "FAIL");
executeTransfer(slot, { fromId: "chelsea", toId: "arsenal", playersOut: [palmer.id], playersBack: [], fee: 80 });
const inArs = slot.teams["arsenal"].players.some(p => p.id === palmer.id);
const inChe = slot.teams["chelsea"].players.some(p => p.id === palmer.id);
console.log(`   Palmer: Chelsea ${cheBefore}→${slot.teams["chelsea"].players.length}, Arsenal ${arsBefore}→${slot.teams["arsenal"].players.length}, у Arsenal: ${inArs}, у Chelsea: ${inChe} →`,
  inArs && !inChe && slot.teams["chelsea"].players.length === cheBefore - 1 ? "OK" : "FAIL");
console.log(`   Бюджеты: Arsenal £${arsBudget}M→£${slot.teams["arsenal"].budget}M, Chelsea £${slot.teams["chelsea"].budget}M; сделок в истории ${slot.transfers.length} →`,
  slot.teams["arsenal"].budget === arsBudget - 80 && slot.transfers.length === 1 ? "OK" : "FAIL");
console.log(`   Состав Arsenal перестроен (Palmer в заявке):`, slot.tactics["arsenal"].starters.every(id => slot.teams["arsenal"].players.some(p => p.id === id)) ? "OK" : "FAIL");
// проверки
const badPlan = { fromId: "hull", toId: "arsenal", playersOut: slot.teams["hull"].players.slice(0, 14).map(p => p.id), playersBack: [], fee: 1 };
console.log(`   Блокировка «останется <11 игроков»:`, !validateTransfer(slot, badPlan).ok ? "OK" : "FAIL");
console.log(`   Блокировка «бюджет мал»:`, !validateTransfer(slot, { fromId: "chelsea", toId: "hull", playersOut: [slot.teams["chelsea"].players[0].id], playersBack: [], fee: 9999 }).ok ? "OK" : "FAIL");
// свободный агент
const fa = slot.freeAgents[0];
executeTransfer(slot, { fromId: null, toId: "everton", playersOut: [fa.id], playersBack: [], fee: 2 });
console.log(`   Свободный агент ${fa.name} → Everton:`, slot.teams["everton"].players.some(p => p.id === fa.id) ? "OK" : "FAIL");
// освобождение
const rel = slot.teams["everton"].players[slot.teams["everton"].players.length - 1];
releasePlayer(slot, "everton", rel.id);
console.log(`   Отпустили ${rel.name} в свободные агенты:`, slot.freeAgents.some(p => p.id === rel.id) ? "OK" : "FAIL");

// 5b. Межлиговый трансфер: Real Madrid → Arsenal
const vini = slot.teams["real_madrid"].players.find(p => p.name === "Vinícius Júnior")!;
executeTransfer(slot, { fromId: "real_madrid", toId: "arsenal", playersOut: [vini.id], playersBack: [], fee: 120 });
console.log(`   Межлиговый трансфер Vinícius (La Liga → PL):`,
  slot.teams["arsenal"].players.some(p => p.id === vini.id) && !slot.teams["real_madrid"].players.some(p => p.id === vini.id) ? "OK" : "FAIL");

// 6. Расписание
const fx = slot.season.fixtures.find(f => f.comp === "PL" && !f.played)!;
const oldDate = fx.date;
moveFixture(slot, fx.id, "2026-08-19");
console.log(`6) Перенос матча ${oldDate} → ${slot.season.fixtures.find(f => f.id === fx.id)!.date} →`,
  slot.season.fixtures.find(f => f.id === fx.id)!.date === "2026-08-19" ? "OK" : "FAIL");
shiftMatchday(slot, 10, 3);
addFriendly(slot, "leeds", "hull", "2026-08-12");
const issues = validateSchedule(slot.season.fixtures, slot.teams);
console.log(`   Сдвиг тура 10 (+3 дн.), товарищеский добавлен; замечаний валидатора: ${issues.length} (ошибок ${issues.filter(i => i.level === "error").length})`);
console.log(`   Перегенерация до старта:`, regenerateLeague(slot, "PL") && regenerateLeague(slot, "LL") ? "OK" : "FAIL");

// 7. Тактика Man City
slot.tactics["man_city"] = { ...slot.tactics["man_city"], style: "defensive", formation: "5-3-2", starters: autoStarters(slot.teams["man_city"], "5-3-2") };
console.log(`7) Man City → 5-3-2 / оборонительный; множители: атака ×${(FORMATIONS["5-3-2"].atk * STYLES.defensive.atk).toFixed(2)}, защита ×${(FORMATIONS["5-3-2"].def * STYLES.defensive.def).toFixed(2)} → OK`);

// 8. Тактики влияют на симуляцию
const home = slot.teams["man_city"], away = slot.teams["hull"];
let atkGoals = 0, defGoals = 0;
for (let i = 0; i < 60; i++) {
  atkGoals += simulateMatch(home, away, { seed: 1000 + i, homeTactics: { ...slot.tactics["man_city"], formation: "3-4-3", style: "attacking" } }).homeScore;
  defGoals += simulateMatch(home, away, { seed: 1000 + i, homeTactics: { ...slot.tactics["man_city"], formation: "5-3-2", style: "defensive" } }).homeScore;
}
console.log(`8) За 60 матчей City: 3-4-3 атак. ${atkGoals} голов vs 5-3-2 обор. ${defGoals} голов →`, atkGoals > defGoals ? "OK" : "FAIL");

// 5 туров
for (const lid of slot.selectedLeagues) for (let i = 0; i < 5; i++) advanceMatchday(slot, lid);
for (const lid of slot.selectedLeagues) {
  const ids = Object.values(slot.teams).filter(t => t.league === lid).map(t => t.id);
  const tb = buildTable(slot.season.fixtures, ids, LEAGUE_CFG[lid].comp);
  console.log(`   ${LEAGUE_CFG[lid].name}: лидер ${slot.teams[tb[0].teamId].name} ${tb[0].pts} очк, сыграно по ${Math.min(...tb.map(r=>r.p))}–${Math.max(...tb.map(r=>r.p))}; бомбардир ${leaderboard(slot,"goals",lid,1)[0]?.name} →`,
    tb.every(r => r.p >= 5) ? "OK" : "FAIL");
}
console.log(`   Ближайший игровой день ${nextMatchDate(slot)}`);
skipToNextMatchDay(slot);
advanceToDate(slot, "2026-10-01");
advanceDay(slot);
console.log(`   advanceToDate / skipToNextMatchDay работают, дата ${slot.currentDate}, сыграно ${slot.season.fixtures.filter(f => f.played).length}`);

// экспорт/импорт
const json = exportSlot(slot.slotId)!;
const imp = importSlot(json);
console.log(`   Экспорт ${(json.length / 1024 / 1024).toFixed(2)} МБ → импорт: тактики ${Object.keys(imp.tactics).length}, трансферы ${imp.transfers.length} →`,
  imp.slotId !== slot.slotId && Object.keys(imp.tactics).length > 0 ? "OK" : "FAIL");
deleteSlot(imp.slotId);

// до конца сезона + итоги
advanceToEndOfSeason(slot);
const report = finishSeason(slot);
saveSlot(slot);
const ch = report.champions;
console.log(`9) Чемпионы: PL ${slot.teams[ch.PL!].name} | LaLiga ${slot.teams[ch.LL!].name} | Ligue1 ${slot.teams[ch.FL1!].name} | UCL ${slot.teams[ch.UCL!].name} | UEL ${slot.teams[ch.UEL!].name}`);
console.log(`   Кубки: FA ${slot.teams[ch.FA!].name} | EFL ${slot.teams[ch.EFL!].name} | CDR ${slot.teams[ch.CDR!].name} | CDF ${slot.teams[ch.CDF!].name} →`,
  [ch.PL,ch.LL,ch.FL1,ch.UCL,ch.UEL,ch.FA,ch.EFL,ch.CDR,ch.CDF].every(Boolean) ? "OK" : "FAIL");
console.log(`   Рейтинги: ${report.improved[0].name} ${report.improved[0].oldOverall}→${report.improved[0].newOverall} (+${report.improved[0].delta}) | ${report.declined[0].name} ${report.declined[0].oldOverall}→${report.declined[0].newOverall} (${report.declined[0].delta})`);
const badDefs = report.all.filter(c => c.position === "DF" && c.apps >= 10 && c.avgRating < 5.5);
for (const lid of report.leagues) {
  const a = report.awardsByLeague[lid];
  console.log(`   ${LEAGUE_CFG[lid].name}: чемпион ${slot.teams[report.finalTables[lid][0].teamId].name} | Boot ${a.goldenBoot?.name} (${a.goldenBoot?.value})`);
}
console.log(`   Защитники с avgRating<5.5 (${badDefs.length}) — все в минусе:`, !badDefs.length || badDefs.every(c => c.delta < 0) ? "OK" : "FAIL");
const gks = report.all.filter(c => { const p = slot.teams[c.teamId].players.find(x => x.id === c.playerId)!; return p.position === "GK" && p.stats.cleanSheets >= 15; });
console.log(`   Вратари с 15+ сухими (${gks.length}) — все в плюсе:`, !gks.length || gks.every(c => c.delta > 0) ? "OK" : "FAIL");

// новый сезон
const s2 = startNextSeason(slot);
console.log(`10) Новый сезон №${s2.seasonNumber}: тактики сохранены (${Object.keys(s2.tactics).length}), трансферы обнулены (${s2.transfers.length}), матчей ${s2.season.fixtures.length} →`,
  s2.seasonNumber === 2 && Object.keys(s2.tactics).length > 0 && s2.transfers.length === 0 ? "OK" : "FAIL");

// независимость
const slotB = createSlot({ leagues: ["PL"] });
const rayaB = slotB.teams["arsenal"].players.find(p => p.name === "David Raya")!;
console.log(`11) Слот B независим: Raya ovr=${rayaB.overall}, MAIN_DB=${MAIN_DB["arsenal"].players.find(p => p.name === "David Raya")!.overall}; Palmer в Chelsea слота B:`,
  slotB.teams["chelsea"].players.some(p => p.name === "Cole Palmer") ? "OK" : "FAIL");
console.log("12) MAIN_DB не изменилась:", JSON.stringify(MAIN_DB) === mainBefore ? "OK" : "FAIL");
console.log(`13) Слотов: ${listSlots().length}, объём ${(store.get("fs_slots")!.length / 1024 / 1024).toFixed(2)} МБ`);
