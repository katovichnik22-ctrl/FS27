// Диагностика повышений/вылетов и плей-офф: npx tsx test/promotion.mts
const store: Record<string, string> = {};
(globalThis as any).localStorage = {
  getItem: (k: string) => store[k] ?? null,
  setItem: (k: string, v: string) => { store[k] = String(v); },
  removeItem: (k: string) => { delete store[k]; },
};

const { createSlot, startNextSeason, applyPromotions } = await import("../src/engine/storage");
const { advanceToEndOfSeason, LEAGUE_CFG } = await import("../src/engine/season");
const { finishSeason } = await import("../src/engine/ratings");

const leagueOf = (slot: any, lid: string) =>
  Object.values(slot.teams).filter((t: any) => t.league === lid).map((t: any) => t.name).sort();

// ── Сценарий A: только АПЛ (без Чемпионшипа), как по умолчанию в визарде ──
console.log("A) Слот: только PL, без связи лиг");
const a = createSlot({ leagues: ["PL"] });
advanceToEndOfSeason(a);
finishSeason(a);
console.log("   сезон завершён, таблица PL получена:", (a.previousSeasonResults?.PL ?? []).length, "клубов");
const beforeA = leagueOf(a, "PL");
const changesA = applyPromotions(a);
const afterA = leagueOf(a, "PL");
console.log("   изменений от applyPromotions:", changesA.length);
console.log("   состав PL изменился:", JSON.stringify(beforeA) !== JSON.stringify(afterA) ? "ДА" : "НЕТ ← повышения не происходит");
console.log("   клубов tier=CH в мире:", Object.values(a.teams).filter((t: any) => t.tier === "CH").length,
            "| tier=L1:", Object.values(a.teams).filter((t: any) => t.tier === "L1").length,
            "| нужно вылетов:", LEAGUE_CFG.PL.drop);

// ── Сценарий B: PL + Чемпионшип со связью и плей-офф ──
console.log("\nB) Слот: PL + CHA, связаны, плей-офф включён");
const b = createSlot({
  leagues: ["PL", "CHA"],
  linkedLeagues: [{ upper: "PL", lower: "CHA" }],
  promotionPlayoff: true,
});
advanceToEndOfSeason(b);
finishSeason(b);
const plOrder = b.previousSeasonResults!.PL!;
const chaOrder = b.previousSeasonResults!.CHA!;
console.log("   низ таблицы PL:", plOrder.slice(-3).map((id) => b.teams[id].name).join(", "));
console.log("   верх Чемпионшипа:", chaOrder.slice(0, 6).map((id, i) => `${i + 1}.${b.teams[id].shortName}`).join(" "));
const changesB = applyPromotions(b);
for (const c of changesB) {
  console.log(`   ${c.league}: вылет → ${c.relegated.map((r) => r.name).join(", ")}`);
  console.log(`   ${c.league}: повышение → ${c.promoted.map((r) => r.name).join(", ")}`);
  console.log(`   через плей-офф → ${c.playoffPromoted?.map((r) => r.name).join(", ") || "—"}`);
}
console.log("   размер PL после:", leagueOf(b, "PL").length, "| CHA после:", leagueOf(b, "CHA").length);

// ── Сценарий C0: детали плей-офф сохраняются для UI ──
console.log("\nB2) Детали плей-офф в PromotionChange:");
const pc = changesB.find((c) => c.playoff);
if (pc?.playoff) {
  for (const s of pc.playoff.semis) console.log(`   ПФ: ${b.teams[s.homeId].shortName} ${s.score} ${b.teams[s.awayId].shortName}`);
  if (pc.playoff.final) console.log(`   Финал: ${b.teams[pc.playoff.final.homeId].shortName} ${pc.playoff.final.score} ${b.teams[pc.playoff.final.awayId].shortName}`);
  console.log("   победитель:", b.teams[pc.playoff.winner].name);
} else {
  console.log("   ОШИБКА: сетка плей-офф не сохранена");
}

// ── Сценарий C: полный переход через startNextSeason ──
console.log("\nC) startNextSeason (как должно работать из UI)");
const c0 = createSlot({
  leagues: ["PL", "CHA"],
  linkedLeagues: [{ upper: "PL", lower: "CHA" }],
  promotionPlayoff: true,
});
advanceToEndOfSeason(c0);
finishSeason(c0);
const plBefore = new Set(Object.values(c0.teams).filter((t: any) => t.league === "PL").map((t: any) => t.id));
const c1 = startNextSeason(c0);
const plAfter = new Set(Object.values(c1.teams).filter((t: any) => t.league === "PL").map((t: any) => t.id));
const newcomers = [...plAfter].filter((id) => !plBefore.has(id));
const left = [...plBefore].filter((id) => !plAfter.has(id));
console.log("   сезон:", c1.seasonNumber, "| дата:", c1.currentDate, "| finished:", c1.season.finished);
console.log("   матчей в календаре:", c1.season.fixtures.length);
console.log("   вошли в PL:", newcomers.map((id) => c1.teams[id].name).join(", ") || "—");
console.log("   покинули PL:", left.map((id) => c1.teams[id].name).join(", ") || "—");

// ── Сценарий D: три сезона подряд без Чемпионшипа (как по умолчанию) ──
console.log("\nD) Три сезона подряд, только PL (fallback-дивизион)");
let d: any = createSlot({ leagues: ["PL"] });
for (let s = 1; s <= 3; s++) {
  advanceToEndOfSeason(d);
  finishSeason(d);
  const before = new Set(Object.values(d.teams).filter((t: any) => t.league === "PL").map((t: any) => t.id));
  d = startNextSeason(d);
  const after = Object.values(d.teams).filter((t: any) => t.league === "PL");
  const up = after.filter((t: any) => !before.has(t.id));
  console.log(`   сезон ${s}→${d.seasonNumber}: клубов в PL ${after.length}, новичков ${up.length}:`,
    up.map((t: any) => t.name).join(", ") || "—");
  console.log(`      lastPromotions: ${(d.lastPromotions ?? []).length}, матчей: ${d.season.fixtures.length}, finished: ${d.season.finished}`);
}

// ── Сценарий E: два сезона со связкой PL↔CHA, размеры лиг стабильны ──
console.log("\nE) Два сезона PL↔CHA: размеры лиг не должны «плыть»");
let e: any = createSlot({ leagues: ["PL", "CHA"], linkedLeagues: [{ upper: "PL", lower: "CHA" }], promotionPlayoff: true });
for (let s = 1; s <= 2; s++) {
  advanceToEndOfSeason(e);
  finishSeason(e);
  e = startNextSeason(e);
  const pl = Object.values(e.teams).filter((t: any) => t.league === "PL").length;
  const cha = Object.values(e.teams).filter((t: any) => t.league === "CHA").length;
  const ch = e.lastPromotions?.[0];
  console.log(`   после перехода в сезон ${e.seasonNumber}: PL ${pl} клубов, CHA ${cha} клубов`);
  console.log(`      поднялись: ${ch?.promoted.map((p: any) => p.name).join(", ") || "—"} | плей-офф: ${ch?.playoff?.winner ? e.teams[ch.playoff.winner].name : "—"}`);
}
