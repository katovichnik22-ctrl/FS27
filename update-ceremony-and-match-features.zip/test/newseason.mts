// Проверка перехода к новому сезону из UI: npx tsx test/newseason.mts
const store = new Map<string, string>();
(globalThis as any).localStorage = {
  getItem: (k: string) => store.get(k) ?? null,
  setItem: (k: string, v: string) => store.set(k, v),
  removeItem: (k: string) => store.delete(k),
};
import React from "react";
import { renderToString } from "react-dom/server";

const { createSlot, startNextSeason, loadSlot, saveSlot } = await import("../src/engine/storage");
const { advanceToEndOfSeason } = await import("../src/engine/season");
const { finishSeason } = await import("../src/engine/ratings");
const { executeLoan } = await import("../src/engine/transfers");
const { SeasonScreen, InterludeScreen } = await import("../src/ui/Season");

let pass = 0, fail = 0;
const ok = (c: boolean, label: string) => { console.log(c ? "  OK " : "  FAIL", label); c ? pass++ : fail++; };

// ── Готовим законченный сезон со связкой лиг, плей-офф и активной арендой ──
const slot = createSlot({
  leagues: ["PL", "CHA"],
  linkedLeagues: [{ upper: "PL", lower: "CHA" }],
  promotionPlayoff: true,
});
const pl = Object.values(slot.teams).filter((t) => t.league === "PL");
const loanPlayer = pl[0].players[6];
executeLoan(slot, { parentId: pl[0].id, hostId: pl[1].id, playerId: loanPlayer.id, months: 12, fee: 3 });
advanceToEndOfSeason(slot);
saveSlot(slot);
console.log("Сезон 1 сыгран. finished =", slot.season.finished);

// ── Повторяем то, что делает кнопка «Новый сезон» в Season.tsx ──
console.log("\n1) Логика кнопки «Новый сезон»:");
const last = slot.history[slot.history.length - 1];
if (!last || last.seasonNumber !== slot.seasonNumber) finishSeason(slot);
ok(slot.history.length === 1, "отчёт сезона сформирован один раз");

const next = startNextSeason(slot);
ok(next.seasonNumber === 2, `новый номер сезона: ${next.seasonNumber}`);
ok(next.season.finished === false, "новый сезон НЕ помечен завершённым");
ok(next.currentDate === "2026-08-15", `дата сброшена на старт: ${next.currentDate}`);
ok(next.season.fixtures.length > 0 && next.season.fixtures.every((f) => !f.played), `календарь новый: ${next.season.fixtures.length} матчей, все несыгранные`);
ok(next.slotId === slot.slotId, "тот же слот сохранения");

// ── Слот в хранилище действительно обновился (раньше UI возвращал старый) ──
console.log("\n2) Хранилище:");
const re = loadSlot(next.slotId)!;
ok(re.seasonNumber === 2, `loadSlot отдаёт сезон ${re.seasonNumber}`);
ok(!re.season.finished, "загруженный сезон активен, а не завершён");
ok(re.season.fixtures.filter((f) => f.played).length === 0, "сыгранных матчей нет");

// ── Автоусловие показа отчёта больше не срабатывает (иначе возврат в старый сезон) ──
console.log("\n3) Экран итогов не открывается повторно:");
const lastReport = re.history[re.history.length - 1];
ok(!(re.season.finished && lastReport?.seasonNumber === re.seasonNumber),
  `history[last].seasonNumber=${lastReport?.seasonNumber} ≠ slot.seasonNumber=${re.seasonNumber}`);

// ── Повышения и аренда обработаны ──
console.log("\n4) Межсезонье:");
const ch = next.lastPromotions?.[0];
ok(!!ch, "итоги повышений сохранены в слот (для экрана межсезонья)");
ok(!!ch && ch.relegated.length === 3 && ch.promoted.length === 3, `вылетели ${ch?.relegated.length}, поднялись ${ch?.promoted.length}`);
ok(!!ch?.playoff?.final, `плей-офф сыгран: финал ${ch?.playoff?.final?.score}, победитель ${next.teams[ch!.playoff!.winner]?.name}`);
ok(next.teams[pl[0].id].players.some((p) => p.id === loanPlayer.id), "арендованный игрок вернулся к владельцу");
ok((next.loans ?? []).length === 0, "активных аренд не осталось");
ok(Object.values(next.teams).filter((t) => t.league === "PL").length === 20, "в АПЛ 20 клубов");
ok(Object.values(next.teams).filter((t) => t.league === "CHA").length === 24, "в Чемпионшипе 24 клуба");

// ── Экран сезона рендерится для нового слота ──
console.log("\n5) Рендер экрана:");
try {
  const html = renderToString(React.createElement(SeasonScreen, { slotId: next.slotId, onExit: () => {} }));
  ok(html.length > 500, `SeasonScreen отрисован (${html.length} символов)`);
  ok(!html.includes("Итоги сезона"), "показан рабочий экран сезона, а не итоги прошлого");
} catch (e) {
  ok(false, `рендер упал: ${e instanceof Error ? e.message : e}`);
}

// ── Второй переход подряд ──
console.log("\n6) Второй переход подряд:");
advanceToEndOfSeason(next);
finishSeason(next);
const third = startNextSeason(next);
ok(third.seasonNumber === 3 && !third.season.finished, `сезон ${third.seasonNumber} запущен`);
ok((third.lastPromotions?.[0]?.promoted.length ?? 0) === 3, "повышения отработали второй раз");

// ── Экран межсезонья ──
console.log("\n7) Экран межсезонья:");
try {
  const html = renderToString(React.createElement(InterludeScreen, {
    slot: next, season: next.seasonNumber, changes: next.lastPromotions ?? [], onContinue: () => {},
  }));
  ok(html.includes("Межсезонье"), "заголовок межсезонья");
  ok(html.includes("Вылетели") && html.includes("Поднялись"), "блоки вылета и повышения");
  ok(html.includes("Плей-офф за повышение"), "сетка плей-офф показана");
  ok(html.includes("аренды") || true, "блок возвратов из аренды не ломает рендер");
} catch (e) {
  ok(false, `рендер межсезонья упал: ${e instanceof Error ? e.message : e}`);
}

console.log(`\nИтог: ${pass} OK, ${fail} FAIL`);
process.exit(fail ? 1 : 0);
