// Рендер-тест UI (ловит ошибки компонентов)
const store = new Map<string, string>();
(globalThis as any).localStorage = {
  getItem: (k: string) => store.get(k) ?? null,
  setItem: (k: string, v: string) => store.set(k, v),
  removeItem: (k: string) => store.delete(k),
};
import React from "react";
import { renderToString } from "react-dom/server";
const { createSlot, saveSlot } = await import("../src/engine/storage");
const { advanceMatchday } = await import("../src/engine/season");
const { SeasonScreen } = await import("../src/ui/Season");
const { MainMenu, AboutScreen, SettingsScreen } = await import("../src/ui/Menu");
const { NewSeason, SavesList } = await import("../src/ui/Saves");
const { QuickMatch } = await import("../src/ui/QuickMatch");

const slot = createSlot({ leagues: ["PL", "LL", "FL1", "BL", "SA"] });
advanceMatchday(slot, "PL"); advanceMatchday(slot, "LL"); advanceMatchday(slot, "BL");
saveSlot(slot);

const cases: [string, React.ReactElement][] = [
  ["MainMenu", React.createElement(MainMenu, { slots: 1, onNavigate: () => {} })],
  ["About", React.createElement(AboutScreen, { onBack: () => {} })],
  ["Settings", React.createElement(SettingsScreen, { onBack: () => {} })],
  ["NewSeason", React.createElement(NewSeason, { onCreated: () => {}, onBack: () => {} })],
  ["SavesList", React.createElement(SavesList, { onOpen: () => {}, onBack: () => {} })],
  ["QuickMatch", React.createElement(QuickMatch, { onMenu: () => {} })],
  ["SeasonScreen", React.createElement(SeasonScreen, { slotId: slot.slotId, onExit: () => {} })],
];
let ok = 0;
for (const [name, el] of cases) {
  try {
    const html = renderToString(el);
    console.log(`${name}: OK (${(html.length/1024).toFixed(1)} КБ разметки)`);
    ok++;
  } catch (e) {
    console.log(`${name}: FAIL — ${e instanceof Error ? e.message : e}`);
  }
}
console.log(`Итого: ${ok}/${cases.length} экранов рендерятся`);

// Разделы сезона и карточка матча
const { ClubsView, ClubCard, TacticsView } = await import("../src/ui/ClubsView");
const { TransfersView } = await import("../src/ui/TransfersView");
const { ScheduleView } = await import("../src/ui/ScheduleView");
const { MatchesView, StatsView, LeagueTable, EuroView, CupView, OverviewView, SquadTable } = await import("../src/ui/SeasonPanels");
const { MatchView } = await import("../src/ui/MatchView");
const { simulateFixture } = await import("../src/engine/season");

const played = slot.season.fixtures.find(f => f.played)!;
const res = simulateFixture(slot, played);
const noop = () => {};
const sections: [string, React.ReactElement][] = [
  ["ClubsView", React.createElement(ClubsView, { slot, onOpen: noop })],
  ["ClubCard(LaLiga)", React.createElement(ClubCard, { slot, teamId: "barcelona", onBack: noop, onChanged: noop })],
  ["ClubCard(Ligue1)", React.createElement(ClubCard, { slot, teamId: "psg", onBack: noop, onChanged: noop })],
  ["TacticsView", React.createElement(TacticsView, { slot, onChanged: noop, onOpenClub: noop })],
  ["TransfersView", React.createElement(TransfersView, { slot, onChanged: noop })],
  ["ScheduleView", React.createElement(ScheduleView, { slot, onChanged: noop })],
  ["MatchesView", React.createElement(MatchesView, { slot, onMatch: noop })],
  ["StatsView", React.createElement(StatsView, { slot })],
  ["Table PL", React.createElement(LeagueTable, { slot, league: "PL" as const })],
  ["Table LL", React.createElement(LeagueTable, { slot, league: "LL" as const })],
  ["Table FL1", React.createElement(LeagueTable, { slot, league: "FL1" as const })],
  ["EuroView UCL", React.createElement(EuroView, { slot, comp: "UCL" as const })],
  ["EuroView UECL", React.createElement(EuroView, { slot, comp: "UECL" as const })],
  ["CupView CDR", React.createElement(CupView, { slot, comp: "CDR" as const })],
  ["CupView CDF", React.createElement(CupView, { slot, comp: "CDF" as const })],
  ["CupView DFB", React.createElement(CupView, { slot, comp: "DFB" as const })],
  ["CupView CIT", React.createElement(CupView, { slot, comp: "CIT" as const })],
  ["Table BL", React.createElement(LeagueTable, { slot, league: "BL" as const })],
  ["Table SA", React.createElement(LeagueTable, { slot, league: "SA" as const })],
  ["ClubCard(Bayern)", React.createElement(ClubCard, { slot, teamId: "bayern", onBack: noop, onChanged: noop })],
  ["ClubCard(Inter)", React.createElement(ClubCard, { slot, teamId: "inter", onBack: noop, onChanged: noop })],
  ["Overview", React.createElement(OverviewView, { slot, onMatch: noop, onClub: noop })],
  ["SquadTable", React.createElement(SquadTable, { slot, teamId: "real_madrid" })],
  ["MatchView", React.createElement(MatchView, { result: res, teams: slot.teams, instant: true, onClose: noop })],
  ["PlayerEditor", React.createElement((await import("../src/ui/PlayerEditor")).PlayerEditor, { slot, onChanged: noop })],
  ["PlayerEditor(target)", React.createElement((await import("../src/ui/PlayerEditor")).PlayerEditor, { slot, onChanged: noop, initialTeamId: "arsenal", initialPlayerId: slot.teams["arsenal"].players[0].id })],
];
let ok2 = 0;
for (const [name, el] of sections) {
  try { renderToString(el); console.log(`${name}: OK`); ok2++; }
  catch (e) { console.log(`${name}: FAIL — ${e instanceof Error ? e.message : e}`); }
}
console.log(`Разделы: ${ok2}/${sections.length}`);

// Ceremony
const { CeremonyView } = await import("../src/ui/Ceremony");
const { buildCeremony } = await import("../src/engine/awards");
try {
  const cer = buildCeremony(slot);
  renderToString(React.createElement(CeremonyView, { slot, ceremony: cer, onContinue: noop }));
  console.log("CeremonyView: OK");
} catch (e) { console.log("CeremonyView: FAIL —", e instanceof Error ? e.message : e); }

// TacticTextEditor
const { TacticTextEditor } = await import("../src/ui/TacticTextEditor");
const { TACTIC_TEMPLATE } = await import("../src/engine/tacticText");
try {
  renderToString(React.createElement(TacticTextEditor, { value: TACTIC_TEMPLATE, onSave: noop }));
  renderToString(React.createElement(TacticTextEditor, { value: "", onSave: noop }));
  console.log("TacticTextEditor: OK");
} catch (e) { console.log("TacticTextEditor: FAIL —", e instanceof Error ? e.message : e); }

// SimPanel
const { SimPanel } = await import("../src/ui/SimPanel");
try {
  renderToString(React.createElement(SimPanel, { slot, onChanged: noop, onFlash: noop, busy: false, setBusy: noop }));
  console.log("SimPanel: OK");
} catch (e) { console.log("SimPanel: FAIL —", e instanceof Error ? e.message : e); }

// LeagueSetup
const { LeagueLinkStep, BudgetStep } = await import("../src/ui/LeagueSetup");
try {
  renderToString(React.createElement(LeagueLinkStep, {
    picked: ["PL","CHA"] as any, links: [{upper:"PL",lower:"CHA"}] as any,
    setLinks: noop, playoff: true, setPlayoff: noop,
  }));
  renderToString(React.createElement(BudgetStep, {
    teams: Object.values(slot.teams).filter((t:any)=>t.league),
    budgets: {arsenal: 500}, setBudgets: noop,
  }));
  console.log("LeagueLinkStep + BudgetStep: OK");
} catch (e) { console.log("LeagueSetup: FAIL —", e instanceof Error ? e.message : e); }

// ScoreEditor
const { ScoreEditor } = await import("../src/ui/ScoreEditor");
try {
  renderToString(React.createElement(ScoreEditor, { slot, fixture: played, onClose: noop, onApplied: noop }));
  console.log("ScoreEditor: OK");
} catch (e) { console.log("ScoreEditor: FAIL —", e instanceof Error ? e.message : e); }

// EuroSetup
const { EuroSetup } = await import("../src/ui/EuroSetup");
try {
  renderToString(React.createElement(EuroSetup, {
    teams: slot.teams, leagues: slot.selectedLeagues, seasonLabel: "2027/28",
    confirmLabel: "OK", onConfirm: noop, onCancel: noop,
  }));
  console.log("EuroSetup: OK");
} catch (e) { console.log("EuroSetup: FAIL —", e instanceof Error ? e.message : e); }

// слот с одной лигой
const solo = createSlot({ leagues: ["PL"] });
try {
  renderToString(React.createElement(SeasonScreen, { slotId: solo.slotId, onExit: noop }));
  const html = renderToString(React.createElement(MatchesView, { slot: solo, onMatch: noop }));
  const bad = ["La Liga", "Ligue 1", "Bundesliga", "Serie A", "LaLiga"].filter(n => html.includes(n));
  console.log(`Слот только PL: упоминаний других лиг в «Матчах» — ${bad.length ? bad.join(", ") : "нет"} →`, bad.length ? "FAIL" : "OK");
} catch (e) { console.log("Solo slot: FAIL —", e instanceof Error ? e.message : e); }
