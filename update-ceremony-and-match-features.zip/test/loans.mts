// Проверка механики аренд (не входит в сборку): npx tsx test/loans.mts
// localStorage-заглушка до импорта storage
const store: Record<string, string> = {};
(globalThis as any).localStorage = {
  getItem: (k: string) => store[k] ?? null,
  setItem: (k: string, v: string) => { store[k] = String(v); },
  removeItem: (k: string) => { delete store[k]; },
};

const { createSlot, startNextSeason, loadSlot } = await import("../src/engine/storage");
const { advanceDay, SEASON_START } = await import("../src/engine/season");
const {
  executeLoan, validateLoan, validateTransfer, processLoanReturns, terminateLoan,
  loanEndFor, suggestLoanFee, loansByPlayer,
} = await import("../src/engine/transfers");

let pass = 0, fail = 0;
const ok = (cond: boolean, label: string) => {
  console.log(cond ? "  OK " : "  FAIL", label);
  cond ? pass++ : fail++;
};

// ── 0. Слот на одну лигу для скорости ──
const slot = createSlot({ leagues: ["PL"], uclTeams: undefined });
console.log("Слот создан:", slot.currentDate, "· клубов:", Object.keys(slot.teams).length);

const [parent, host] = Object.values(slot.teams).filter((t) => t.league === "PL");
const player = parent.players.find((p) => p.position === "MF")!;
const fee = suggestLoanFee(player, 6);
const parentBudget = parent.budget, hostBudget = host.budget;

// ── 1. Оформление аренды на 6 месяцев (лето → до января) ──
console.log("\n1) Аренда 6 мес (летнее окно):");
const ln6 = executeLoan(slot, { parentId: parent.id, hostId: host.id, playerId: player.id, months: 6, fee });
ok(ln6.endDate === "2027-01-01" && ln6.endSeason === 1, `точка возврата ${ln6.endDate}, сезон ${ln6.endSeason}`);
ok(host.players.some((p) => p.id === player.id), "игрок в составе клуба аренды");
ok(!parent.players.some((p) => p.id === player.id), "игрок ушёл из клуба-владельца");
ok(Math.abs(host.budget - (hostBudget - fee)) < 1e-9 && Math.abs(parent.budget - (parentBudget + fee)) < 1e-9, `бюджеты: владелец +£${fee}M, арендатор -£${fee}M`);
ok(slot.loans.length === 1, "аренда в списке активных");
ok(slot.transfers[0].kind === "loan" && slot.transfers[0].fee === fee, "запись АРЕНДА в истории");

// нельзя продать/обменять арендованного
const badPlan = { fromId: host.id, toId: parent.id, playersOut: [player.id], playersBack: [], fee: 1 };
ok(!validateTransfer(slot, badPlan).ok, "продажа арендованного игрока заблокирована");
// нельзя повторно отдать в аренду
ok(!validateLoan(slot, { parentId: host.id, hostId: parent.id, playerId: player.id, months: 6, fee: 0 }).ok, "повторная аренда заблокирована");

// ── 2. Прогон до 1 января — автоматический возврат ──
console.log("\n2) Прогон сезона до 1 января (advanceDay):");
slot.currentDate = "2026-12-30";
advanceDay(slot); // 31 декабря
ok(host.players.some((p) => p.id === player.id), `31 декабря игрок ещё в аренде (дата ${slot.currentDate})`);
advanceDay(slot); // 1 января
ok(slot.currentDate === "2027-01-01", "наступило 1 января");
ok(slot.loans.length === 0, "аренда завершена автоматически");
ok(parent.players.some((p) => p.id === player.id), "игрок вернулся к владельцу");
ok(!host.players.some((p) => p.id === player.id), "игрок ушёл из клуба аренды");
ok(slot.transfers[0].kind === "loan_return", "запись ВОЗВРАТ в истории");

// ── 3. Аренда на год (лето) → вернётся в начале следующего сезона ──
console.log("\n3) Аренда 1 год (лето) → возврат при старте нового сезона:");
slot.currentDate = "2027-08-20"; // снова летнее окно текущего «календаря»
const p2 = parent.players.find((x) => x.position === "FW")!;
const ln12 = executeLoan(slot, { parentId: parent.id, hostId: host.id, playerId: p2.id, months: 12, fee: 2 });
ok(ln12.endDate === "2027-07-01" && ln12.endSeason === 1, `точка возврата ${ln12.endDate}, сезон ${ln12.endSeason}`);
processLoanReturns(slot, "day"); // внутри сезона летняя аренда не возвращается
ok(slot.loans.length === 1 && host.players.some((p) => p.id === p2.id), "в течение сезона игрок остаётся в аренде");
const s2 = startNextSeason(slot);
const parent2 = s2.teams[parent.id], host2 = s2.teams[host.id];
ok(s2.seasonNumber === 2, "начался сезон 2");
ok((s2.loans ?? []).length === 0, "аренда закрыта в межсезонье");
ok(parent2.players.some((p) => p.id === p2.id) && !host2.players.some((p) => p.id === p2.id), "игрок дома у владельца");
ok(s2.transfers.some((t) => t.kind === "loan_return" && t.playerIds.includes(p2.id)), "в истории нового сезона есть ВОЗВРАТ");

// ── 4. Аренда на 2 года (лето сезона 2) → переживает один переход ──
console.log("\n4) Аренда 2 года:");
s2.currentDate = "2026-08-20";
const p3 = parent2.players.find((x) => x.position === "DF")!;
const ln24 = executeLoan(s2, { parentId: parent.id, hostId: host.id, playerId: p3.id, months: 24, fee: 4 });
ok(ln24.endSeason === 3 && ln24.endDate === "2027-07-01", `точка возврата ${ln24.endDate}, сезон ${ln24.endSeason}`);
const s3 = startNextSeason(s2);
ok(s3.seasonNumber === 3, "начался сезон 3");
ok((s3.loans ?? []).length === 1, "(переход 2→3) двухлетняя аренда ещё активна");
ok(s3.teams[host.id].players.some((p) => p.id === p3.id), "после перехода 2→3 игрок ещё в аренде");
const s4 = startNextSeason(s3);
ok(s4.teams[parent.id].players.some((p) => p.id === p3.id), "после перехода 3→4 игрок вернулся домой");
ok(!(s4.loans ?? []).length, "список аренд пуст");

// ── 5. Зимняя аренда на 12 месяцев → вернётся в январе следующего сезона ──
console.log("\n5) Зимняя аренда 12 мес (оформлена в январе):");
s4.currentDate = "2027-01-10";
const p4 = s4.teams[parent.id].players.find((x) => x.position === "GK") ?? s4.teams[parent.id].players[0];
const lnW = executeLoan(s4, { parentId: parent.id, hostId: host.id, playerId: p4.id, months: 12, fee: 1.5 });
ok(lnW.endDate === "2027-01-01" && lnW.endSeason === s4.seasonNumber + 1, `возврат в январе след. сезона (${lnW.endDate}, сезон ${lnW.endSeason})`);
const s5 = startNextSeason(s4);
ok((s5.loans ?? []).length === 1, "при старте нового сезона зимняя аренда НЕ прервалась");
ok(s5.teams[host.id].players.some((p) => p.id === p4.id), "игрок доигрывает осень в аренде");
s5.currentDate = "2026-12-31";
advanceDay(s5); // 1 января нового сезона
ok((s5.loans ?? []).length === 0 && s5.teams[parent.id].players.some((p) => p.id === p4.id), "1 января нового сезона — автовозврат");

// ── 6. Досрочный отзыв ──
console.log("\n6) Досрочный отзыв:");
s5.currentDate = "2026-08-25";
const p5 = s5.teams[parent.id].players[5];
const ln6b = executeLoan(s5, { parentId: parent.id, hostId: host.id, playerId: p5.id, months: 6, fee: 0.5 });
const recalled = terminateLoan(s5, ln6b.id);
ok(!!recalled, "отзыв выполнен");
ok(!s5.loans.length && s5.teams[parent.id].players.some((p) => p.id === p5.id), "игрок вернулся сразу");
ok(s5.transfers[0].kind === "loan_return" && s5.transfers[0].date === s5.currentDate, "возврат записан текущей датой");

// ── 7. loanEndFor — матрица сроков ──
console.log("\n7) Матрица loanEndFor:");
ok(JSON.stringify(loanEndFor(1, "2026-08-15", 6)) === JSON.stringify({ endDate: "2027-01-01", endSeason: 1 }), "лето +6м → январь этого сезона");
ok(JSON.stringify(loanEndFor(1, "2026-08-15", 12)) === JSON.stringify({ endDate: "2027-07-01", endSeason: 1 }), "лето +12м → конец сезона");
ok(JSON.stringify(loanEndFor(1, "2026-08-15", 24)) === JSON.stringify({ endDate: "2027-07-01", endSeason: 2 }), "лето +24м → конец след. сезона");
ok(JSON.stringify(loanEndFor(1, "2027-01-10", 6)) === JSON.stringify({ endDate: "2027-07-01", endSeason: 1 }), "зима +6м → конец сезона");
ok(JSON.stringify(loanEndFor(1, "2027-01-10", 12)) === JSON.stringify({ endDate: "2027-01-01", endSeason: 2 }), "зима +12м → январь след. сезона");
ok(JSON.stringify(loanEndFor(1, "2027-01-10", 24)) === JSON.stringify({ endDate: "2027-01-01", endSeason: 3 }), "зима +24м → январь через сезон");

// ── 8. Слот сохраняется и читается с арендами ──
console.log("\n8) Персистентность:");
s5.currentDate = "2026-08-25";
executeLoan(s5, { parentId: parent.id, hostId: host.id, playerId: s5.teams[parent.id].players[7].id, months: 24, fee: 3 });
delete (globalThis as any).__x; // noop
const { saveSlot } = await import("../src/engine/storage");
saveSlot(s5);
const re = loadSlot(s5.slotId)!;
ok(re.loans.length === 1 && loansByPlayer(re).size === 1, "аренды переживают сохранение/загрузку");

console.log(`\nИтог: ${pass} OK, ${fail} FAIL`);
process.exit(fail ? 1 : 0);
