const store = new Map<string, string>();
(globalThis as any).localStorage = {
  getItem: (k: string) => store.get(k) ?? null,
  setItem: (k: string, v: string) => store.set(k, v),
  removeItem: (k: string) => store.delete(k),
};
const { createSlot, startNextSeason, applyPromotions } = await import("../src/engine/storage");
const { advanceToEndOfSeason, buildTable, LEAGUE_CFG, LEAGUE_IDS, autoEuroTeams } = await import("../src/engine/season");
const { finishSeason } = await import("../src/engine/ratings");

// 1) Только АПЛ
const s1 = createSlot({ leagues: ["PL"] });
const comps1 = new Set(s1.season.fixtures.map(f => f.comp));
console.log(`1) Только PL: лиг ${s1.selectedLeagues}, матчей ${s1.season.fixtures.length}, турниры [${[...comps1].join(",")}] →`,
  !comps1.has("LL") && !comps1.has("FL1") && !comps1.has("BL") && !comps1.has("SA") && !comps1.has("CDR") && comps1.has("PL") && comps1.has("FA") && comps1.has("EFL") ? "OK" : "FAIL");
const eng1 = s1.uclTeams.filter(id => s1.teams[id].league === "PL").length;
console.log(`   UCL: ${s1.uclTeams.length} команд, из них английских ${eng1}, прочих ${s1.uclTeams.length - eng1} →`,
  s1.uclTeams.length === 36 && eng1 === 4 ? "OK" : "FAIL");
console.log(`   UEL: ${s1.uelTeams.length}, пересечений с UCL ${s1.uelTeams.filter(id => s1.uclTeams.includes(id)).length} →`,
  s1.uelTeams.length === 36 && !s1.uelTeams.some(id => s1.uclTeams.includes(id)) ? "OK" : "FAIL");

// 2) Две лиги
const s2 = createSlot({ leagues: ["PL", "LL"] });
const comps2 = new Set(s2.season.fixtures.map(f => f.comp));
console.log(`2) PL+LaLiga: матчей ${s2.season.fixtures.length}, турниры [${[...comps2].sort().join(",")}] →`,
  comps2.has("PL") && comps2.has("LL") && comps2.has("CDR") && !comps2.has("FL1") && !comps2.has("BL") ? "OK" : "FAIL");

// 3) Все пять
const s5 = createSlot({ leagues: LEAGUE_IDS });
const per: string[] = [];
for (const lid of LEAGUE_IDS) {
  const ids = Object.values(s5.teams).filter(t => t.league === lid).map(t => t.id);
  const fx = s5.season.fixtures.filter(f => f.comp === LEAGUE_CFG[lid].comp);
  per.push(`${LEAGUE_CFG[lid].short} ${ids.length}кл/${fx.length}м`);
  if (fx.length !== ids.length * (ids.length - 1)) console.log(`   FAIL ${lid}: ${fx.length} вместо ${ids.length*(ids.length-1)}`);
}
console.log(`3) Все 5 лиг: ${per.join(" · ")}, всего матчей ${s5.season.fixtures.length}`);
const cnt5: Record<string, number> = {};
for (const id of s5.uclTeams) { const c = s5.teams[id].country!; cnt5[c] = (cnt5[c] ?? 0) + 1; }
console.log(`   UCL по странам: ${Object.entries(cnt5).map(([k,v])=>`${k}:${v}`).join(" ")} →`, s5.uclTeams.length === 36 ? "OK" : "FAIL");
const cups5 = new Set(s5.season.fixtures.map(f=>f.comp));
console.log(`   Кубки: FA ${cups5.has("FA")}, EFL ${cups5.has("EFL")}, CDR ${cups5.has("CDR")}, CDF ${cups5.has("CDF")}, DFB ${cups5.has("DFB")}, CIT ${cups5.has("CIT")}`);

// 4) Промотать сезон, отчёт
const t0 = Date.now();
advanceToEndOfSeason(s5);
const rep = finishSeason(s5);
console.log(`4) Сезон 5 лиг за ${((Date.now()-t0)/1000).toFixed(1)}с, сыграно ${s5.season.fixtures.filter(f=>f.played).length}`);
console.log(`   Чемпионы: ${LEAGUE_IDS.map(l=>`${LEAGUE_CFG[l].short}=${s5.teams[rep.champions[LEAGUE_CFG[l].comp]!]?.name}`).join(" | ")}`);
console.log(`   Кубки: UCL ${s5.teams[rep.champions.UCL!]?.name} | DFB ${s5.teams[rep.champions.DFB!]?.name} | CIT ${s5.teams[rep.champions.CIT!]?.name} →`,
  LEAGUE_IDS.every(l=>rep.champions[LEAGUE_CFG[l].comp]) && rep.champions.UCL && rep.champions.DFB && rep.champions.CIT ? "OK" : "FAIL");
console.log(`   previousSeasonResults заполнен:`, Object.keys(s5.previousSeasonResults ?? {}).length === 5 ? "OK" : "FAIL");

// 5) Ручной выбор еврокубков
const auto = autoEuroTeams(s5.teams, s5.selectedLeagues, s5.previousSeasonResults);
const manual = [...auto.ucl];
const outsiders = Object.values(s5.teams).filter(t => t.league && !manual.includes(t.id)).slice(0, 3).map(t => t.id);
manual[33] = outsiders[0]; manual[34] = outsiders[1]; manual[35] = outsiders[2];
const s6 = startNextSeason(s5, { uclTeams: manual, autoPromotion: false });
console.log(`5) Ручной UCL: 3 клуба заменены (${outsiders.map(id=>s6.teams[id].name).join(", ")}) →`,
  outsiders.every(id => s6.season.ucl.participants.includes(id)) && s6.uclTeams.length === 36 ? "OK" : "FAIL");
console.log(`   Новый сезон №${s6.seasonNumber}, матчей ${s6.season.fixtures.length}, лиг ${s6.selectedLeagues.length}`);

// 6) Автоподъём/вылет
const s7 = createSlot({ leagues: ["PL", "SA"] });
advanceToEndOfSeason(s7);
finishSeason(s7);
const before = Object.values(s7.teams).filter(t => t.league === "PL").map(t => t.name);
const changes = applyPromotions(s7);
for (const c of changes)
  console.log(`6) ${LEAGUE_CFG[c.league].short}: вылетели ${c.relegated.map(r=>r.name).join(", ")} | поднялись ${c.promoted.map(r=>r.name).join(", ")}`);
const after = Object.values(s7.teams).filter(t => t.league === "PL").map(t => t.name);
console.log(`   Размер PL не изменился: ${before.length} → ${after.length} →`, before.length === after.length ? "OK" : "FAIL");
console.log(`   Состав обновился:`, after.some(n => !before.includes(n)) ? "OK" : "FAIL");
