// Проверка новых фич: церемония ЗМ, плей-офф повышения как реальные матчи,
// правка счёта финала меняет обладателя путёвки, вратари без инфляции рейтинга.
// Запуск: npx tsx test/playoff_upgrade.mts

const store: Record<string, string> = {};
(globalThis as any).localStorage = {
  getItem: (k: string) => store[k] ?? null,
  setItem: (k: string, v: string) => { store[k] = String(v); },
  removeItem: (k: string) => { delete store[k]; },
};

const { createSlot, startNextSeason } = await import("../src/engine/storage");
const {
  advanceToEndOfSeason, applyResult, playoffsSettled,
  setFixtureScore, simulateFixture,
} = await import("../src/engine/season");
const { finishSeason } = await import("../src/engine/ratings");
const { buildCeremony } = await import("../src/engine/awards");

let fails = 0;
const check = (name: string, ok: boolean, extra = "") => {
  console.log(`${ok ? "✅" : "❌ FAIL"} ${name}${extra ? " — " + extra : ""}`);
  if (!ok) fails++;
};

console.log("\n═══ Слот: PL + CHA, связь, плей-офф включён ═══\n");
const slot = createSlot({
  leagues: ["PL", "CHA"],
  linkedLeagues: [{ upper: "PL", lower: "CHA" }],
  promotionPlayoff: true,
});
advanceToEndOfSeason(slot);

// 1) после «до конца сезона» плей-офф ЗАПЛАНИРОВАН, но НЕ сыграл сам
const st = slot.season.playoffs?.[0];
check("сезон завершён", slot.season.finished);
check("плей-офф запланирован (2 полуфинала)", !!st && st.semiIds.length === 2, JSON.stringify(st?.semiIds ?? null));
const ppoPending = slot.season.fixtures.filter((f: any) => f.comp === "PPO" && !f.played);
check("матчи PPO остались несыгранными после «до конца»", ppoPending.length === 2, `pending=${ppoPending.length}`);
const chaOrder = slot.previousSeasonResults!.CHA!;
const semi1 = slot.season.fixtures.find((f: any) => f.id === st!.semiIds[0])!;
check("пары 3–6 мест Чемпионшипа", [semi1.homeId, semi1.awayId].join() === [chaOrder[2], chaOrder[5]].join(),
  `${slot.teams[semi1.homeId].name} vs ${slot.teams[semi1.awayId].name}`);

// 2) итоги + церемония
const report = finishSeason(slot);
const ceremony = buildCeremony(slot);
check("отчёт сезона построен", report.seasonNumber === 1 && !!report.finalTables.PL);
check("церемония: есть Золотой мяч", !!ceremony.ballonDor,
  ceremony.ballonDor ? `${ceremony.ballonDor.name} (${ceremony.ballonDor.teamName})` : "нет");
check("церемония: топ ЗМ заполнен", ceremony.ballonDorTop.length >= 8, `топ=${ceremony.ballonDorTop.length}`);
check("церемония: есть лучший вратарь", !!ceremony.bestGoalkeeper, ceremony.bestGoalkeeper?.name ?? "");
check("церемония: есть лучший молодой (U21)", !!ceremony.bestYoung, ceremony.bestYoung?.name ?? "");
check("церемония: есть бомбардир сезона", !!ceremony.topScorer, ceremony.topScorer?.name ?? "");
check("церемония: есть клуб сезона", !!ceremony.bestClub, ceremony.bestClub?.name ?? "");

// 3) вратари — умеренный рост
const ratedGK = report.all.filter((c: any) => c.position === "GK" && c.apps >= 10);
const gkPlus3 = ratedGK.filter((c: any) => c.delta >= 3);
const gkPlus2 = ratedGK.filter((c: any) => c.delta >= 2);
check("вратари: никто не получил +3 и больше", gkPlus3.length === 0,
  gkPlus3.map((c: any) => `${c.name}+${c.delta}`).join(", ") || "ок");
console.log(`   (инфо: вратарей с +2: ${gkPlus2.length} из ${ratedGK.length}; топ дельты: ` +
  [...ratedGK].sort((a: any, b: any) => b.delta - a.delta).slice(0, 3)
    .map((c: any) => `${c.name} ${c.oldOverall}→${c.newOverall} [${c.reason}]`).join("; ") + ")");

// 4) играем полуфиналы движком — финал создаётся автоматически (как в watchMatch)
const statsBefore = JSON.stringify(Object.values(slot.teams)
  .flatMap((t: any) => t.players).map((p: any) => [p.id, (p as any).stats.apps, (p as any).stats.goals]));
for (const f of slot.season.fixtures.filter((f: any) => f.comp === "PPO" && !f.played))
  applyResult(slot, f, simulateFixture(slot, f));
check("после полуфиналов создан финал", !!st!.finalId);
const finId = st!.finalId!;
const fin = slot.season.fixtures.find((f: any) => f.id === finId)!;
check("финал на нейтральном поле", fin.neutral === true);
console.log(`   финал: ${slot.teams[fin.homeId].name} — ${slot.teams[fin.awayId].name}, ${fin.date}`);

// 5) детальный повтор матча работает (карточка со статистикой)
const replaySf = simulateFixture(slot, semi1);
check("повтор полуфинала воспроизводит счёт",
  replaySf.homeScore === semi1.result!.h && replaySf.awayScore === semi1.result!.a,
  `${replaySf.homeScore}:${replaySf.awayScore} vs сохр. ${semi1.result!.h}:${semi1.result!.a}`);
check("в повторе есть рейтинги игроков и минуты", Object.keys(replaySf.playerRatings).length > 15 && replaySf.minutes.length > 80);

// 6) статистика игроков НЕ загрязнена плей-офф
const statsAfter = JSON.stringify(Object.values(slot.teams)
  .flatMap((t: any) => t.players).map((p: any) => [p.id, (p as any).stats.apps, (p as any).stats.goals]));
check("PPO-матчи не идут в сезонную статистику игроков", statsBefore === statsAfter);

// 7) играем финал, потом ПЕРЕПИСЫВАЕМ счёт так, чтобы путёвка ушла другой команде
applyResult(slot, fin, simulateFixture(slot, fin));
check("плей-офф доигран, победитель есть", playoffsSettled(slot) && !!st!.winner, slot.teams[st!.winner!]?.name);
const winner1 = st!.winner!;
const loser = winner1 === fin.homeId ? fin.awayId : fin.homeId;
const cur = fin.result!;
const swap = winner1 === fin.homeId && cur.h > cur.a
  ? setFixtureScore(slot, finId, cur.a, cur.h)
  : setFixtureScore(slot, finId, cur.a - 0, cur.h + 2); // усиленная победа другой команды
const finalWinner = winner1 === fin.homeId ? fin.awayId : fin.homeId;
check("ручная правка финала применилась", swap.ok && fin.result!.manual === true, `${fin.result!.h}:${fin.result!.a}`);
check("обладатель путёвки сменился после правки", st!.winner === loser || st!.winner === finalWinner, slot.teams[st!.winner!]?.name);

// 8) переход к новому сезону: повышается именно победитель плей-офф
const expectedUp = [chaOrder[0], chaOrder[1], st!.winner!];
const next = startNextSeason(slot);
const plChanged = expectedUp.every((id) => next.teams[id]?.league === "PL");
check("в АПЛ поднялись 1-е, 2-е и победитель плей-офф", plChanged,
  expectedUp.map((id) => next.teams[id]?.shortName).join(", "));
const ch = next.lastPromotions?.find((c: any) => c.league === "PL");
check("в межсезонье показана сетка плей-офф из реальных матчей",
  !!ch?.playoff && ch.playoff.semis.length === 2 && !!ch.playoff.final,
  ch?.playoff ? `1/2: ${ch.playoff.semis.map((s: any) => s.score).join(", ")} · финал: ${ch.playoff.final?.score}` : "нет");
check("playoffPromoted = победитель финала", ch?.playoffPromoted?.[0]?.id === st!.winner,
  ch?.playoffPromoted?.[0]?.name ?? "");

// 9) в новом сезоне чисто
check("в новом сезоне PPO-матчей нет", !next.season.fixtures.some((f: any) => f.comp === "PPO"));
check("сезон 2 не завершён и без плей-офф", !next.season.finished && !next.season.playoffs);

console.log(fails ? `\n❌ Ошибок: ${fails}` : "\n🎉 Все проверки прошли");
process.exit(fails ? 1 : 0);
