const store = new Map<string,string>();
(globalThis as any).localStorage = { getItem:(k:string)=>store.get(k)??null, setItem:(k:string,v:string)=>store.set(k,v), removeItem:(k:string)=>store.delete(k) };
const { MAIN_DB } = await import("../src/data/db");
const { createSlot } = await import("../src/engine/storage");
const { advanceDay, setFixtureScore, buildTable, simulateFixture, LEAGUE_CFG } = await import("../src/engine/season");
const mainBefore = JSON.stringify(MAIN_DB);
const slot = createSlot({ leagues: ["PL"] });
for (let i=0;i<8;i++) advanceDay(slot);

const fx = slot.season.fixtures.find(f=>f.played && f.comp==="PL")!;
const plIds = Object.values(slot.teams).filter(t=>t.league==="PL").map(t=>t.id);
const before = fx.result!.h + ":" + fx.result!.a;
const homeName = slot.teams[fx.homeId].name, awayName = slot.teams[fx.awayId].name;
const tblBefore = buildTable(slot.season.fixtures, plIds, "PL");
const posBefore = tblBefore.findIndex(r=>r.teamId===fx.homeId)+1;
const ptsBefore = tblBefore.find(r=>r.teamId===fx.homeId)!.pts;
const scorerStatsBefore = slot.teams[fx.homeId].players.reduce((a,p)=>a+p.stats.goals,0);

console.log(`1) Было: ${homeName} ${before} ${awayName}; хозяева ${posBefore}-е, ${ptsBefore} очк, голов у клуба ${scorerStatsBefore}`);
const r = setFixtureScore(slot, fx.id, 7, 1);
console.log(`   Ставим 7:1 →`, r.ok ? "OK" : "FAIL " + r.error);
console.log(`   В расписании: ${fx.result!.h}:${fx.result!.a}, вручную: ${fx.result!.manual} →`, fx.result!.h===7 && fx.result!.a===1 ? "OK":"FAIL");

const replay = simulateFixture(slot, fx);
console.log(`2) Детальный просмотр показывает: ${replay.homeScore}:${replay.awayScore} →`, replay.homeScore===7&&replay.awayScore===1?"OK":"FAIL");
const goals = replay.events.filter(e=>e.type==="goal"||e.type==="penalty");
const names = goals.map(e=>slot.teams[e.teamId!].players.find(p=>p.id===e.playerId)?.name ?? "?");
console.log(`   авторы (${goals.length}): ${names.join(", ")}`);

const tblAfter = buildTable(slot.season.fixtures, plIds, "PL");
const rowH = tblAfter.find(r=>r.teamId===fx.homeId)!;
console.log(`3) Таблица пересчитана: ${homeName} ${rowH.pts} очк, ГЗ-ГП ${rowH.gf}-${rowH.ga}, РГ ${rowH.gd} →`, rowH.pts>=ptsBefore?"OK":"FAIL");
const scorerStatsAfter = slot.teams[fx.homeId].players.reduce((a,p)=>a+p.stats.goals,0);
console.log(`4) Голы игроков клуба: ${scorerStatsBefore} → ${scorerStatsAfter} (разница ${scorerStatsAfter-scorerStatsBefore})`);
const apps = slot.teams[fx.homeId].players.filter(p=>p.stats.apps>0);
const maxApps = Math.max(...apps.map(p=>p.stats.apps));
const playedGames = slot.season.fixtures.filter(f=>f.played && (f.homeId===fx.homeId||f.awayId===fx.homeId)).length;
console.log(`   Матчей у клуба ${playedGames}, макс. apps у игрока ${maxApps} →`, maxApps<=playedGames?"OK (двойного учёта нет)":"FAIL");

// повторное изменение
setFixtureScore(slot, fx.id, 0, 3);
console.log(`5) Переставили на 0:3: ${fx.result!.h}:${fx.result!.a}, apps макс ${Math.max(...slot.teams[fx.homeId].players.map(p=>p.stats.apps))} →`,
  fx.result!.h===0&&fx.result!.a===3 ? "OK":"FAIL");

// несыгранный матч
const future = slot.season.fixtures.find(f=>!f.played && f.comp==="PL")!;
const r2 = setFixtureScore(slot, future.id, 2, 2);
console.log(`6) Счёт будущему матчу 2:2: ${future.played?"сыгран":"нет"} ${future.result?.h}:${future.result?.a} →`, r2.ok&&future.played&&future.result!.h===2?"OK":"FAIL");
console.log(`7) Валидация -1:5 →`, setFixtureScore(slot, future.id, -1, 5).ok ? "FAIL" : "OK (отклонено)");
console.log(`8) MAIN_DB не изменилась:`, JSON.stringify(MAIN_DB)===mainBefore?"OK":"FAIL");
