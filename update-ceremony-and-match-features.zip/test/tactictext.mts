import { analyzeTactic, TACTIC_TEMPLATE } from "../src/engine/tacticText";
import { MAIN_DB, deepClone } from "../src/data/db";
import { simulateMatch } from "../src/engine/match";
import { defaultTactics } from "../src/engine/tactics";
import type { Team } from "../src/types";

const cases: [string,string][] = [
  ["пусто", ""],
  ["мусор", "я не знаю фыва фыва фыва фыва фыва фыва фыва"],
  ["односложно", "играем в атаку и побеждаем"],
  ["средне", "Прессингуем высоко, играем через фланги, после потери сразу контрпрессинг. Обороняемся компактно."],
  ["противоречие", "Высокий прессинг всей командой и одновременно низкий блок, садимся глубоко и давим высоко."],
  ["шаблон", TACTIC_TEMPLATE],
];
console.log("— Оценка планов —");
for (const [name, txt] of cases) {
  const a = analyzeTactic(txt);
  console.log(`  ${name.padEnd(13)} score ${String(a.score).padStart(3)} · ${a.grade.padEnd(18)} концепций ${String(a.detected.length).padStart(2)} · фаз ${a.phases.length}/7 · atk×${a.atk} def×${a.def} mid×${a.mid}`);
  if (a.issues.length) console.log(`                 замечания: ${a.issues.join("; ")}`);
}
const t = analyzeTactic(TACTIC_TEMPLATE);
console.log(`\nШаблон: press ${t.pressBias} counter ${t.counterBias} setPiece ${t.setPieceBias} discipline ${t.disciplineBias}`);
console.log(`  концепции: ${t.detected.slice(0,8).map(d=>d.label).join(", ")}…`);
console.log("Детерминизм:", JSON.stringify(analyzeTactic(TACTIC_TEMPLATE))===JSON.stringify(analyzeTactic(TACTIC_TEMPLATE))?"OK":"FAIL");

const teams = deepClone(MAIN_DB) as Record<string, Team>;
const base = defaultTactics(teams.everton);
const good = { ...base, textTactic: TACTIC_TEMPLATE };
const bad  = { ...base, textTactic: "низкий блок и высокий прессинг одновременно, бьём куда попало, фыва фыва" };
const opp  = defaultTactics(teams.arsenal);
let gp=0, bp=0, gGoals=0, bGoals=0, gConc=0, bConc=0;
for (let i=0;i<400;i++){
  const m1 = simulateMatch(teams.everton, teams.arsenal, {seed:3000+i, homeTactics:good, awayTactics:opp});
  const m2 = simulateMatch(teams.everton, teams.arsenal, {seed:3000+i, homeTactics:bad,  awayTactics:opp});
  gGoals+=m1.homeScore; gConc+=m1.awayScore; bGoals+=m2.homeScore; bConc+=m2.awayScore;
  gp += m1.homeScore>m1.awayScore?3:m1.homeScore===m1.awayScore?1:0;
  bp += m2.homeScore>m2.awayScore?3:m2.homeScore===m2.awayScore?1:0;
}
console.log(`\nEverton vs Arsenal, 400 матчей:`);
console.log(`  хороший план: ${gp} очк, забито ${gGoals}, пропущено ${gConc}`);
console.log(`  плохой план:  ${bp} очк, забито ${bGoals}, пропущено ${bConc}`);
console.log(`  прирост очков: ${((gp/Math.max(1,bp)-1)*100).toFixed(1)}% →`, gp>bp?"OK":"FAIL");
