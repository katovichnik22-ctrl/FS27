// Самотестирование движка и БД (не входит в сборку)
import { MAIN_DB, getTeam } from "../src/data/db";
import { simulateMatch } from "../src/engine/match";

const home = getTeam("arsenal");
const away = getTeam("liverpool");

// 1. MAIN_DB неизменна после серии быстрых матчей
const before = JSON.stringify(MAIN_DB);
for (let i = 0; i < 10; i++) simulateMatch(home, away, { seed: 1000 + i });
const after = JSON.stringify(MAIN_DB);
console.log("1) MAIN_DB неизменна после 10 симуляций:", before === after ? "OK" : "FAIL");

// 2. Воспроизводимость seed
const r1 = simulateMatch(home, away, { seed: 42 });
const r2 = simulateMatch(home, away, { seed: 42 });
const sameDeep = JSON.stringify(r1) === JSON.stringify(r2);
console.log("2) Один seed = один результат:", sameDeep ? "OK" : "FAIL", `(${r1.homeName} ${r1.homeScore}:${r1.awayScore} ${r1.awayName})`);
const r3 = simulateMatch(home, away, { seed: 43 });
console.log("   Другой seed ≠:", r3.homeScore !== r1.homeScore || r3.awayScore !== r1.awayScore || r3.events.length !== r1.events.length ? "OK" : "похоже, но допустимо");

// 3. Реалистичность тоталов (200 матчей)
let total = 0, big = 0, zero = 0;
const N = 200;
for (let i = 0; i < N; i++) {
  const r = simulateMatch(home, away, { seed: i * 7919 + 7 });
  const g = r.homeScore + r.awayScore;
  total += g;
  if (g > 7) big++;
  if (g === 0) zero++;
}
console.log(`3) Среднее голов за матч: ${(total / N).toFixed(2)} (топ-пара, цель 2.6–3.8), >7 голов: ${big}, 0:0: ${zero}`);
console.log(`   xG: ${r1.stats.xgH.toFixed(2)}–${r1.stats.xgA.toFixed(2)}, удары: ${r1.stats.shotsH}+${r1.stats.shotsA}, владение: ${r1.stats.possessionH}%`);

// 4. Рейтинги в диапазоне 3–10
let ok = true;
for (const v of Object.values(r1.playerRatings)) if (v < 3 || v > 10) ok = false;
console.log("4) Матч-рейтинги в 3.0–10.0:", ok ? "OK" : "FAIL");

// 5. Слабая команда vs сильная — сильная чаще выигрывает
const weak = getTeam("hull");
const strong = getTeam("man_city");
let strongWins = 0, weakWins = 0;
for (let i = 0; i < 100; i++) {
  const r = simulateMatch(weak, strong, { seed: 500 + i });
  if (r.homeScore > r.awayScore) weakWins++;
  else if (r.awayScore > r.homeScore) strongWins++;
}
console.log(`5) Hull (дома) vs Man City за 100 матчей: побед City ${strongWins}, побед Hull ${weakWins}, ничьих ${100 - strongWins - weakWins} →`, strongWins > weakWins ? "OK" : "FAIL");

// 6. Размеры составов: АПЛ >22, La Liga / Ligue 1 >=18
let allOk = true;
const counts: Record<string, number[]> = { PL: [], LL: [], FL1: [], BL: [], SA: [] };
for (const t of Object.values(MAIN_DB)) {
  if (!(t.league && counts[t.league])) continue; // проверяем только эти пять лиг
  counts[t.league].push(t.players.length);
  const min = t.league === "PL" ? 20 : 16;
  if (t.players.length < min) { allOk = false; console.log("   Мало игроков:", t.name, t.players.length); }
}
for (const [lg, c] of Object.entries(counts))
  console.log(`   ${lg}: ${c.length} клубов, составы ${Math.min(...c)}–${Math.max(...c)} игроков`);
console.log("6) Размеры составов в норме:", allOk ? "OK" : "FAIL");
console.log("7) Всего игроков в базе:", Object.values(MAIN_DB).reduce((a, t) => a + t.players.length, 0));
