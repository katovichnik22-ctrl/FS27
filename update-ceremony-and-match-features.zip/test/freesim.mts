const store = new Map<string,string>();
(globalThis as any).localStorage = { getItem:(k:string)=>store.get(k)??null, setItem:(k:string,v:string)=>store.set(k,v), removeItem:(k:string)=>store.delete(k) };
const { createSlot } = await import("../src/engine/storage");
const { simulateRound, simulateWholeComp, compsOverview, nextRound, buildTable, simulateFixture, advanceDay, LEAGUE_CFG } = await import("../src/engine/season");
const { finishSeason } = await import("../src/engine/ratings");
const { MAIN_DB } = await import("../src/data/db");
const mainBefore = JSON.stringify(MAIN_DB);

const slot = createSlot({ leagues: ["PL","LL"] });
const cnt = (c:string)=>slot.season.fixtures.filter(f=>f.comp===c&&f.played).length;
console.log("1) Турниры в слоте:", compsOverview(slot).map(c=>`${c.short}(0/${c.total})`).join(" "));

// один тур PL
const r = simulateRound(slot, "PL");
console.log(`2) Тур PL: ${r.round?.label}, матчей ${r.results.length}; сыграно PL ${cnt("PL")}, UCL ${cnt("UCL")}, LL ${cnt("LL")} →`,
  r.results.length===10 && cnt("UCL")===0 && cnt("LL")===0 ? "OK (только PL)" : "FAIL");

// вся лига целиком
const w = simulateWholeComp(slot, "PL");
const plIds = Object.values(slot.teams).filter(t=>t.league==="PL").map(t=>t.id);
const tbl = buildTable(slot.season.fixtures, plIds, "PL");
console.log(`3) Вся АПЛ: туров ${w.rounds+1}, матчей ${w.matches+10}/380; у всех по ${Math.min(...tbl.map(x=>x.p))}–${Math.max(...tbl.map(x=>x.p))} игр`);
console.log(`   чемпион ${slot.teams[tbl[0].teamId].name} ${tbl[0].pts} очк; еврокубки не тронуты: UCL ${cnt("UCL")}, UEL ${cnt("UEL")}, LL ${cnt("LL")} →`,
  cnt("PL")===380 && cnt("UCL")===0 && cnt("LL")===0 ? "OK" : "FAIL");

// еврокубок целиком (со стадиями плей-офф)
const u = simulateWholeComp(slot, "UCL");
console.log(`4) Вся ЛЧ: раундов ${u.rounds}, матчей ${u.matches}, победитель ${u.champion?slot.teams[u.champion].name:"—"} →`, u.champion?"OK":"FAIL");
console.log(`   La Liga по-прежнему не тронута: ${cnt("LL")} →`, cnt("LL")===0?"OK":"FAIL");

// кубок целиком
const fa = simulateWholeComp(slot, "FA");
console.log(`5) FA Cup: раундов ${fa.rounds}, матчей ${fa.matches}, обладатель ${fa.champion?slot.teams[fa.champion].name:"—"} →`, fa.champion?"OK":"FAIL");

// счёт списка = счёт просмотра
let bad=0; for(const f of slot.season.fixtures.filter(f=>f.played)){ const x=simulateFixture(slot,f); if(x.homeScore!==f.result!.h||x.awayScore!==f.result!.a) bad++; }
console.log(`6) Расхождений счёта: ${bad} из ${slot.season.fixtures.filter(f=>f.played).length} →`, bad?"FAIL":"OK");

// добиваем остальное и подводим итоги
simulateWholeComp(slot,"LL"); simulateWholeComp(slot,"UEL"); simulateWholeComp(slot,"EFL"); simulateWholeComp(slot,"CDR");
for(let i=0;i<40 && slot.season.fixtures.some(f=>!f.played);i++) advanceDay(slot);
console.log(`7) Все матчи сыграны: ${!slot.season.fixtures.some(f=>!f.played)} · сезон завершён: ${slot.season.finished}`);
const rep = finishSeason(slot);
console.log(`   Чемпионы: ${Object.entries(rep.champions).map(([k,v])=>`${k}=${slot.teams[v!].shortName}`).join(" ")}`);
console.log(`   Рейтинги обновлены у ${rep.all.length} игроков`);
console.log("8) MAIN_DB не изменилась:", JSON.stringify(MAIN_DB)===mainBefore?"OK":"FAIL");
