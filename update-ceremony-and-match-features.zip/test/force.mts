import { MAIN_DB, deepClone } from "../src/data/db";
import { simulateMatch } from "../src/engine/match";
import { buildAllTactics } from "../src/engine/tactics";
import type { Team } from "../src/types";
const t = deepClone(MAIN_DB) as Record<string, Team>;
const tac = buildAllTactics(t);
const targets: [number, number][] = [[0,0],[1,0],[2,1],[3,3],[5,4],[7,0],[10,2],[0,6],[4,4]];
let ok = 0;
for (const [h,a] of targets) {
  let hits = 0;
  for (let i=0;i<20;i++){
    const m = simulateMatch(t.hull, t.man_city, { seed: 700+i, forceScore: {h,a}, homeTactics: tac.hull, awayTactics: tac.man_city });
    if (m.homeScore===h && m.awayScore===a) hits++;
  }
  const good = hits===20;
  if (good) ok++;
  console.log(`  ${h}:${a} → точный счёт ${hits}/20 ${good?"OK":"FAIL"}`);
}
console.log(`Итого: ${ok}/${targets.length} целей достигнуто точно`);
const m = simulateMatch(t.hull, t.man_city, { seed: 5, forceScore: {h:5,a:4}, homeTactics: tac.hull, awayTactics: tac.man_city });
const goals = m.events.filter(e=>e.type==="goal"||e.type==="penalty");
console.log(`\n5:4 детально: голов в ленте ${goals.length}, минуты ${goals.map(e=>e.minute).join(",")}`);
console.log(`  удары ${m.stats.shotsH}/${m.stats.shotsA} · xG ${m.stats.xgH.toFixed(2)}/${m.stats.xgA.toFixed(2)} · владение ${m.stats.possessionH}%`);
const scorers = goals.map(e=>Object.values(t).flatMap(x=>x.players).find(p=>p.id===e.playerId)?.name);
console.log(`  авторы: ${scorers.join(", ")}`);
const sum = Object.values(m.playerMatchStats).reduce((a,l)=>a+l.goals,0);
console.log(`  сумма голов в статистике игроков: ${sum} (счёт ${m.homeScore}+${m.awayScore}=${m.homeScore+m.awayScore}) →`, sum===m.homeScore+m.awayScore?"OK":"FAIL");
