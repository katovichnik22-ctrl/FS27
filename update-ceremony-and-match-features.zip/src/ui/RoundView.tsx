// ─── Раздел «Тур»: сводка по одному туру выбранной лиги ────────────────────
import { useMemo, useState } from "react";
import { Copy, Check, Star, Target, Trophy, LayoutGrid } from "lucide-react";
import type { Competition, Fixture, Player, Slot } from "../types";
import { COMP_NAME, LEAGUE_CFG } from "../engine/season";
import { loadSettings } from "../engine/storage";
import { copyText } from "../utils/copy";
import { Panel, PanelHead, Select, Crest, ratingClass, Btn } from "./bits";
import { cn } from "../utils/cn";

interface RoundData {
  fixtures: Fixture[];
  /** все игроки тура с их вкладом, отсортированные по рейтингу */
  players: { p: Player; teamId: string; rating: number; goals: number; assists: number }[];
}

function collectRound(slot: Slot, comp: Competition, matchday: number): RoundData {
  const fixtures = slot.season.fixtures.filter((f) => f.comp === comp && f.matchday === matchday);
  const players: RoundData["players"] = [];
  for (const f of fixtures) {
    if (!f.result) continue;
    for (const t of [f.homeId, f.awayId]) {
      const team = slot.teams[t];
      if (!team) continue;
      for (const p of team.players) {
        const line = (f.result as any).lines?.[p.id];
        if (!line) continue;
        players.push({
          p, teamId: t,
          rating: line.rating ?? 6, goals: line.goals ?? 0, assists: line.assists ?? 0,
        });
      }
    }
  }
  players.sort((a, b) => b.rating - a.rating || b.goals - a.goals);
  return { fixtures, players };
}

/** Текст поста для ТГ (Telegram-канал) */
export function roundPostText(
  slot: Slot, data: RoundData, comp: Competition, matchday: number, settings: ReturnType<typeof loadSettings>
): string {
  const league = comp === "PL" ? settings.leagueName : (LEAGUE_CFG as any)[comp]?.name ?? COMP_NAME[comp];
  const L: string[] = [];
  L.push(`🏆 ${league} — тур ${matchday}`);
  L.push("");

  // Игрок тура
  const top = data.players[0];
  if (top) L.push(`⭐ Игрок тура: ${top.p.name} (${slot.teams[top.teamId]?.shortName}) — ${top.rating.toFixed(1)}`);

  // Сборная тура 4-3-3
  L.push("");
  L.push("📋 Сборная тура (4-3-3):");
  const xi: RoundData["players"] = [];
  const byPos: Record<string, RoundData["players"]> = { GK: [], DF: [], MF: [], FW: [] };
  for (const row of data.players) byPos[row.p.position]?.push(row);
  const need: Record<string, number> = { GK: 1, DF: 4, MF: 3, FW: 3 };
  for (const pos of ["GK", "DF", "MF", "FW"]) {
    xi.push(...byPos[pos].slice(0, need[pos]));
  }
  for (const pos of ["GK", "DF", "MF", "FW"]) {
    const line = xi.filter((x) => x.p.position === pos);
    if (!line.length) continue;
    const lbl = pos === "GK" ? "ВР" : pos === "DF" ? "ЗАЩ" : pos === "MF" ? "ПЗ" : "НАП";
    L.push(`  ${lbl}: ${line.map((x) => `${x.p.name} (${x.rating.toFixed(1)})`).join(", ")}`);
  }

  // Топ-5 бомбардиров тура
  const scorers = [...data.players].filter((x) => x.goals > 0).sort((a, b) => b.goals - a.goals || b.assists - a.assists).slice(0, 5);
  if (scorers.length) {
    L.push("");
    L.push("⚽ Бомбардиры тура:");
    scorers.forEach((s, i) => L.push(`  ${i + 1}. ${s.p.name} (${slot.teams[s.teamId]?.shortName}) — ${s.goals}`));
  }

  // Результаты
  L.push("");
  L.push("📊 Результаты:");
  const sorted = [...data.fixtures].sort((a, b) => (a.date < b.date ? -1 : 1));
  for (const f of sorted) {
    const h = slot.teams[f.homeId]?.shortName ?? "?";
    const a = slot.teams[f.awayId]?.shortName ?? "?";
    const sc = f.result ? `${f.result.h}:${f.result.a}` : "—:—";
    L.push(`  ${h} ${sc} ${a}`);
  }

  L.push("");
  L.push(settings.leagueHashtag || "#PremierLeague");
  return L.join("\n");
}

export function RoundView({ slot, onMatch }: { slot: Slot; onMatch: (f: Fixture) => void }) {
  const present = useMemo(() => {
    const has = new Set(slot.season.fixtures.map((f) => f.comp));
    const order: Competition[] = ["PL", "LL", "FL1", "BL", "SA", "PT", "SPL", "TUR", "BEL", "NED", "GRE", "UKR", "POL", "SCO", "SUI", "CHA"];
    return order.filter((c) => has.has(c));
  }, [slot]);

  const [comp, setComp] = useState<Competition>(present[0] ?? "PL");
  const [matchday, setMatchday] = useState(1);
  const [copied, setCopied] = useState(false);

  const maxMds = useMemo(() => {
    const all = slot.season.fixtures.filter((f) => f.comp === comp);
    return all.length ? Math.max(...all.map((f) => f.matchday)) : 1;
  }, [slot, comp]);

  const data = useMemo(
    () => collectRound(slot, comp, matchday),
    [slot, comp, matchday, slot.currentDate]
  );

  const copyPost = async () => {
    const settings = loadSettings();
    const text = roundPostText(slot, data, comp, matchday, settings);
    if (await copyText(text)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    }
  };

  const top = data.players[0];
  const scorers = [...data.players]
    .filter((x) => x.goals > 0)
    .sort((a, b) => b.goals - a.goals || b.assists - a.assists)
    .slice(0, 5);

  // Сборная 4-3-3
  const byPos: Record<string, typeof data.players> = { GK: [], DF: [], MF: [], FW: [] };
  for (const row of data.players) byPos[row.p.position]?.push(row);
  const need: Record<string, number> = { GK: 1, DF: 4, MF: 3, FW: 3 };
  const xi = (["GK", "DF", "MF", "FW"] as const).flatMap((pos) => byPos[pos].slice(0, need[pos]));

  const results = useMemo(
    () => [...data.fixtures].sort((a, b) => (a.date < b.date ? -1 : 1)),
    [data.fixtures]
  );

  if (!present.length) {
    return <p className="py-8 text-center text-[12px] text-[#6b7280]">Лиг ещё нет</p>;
  }

  return (
    <div className="space-y-3">
      {/* Селекторы */}
      <div className="flex flex-wrap items-center gap-1.5">
        <Select value={comp} onChange={(e) => setComp(e.target.value as Competition)}>
          {present.map((c) => (
            <option key={c} value={c}>{COMP_NAME[c]}</option>
          ))}
        </Select>
        <Select value={matchday} onChange={(e) => setMatchday(Number(e.target.value))}>
          {Array.from({ length: maxMds }, (_, i) => i + 1).map((md) => (
            <option key={md} value={md}>Тур {md}</option>
          ))}
        </Select>
        <Btn
          className="ml-auto"
          onClick={copyPost}
          disabled={!data.fixtures.length}
          icon={copied ? <Check size={13} className="text-[#4ade80]" /> : <Copy size={13} />}
        >
          {copied ? "Скопировано" : "📋 Скопировать как пост для ТГК"}
        </Btn>
      </div>

      {/* Игрок тура */}
      {top && (
        <Panel className="border-[#fbbf24]/40 bg-[#fbbf24]/5">
          <div className="flex items-center gap-3">
            <span className="rounded-xl bg-[#fbbf24] p-2.5 text-[#2a1e00]"><Star size={20} className="fill-current" /></span>
            <div className="min-w-0 flex-1">
              <div className="text-[10px] font-bold uppercase tracking-widest text-[#fbbf24]">Игрок тура</div>
              <div className="truncate text-[17px] font-black text-white">{top.p.name}</div>
              <div className="truncate text-[11.5px] text-[#9ca3af]">
                {slot.teams[top.teamId]?.name} · {top.p.position} · {top.goals} гол. {top.assists} пас.
              </div>
            </div>
            <span className={cn("rounded-lg px-2.5 py-1 font-mono text-xl font-black", ratingClass(top.rating))}>
              {top.rating.toFixed(1)}
            </span>
          </div>
        </Panel>
      )}

      <div className="m-stack grid gap-3 lg:grid-cols-2">
        {/* Сборная тура */}
        <Panel>
          <PanelHead title={<span className="flex items-center gap-1.5"><LayoutGrid size={12} /> Сборная тура · 4-3-3</span>} />
          {!xi.length && <p className="py-4 text-center text-[12px] text-[#6b7280]">Нет данных — тур не сыгран</p>}
          {(["GK", "DF", "MF", "FW"] as const).map((pos) => {
            const line = xi.filter((x) => x.p.position === pos);
            if (!line.length) return null;
            const lbl = pos === "GK" ? "ВРАТАРЬ" : pos === "DF" ? "ЗАЩИТА" : pos === "MF" ? "ПОЛУЗАЩИТА" : "НАПАДЕНИЕ";
            return (
              <div key={pos} className="mb-2 last:mb-0">
                <div className="mb-1 text-[9.5px] font-bold uppercase tracking-widest text-[#6b7280]">{lbl}</div>
                {line.map((x) => (
                  <div key={x.p.id} className="flex items-center gap-2 border-b border-[#232b36] py-1 text-[12.5px] last:border-0">
                    <Crest name={slot.teams[x.teamId]?.name ?? "?"} color={slot.teams[x.teamId]?.color ?? "#555"} size={12} />
                    <span className="min-w-0 flex-1 truncate font-medium">{x.p.name}</span>
                    {x.goals > 0 && <span className="text-[10px] text-[#4ade80]">⚽{x.goals}</span>}
                    {x.assists > 0 && <span className="text-[10px] text-[#60a5fa]">🅰{x.assists}</span>}
                    <span className={cn("w-10 rounded px-1 text-center font-mono text-[11px] font-bold", ratingClass(x.rating))}>
                      {x.rating.toFixed(1)}
                    </span>
                  </div>
                ))}
              </div>
            );
          })}
        </Panel>

        <div className="space-y-3">
          {/* Бомбардиры */}
          <Panel>
            <PanelHead title={<span className="flex items-center gap-1.5"><Target size={12} /> Бомбардиры тура</span>} />
            {!scorers.length && <p className="py-3 text-center text-[12px] text-[#6b7280]">Голов не забито</p>}
            {scorers.map((s, i) => (
              <div key={s.p.id} className="flex items-center gap-2 border-b border-[#232b36] py-1 text-[12.5px] last:border-0">
                <span className="w-4 text-center font-mono text-[10px] text-[#6b7280]">{i + 1}</span>
                <Crest name={slot.teams[s.teamId]?.name ?? "?"} color={slot.teams[s.teamId]?.color ?? "#555"} size={12} />
                <span className="min-w-0 flex-1 truncate">{s.p.name}</span>
                {s.assists > 0 && <span className="text-[10px] text-[#60a5fa]">🅰{s.assists}</span>}
                <span className="w-7 text-right font-mono text-[13px] font-bold text-[#4ade80]">{s.goals}</span>
              </div>
            ))}
          </Panel>

          {/* Результаты */}
          <Panel>
            <PanelHead title={<span className="flex items-center gap-1.5"><Trophy size={12} /> Результаты тура</span>} />
            {!results.length && <p className="py-3 text-center text-[12px] text-[#6b7280]">Матчей нет</p>}
            {results.map((f) => (
              <button
                key={f.id}
                onClick={() => onMatch(f)}
                className="flex w-full items-center gap-2 border-b border-[#232b36] py-1.5 text-left text-[12.5px] last:border-0 hover:bg-[#2a3140]"
              >
                <span className="w-11 shrink-0 text-center font-mono text-[12px] font-bold">
                  {f.result ? `${f.result.h}:${f.result.a}` : "—:—"}
                </span>
                <span className="flex min-w-0 flex-1 items-center justify-end gap-1.5">
                  <span className={cn("truncate", f.result && f.result.h > f.result.a && "font-semibold")}>
                    {slot.teams[f.homeId]?.shortName}
                  </span>
                  <Crest name={slot.teams[f.homeId]?.name ?? "?"} color={slot.teams[f.homeId]?.color ?? "#555"} size={11} />
                </span>
                <span className="flex min-w-0 flex-1 items-center gap-1.5">
                  <Crest name={slot.teams[f.awayId]?.name ?? "?"} color={slot.teams[f.awayId]?.color ?? "#555"} size={11} />
                  <span className={cn("truncate", f.result && f.result.a > f.result.h && "font-semibold")}>
                    {slot.teams[f.awayId]?.shortName}
                  </span>
                </span>
              </button>
            ))}
          </Panel>
        </div>
      </div>
    </div>
  );
}
