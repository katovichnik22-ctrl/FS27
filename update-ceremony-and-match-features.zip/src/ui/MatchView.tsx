// ─── Карточка матча: живая трансляция и детальный разбор ────────────────────
import { useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import { Play, Pause, SkipForward, Copy, Check, X, Activity, BarChart3, Users, Star, Table2, Wand2 } from "lucide-react";
import type { MatchEvent, MatchResult, Player, Team } from "../types";
import { Btn, Crest, Panel, PanelHead, StatBar, Tabs, ratingClass, PosBadge } from "./bits";
import { cn } from "../utils/cn";
import { loadSettings } from "../engine/storage";
import { matchReportText, copyText } from "../utils/copy";

const SPEEDS = [
  { label: "x1", ms: 150 },
  { label: "x5", ms: 55 },
  { label: "x10", ms: 20 },
  { label: "MAX", ms: 3 },
];

export function minuteLabel(m: number): string {
  return m <= 90 ? `${m}'` : `90+${m - 90}'`;
}

const EV: Record<string, { icon: string; cls: string }> = {
  goal: { icon: "⚽", cls: "text-[#4ade80]" },
  penalty: { icon: "🥅", cls: "text-[#4ade80]" },
  penalty_miss: { icon: "❌", cls: "text-[#f87171]" },
  miss: { icon: "😖", cls: "text-[#fbbf24]" },
  offside: { icon: "🚩", cls: "text-[#9ca3af]" },
  own_goal: { icon: "⚽", cls: "text-[#f87171]" },
  block: { icon: "🛡", cls: "text-[#9ca3af]" },
  corner: { icon: "🚩", cls: "text-[#9ca3af]" },
  post: { icon: "🎯", cls: "text-[#fbbf24]" },
  save: { icon: "🧤", cls: "text-[#60a5fa]" },
  yellow: { icon: "🟨", cls: "text-[#fbbf24]" },
  second_yellow: { icon: "🟨🟥", cls: "text-[#ef4444]" },
  red: { icon: "🟥", cls: "text-[#ef4444]" },
  injury: { icon: "🚑", cls: "text-[#f472b6]" },
  sub: { icon: "🔄", cls: "text-[#9ca3af]" },
  ht: { icon: "⏸", cls: "text-[#9ca3af]" },
  ft: { icon: "🏁", cls: "text-[#e5e7eb]" },
  kickoff: { icon: "▶", cls: "text-[#9ca3af]" },
};

interface Props {
  result: MatchResult;
  teams: Record<string, Team>;
  instant?: boolean;
  onClose: () => void;
  closeLabel?: string;
  standings?: ReactNode;
  /** показывать поверх экрана (детальный просмотр сыгранного матча) */
  overlay?: boolean;
  onRematch?: () => void;
  /** открыть редактор счёта */
  onEditScore?: () => void;
  /** счёт был задан вручную */
  manual?: boolean;
  /** фикстура — для стадиона, тура и лиги в копируемом отчёте */
  fixture?: { homeId: string; awayId: string; matchday: number; comp: string } | null;
  /** слот — для поиска имён игроков при формировании отчёта */
  slot?: { teams: Record<string, Team> };
}

export function MatchView({ result, teams, instant, onClose, closeLabel = "Закрыть", standings, overlay, onRematch, onEditScore, manual, fixture, slot }: Props) {
  const minutes = result.minutes;
  const [idx, setIdx] = useState(instant ? minutes.length : 0);
  const [playing, setPlaying] = useState(!instant);
  const [speedIdx, setSpeedIdx] = useState(1);
  const [tab, setTab] = useState<"feed" | "stats" | "lineups" | "ratings" | "table">("feed");
  const [copied, setCopied] = useState(false);
  const feedRef = useRef<HTMLDivElement>(null);
  const finished = idx >= minutes.length;

  const pmap = useMemo(() => {
    const m = new Map<string, Player>();
    for (const t of [result.homeId, result.awayId]) for (const p of teams[t]?.players ?? []) m.set(p.id, p);
    return m;
  }, [result, teams]);
  const pname = (id?: string) => (id ? pmap.get(id)?.name ?? "?" : "—");

  useEffect(() => {
    if (!playing || finished) return;
    const t = setInterval(() => setIdx((i) => Math.min(minutes.length, i + 1)), SPEEDS[speedIdx].ms);
    return () => clearInterval(t);
  }, [playing, finished, speedIdx, minutes.length]);

  useEffect(() => { if (feedRef.current) feedRef.current.scrollTop = 0; }, [idx]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);

  const live = useMemo(() => {
    let h = 0, a = 0;
    const acc = { shotsH: 0, shotsA: 0, sotH: 0, sotA: 0, corH: 0, corA: 0, foulsH: 0, foulsA: 0, xgH: 0, xgA: 0 };
    const evs: MatchEvent[] = [];
    for (let i = 0; i < Math.min(idx, minutes.length); i++) {
      const ml = minutes[i];
      for (const k of Object.keys(acc) as (keyof typeof acc)[]) acc[k] += ml.delta[k];
      for (const e of ml.events) {
        if (e.type === "goal") { if (e.teamId === result.homeId) h++; else a++; }
        evs.push(e);
      }
    }
    return { h, a, acc, evs };
  }, [idx, minutes, result.homeId]);

  const cur = minutes[Math.min(idx, minutes.length) - 1];
  const clock = finished ? "FT" : cur ? minuteLabel(cur.minute) : "0'";

  const copySeed = async () => {
    try { await navigator.clipboard.writeText(String(result.seed)); setCopied(true); setTimeout(() => setCopied(false), 1200); } catch { /* */ }
  };

  // Копирование текстового отчёта о матче (счёт, стадион, голы, статистика, MOTM)
  const [copiedReport, setCopiedReport] = useState(false);
  const copyReport = async () => {
    if (!slot) return;
    const settings = loadSettings();
    const fx = fixture
      ? ({ ...fixture, date: "", stage: "", neutral: false, played: true, result: null } as unknown as import("../types").Fixture)
      : null;
    const text = matchReportText(result, fx, slot as import("../types").Slot, settings);
    if (await copyText(text)) {
      setCopiedReport(true);
      setTimeout(() => setCopiedReport(false), 1400);
    }
  };

  const teamPlayers = (tid: string) =>
    (teams[tid]?.players ?? []).filter((p) => result.playerRatings[p.id] !== undefined);
  const startersOf = (tid: string) => result.lineups[tid] ?? [];

  const body = (
    <div className={cn("mx-auto w-full max-w-5xl p-2", overlay && "max-h-[92vh] overflow-y-auto")}>
      {/* ── Табло ── */}
      <Panel className="mb-2">
        <div className="flex items-center gap-2 sm:gap-4">
          <div className="flex min-w-0 flex-1 items-center justify-end gap-2">
            <span className="truncate text-[13px] font-semibold sm:text-[15px]">{result.homeName}</span>
            <Crest name={result.homeName} color={result.homeColor} size={26} />
          </div>
          <div className="flex shrink-0 flex-col items-center">
            <span className="font-mono text-2xl font-black tabular-nums sm:text-3xl">
              {live.h}<span className="mx-1 text-[#4b5563]">:</span>{live.a}
            </span>
            {finished && result.pens && (
              <span className="text-[10px] text-[#fbbf24]">пен. {result.pens.h}:{result.pens.a}</span>
            )}
            {manual && <span className="text-[9px] text-[#a78bfa]">✎ счёт задан вручную</span>}
            <span className={cn("rounded px-1.5 font-mono text-[10.5px] font-bold",
              finished ? "bg-[#232b36] text-[#9ca3af]" : "fs-live bg-[#4ade80]/15 text-[#4ade80]")}>
              {clock}
            </span>
          </div>
          <div className="flex min-w-0 flex-1 items-center gap-2">
            <Crest name={result.awayName} color={result.awayColor} size={26} />
            <span className="truncate text-[13px] font-semibold sm:text-[15px]">{result.awayName}</span>
          </div>
        </div>

        <div className="mt-2 h-[3px] overflow-hidden rounded-full bg-[#0f1419]">
          <div className="h-full bg-gradient-to-r from-[#4ade80] to-[#3b82f6] transition-all duration-150"
            style={{ width: `${(Math.min(idx, minutes.length) / minutes.length) * 100}%` }} />
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          {!finished ? (
            <>
              <Btn variant="primary" onClick={() => setPlaying((p) => !p)} icon={playing ? <Pause size={13} /> : <Play size={13} />}>
                {playing ? "Пауза" : "Играть"}
              </Btn>
              <div className="flex overflow-hidden rounded-md border border-[#2f3847]">
                {SPEEDS.map((s, i) => (
                  <button key={s.label} onClick={() => { setSpeedIdx(i); setPlaying(true); }}
                    className={cn("px-2 py-1 font-mono text-[11px] transition-colors",
                      i === speedIdx ? "bg-[#3b82f6] font-bold text-white" : "text-[#9ca3af] hover:bg-[#232b36]")}>
                    {s.label}
                  </button>
                ))}
              </div>
              <Btn onClick={() => { setIdx(minutes.length); setPlaying(false); }} icon={<SkipForward size={13} />}>Мгновенно</Btn>
            </>
          ) : (
            <>
              <Btn variant="primary" onClick={onClose} icon={<X size={13} />}>{closeLabel}</Btn>
              {onRematch && <Btn variant="outline" onClick={onRematch}>Ещё раз</Btn>}
            </>
          )}
          {!finished && <Btn variant="outline" onClick={onClose}>{closeLabel}</Btn>}
          {onEditScore && (
            <Btn variant="outline" onClick={onEditScore} icon={<Wand2 size={13} />} title="Задать счёт вручную">
              Изменить счёт
            </Btn>
          )}
          {slot && (
            <Btn
              variant="outline"
              onClick={copyReport}
              icon={copiedReport ? <Check size={13} className="text-[#4ade80]" /> : <Copy size={13} />}
              title="Скопировать отчёт о матче"
            >
              {copiedReport ? "Скопировано" : "Скопировать"}
            </Btn>
          )}
          <span className="ml-auto flex items-center gap-1 text-[10.5px] text-[#4b5563]">
            seed <span className="font-mono text-[#6b7280]">{result.seed}</span>
            <button onClick={copySeed} className="rounded p-0.5 hover:text-[#3b82f6]">
              {copied ? <Check size={11} className="text-[#4ade80]" /> : <Copy size={11} />}
            </button>
          </span>
        </div>
      </Panel>

      <div className="m-stack grid gap-2 lg:grid-cols-[1.15fr_1fr]">
        <Panel>
          <Tabs
            className="mb-2"
            value={tab}
            onChange={setTab}
            items={[
              { id: "feed" as const, label: "События" },
              { id: "stats" as const, label: "Статистика" },
              { id: "lineups" as const, label: "Составы" },
              { id: "ratings" as const, label: "Рейтинги" },
              ...(standings ? [{ id: "table" as const, label: "Таблица" }] : []),
            ]}
          />

          {tab === "feed" && (
            <div ref={feedRef} className="h-[380px] overflow-y-auto rounded-md border border-[#2a3140] bg-[#182029]">
              {!live.evs.length && <p className="p-6 text-center text-[12px] text-[#6b7280]">Ожидаем первый свисток…</p>}
              {[...live.evs].reverse().map((e, i) => {
                const meta = EV[e.type] ?? EV.kickoff;
                const home = e.teamId === result.homeId;
                return (
                  <div key={i} className="flex items-start gap-2 border-b border-[#232b36] px-2 py-1 text-[12.5px] last:border-0">
                    <span className="w-9 shrink-0 text-right font-mono text-[10.5px] text-[#6b7280]">
                      {e.type === "ht" ? "45'" : e.type === "kickoff" ? "0'" : minuteLabel(e.minute)}
                    </span>
                    <span className="w-6 shrink-0 text-center">{meta.icon}</span>
                    <div className={cn("min-w-0 flex-1 leading-snug", meta.cls)}>
                      {e.type === "goal" && (
                        <span className="text-[#e5e7eb]">
                          <b>{pname(e.playerId)}</b>
                          {e.assistId && <span className="text-[#6b7280]"> (пас: {pname(e.assistId)})</span>}
                        </span>
                      )}
                      {e.type === "post" && <span>Штанга — {pname(e.playerId)}</span>}
                      {e.type === "penalty" && <span className="text-[#e5e7eb]"><b>{pname(e.playerId)}</b> — пенальти реализован</span>}
                      {e.type === "penalty_miss" && <span>{pname(e.playerId)} не забил пенальти</span>}
                      {e.type === "miss" && <span>{pname(e.playerId)} промахнулся из убойной позиции{e.xg ? ` (xG ${e.xg.toFixed(2)})` : ""}</span>}
                      {e.type === "offside" && <span>Офсайд — {pname(e.playerId)}</span>}
                      {e.type === "save" && (
                        <span>Сейв — {pname(e.playerId)}{e.quality ? <span className="text-[#6b7280]"> (сложность {e.quality.toFixed(2)})</span> : null}</span>
                      )}
                      {(e.type === "yellow" || e.type === "red" || e.type === "second_yellow") && (
                        <span>{pname(e.playerId)}{e.note ? <span className="text-[#6b7280]"> · {e.note}</span> : null}</span>
                      )}
                      {e.type === "injury" && <span>Травма: {pname(e.playerId)}{e.note ? ` — ${e.note}` : ""}</span>}
                      {e.type === "sub" && (
                        <span className="text-[#9ca3af]">
                          <span className="text-[#4ade80]">↑</span> {pname(e.playerInId)} · <span className="text-[#f87171]">↓</span> {pname(e.playerOutId)}
                        </span>
                      )}
                      {(e.type === "ht" || e.type === "ft" || e.type === "kickoff") && (
                        <span>{e.type === "ht" ? "Перерыв" : e.type === "ft" ? "Матч окончен" : "Стартовый свисток"}</span>
                      )}
                    </div>
                    {e.teamId && <Crest name={home ? result.homeName : result.awayName} color={home ? result.homeColor : result.awayColor} size={13} />}
                  </div>
                );
              })}
            </div>
          )}

          {tab === "stats" && (
            <div className="h-[380px] overflow-y-auto pr-1">
              <div className="mb-1 flex items-center justify-between text-[11px] font-semibold">
                <span>{result.homeShort}</span><span>{result.awayShort}</span>
              </div>
              <StatBar label="Владение, %" home={result.stats.possessionH} away={result.stats.possessionA} />
              <StatBar label="Удары" home={result.stats.shotsH} away={result.stats.shotsA} />
              <StatBar label="В створ" home={result.stats.sotH} away={result.stats.sotA} />
              <StatBar label="xG" home={result.stats.xgH} away={result.stats.xgA} format={(v) => v.toFixed(2)} />
              <StatBar label="Угловые" home={result.stats.cornersH} away={result.stats.cornersA} />
              <StatBar label="Фолы" home={result.stats.foulsH} away={result.stats.foulsA} />
              <StatBar label="Жёлтые" home={result.stats.yellowH} away={result.stats.yellowA} />
              <StatBar label="Красные" home={result.stats.redH} away={result.stats.redA} />
              <StatBar label="Сейвы" home={result.stats.savesH} away={result.stats.savesA} />
              <StatBar label="Офсайды" home={result.stats.offsidesH} away={result.stats.offsidesA} />
              <StatBar label="Пенальти" home={result.stats.penaltiesH} away={result.stats.penaltiesA} />
              <StatBar label="Голевые моменты" home={result.stats.bigChancesH} away={result.stats.bigChancesA} />
              <StatBar label="Передачи" home={result.stats.passesH} away={result.stats.passesA} />
              <StatBar label="Точность паса, %" home={result.stats.passAccH} away={result.stats.passAccA} />
              <div className="mt-2 text-center text-[10.5px] text-[#6b7280]">
                Погода: {result.weather === "clear" ? "☀️ ясно" : result.weather === "rain" ? "🌧 дождь" : result.weather === "snow" ? "❄️ снег" : "💨 ветер"}
                {result.injuries.length > 0 && ` · травм за матч: ${result.injuries.length}`}
              </div>
            </div>
          )}

          {tab === "lineups" && (
            <div className="grid h-[380px] grid-cols-2 gap-2 overflow-y-auto">
              {([result.homeId, result.awayId] as const).map((tid) => {
                const starters = startersOf(tid);
                const subs = teamPlayers(tid).filter((p) => !starters.some((s) => s.id === p.id));
                return (
                  <div key={tid}>
                    <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold">
                      <Crest name={teams[tid].name} color={teams[tid].color} size={14} />
                      <span className="truncate">{teams[tid].shortName}</span>
                    </div>
                    {starters.map((p) => (
                      <div key={p.id} className="flex items-center gap-1 border-b border-[#232b36] py-0.5 text-[11.5px]">
                        <PosBadge pos={p.position} />
                        <span className="min-w-0 flex-1 truncate">{p.name}</span>
                        {result.playerRatings[p.id] !== undefined && (
                          <span className={cn("rounded px-1 font-mono text-[10.5px] font-bold", ratingClass(result.playerRatings[p.id]))}>
                            {result.playerRatings[p.id].toFixed(1)}
                          </span>
                        )}
                      </div>
                    ))}
                    {!!subs.length && <div className="mt-1 text-[9.5px] uppercase tracking-wider text-[#6b7280]">вышли на замену</div>}
                    {subs.map((p) => (
                      <div key={p.id} className="flex items-center gap-1 border-b border-[#232b36] py-0.5 text-[11.5px] text-[#9ca3af]">
                        <PosBadge pos={p.position} />
                        <span className="min-w-0 flex-1 truncate">{p.name}</span>
                        <span className={cn("rounded px-1 font-mono text-[10.5px]", ratingClass(result.playerRatings[p.id]))}>
                          {result.playerRatings[p.id].toFixed(1)}
                        </span>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          )}

          {tab === "ratings" && (
            <div className="h-[380px] overflow-y-auto">
              <div className="mb-1.5 flex flex-wrap gap-1.5">
                {result.topPerformers.map((t, i) => (
                  <span key={t.playerId} className="rounded border border-[#2a3140] bg-[#182029] px-1.5 py-0.5 text-[10.5px]">
                    {["🥇", "🥈", "🥉"][i]} {pname(t.playerId)} <b className="text-[#4ade80]">{t.rating.toFixed(1)}</b>
                  </span>
                ))}
              </div>
              {([result.homeId, result.awayId] as const).map((tid) => (
                <div key={tid} className="mb-2">
                  <div className="mb-0.5 flex items-center gap-1.5 text-[11px] font-bold text-[#9ca3af]">
                    <Crest name={teams[tid].name} color={teams[tid].color} size={13} /> {teams[tid].name}
                  </div>
                  {teamPlayers(tid)
                    .sort((a, b) => result.playerRatings[b.id] - result.playerRatings[a.id])
                    .map((p) => (
                      <div key={p.id} className="flex items-center gap-1.5 border-b border-[#232b36] py-0.5 text-[12px] last:border-0">
                        <PosBadge pos={p.position} />
                        <span className={cn("min-w-0 flex-1 truncate", p.id === result.motm && "font-semibold")}>
                          {p.name}
                          {p.id === result.motm && <Star size={10} className="mb-0.5 ml-1 inline fill-[#fbbf24] text-[#fbbf24]" />}
                        </span>
                        {(() => {
                          const l = result.playerMatchStats[p.id];
                          if (!l) return null;
                          return (
                            <span className="hidden shrink-0 gap-1.5 font-mono text-[9.5px] text-[#6b7280] sm:flex">
                              <span>{l.minutes}'</span>
                              {!!l.goals && <span className="text-[#4ade80]">{l.goals}г</span>}
                              {!!l.assists && <span className="text-[#60a5fa]">{l.assists}п</span>}
                              {!!l.shots && <span>{l.shots}уд</span>}
                              {l.xg > 0.04 && <span>xG {l.xg.toFixed(2)}</span>}
                              {!!l.keyPasses && <span>{l.keyPasses}кп</span>}
                              {!!(l.tackles + l.interceptions) && <span>{l.tackles + l.interceptions}об</span>}
                              {!!l.saves && <span className="text-[#fbbf24]">{l.saves}сэйв</span>}
                            </span>
                          );
                        })()}
                        <span className={cn("w-9 rounded text-center font-mono text-[11px] font-bold", ratingClass(result.playerRatings[p.id]))}>
                          {result.playerRatings[p.id].toFixed(1)}
                        </span>
                      </div>
                    ))}
                </div>
              ))}
            </div>
          )}

          {tab === "table" && standings && <div className="h-[380px] overflow-y-auto pr-1">{standings}</div>}
        </Panel>

        <div className="space-y-2">
          <Panel>
            <PanelHead title="Live-статистика" icon={<Activity size={12} />} />
            <StatBar label="Удары" home={live.acc.shotsH} away={live.acc.shotsA} />
            <StatBar label="В створ" home={live.acc.sotH} away={live.acc.sotA} />
            <StatBar label="xG" home={live.acc.xgH} away={live.acc.xgA} format={(v) => v.toFixed(2)} />
            <StatBar label="Угловые" home={live.acc.corH} away={live.acc.corA} />
            <StatBar label="Фолы" home={live.acc.foulsH} away={live.acc.foulsA} />
          </Panel>
          <Panel>
            <PanelHead title="Голы" icon={<BarChart3 size={12} />} />
            {!live.evs.filter((e) => e.type === "goal").length && (
              <p className="py-2 text-center text-[12px] text-[#6b7280]">Голов пока нет</p>
            )}
            {live.evs.filter((e) => e.type === "goal").map((e, i) => (
              <div key={i} className="flex items-center gap-1.5 border-b border-[#232b36] py-1 text-[12px] last:border-0">
                <span className="w-8 text-right font-mono text-[10.5px] text-[#6b7280]">{minuteLabel(e.minute)}</span>
                <Crest name={e.teamId === result.homeId ? result.homeName : result.awayName}
                  color={e.teamId === result.homeId ? result.homeColor : result.awayColor} size={13} />
                <span className="min-w-0 flex-1 truncate">{pname(e.playerId)}</span>
                {e.assistId && <span className="truncate text-[10px] text-[#6b7280]">пас: {pname(e.assistId)}</span>}
              </div>
            ))}
            {finished && result.motm && (
              <div className="mt-2 flex items-center justify-between rounded-md border border-[#fbbf24]/30 bg-[#fbbf24]/5 px-2 py-1.5">
                <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-[#fbbf24]">
                  <Star size={11} /> Игрок матча
                </span>
                <span className="text-[12.5px] font-semibold">{pname(result.motm)}</span>
                <span className={cn("rounded px-1.5 font-mono text-[11px] font-bold", ratingClass(result.playerRatings[result.motm]))}>
                  {result.playerRatings[result.motm].toFixed(1)}
                </span>
              </div>
            )}
          </Panel>
          <Panel>
            <PanelHead title="Составы" icon={<Users size={12} />} right={<Table2 size={11} className="text-[#4b5563]" />} />
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              {([result.homeId, result.awayId] as const).map((tid) => (
                <div key={tid}>
                  <div className="mb-0.5 truncate font-semibold text-[#9ca3af]">{teams[tid].shortName}</div>
                  {startersOf(tid).map((p) => (
                    <div key={p.id} className="truncate text-[#9ca3af]">{p.name.split(" ").pop()}</div>
                  ))}
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );

  if (overlay) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/75 p-2" onClick={onClose}>
        <div className="fs-fade w-full" onClick={(e) => e.stopPropagation()}>{body}</div>
      </div>
    );
  }
  return <div className="min-h-dvh bg-[#0f1419] py-2">{body}</div>;
}
