// ─── Быстрый матч: выбор команд → симуляция → результат ──────────────────────
// НИЧЕГО не сохраняет: работает только с замороженной MAIN_DB.
import { useMemo, useState } from "react";
import { ArrowLeft, Play, FastForward, Shuffle, Swords } from "lucide-react";
import { LEAGUES, MAIN_DB, TEAM_LIST, getTeam } from "../data/db";
import { simulateMatch } from "../engine/match";
import { defaultTactics } from "../engine/tactics";
import type { MatchResult, Team } from "../types";
import { Panel, Btn, PanelHead, Select, Crest } from "./bits";
import { MatchView } from "./MatchView";
import { loadSettings } from "../engine/storage";
import { cn } from "../utils/cn";

function TeamPreview({ team, side }: { team: Team; side: "H" | "A" }) {
  const best = [...team.players].sort((a, b) => b.overall - a.overall).slice(0, 3);
  return (
    <div className="min-w-0 flex-1">
      <div className={cn("flex items-center gap-2", side === "A" && "sm:flex-row-reverse")}>
        <Crest name="" color={team.color} size={14} />
        <span className="truncate text-lg font-bold text-white">{team.name}</span>
      </div>
      <div className={cn("mt-2 grid grid-cols-4 gap-1.5", side === "A" && "sm:direction-rtl")}>
        {(["attack", "midfield", "defense", "goalkeeping"] as const).map((k) => (
          <div key={k} className="rounded-lg bg-[#0f1419] px-2 py-1.5 text-center">
            <div className="text-[9px] uppercase tracking-wider text-[#6b7280]">
              {k === "attack" ? "АТК" : k === "midfield" ? "ПЗ" : k === "defense" ? "ЗАЩ" : "ВРТ"}
            </div>
            <div className={cn("font-mono text-sm font-bold", team[k] >= 84 ? "text-[#4ade80]" : team[k] >= 76 ? "text-[#e5e7eb]" : "text-[#9ca3af]")}>
              {team[k]}
            </div>
          </div>
        ))}
      </div>
      <div className={cn("mt-1.5 text-[11px] text-[#6b7280]", side === "A" && "sm:text-right")}>
        {team.stadium} · топ: {best.map((p) => p.name.split(" ").pop()).join(", ")}
      </div>
    </div>
  );
}

export function QuickMatch({ onMenu }: { onMenu: () => void }) {
  const settings = useMemo(loadSettings, []);
  const [homeId, setHomeId] = useState("arsenal");
  const [awayId, setAwayId] = useState("liverpool");
  const [result, setResult] = useState<MatchResult | null>(null);
  const [instant, setInstant] = useState(settings.skipBroadcast);

  const home = getTeam(homeId);
  const away = getTeam(awayId);
  const valid = homeId !== awayId;

  const runSim = (inst: boolean) => {
    if (!valid) return;
    // глубокая перестраховка: движок не мутирует, но и ссылок наружу не отдаём
    setInstant(inst);
    setResult(simulateMatch(home, away, { seed: Math.floor(Math.random() * 2 ** 31), homeTactics: defaultTactics(home), awayTactics: defaultTactics(away) }));
  };

  const randomTeams = () => {
    const ids = TEAM_LIST.map((t) => t.id);
    const h = ids[Math.floor(Math.random() * ids.length)];
    let a = ids[Math.floor(Math.random() * ids.length)];
    if (a === h) a = ids[(ids.indexOf(h) + 1) % ids.length];
    setHomeId(h);
    setAwayId(a);
    setResult(null);
  };

  if (result) {
    return (
      <MatchView
        result={result}
        teams={MAIN_DB as unknown as Record<string, Team>}
        instant={instant}
        onRematch={() => runSim(instant)}
        onClose={() => setResult(null)}
        closeLabel="Новый матч"
      />
    );
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-8">
      <Btn onClick={onMenu} icon={<ArrowLeft size={15} />}>В меню</Btn>
      <div className="mt-4">
        <Panel>
          <PanelHead title="Быстрый матч" />

          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-[#4ade80]">Хозяева</label>
              <Select value={homeId} onChange={(e) => setHomeId(e.target.value)} className="w-full">
                {LEAGUES.map((lg) => (
                  <optgroup key={lg.id} label={lg.name}>
                    {TEAM_LIST.filter((t) => t.league === lg.id).map((t) => (
                      <option key={t.id} value={t.id} disabled={t.id === awayId}>{t.name}</option>
                    ))}
                  </optgroup>
                ))}
              </Select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-widest text-[#fbbf24]">Гости</label>
              <Select value={awayId} onChange={(e) => setAwayId(e.target.value)} className="w-full">
                {LEAGUES.map((lg) => (
                  <optgroup key={lg.id} label={lg.name}>
                    {TEAM_LIST.filter((t) => t.league === lg.id).map((t) => (
                      <option key={t.id} value={t.id} disabled={t.id === homeId}>{t.name}</option>
                    ))}
                  </optgroup>
                ))}
              </Select>
            </div>
          </div>

          <div className="mt-4 flex flex-col gap-4 rounded-2xl border border-[#2a3140] bg-[#182029] p-4 sm:flex-row sm:items-start">
            <TeamPreview team={home} side="H" />
            <div className="flex items-center justify-center sm:pt-6">
              <span className="rounded-full border border-[#2f3847] bg-[#0f1419] p-2.5 text-[#9ca3af]">
                <Swords size={18} />
              </span>
            </div>
            <TeamPreview team={away} side="A" />
          </div>

          {!valid && (
            <p className="mt-3 text-center text-sm text-[#f87171]">Выберите две разные команды</p>
          )}

          <div className="mt-5 flex flex-wrap items-center justify-center gap-2.5">
            <Btn variant="primary" disabled={!valid} onClick={() => runSim(false)} icon={<Play size={16} />} className="px-6">
              Смотреть трансляцию
            </Btn>
            <Btn variant="warn" disabled={!valid} onClick={() => runSim(true)} icon={<FastForward size={16} />} className="px-6">
              Мгновенный результат
            </Btn>
            <Btn onClick={randomTeams} icon={<Shuffle size={15} />} title="Случайные команды">
              Случайно
            </Btn>
          </div>
          <p className="mt-4 text-center text-[11px] text-[#6b7280]">
            Поминутная симуляция: удары, xG, сейвы, карточки, травмы, замены · каждый запуск — новый seed
          </p>
        </Panel>
      </div>
    </div>
  );
}
