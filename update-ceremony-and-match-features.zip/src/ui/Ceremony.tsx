// ─── Церемония вручения наград по итогам сезона ─────────────────────────────
import { useState } from "react";
import { Trophy, Hand, Sparkles, Target, Shield, ChevronRight, Award } from "lucide-react";
import type { Slot } from "../types";
import type { AwardNominee, ClubNominee, SeasonCeremony } from "../engine/awards";
import { Btn, Crest, Panel, PanelHead, PosBadge, ratingClass } from "./bits";
import { cn } from "../utils/cn";

const MEDALS = ["🥇", "🥈", "🥉"];

function NomineeCard({
  slot, n, title, icon, accent, subtitle,
}: {
  slot: Slot; n: AwardNominee; title: string; icon: React.ReactNode; accent: string; subtitle: string;
}) {
  const team = slot.teams[n.teamId];
  return (
    <div className="relative overflow-hidden rounded-lg border p-3" style={{ borderColor: `${accent}55`, background: `${accent}0d` }}>
      <div className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest" style={{ color: accent }}>
        {icon} {title}
      </div>
      <div className="flex items-center gap-2.5">
        <Crest name={team?.name ?? "?"} color={team?.color ?? "#555"} size={34} />
        <div className="min-w-0 flex-1">
          <div className="truncate text-[16px] font-black leading-tight text-white">{n.name}</div>
          <div className="truncate text-[11.5px] text-[#9ca3af]">
            {team?.name} · {n.age} лет · {n.nationality}
          </div>
        </div>
        <div className="shrink-0 text-right">
          <div className="font-mono text-[20px] font-black leading-none" style={{ color: accent }}>{n.overall}</div>
          <div className="text-[9px] uppercase text-[#6b7280]">ovr</div>
        </div>
      </div>
      <div className="mt-2 text-[11.5px] text-[#cbd5e1]">{subtitle}</div>
      {!!n.trophies.length && (
        <div className="mt-1.5 flex flex-wrap gap-1">
          {n.trophies.map((t) => (
            <span key={t} className="rounded bg-[#0f1419] px-1.5 py-0.5 text-[9.5px] text-[#fbbf24]">🏆 {t}</span>
          ))}
        </div>
      )}
    </div>
  );
}

function NomineeRow({ slot, n, i }: { slot: Slot; n: AwardNominee; i: number }) {
  const team = slot.teams[n.teamId];
  return (
    <div className="flex items-center gap-1.5 border-b border-[#232b36] py-1 text-[12px] last:border-0">
      <span className="w-6 text-center">{i < 3 ? MEDALS[i] : <span className="font-mono text-[10px] text-[#6b7280]">{i + 1}</span>}</span>
      <PosBadge pos={n.position} />
      <Crest name={team?.name ?? "?"} color={team?.color ?? "#555"} size={13} />
      <span className="min-w-0 flex-1 truncate">{n.name}</span>
      <span className="m-hide hidden w-12 truncate text-[10px] text-[#6b7280] sm:block">{team?.shortName}</span>
      {!!n.trophies.length && (
        <span className="m-hide hidden shrink-0 text-[10px] text-[#fbbf24] sm:inline" title={n.trophies.join(", ")}>
          🏆{n.trophies.length}
        </span>
      )}
      <span className={cn("w-10 rounded px-1 text-center font-mono text-[10.5px]", ratingClass(n.rating))}>
        {n.rating.toFixed(2)}
      </span>
      <span className="w-12 text-right font-mono text-[11px] font-bold text-[#60a5fa]">{n.score.toFixed(1)}</span>
    </div>
  );
}

export function CeremonyView({
  slot, ceremony, onContinue,
}: { slot: Slot; ceremony: SeasonCeremony; onContinue: () => void }) {
  const [tab, setTab] = useState<"bd" | "gk" | "young" | "scorer" | "club">("bd");
  const c = ceremony;

  const lists: Record<string, { title: string; rows: AwardNominee[] }> = {
    bd: { title: "Золотой мяч — топ-15", rows: c.ballonDorTop },
    gk: { title: "Лучший вратарь — 5 номинантов", rows: c.goalkeeperTop },
    young: { title: "Лучший молодой — 5 номинантов", rows: c.youngTop },
    scorer: { title: "Бомбардиры — топ-15", rows: c.scorerTop },
    club: { title: "Клубы сезона — топ-15", rows: [] },
  };

  return (
    <div className="mx-auto max-w-5xl p-3">
      <div className="mb-4 text-center">
        <div className="flex items-center justify-center gap-2 text-[11px] uppercase tracking-[0.25em] text-[#fbbf24]">
          <Sparkles size={14} /> Церемония наград <Sparkles size={14} />
        </div>
        <h1 className="mt-1 text-2xl font-black text-white sm:text-3xl">Итоги сезона {c.seasonNumber}</h1>
        <p className="text-[11.5px] text-[#6b7280]">Лучшие игроки и клуб по совокупности статистики, рейтингов и трофеев</p>
      </div>

      {/* ── Главная награда ── */}
      {c.ballonDor && (
        <div className="mb-3">
          <NomineeCard
            slot={slot} n={c.ballonDor} accent="#fbbf24"
            title="Золотой мяч · игрок сезона" icon={<Award size={12} />}
            subtitle={c.ballonDor.line}
          />
        </div>
      )}

      {/* ── Остальные номинации ── */}
      <div className="m-stack grid gap-2 md:grid-cols-2">
        {c.bestClub && (
          <div className="relative overflow-hidden rounded-lg border border-[#4ade80]/40 bg-[#4ade80]/5 p-3">
            <div className="mb-2 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-[#4ade80]">
              <Trophy size={12} /> Клуб сезона
            </div>
            <div className="flex items-center gap-2.5">
              <Crest name={c.bestClub.name} color={c.bestClub.color} size={30} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[15px] font-black text-white">{c.bestClub.name}</div>
                <div className="text-[11.5px] text-[#9ca3af]">{c.bestClub.league} · {c.bestClub.line}</div>
              </div>
            </div>
            {!!c.bestClub.trophies.length && (
              <div className="mt-1.5 flex flex-wrap gap-1">
                {c.bestClub.trophies.map((t) => (
                  <span key={t} className="rounded bg-[#0f1419] px-1.5 py-0.5 text-[9.5px] text-[#fbbf24]">🏆 {t}</span>
                ))}
              </div>
            )}
          </div>
        )}
        {c.bestGoalkeeper && (
          <NomineeCard slot={slot} n={c.bestGoalkeeper} accent="#60a5fa"
            title="Лучший вратарь" icon={<Hand size={12} />} subtitle={c.bestGoalkeeper.line} />
        )}
        {c.bestYoung && (
          <NomineeCard slot={slot} n={c.bestYoung} accent="#a78bfa"
            title={`Лучший молодой игрок · до 21`} icon={<Sparkles size={12} />} subtitle={c.bestYoung.line} />
        )}
        {c.topScorer && (
          <NomineeCard slot={slot} n={c.topScorer} accent="#f87171"
            title="Лучший бомбардир сезона" icon={<Target size={12} />}
            subtitle={`${c.topScorer.goals} голов · ${c.topScorer.assists} передач · ${c.topScorer.apps} матчей`} />
        )}
      </div>

      {/* ── Таблицы номинантов ── */}
      <Panel className="mt-3">
        <PanelHead
          title={lists[tab].title}
          icon={<Shield size={12} />}
          right={
            <div className="fs-scroll-x flex gap-1">
              {([
                ["bd", "Золотой мяч"], ["gk", "Вратари"], ["young", "Молодые"],
                ["scorer", "Бомбардиры"], ["club", "Клубы"],
              ] as const).map(([id, label]) => (
                <button key={id} onClick={() => setTab(id)}
                  className={cn("shrink-0 rounded px-2 py-1 text-[11px] transition-colors",
                    tab === id ? "bg-[#3b82f6] text-white" : "bg-[#232b36] text-[#9ca3af] hover:text-[#e5e7eb]")}>
                  {label}
                </button>
              ))}
            </div>
          }
        />
        <div className="max-h-[430px] overflow-y-auto">
          {tab === "club"
            ? c.clubTop.map((cl: ClubNominee, i) => (
                <div key={cl.teamId} className="flex items-center gap-1.5 border-b border-[#232b36] py-1 text-[12px] last:border-0">
                  <span className="w-6 text-center">{i < 3 ? MEDALS[i] : <span className="font-mono text-[10px] text-[#6b7280]">{i + 1}</span>}</span>
                  <Crest name={cl.name} color={cl.color} size={14} />
                  <span className="min-w-0 flex-1 truncate">{cl.name}</span>
                  <span className="m-hide hidden text-[10px] text-[#6b7280] sm:block">{cl.league}</span>
                  <span className="w-28 truncate text-right text-[10px] text-[#9ca3af]">{cl.line}</span>
                  <span className="w-12 text-right font-mono text-[11px] font-bold text-[#4ade80]">{cl.score.toFixed(1)}</span>
                </div>
              ))
            : lists[tab].rows.map((n, i) => <NomineeRow key={n.playerId} slot={slot} n={n} i={i} />)}
          {tab !== "club" && !lists[tab].rows.length && (
            <p className="py-6 text-center text-[12px] text-[#6b7280]">Недостаточно данных для номинации</p>
          )}
        </div>
      </Panel>

      <div className="mt-3 flex justify-center">
        <Btn variant="primary" onClick={onContinue} icon={<ChevronRight size={15} />} className="px-6">
          К итогам сезона
        </Btn>
      </div>
    </div>
  );
}
