// ─── Плей-офф повышения: постсезонные матчи за путёвку в верхнюю лигу ────────
import { Trophy, Zap, Info, Medal } from "lucide-react";
import type { Fixture, Slot, PromotionPlayoff } from "../types";
import { LEAGUE_CFG } from "../engine/season";
import { Btn, Crest, Panel, PanelHead } from "./bits";
import { MatchRow } from "./SeasonPanels";

function PlayoffBracket({
  slot, st, onMatch, onEditScore,
}: {
  slot: Slot;
  st: PromotionPlayoff;
  onMatch?: (f: Fixture) => void;
  onEditScore?: (f: Fixture) => void;
}) {
  const fx = (id?: string) => slot.season.fixtures.find((f) => f.id === id);
  const semis = st.semiIds.map((id) => fx(id)).filter((f): f is Fixture => !!f);
  const fin = fx(st.finalId);
  const semisLocked = !!st.finalId; // финал создан — полуфиналы уже не меняем
  const upperName = LEAGUE_CFG[st.upper]?.name ?? st.upper;
  const lowerName = LEAGUE_CFG[st.lower]?.name ?? st.lower;
  const winner = st.winner ? slot.teams[st.winner] : undefined;

  return (
    <Panel>
      <PanelHead
        title={
          <span className="flex items-center gap-1.5">
            {lowerName} → {upperName}
            <span className="rounded bg-[#fbbf24]/15 px-1.5 py-0.5 text-[9px] font-bold text-[#fbbf24]">
              путёвка №3
            </span>
          </span>
        }
        icon={<Medal size={12} />}
      />
      <p className="mb-2 text-[11px] leading-relaxed text-[#9ca3af]">
        3–6 места {lowerName === "EFL Championship" ? "Чемпионшипа" : `лиги «${lowerName}»`} разыгрывают
        последнюю путёвку. Полуфиналы — по дому у высшего места, финал — на нейтральном поле,
        при ничьей — серия пенальти. Матчи можно смотреть и редактировать.
      </p>

      <div className="grid gap-3 md:grid-cols-2">
        <div>
          <div className="mb-1 text-[10.5px] font-bold uppercase tracking-wider text-[#9ca3af]">Полуфиналы</div>
          <div className="rounded-md border border-[#2a3140] bg-[#182029]">
            {semis.map((f) => (
              <MatchRow key={f.id} slot={slot} f={f} onClick={onMatch} showDate
                onEditScore={semisLocked ? undefined : onEditScore} />
            ))}
          </div>
        </div>
        <div>
          <div className="mb-1 text-[10.5px] font-bold uppercase tracking-wider text-[#fbbf24]">Финал</div>
          <div className="rounded-md border border-[#fbbf24]/25 bg-[#182029]">
            {fin ? (
              <div>
                <MatchRow slot={slot} f={fin} onClick={onMatch} showDate onEditScore={onEditScore} />
                <div className="px-2 pb-1.5 text-[10px] text-[#6b7280]">
                  нейтральное поле · победитель поднимается в {upperName}
                </div>
              </div>
            ) : (
              <p className="px-2 py-3 text-center text-[11.5px] text-[#6b7280]">
                Пары появятся после полуфиналов
              </p>
            )}
          </div>
        </div>
      </div>

      {winner && (
        <div className="mt-2 flex items-center justify-center gap-2 rounded-md border border-[#4ade80]/40 bg-[#4ade80]/10 py-2 text-[13px]">
          <Trophy size={14} className="text-[#4ade80]" />
          <Crest name={winner.name} color={winner.color} size={16} />
          <b>{winner.name}</b>
          <span className="text-[#9ca3af]">выиграл плей-офф и поднимается в {upperName}</span>
        </div>
      )}
    </Panel>
  );
}

export function PlayoffsView({
  slot, onMatch, onEditScore, onSimAll, busy,
}: {
  slot: Slot;
  onMatch?: (f: Fixture) => void;
  onEditScore?: (f: Fixture) => void;
  onSimAll?: () => void;
  busy?: boolean;
}) {
  const states = slot.season.playoffs ?? [];
  const pendingAll = slot.season.fixtures.filter((f) => f.comp === "PPO" && !f.played).length;

  if (!states.length) {
    return (
      <Panel>
        <div className="flex flex-col items-center gap-2 py-8 text-center">
          <Info size={18} className="text-[#6b7280]" />
          <p className="max-w-md text-[12.5px] leading-relaxed text-[#9ca3af]">
            В этом слоте плей-офф повышения нет. Он создаётся в конце сезона, если в настройках
            включён «плей-офф повышения» и связаны лиги (например, АПЛ ↔ Чемпионшип).
          </p>
        </div>
      </Panel>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-2 rounded-md border border-[#2a3140] bg-[#182029] px-2.5 py-2 text-[11.5px] text-[#9ca3af]">
        <Info size={13} className="shrink-0 text-[#fbbf24]" />
        <span className="min-w-0 flex-1">
          Постсезонные матчи: статистика игроков за них в итоги чемпионата не идёт.
          Нажмите на матч, чтобы открыть карточку, а иконку ✎ — чтобы задать счёт вручную.
        </span>
        {pendingAll > 0 && onSimAll && (
          <Btn sm variant="warn" onClick={onSimAll} disabled={busy} icon={<Zap size={12} />}>
            Симулировать всё ({pendingAll})
          </Btn>
        )}
      </div>
      {states.map((st) => (
        <PlayoffBracket key={st.id} slot={slot} st={st} onMatch={onMatch} onEditScore={onEditScore} />
      ))}
    </div>
  );
}
