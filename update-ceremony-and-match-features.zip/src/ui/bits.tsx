// ─── UI-примитивы плотной тёмной темы ───────────────────────────────────────
import type { ReactNode, ButtonHTMLAttributes, SelectHTMLAttributes, InputHTMLAttributes } from "react";
import { cn } from "../utils/cn";

export const C = {
  bg: "#0f1419", panel: "#1e2530", panel2: "#182029", line: "#2a3140",
  green: "#4ade80", red: "#ef4444", yellow: "#fbbf24", blue: "#3b82f6",
  text: "#e5e7eb", muted: "#9ca3af",
};

export function Panel({ children, className, pad = true }: { children: ReactNode; className?: string; pad?: boolean }) {
  return (
    <div className={cn("fs-panel rounded-lg border border-[#2a3140] bg-[#1e2530]", pad && "p-3", className)}>{children}</div>
  );
}

export function PanelHead({ title, right, icon }: { title: ReactNode; right?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="mb-2 flex items-center gap-2 border-b border-[#2a3140] pb-1.5">
      {icon && <span className="text-[#3b82f6]">{icon}</span>}
      <h3 className="text-[11px] font-bold uppercase tracking-wider text-[#9ca3af]">{title}</h3>
      {right && <div className="ml-auto flex items-center gap-1.5">{right}</div>}
    </div>
  );
}

type BtnVariant = "primary" | "blue" | "danger" | "ghost" | "outline" | "warn";

const BTN: Record<BtnVariant, string> = {
  primary: "bg-[#4ade80] text-[#06281a] hover:bg-[#6ee7a0] font-semibold",
  blue: "bg-[#3b82f6] text-white hover:bg-[#60a5fa] font-semibold",
  danger: "bg-[#ef4444] text-white hover:bg-[#f87171] font-semibold",
  warn: "bg-[#fbbf24] text-[#2a1e00] hover:bg-[#fcd34d] font-semibold",
  ghost: "bg-[#232b36] text-[#e5e7eb] hover:bg-[#2a3140]",
  outline: "border border-[#2f3847] bg-transparent text-[#e5e7eb] hover:border-[#3b82f6] hover:text-[#3b82f6]",
};

interface BtnProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: BtnVariant;
  icon?: ReactNode;
  sm?: boolean;
}

export function Btn({ variant = "ghost", icon, sm, children, className, ...rest }: BtnProps) {
  return (
    <button
      {...rest}
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-md transition-colors duration-150 disabled:cursor-not-allowed disabled:opacity-40",
        sm ? "px-2 py-1 text-[11px]" : "px-2.5 py-1.5 text-[12.5px]",
        !children && "fs-icon-btn",
        BTN[variant],
        className
      )}
    >
      {icon}
      {children}
    </button>
  );
}

/** Герб клуба: щит с инициалами в клубном цвете */
export function Crest({ name, color, size = 18 }: { name: string; color: string; size?: number }) {
  const letters = name
    .replace(/^(FC|AS|AJ|RC|SC|CD|UD|RCD|OGC|ESTAC)\s+/i, "")
    .split(/[\s-]/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
  return (
    <span
      className="inline-flex shrink-0 items-center justify-center font-bold leading-none text-black/80"
      style={{
        width: size,
        height: size,
        fontSize: size * 0.44,
        background: color,
        borderRadius: `${size * 0.22}px ${size * 0.22}px ${size * 0.45}px ${size * 0.45}px`,
        boxShadow: "inset 0 0 0 1px rgba(255,255,255,.18)",
      }}
      title={name}
    >
      {letters}
    </span>
  );
}

export function StatBar({ label, home, away, format }: { label: string; home: number; away: number; format?: (v: number) => string }) {
  const total = home + away;
  const hp = total === 0 ? 50 : (home / total) * 100;
  const f = format ?? ((v: number) => String(v));
  return (
    <div className="py-1">
      <div className="mb-0.5 flex items-center justify-between text-[11.5px]">
        <span className="w-12 font-semibold">{f(home)}</span>
        <span className="text-[#9ca3af]">{label}</span>
        <span className="w-12 text-right font-semibold">{f(away)}</span>
      </div>
      <div className="flex h-1 overflow-hidden rounded-full bg-[#0f1419]">
        <div className="bg-[#4ade80] transition-all duration-300" style={{ width: `${hp}%` }} />
        <div className="flex-1 bg-[#3b82f6]/60" />
      </div>
    </div>
  );
}

export function ratingClass(r: number): string {
  if (r >= 7.5) return "bg-[#4ade80]/20 text-[#4ade80]";
  if (r >= 6.0) return "bg-[#fbbf24]/15 text-[#fbbf24]";
  return "bg-[#ef4444]/15 text-[#f87171]";
}

export function Select({ className, children, ...rest }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...rest}
      className={cn(
        "rounded-md border border-[#2f3847] bg-[#0f1419] px-2 py-1.5 text-[12.5px] text-[#e5e7eb] outline-none transition-colors focus:border-[#3b82f6]",
        className
      )}
    >
      {children}
    </select>
  );
}

export function Input({ className, ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...rest}
      className={cn(
        "rounded-md border border-[#2f3847] bg-[#0f1419] px-2 py-1.5 text-[12.5px] text-[#e5e7eb] outline-none transition-colors focus:border-[#3b82f6]",
        className
      )}
    />
  );
}

/** Табы-пилюли (плотные) */
export function Tabs<T extends string>({
  value, onChange, items, className,
}: { value: T; onChange: (v: T) => void; items: { id: T; label: string; count?: number }[]; className?: string }) {
  return (
    <div className={cn("flex gap-0.5 overflow-x-auto rounded-md bg-[#0f1419] p-0.5", className)}>
      {items.map((it) => (
        <button
          key={it.id}
          onClick={() => onChange(it.id)}
          className={cn(
            "shrink-0 whitespace-nowrap rounded px-2.5 py-1 text-[12px] font-medium transition-colors",
            value === it.id ? "bg-[#3b82f6] text-white" : "text-[#9ca3af] hover:bg-[#232b36] hover:text-[#e5e7eb]"
          )}
        >
          {it.label}
          {it.count !== undefined && <span className="ml-1 opacity-70">{it.count}</span>}
        </button>
      ))}
    </div>
  );
}

/** Результат матча для клуба: W/D/L квадратик */
export function FormBox({ r }: { r: string }) {
  const map: Record<string, string> = {
    W: "bg-[#4ade80]/20 text-[#4ade80]",
    D: "bg-[#fbbf24]/20 text-[#fbbf24]",
    L: "bg-[#ef4444]/20 text-[#f87171]",
  };
  return (
    <span className={cn("inline-block h-4 w-4 rounded text-center text-[9px] font-bold leading-4", map[r])}>
      {r === "W" ? "В" : r === "D" ? "Н" : "П"}
    </span>
  );
}

export function PosBadge({ pos }: { pos: string }) {
  const cls: Record<string, string> = {
    GK: "bg-[#fbbf24]/15 text-[#fbbf24]",
    DF: "bg-[#3b82f6]/15 text-[#60a5fa]",
    MF: "bg-[#4ade80]/15 text-[#4ade80]",
    FW: "bg-[#ef4444]/15 text-[#f87171]",
  };
  const label: Record<string, string> = { GK: "ВР", DF: "ЗЩ", MF: "ПЗ", FW: "НП" };
  return (
    <span className={cn("inline-block w-6 rounded text-center text-[9.5px] font-bold leading-[15px]", cls[pos])}>
      {label[pos]}
    </span>
  );
}

/** Модальное окно (закрывается по ESC — обработчик в Layout) */
export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 p-4 sm:items-center" onClick={onClose}>
      <div
        className={cn("fs-modal fs-fade w-full rounded-lg border border-[#2a3140] bg-[#1e2530] shadow-2xl", wide ? "max-w-4xl" : "max-w-xl")}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 border-b border-[#2a3140] px-3 py-2">
          <h3 className="text-[13px] font-bold">{title}</h3>
          <button onClick={onClose} className="ml-auto rounded px-2 py-0.5 text-[#9ca3af] hover:bg-[#232b36] hover:text-[#e5e7eb]">
            ESC ✕
          </button>
        </div>
        <div className="p-3">{children}</div>
      </div>
    </div>
  );
}
