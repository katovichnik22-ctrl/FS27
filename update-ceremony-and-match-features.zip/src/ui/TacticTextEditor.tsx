// ─── Редактор текстовой тактики с живой оценкой качества ────────────────────
import { useMemo, useState } from "react";
import { Wand2, FileText, Check, AlertTriangle, Lightbulb, Save, Eraser } from "lucide-react";
import { analyzeTactic, PHASE_NAMES, TACTIC_TEMPLATE, type Phase } from "../engine/tacticText";
import { Btn, Panel, PanelHead } from "./bits";
import { cn } from "../utils/cn";

const ALL_PHASES: Phase[] = ["buildup", "attack", "press", "defense", "transition", "setpiece", "mentality"];

function gradeColor(score: number) {
  if (score >= 85) return "#4ade80";
  if (score >= 70) return "#86efac";
  if (score >= 55) return "#fbbf24";
  if (score >= 40) return "#fb923c";
  return "#f87171";
}

export function TacticTextEditor({
  value, onSave,
}: { value?: string; onSave: (text: string) => void }) {
  const [text, setText] = useState(value ?? "");
  const [dirty, setDirty] = useState(false);
  const a = useMemo(() => analyzeTactic(text), [text]);
  const color = gradeColor(a.score);

  const set = (t: string) => { setText(t); setDirty(true); };

  return (
    <Panel className="bg-[#182029]">
      <PanelHead
        title={<span className="flex items-center gap-1.5"><FileText size={12} /> Текстовая тактика</span>}
        right={
          <>
            <Btn sm onClick={() => set(TACTIC_TEMPLATE)} icon={<Wand2 size={11} />} title="Вставить шаблон">Шаблон</Btn>
            <Btn sm onClick={() => set("")} icon={<Eraser size={11} />} title="Очистить" />
            <Btn sm variant={dirty ? "primary" : "outline"} disabled={!dirty}
              onClick={() => { onSave(text); setDirty(false); }} icon={<Save size={11} />}>
              Сохранить план
            </Btn>
          </>
        }
      />

      {/* Оценка */}
      <div className="mb-2 flex items-center gap-2 rounded-md border border-[#2a3140] bg-[#0f1419] px-2 py-1.5">
        <div className="relative h-9 w-9 shrink-0">
          <svg viewBox="0 0 36 36" className="h-9 w-9 -rotate-90">
            <circle cx="18" cy="18" r="15" fill="none" stroke="#232b36" strokeWidth="4" />
            <circle cx="18" cy="18" r="15" fill="none" stroke={color} strokeWidth="4" strokeLinecap="round"
              strokeDasharray={`${(a.score / 100) * 94.2} 94.2`} />
          </svg>
          <span className="absolute inset-0 flex items-center justify-center font-mono text-[11px] font-bold" style={{ color }}>
            {a.score}
          </span>
        </div>
        <div className="min-w-0 flex-1">
          <div className="text-[12.5px] font-bold" style={{ color }}>{a.grade}</div>
          <div className="text-[10.5px] text-[#6b7280]">
            {a.detected.length} концепц. · {a.phases.length}/7 фаз · {a.words} слов
          </div>
        </div>
        <div className="shrink-0 text-right font-mono text-[10.5px]">
          <div className={cn(a.atk > 1 ? "text-[#4ade80]" : a.atk < 1 ? "text-[#f87171]" : "text-[#6b7280]")}>
            атака ×{a.atk.toFixed(3)}
          </div>
          <div className={cn(a.def > 1 ? "text-[#4ade80]" : a.def < 1 ? "text-[#f87171]" : "text-[#6b7280]")}>
            защита ×{a.def.toFixed(3)}
          </div>
          <div className={cn(a.mid > 1 ? "text-[#4ade80]" : a.mid < 1 ? "text-[#f87171]" : "text-[#6b7280]")}>
            центр ×{a.mid.toFixed(3)}
          </div>
        </div>
      </div>

      <textarea
        value={text}
        onChange={(e) => set(e.target.value)}
        rows={10}
        placeholder="Опишите план на матч: начало атаки, финальная треть, прессинг, оборона, переходные фазы, стандарты, что делать при разном счёте…"
        className="w-full rounded-md border border-[#2f3847] bg-[#0f1419] p-2 text-[12.5px] leading-relaxed text-[#e5e7eb] outline-none transition-colors focus:border-[#3b82f6] placeholder:text-[#4b5563]"
      />

      {/* Фазы */}
      <div className="mt-2 flex flex-wrap gap-1">
        {ALL_PHASES.map((p) => {
          const on = a.phases.includes(p);
          return (
            <span key={p} className={cn(
              "rounded border px-1.5 py-0.5 text-[10px]",
              on ? "border-[#4ade80]/50 bg-[#4ade80]/10 text-[#4ade80]" : "border-[#2f3847] text-[#4b5563]"
            )}>
              {on && <Check size={9} className="mr-0.5 inline" />}{PHASE_NAMES[p]}
            </span>
          );
        })}
      </div>

      {/* Распознанные концепции */}
      {!!a.detected.length && (
        <div className="mt-2">
          <div className="mb-1 text-[10px] font-bold uppercase tracking-wider text-[#9ca3af]">
            Движок распознал · {a.detected.length}
          </div>
          <div className="flex max-h-24 flex-wrap gap-1 overflow-y-auto">
            {a.detected.map((d) => (
              <span key={d.id} className="rounded bg-[#232b36] px-1.5 py-0.5 text-[10px] text-[#cbd5e1]">{d.label}</span>
            ))}
          </div>
        </div>
      )}

      {/* Эффекты поведения */}
      {a.score > 0 && (
        <div className="mt-2 grid grid-cols-2 gap-1 sm:grid-cols-4">
          {([
            ["Прессинг", a.pressBias, "#4ade80"],
            ["Контратаки", a.counterBias, "#60a5fa"],
            ["Стандарты", a.setPieceBias, "#fbbf24"],
            ["Дисциплина", a.disciplineBias, "#a78bfa"],
          ] as const).map(([label, v, c]) => (
            <div key={label} className="rounded border border-[#2a3140] bg-[#0f1419] px-1.5 py-1">
              <div className="text-[9.5px] text-[#6b7280]">{label}</div>
              <div className="mt-0.5 h-1 overflow-hidden rounded-full bg-[#232b36]">
                <div className="h-full rounded-full" style={{ width: `${Math.abs(v) * 100}%`, background: c }} />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Замечания и подсказки */}
      {!!a.issues.length && (
        <ul className="mt-2 space-y-0.5">
          {a.issues.map((i, k) => (
            <li key={k} className="flex items-start gap-1 text-[11px] text-[#f87171]">
              <AlertTriangle size={10} className="mt-0.5 shrink-0" /> {i}
            </li>
          ))}
        </ul>
      )}
      {!!a.tips.length && a.score < 85 && (
        <ul className="mt-1 space-y-0.5">
          {a.tips.slice(0, 4).map((t, k) => (
            <li key={k} className="flex items-start gap-1 text-[11px] text-[#9ca3af]">
              <Lightbulb size={10} className="mt-0.5 shrink-0 text-[#fbbf24]" /> {t}
            </li>
          ))}
        </ul>
      )}

      <p className="mt-2 text-[10px] leading-relaxed text-[#4b5563]">
        Чем полнее и конкретнее план, тем сильнее играет команда: оценка влияет на атаку, оборону и контроль центра,
        а распознанные идеи меняют поведение в матче (высота прессинга, доля контратак, опасность стандартов, число карточек).
      </p>
    </Panel>
  );
}

export { gradeColor };
