// ─── Редактор игроков: правка любого футболиста в текущем слоте ─────────────
// MAIN_DB никогда не меняется — все правки идут в slot.teams.
import { useMemo, useRef, useState } from "react";
import {
  Search, Save, RotateCcw, Trash2, UserPlus, Download, Upload, Undo2,
  CheckSquare, Square, Wand2, AlertTriangle,
} from "lucide-react";
import type { Injury, Player, PlayerRole, Position, Slot } from "../types";
import { MAIN_DB } from "../data/db";
import { LEAGUE_CFG } from "../engine/season";
import { sanitizeTactics } from "../engine/tactics";
import { marketValue } from "../engine/transfers";
import { Btn, Crest, Panel, PanelHead, PosBadge, Select, Input, Tabs } from "./bits";
import { cn } from "../utils/cn";

const ROLES: { id: PlayerRole; label: string; pos: Position }[] = [
  { id: "GK", label: "Вратарь", pos: "GK" },
  { id: "SW", label: "Свободный защитник", pos: "DF" },
  { id: "CB", label: "Центральный защитник", pos: "DF" },
  { id: "LB", label: "Левый защитник", pos: "DF" },
  { id: "RB", label: "Правый защитник", pos: "DF" },
  { id: "LWB", label: "Левый латераль", pos: "DF" },
  { id: "RWB", label: "Правый латераль", pos: "DF" },
  { id: "DM", label: "Опорный полузащитник", pos: "MF" },
  { id: "CM", label: "Центральный полузащитник", pos: "MF" },
  { id: "BBM", label: "Box-to-box", pos: "MF" },
  { id: "AM", label: "Атакующий полузащитник", pos: "MF" },
  { id: "LM", label: "Левый полузащитник", pos: "MF" },
  { id: "RM", label: "Правый полузащитник", pos: "MF" },
  { id: "LW", label: "Левый вингер", pos: "FW" },
  { id: "RW", label: "Правый вингер", pos: "FW" },
  { id: "SS", label: "Оттянутый форвард", pos: "FW" },
  { id: "CF", label: "Центральный форвард", pos: "FW" },
  { id: "TM", label: "Таргетмен", pos: "FW" },
  { id: "PF", label: "Прессинг-форвард", pos: "FW" },
];

const NATIONS = [
  "ENG", "SCO", "WAL", "IRL", "NIR", "FRA", "ESP", "GER", "ITA", "POR", "NED", "BEL", "BRA", "ARG",
  "URU", "COL", "CHI", "MEX", "USA", "CAN", "SEN", "CIV", "GHA", "NGA", "MAR", "ALG", "TUN", "EGY",
  "CMR", "MLI", "COD", "JPN", "KOR", "AUS", "TUR", "GRE", "CRO", "SRB", "SVN", "SVK", "CZE", "POL",
  "UKR", "RUS", "SWE", "NOR", "DEN", "FIN", "ISL", "SUI", "AUT", "HUN", "ROU", "BUL", "GEO", "ARM",
  "ALB", "BIH", "MNE", "KOS", "ISR", "IRN", "UZB", "ECU", "PAR", "PER", "VEN", "BFA", "GIN", "GAM",
  "ANG", "ZAM", "ZIM", "NZL", "JAM", "DOM", "PAN", "HON", "GNB", "GNQ", "CAF", "MAD", "LTU", "LUX",
  "CYP", "KAZ", "IDN", "TOG", "BEN", "MOZ", "EST", "JOR",
];

interface HistoryEntry {
  at: number;
  label: string;
  teamId: string;
  before: Player[];
}

function defaultRole(pos: Position): PlayerRole {
  return pos === "GK" ? "GK" : pos === "DF" ? "CB" : pos === "MF" ? "CM" : "CF";
}

function estWage(p: Player): number {
  return Math.round(Math.max(2, Math.pow(Math.max(40, p.overall) - 35, 2.15) / 26));
}

export function PlayerEditor({
  slot, onChanged, initialTeamId, initialPlayerId,
}: { slot: Slot; onChanged: () => void; initialTeamId?: string; initialPlayerId?: string }) {
  const clubs = useMemo(
    () => Object.values(slot.teams)
      .filter((t) => t.league)
      .sort((a, b) => (a.league! < b.league! ? -1 : a.league! > b.league! ? 1 : b.reputation - a.reputation)),
    [slot]
  );
  const [teamId, setTeamId] = useState(initialTeamId ?? clubs[0]?.id ?? "");
  const [sel, setSel] = useState<string | null>(initialPlayerId ?? null);
  const [qTeam, setQTeam] = useState("");
  const [qPlayer, setQPlayer] = useState("");
  const [posFilter, setPosFilter] = useState<Position | "ALL">("ALL");
  const [draft, setDraft] = useState<Player | null>(null);
  const [multi, setMulti] = useState<string[]>([]);
  const [bulkField, setBulkField] = useState<"attack" | "defense" | "overall" | "fitness" | "morale">("overall");
  const [bulkDelta, setBulkDelta] = useState(1);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [confirmDel, setConfirmDel] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const team = slot.teams[teamId];
  const players = useMemo(() => {
    if (!team) return [];
    return team.players
      .filter((p) => (posFilter === "ALL" ? true : p.position === posFilter))
      .filter((p) => p.name.toLowerCase().includes(qPlayer.toLowerCase()))
      .sort((a, b) => b.overall - a.overall);
  }, [team, posFilter, qPlayer]);

  const flash = (m: string) => { setMsg(m); setTimeout(() => setMsg(null), 2000); };

  const snapshot = (label: string) => {
    setHistory((h) => [{ at: Date.now(), label, teamId, before: JSON.parse(JSON.stringify(team.players)) }, ...h].slice(0, 50));
  };

  const open = (p: Player) => {
    setSel(p.id);
    setDraft({
      ...JSON.parse(JSON.stringify(p)),
      role: p.role ?? defaultRole(p.position),
      potential: p.potential ?? Math.min(99, p.overall + (p.age < 23 ? 8 : p.age < 27 ? 4 : 1)),
      value: p.value ?? marketValue(p),
      wage: p.wage ?? estWage(p),
      contractUntil: p.contractUntil ?? `${2027 + (p.age < 25 ? 3 : 1)}-06-30`,
      number: p.number ?? 0,
    });
  };

  const patch = (d: Partial<Player>) => setDraft((x) => (x ? { ...x, ...d } : x));

  const save = () => {
    if (!draft || !team) return;
    snapshot(`Правка: ${draft.name}`);
    const i = team.players.findIndex((p) => p.id === draft.id);
    if (i === -1) return;
    team.players[i] = { ...draft };
    slot.tactics[teamId] = sanitizeTactics(team, slot.tactics[teamId]);
    onChanged();
    flash("Изменения сохранены");
  };

  const resetToMain = () => {
    if (!draft) return;
    const orig = Object.values(MAIN_DB).flatMap((t) => t.players).find((p) => p.id === draft.id);
    if (!orig) { flash("Игрока нет в главной базе"); return; }
    setDraft({ ...JSON.parse(JSON.stringify(orig)), role: draft.role, number: draft.number });
    flash("Данные возвращены из главной базы (не забудьте сохранить)");
  };

  const removePlayer = () => {
    if (!draft || !team) return;
    if (team.players.length <= 11) { flash("Нельзя: в команде останется меньше 11 игроков"); return; }
    snapshot(`Удаление: ${draft.name}`);
    team.players = team.players.filter((p) => p.id !== draft.id);
    slot.tactics[teamId] = sanitizeTactics(team, slot.tactics[teamId]);
    setDraft(null);
    setSel(null);
    setConfirmDel(false);
    onChanged();
    flash("Игрок удалён");
  };

  const createPlayer = () => {
    if (!team) return;
    snapshot("Создание игрока");
    const np: Player = {
      id: `cus_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
      name: "Новый игрок", position: "MF", role: "CM", number: 0,
      age: 20, nationality: "ENG", attack: 65, defense: 60, goalkeeping: 8, overall: 65,
      potential: 80, value: 5, wage: 20, contractUntil: "2030-06-30", injury: null,
      form: 1, fitness: 100, morale: 70,
      stats: {
        apps: 0, goals: 0, assists: 0, cleanSheets: 0, yellow: 0, red: 0, saves: 0,
        conceded: 0, errors: 0, keyPasses: 0, tackles: 0, minutes: 0,
        shots: 0, shotsOnTarget: 0, xg: 0, interceptions: 0, fouls: 0, offsides: 0, dribbles: 0, motm: 0,
        plApps: 0, plGoals: 0, plAssists: 0, plCleanSheets: 0, ratingSum: 0, avgRating: 0,
      },
    };
    team.players.push(np);
    onChanged();
    open(np);
    flash("Игрок создан — заполните карточку");
  };

  const applyBulk = () => {
    if (!team || !multi.length) return;
    snapshot(`Массовая правка (${multi.length})`);
    for (const id of multi) {
      const p = team.players.find((x) => x.id === id);
      if (!p) continue;
      const lo = bulkField === "fitness" || bulkField === "morale" ? 0 : 20;
      const hi = bulkField === "fitness" || bulkField === "morale" ? 100 : 99;
      p[bulkField] = Math.max(lo, Math.min(hi, Math.round(p[bulkField] + bulkDelta)));
    }
    onChanged();
    flash(`Применено к ${multi.length} игрокам`);
  };

  const undo = () => {
    const h = history[0];
    if (!h) return;
    slot.teams[h.teamId].players = h.before;
    slot.tactics[h.teamId] = sanitizeTactics(slot.teams[h.teamId], slot.tactics[h.teamId]);
    setHistory((x) => x.slice(1));
    setDraft(null);
    setSel(null);
    onChanged();
    flash(`Откат: ${h.label}`);
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(team.players, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `fs26_${team.shortName}_players.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importJson = (text: string) => {
    try {
      const arr = JSON.parse(text) as Player[];
      if (!Array.isArray(arr) || !arr.length || !arr[0].id) throw new Error("Неверный формат");
      snapshot("Импорт состава");
      team.players = arr;
      slot.tactics[teamId] = sanitizeTactics(team, slot.tactics[teamId]);
      onChanged();
      flash(`Импортировано игроков: ${arr.length}`);
    } catch (e) {
      flash(e instanceof Error ? e.message : "Ошибка импорта");
    }
  };

  const Slider = ({ label, value, min, max, step = 1, onChange, color = "#4ade80" }: {
    label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void; color?: string;
  }) => (
    <div>
      <div className="flex items-center justify-between text-[11px]">
        <span className="text-[#9ca3af]">{label}</span>
        <span className="font-mono font-bold" style={{ color }}>{step < 1 ? value.toFixed(2) : Math.round(value)}</span>
      </div>
      <input
        type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-[#0f1419] accent-[#3b82f6]"
      />
    </div>
  );

  return (
    <div className="m-stack grid gap-2 lg:grid-cols-[190px_260px_1fr]">
      {/* ── Клубы ── */}
      <Panel className="max-h-[calc(100vh-150px)] overflow-hidden">
        <PanelHead title="Клубы" />
        <div className="mb-1.5 flex items-center gap-1.5 rounded border border-[#2f3847] bg-[#0f1419] px-2 py-1">
          <Search size={12} className="text-[#6b7280]" />
          <input value={qTeam} onChange={(e) => setQTeam(e.target.value)} placeholder="Поиск…"
            className="w-full bg-transparent text-[12px] outline-none placeholder:text-[#4b5563]" />
        </div>
        <div className="max-h-[calc(100vh-215px)] overflow-y-auto pr-1">
          {clubs.filter((t) => t.name.toLowerCase().includes(qTeam.toLowerCase())).map((t) => (
            <button key={t.id} onClick={() => { setTeamId(t.id); setSel(null); setDraft(null); setMulti([]); }}
              className={cn("flex w-full items-center gap-1.5 rounded px-1.5 py-1 text-left text-[12px]",
                teamId === t.id ? "bg-[#3b82f6]/15 font-semibold text-[#60a5fa]" : "hover:bg-[#232b36]")}>
              <Crest name={t.name} color={t.color} size={13} />
              <span className="min-w-0 flex-1 truncate">{t.name}</span>
              <span className="text-[9px] text-[#4b5563]">{LEAGUE_CFG[t.league!].short}</span>
            </button>
          ))}
        </div>
      </Panel>

      {/* ── Игроки ── */}
      <Panel className="max-h-[calc(100vh-150px)] overflow-hidden">
        <PanelHead title={`Состав · ${team?.players.length ?? 0}`} right={
          <Btn sm onClick={createPlayer} icon={<UserPlus size={11} />} title="Создать игрока" />} />
        <div className="mb-1.5 flex items-center gap-1.5 rounded border border-[#2f3847] bg-[#0f1419] px-2 py-1">
          <Search size={12} className="text-[#6b7280]" />
          <input value={qPlayer} onChange={(e) => setQPlayer(e.target.value)} placeholder="Поиск игрока…"
            className="w-full bg-transparent text-[12px] outline-none placeholder:text-[#4b5563]" />
        </div>
        <Tabs className="mb-1.5" value={posFilter} onChange={setPosFilter}
          items={[{ id: "ALL" as const, label: "Все" }, { id: "GK" as const, label: "ВР" },
                  { id: "DF" as const, label: "ЗЩ" }, { id: "MF" as const, label: "ПЗ" }, { id: "FW" as const, label: "НП" }]} />
        <div className="max-h-[calc(100vh-280px)] overflow-y-auto pr-1">
          {players.map((p) => (
            <div key={p.id} className={cn("flex items-center gap-1 rounded px-1 py-[3px] text-[12px]",
              sel === p.id ? "bg-[#3b82f6]/15" : "hover:bg-[#232b36]")}>
              <button onClick={() => setMulti((m) => m.includes(p.id) ? m.filter((x) => x !== p.id) : [...m, p.id])}
                className="shrink-0 text-[#6b7280] hover:text-[#4ade80]">
                {multi.includes(p.id) ? <CheckSquare size={12} className="text-[#4ade80]" /> : <Square size={12} />}
              </button>
              <button onClick={() => open(p)} className="flex min-w-0 flex-1 items-center gap-1.5 text-left">
                <PosBadge pos={p.position} />
                <span className="min-w-0 flex-1 truncate">{p.name}</span>
                {p.injury && <span title={`${p.injury.label}, ${p.injury.daysLeft} дн.`}>🚑</span>}
                <span className="font-mono text-[11px] font-bold text-[#4ade80]">{p.overall}</span>
              </button>
            </div>
          ))}
          {!players.length && <p className="py-4 text-center text-[11.5px] text-[#6b7280]">Не найдено</p>}
        </div>

        {!!multi.length && (
          <div className="mt-1.5 rounded border border-[#2a3140] bg-[#0f1419] p-1.5">
            <div className="mb-1 text-[10px] font-bold uppercase tracking-wider text-[#fbbf24]">
              Массово · {multi.length}
            </div>
            <div className="flex gap-1">
              <Select value={bulkField} onChange={(e) => setBulkField(e.target.value as typeof bulkField)} className="min-w-0 flex-1 px-1 py-0.5 text-[11px]">
                <option value="overall">Overall</option><option value="attack">Атака</option>
                <option value="defense">Защита</option><option value="fitness">Свежесть</option><option value="morale">Мораль</option>
              </Select>
              <Input type="number" value={bulkDelta} onChange={(e) => setBulkDelta(Number(e.target.value) || 0)} className="w-14 px-1 py-0.5 text-[11px]" />
              <Btn sm variant="blue" onClick={applyBulk} icon={<Wand2 size={11} />} />
            </div>
            <button onClick={() => setMulti([])} className="mt-1 text-[10px] text-[#6b7280] hover:text-[#e5e7eb]">снять выделение</button>
          </div>
        )}
      </Panel>

      {/* ── Карточка ── */}
      <Panel className="max-h-[calc(100vh-150px)] overflow-y-auto">
        {!draft ? (
          <div className="flex h-40 flex-col items-center justify-center gap-2 text-[12px] text-[#6b7280]">
            <UserPlus size={22} className="text-[#2f3847]" />
            Выберите игрока слева, чтобы отредактировать его данные
          </div>
        ) : (
          <>
            <PanelHead
              title={<span className="flex items-center gap-1.5"><Crest name={team.name} color={team.color} size={14} />{draft.name}</span>}
              right={
                <>
                  <Btn sm onClick={resetToMain} icon={<RotateCcw size={11} />} title="Сбросить к исходным" />
                  <Btn sm variant="primary" onClick={save} icon={<Save size={12} />}>Сохранить</Btn>
                </>
              }
            />
            <div className="grid gap-3 md:grid-cols-2">
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <label className="block"><span className="text-[11px] text-[#9ca3af]">Имя</span>
                    <Input value={draft.name} onChange={(e) => patch({ name: e.target.value })} className="w-full" /></label>
                  <label className="block"><span className="text-[11px] text-[#9ca3af]">Номер</span>
                    <Input type="number" min={1} max={99} value={draft.number ?? 0}
                      onChange={(e) => patch({ number: Math.max(0, Math.min(99, Number(e.target.value) || 0)) })} className="w-full" /></label>
                  <label className="block"><span className="text-[11px] text-[#9ca3af]">Возраст</span>
                    <Input type="number" min={15} max={45} value={draft.age}
                      onChange={(e) => patch({ age: Math.max(15, Math.min(45, Number(e.target.value) || 15)) })} className="w-full" /></label>
                  <label className="block"><span className="text-[11px] text-[#9ca3af]">Гражданство</span>
                    <Select value={draft.nationality} onChange={(e) => patch({ nationality: e.target.value })} className="w-full">
                      {NATIONS.map((n) => <option key={n} value={n}>{n}</option>)}
                    </Select></label>
                  <label className="block"><span className="text-[11px] text-[#9ca3af]">Позиция</span>
                    <Select value={draft.position} onChange={(e) => {
                      const pos = e.target.value as Position;
                      patch({ position: pos, role: defaultRole(pos) });
                    }} className="w-full">
                      <option value="GK">GK — вратарь</option><option value="DF">DF — защитник</option>
                      <option value="MF">MF — полузащитник</option><option value="FW">FW — нападающий</option>
                    </Select></label>
                  <label className="block"><span className="text-[11px] text-[#9ca3af]">Роль</span>
                    <Select value={draft.role ?? defaultRole(draft.position)} onChange={(e) => patch({ role: e.target.value as PlayerRole })} className="w-full">
                      {ROLES.filter((r) => r.pos === draft.position).map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}
                    </Select></label>
                </div>

                <div className="space-y-1.5 rounded border border-[#2a3140] bg-[#182029] p-2">
                  <Slider label="Overall" value={draft.overall} min={40} max={99} onChange={(v) => patch({ overall: v })} />
                  <Slider label="Потенциал" value={draft.potential ?? draft.overall} min={40} max={99} onChange={(v) => patch({ potential: v })} color="#fbbf24" />
                  <Slider label="Атака" value={draft.attack} min={0} max={99} onChange={(v) => patch({ attack: v })} color="#f87171" />
                  <Slider label="Защита" value={draft.defense} min={0} max={99} onChange={(v) => patch({ defense: v })} color="#60a5fa" />
                  {draft.position === "GK" && (
                    <Slider label="Вратарь" value={draft.goalkeeping} min={0} max={99} onChange={(v) => patch({ goalkeeping: v })} color="#fbbf24" />
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <div className="space-y-1.5 rounded border border-[#2a3140] bg-[#182029] p-2">
                  <Slider label="Свежесть" value={draft.fitness} min={0} max={100} onChange={(v) => patch({ fitness: v })} />
                  <Slider label="Мораль" value={draft.morale} min={0} max={100} onChange={(v) => patch({ morale: v })} color="#60a5fa" />
                  <Slider label="Форма" value={draft.form} min={0.85} max={1.15} step={0.01} onChange={(v) => patch({ form: v })} color="#fbbf24" />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <label className="block"><span className="text-[11px] text-[#9ca3af]">Стоимость, £M</span>
                    <Input type="number" step={0.5} value={draft.value ?? 0}
                      onChange={(e) => patch({ value: Number(e.target.value) || 0 })} className="w-full" /></label>
                  <label className="block"><span className="text-[11px] text-[#9ca3af]">Зарплата, £k/нед</span>
                    <Input type="number" value={draft.wage ?? 0}
                      onChange={(e) => patch({ wage: Number(e.target.value) || 0 })} className="w-full" /></label>
                  <label className="col-span-2 block"><span className="text-[11px] text-[#9ca3af]">Контракт до</span>
                    <Input type="date" value={draft.contractUntil ?? "2029-06-30"}
                      onChange={(e) => patch({ contractUntil: e.target.value })} className="w-full" /></label>
                </div>
                <Btn sm className="w-full" onClick={() => patch({ value: marketValue(draft), wage: estWage(draft) })} icon={<Wand2 size={11} />}>
                  Пересчитать стоимость и зарплату
                </Btn>

                <div className="rounded border border-[#2a3140] bg-[#182029] p-2">
                  <label className="flex cursor-pointer items-center gap-2 text-[12px]">
                    <input type="checkbox" checked={!!draft.injury}
                      onChange={(e) => patch({
                        injury: e.target.checked
                          ? ({ type: "medium", daysLeft: 21, label: "средняя" } as Injury)
                          : null,
                      })}
                      className="h-3.5 w-3.5 accent-[#ef4444]" />
                    Травмирован
                  </label>
                  {draft.injury && (
                    <div className="mt-1.5 grid grid-cols-2 gap-1.5">
                      <Select value={draft.injury.type}
                        onChange={(e) => {
                          const t = e.target.value as Injury["type"];
                          patch({ injury: { ...draft.injury!, type: t, label: t === "light" ? "лёгкая" : t === "medium" ? "средняя" : "тяжёлая" } });
                        }} className="w-full">
                        <option value="light">Лёгкая</option><option value="medium">Средняя</option><option value="severe">Тяжёлая</option>
                      </Select>
                      <Input type="number" min={0} value={draft.injury.daysLeft}
                        onChange={(e) => patch({ injury: { ...draft.injury!, daysLeft: Math.max(0, Number(e.target.value) || 0) } })}
                        className="w-full" />
                    </div>
                  )}
                </div>

                <div className="rounded border border-[#2a3140] bg-[#182029] p-2 text-[11px] text-[#9ca3af]">
                  Сезон: {draft.stats.apps} матч. · {draft.stats.goals} гол. · {draft.stats.assists} пас. ·
                  рейтинг {draft.stats.avgRating ? draft.stats.avgRating.toFixed(2) : "—"} ·
                  xG {draft.stats.xg.toFixed(1)} · отборы {draft.stats.tackles}
                </div>

                {!confirmDel ? (
                  <Btn sm variant="danger" className="w-full" onClick={() => setConfirmDel(true)} icon={<Trash2 size={12} />}>
                    Удалить игрока
                  </Btn>
                ) : (
                  <div className="flex gap-1.5">
                    <Btn sm variant="danger" className="flex-1" onClick={removePlayer}>Подтвердить удаление</Btn>
                    <Btn sm onClick={() => setConfirmDel(false)}>Отмена</Btn>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-1.5 border-t border-[#2a3140] pt-2">
              <Btn sm onClick={exportJson} icon={<Download size={11} />}>Экспорт состава</Btn>
              <input ref={fileRef} type="file" accept=".json" className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) f.text().then(importJson); e.target.value = ""; }} />
              <Btn sm onClick={() => fileRef.current?.click()} icon={<Upload size={11} />}>Импорт состава</Btn>
              <Btn sm disabled={!history.length} onClick={undo} icon={<Undo2 size={11} />}>
                Откатить {history.length ? `(${history.length})` : ""}
              </Btn>
              <span className="ml-auto flex items-center gap-1 text-[10.5px] text-[#4b5563]">
                <AlertTriangle size={10} /> правки только в этом слоте, главная база не меняется
              </span>
            </div>

            {!!history.length && (
              <div className="mt-2 max-h-24 overflow-y-auto rounded border border-[#2a3140] bg-[#0f1419] p-1.5">
                {history.slice(0, 12).map((h, i) => (
                  <div key={h.at + "" + i} className="flex justify-between text-[10.5px] text-[#6b7280]">
                    <span>{h.label}</span>
                    <span>{new Date(h.at).toLocaleTimeString("ru-RU")}</span>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </Panel>

      {msg && (
        <div className="fixed bottom-16 left-1/2 z-50 -translate-x-1/2 rounded-md border border-[#4ade80]/40 bg-[#1e2530] px-3 py-1.5 text-[12px] shadow-xl md:bottom-5">
          {msg}
        </div>
      )}
    </div>
  );
}
