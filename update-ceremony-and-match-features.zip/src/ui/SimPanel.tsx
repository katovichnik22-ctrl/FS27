// ─── Панель свободной симуляции: каждый турнир играется отдельно ────────────
import { useState } from "react";
import { Play, FastForward, Trophy, CheckCircle2, Zap } from "lucide-react";
import type { Competition, Slot } from "../types";
import { compsOverview, nextRound, simulateRound, simulateWholeComp } from "../engine/season";
import { Btn, Panel, PanelHead } from "./bits";
import { COMP_COLOR } from "./SeasonPanels";
import { cn } from "../utils/cn";

export function SimPanel({
  slot, onChanged, onFlash, busy, setBusy,
}: {
  slot: Slot;
  onChanged: () => void;
  onFlash: (m: string) => void;
  busy: boolean;
  setBusy: (b: boolean) => void;
}) {
  const [last, setLast] = useState<string | null>(null);
  const comps = compsOverview(slot).filter((c) => c.comp !== "FR");

  const run = (fn: () => string) => {
    setBusy(true);
    setTimeout(() => {
      const msg = fn();
      setLast(msg);
      onChanged();
      onFlash(msg);
      setBusy(false);
    }, 15);
  };

  const oneRound = (comp: Competition, name: string) =>
    run(() => {
      const r = simulateRound(slot, comp);
      if (!r.round) return `${name}: матчей не осталось`;
      return `${name} · ${r.round.label}: сыграно ${r.results.length} матч(ей)`;
    });

  const wholeComp = (comp: Competition, name: string) =>
    run(() => {
      const w = simulateWholeComp(slot, comp);
      if (!w.rounds) return `${name}: уже завершён`;
      const champ = w.champion ? ` · победитель: ${slot.teams[w.champion]?.name}` : "";
      return `${name}: сыграно ${w.matches} матч(ей) за ${w.rounds} раунд(ов)${champ}`;
    });

  const allLeagues = () =>
    run(() => {
      let n = 0;
      for (const c of comps.filter((x) => ["PL", "CHA", "LL", "FL1", "BL", "SA", "PT", "SPL", "TUR", "BEL", "NED", "GRE", "UKR", "POL", "SCO", "SUI"].includes(x.comp)))
        n += simulateWholeComp(slot, c.comp).matches;
      return `Все чемпионаты доиграны: ${n} матч(ей)`;
    });

  const allCups = () =>
    run(() => {
      let n = 0;
      for (const c of comps.filter((x) => ["FA", "EFL", "CDR", "CDF", "DFB", "CIT", "TCP", "KSC", "TUC", "BCB", "DTC", "GRC", "UKC", "PLC", "SCC", "SWC"].includes(x.comp)))
        n += simulateWholeComp(slot, c.comp).matches;
      return `Все кубки доиграны: ${n} матч(ей)`;
    });

  const allEuro = () =>
    run(() => {
      let n = 0;
      for (const c of comps.filter((x) => x.comp === "UCL" || x.comp === "UEL"))
        n += simulateWholeComp(slot, c.comp).matches;
      return `Еврокубки доиграны: ${n} матч(ей)`;
    });

  return (
    <Panel>
      <PanelHead
        title="Свободная симуляция по турнирам"
        icon={<Zap size={12} />}
        right={
          <>
            <Btn sm onClick={allLeagues} disabled={busy}>Все чемпионаты</Btn>
            <Btn sm onClick={allEuro} disabled={busy}>Еврокубки</Btn>
            <Btn sm onClick={allCups} disabled={busy}>Все кубки</Btn>
          </>
        }
      />
      <p className="mb-2 text-[11px] leading-relaxed text-[#9ca3af]">
        Каждый турнир играется независимо от календаря: можно прогнать хоть все туры чемпионата,
        не трогая еврокубки и кубки.
      </p>

      <div className="grid gap-1.5 sm:grid-cols-2 xl:grid-cols-3">
        {comps.map((c) => {
          const nr = nextRound(slot, c.comp);
          const pct = c.total ? Math.round((c.played / c.total) * 100) : 0;
          const champ = slot.season.champions[c.comp];
          return (
            <div key={c.comp} className="rounded-md border border-[#2a3140] bg-[#182029] p-2">
              <div className="mb-1 flex items-center gap-1.5">
                <span className={cn("shrink-0 rounded px-1 py-0.5 text-[9px] font-bold", COMP_COLOR[c.comp])}>{c.short}</span>
                <span className="min-w-0 flex-1 truncate text-[12px] font-semibold">{c.name}</span>
                {champ ? (
                  <span className="flex shrink-0 items-center gap-1 text-[10px] text-[#4ade80]">
                    <Trophy size={10} /> {slot.teams[champ]?.shortName}
                  </span>
                ) : (
                  <span className="shrink-0 font-mono text-[10px] text-[#6b7280]">{c.played}/{c.total}</span>
                )}
              </div>

              <div className="mb-1.5 h-1 overflow-hidden rounded-full bg-[#0f1419]">
                <div className="h-full rounded-full bg-[#3b82f6] transition-all duration-300" style={{ width: `${pct}%` }} />
              </div>

              <div className="flex items-center gap-1">
                <span className="min-w-0 flex-1 truncate text-[10.5px] text-[#6b7280]">
                  {nr ? `Далее: ${nr.label} · ${nr.fixtures.length} матч.` : (
                    <span className="flex items-center gap-1 text-[#4ade80]"><CheckCircle2 size={10} /> завершён</span>
                  )}
                </span>
                <Btn sm variant="primary" disabled={busy || !nr} onClick={() => oneRound(c.comp, c.short)}
                  icon={<Play size={10} />} title="Сыграть следующий раунд">Раунд</Btn>
                <Btn sm variant="blue" disabled={busy || !nr} onClick={() => wholeComp(c.comp, c.short)}
                  icon={<FastForward size={10} />} title="Доиграть турнир целиком">Всё</Btn>
              </div>
            </div>
          );
        })}
      </div>

      {last && <div className="mt-2 rounded border border-[#2a3140] bg-[#0f1419] px-2 py-1 text-[11px] text-[#9ca3af]">{last}</div>}
    </Panel>
  );
}
