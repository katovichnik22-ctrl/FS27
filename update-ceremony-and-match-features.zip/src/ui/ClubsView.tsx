// ─── Вкладки «Клубы» и «Тактики»: редактор состава, схемы и стиля ────────────
import { useMemo, useState } from "react";
import { ArrowLeft, Search, Shuffle, Save, RotateCcw, Users, UserMinus, Pencil } from "lucide-react";
import type { Player, Slot, Formation, PlayStyle, TeamTactics } from "../types";
import { FORMATIONS, FORMATION_LIST, STYLES, STYLE_LIST, autoStarters, defaultTactics, linesOf } from "../engine/tactics";
import { releasePlayer, marketValue, loansByPlayer, loanUntilLabel } from "../engine/transfers";
import { Btn, Panel, PanelHead, Select, Crest } from "./bits";
import { TacticTextEditor } from "./TacticTextEditor";
import { analyzeTactic } from "../engine/tacticText";
import { cn } from "../utils/cn";

const POS_LABEL: Record<string, string> = { GK: "ВРТ", DF: "ЗАЩ", MF: "ПЗ", FW: "НАП" };
const POS_CLS: Record<string, string> = {
  GK: "bg-[#2a2410] text-[#fbbf24]",
  DF: "bg-[#10243a] text-[#60a5fa]",
  MF: "bg-[#0f2e22] text-[#4ade80]",
  FW: "bg-[#331410] text-[#f87171]",
};

export function PosBadge({ pos }: { pos: string }) {
  return (
    <span className={cn("block w-8 shrink-0 rounded-md py-0.5 text-center font-mono text-[10px] font-bold", POS_CLS[pos])}>
      {POS_LABEL[pos]}
    </span>
  );
}

// ─── Список клубов ───────────────────────────────────────────────────────────

export function ClubsView({ slot, onOpen }: { slot: Slot; onOpen: (id: string) => void }) {
  const [q, setQ] = useState("");
  const [scope, setScope] = useState<"PL" | "EU" | "EN" | "ALL">("PL");

  const clubs = useMemo(() => {
    const all = Object.values(slot.teams);
    const filtered = all.filter((t) => {
      const tier = t.tier ?? "PL";
      if (scope === "PL" && tier !== "PL") return false;
      if (scope === "EU" && tier !== "EU") return false;
      if (scope === "EN" && !(tier === "CH" || tier === "L1")) return false;
      return t.name.toLowerCase().includes(q.toLowerCase());
    });
    return filtered.sort((a, b) => b.reputation - a.reputation);
  }, [slot, q, scope]);

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="flex flex-1 items-center gap-2 rounded-xl border border-[#2f3847] bg-[#0f1419] px-3 py-2">
          <Search size={14} className="text-[#6b7280]" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск клуба…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-[#6b7280]"
          />
        </div>
        <div className="flex gap-1 rounded-xl bg-[#0f1419] p-1">
          {([["PL", "АПЛ"], ["EU", "Европа"], ["EN", "Англия"], ["ALL", "Все"]] as const).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setScope(id)}
              className={cn(
                "rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors",
                scope === id ? "bg-[#2a3140] text-[#4ade80]" : "text-[#9ca3af] hover:text-[#e5e7eb]"
              )}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid max-h-[560px] gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
        {clubs.map((t) => {
          const tac = slot.tactics[t.id];
          return (
            <button
              key={t.id}
              onClick={() => onOpen(t.id)}
              className="flex items-center gap-3 rounded-xl border border-[#2a3140] bg-[#182029] px-3 py-2.5 text-left transition-all hover:-translate-y-0.5 hover:border-[#4ade80]/50"
            >
              <Crest name={t.name} color={t.color} size={16} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-semibold text-white">{t.name}</div>
                <div className="text-[11px] text-[#6b7280]">
                  {tac?.formation} · {STYLES[tac?.style ?? "balanced"].short} · {t.players.length} игр. · £{t.budget}M
                </div>
              </div>
              <div className="text-right font-mono text-xs">
                <div className="text-[#4ade80]">{Math.round((t.attack + t.midfield + t.defense + t.goalkeeping) / 4)}</div>
                <div className="text-[10px] text-[#6b7280]">{t.country}</div>
              </div>
            </button>
          );
        })}
        {!clubs.length && <p className="col-span-2 py-6 text-center text-sm text-[#6b7280]">Ничего не найдено</p>}
      </div>
    </div>
  );
}

// ─── Карточка клуба ──────────────────────────────────────────────────────────

export function ClubCard({
  slot, teamId, onBack, onChanged, onEditPlayer,
}: { slot: Slot; teamId: string; onBack: () => void; onChanged: () => void; onEditPlayer?: (playerId: string) => void }) {
  const team = slot.teams[teamId];
  const [tac, setTac] = useState<TeamTactics>(() => ({ ...slot.tactics[teamId] }));
  const [dirty, setDirty] = useState(false);
  const [saved, setSaved] = useState(false);

  const byId = useMemo(() => new Map(team.players.map((p) => [p.id, p])), [team]);
  const loanMap = useMemo(() => loansByPlayer(slot), [slot]);
  const starters = tac.starters.map((id) => byId.get(id)).filter(Boolean) as Player[];
  const bench = team.players.filter((p) => !tac.starters.includes(p.id)).sort((a, b) => b.overall - a.overall);
  const shape = FORMATIONS[tac.formation];

  const patch = (p: Partial<TeamTactics>) => {
    setTac((t) => ({ ...t, ...p }));
    setDirty(true);
    setSaved(false);
  };

  const swap = (outId: string, inId: string) => {
    patch({ starters: tac.starters.map((id) => (id === outId ? inId : id)) });
  };

  const [pending, setPending] = useState<string | null>(null); // выбранный для замены игрок
  const clickStarter = (id: string) => {
    if (pending && pending !== id) {
      // перестановка внутри состава
      const a = tac.starters.indexOf(pending);
      const b = tac.starters.indexOf(id);
      if (a !== -1 && b !== -1) {
        const next = [...tac.starters];
        [next[a], next[b]] = [next[b], next[a]];
        patch({ starters: next });
      } else if (a === -1) {
        swap(id, pending);
      }
      setPending(null);
    } else {
      setPending(pending === id ? null : id);
    }
  };
  const clickBench = (id: string) => {
    if (pending && tac.starters.includes(pending)) {
      swap(pending, id);
      setPending(null);
    } else {
      setPending(pending === id ? null : id);
    }
  };

  const save = () => {
    slot.tactics[teamId] = { ...tac };
    setDirty(false);
    setSaved(true);
    onChanged();
    setTimeout(() => setSaved(false), 1600);
  };

  const applyFormation = (f: Formation) => {
    patch({ formation: f, starters: autoStarters(team, f) });
  };

  const release = (playerId: string) => {
    if (releasePlayer(slot, teamId, playerId)) {
      setTac({ ...slot.tactics[teamId] });
      onChanged();
    }
  };

  const lines = linesOf(team, tac);

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <Btn onClick={onBack} icon={<ArrowLeft size={15} />}>Все клубы</Btn>
        <div className="flex items-center gap-2 rounded-xl border border-[#2a3140] bg-[#182029] px-3 py-2">
          <Crest name={team.name} color={team.color} size={18} />
          <span className="font-semibold">{team.name}</span>
          <span className="text-xs text-[#6b7280]">{team.stadium}</span>
        </div>
        <div className="ml-auto flex gap-2">
          <Btn onClick={() => { const d = defaultTactics(team); setTac(d); setDirty(true); }} icon={<RotateCcw size={14} />}>
            Сброс
          </Btn>
          <Btn variant={dirty ? "primary" : "outline"} onClick={save} icon={<Save size={15} />} disabled={!dirty}>
            {saved ? "Сохранено ✓" : "Сохранить изменения"}
          </Btn>
        </div>
      </div>

      <div className="m-stack grid gap-4 lg:grid-cols-[1fr_1fr]">
        {/* ── Тактика и поле ── */}
        <div className="space-y-3">
          <Panel className="bg-[#182029]">
            <PanelHead
              title="Схема и стиль"
              right={<span className="font-mono text-[10px] text-[#6b7280]">
                атк ×{(shape.atk * STYLES[tac.style].atk).toFixed(2)} · защ ×{(shape.def * STYLES[tac.style].def).toFixed(2)} · центр ×{shape.mid.toFixed(2)}
              </span>}
            />
            <div className="grid gap-2 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-[11px] text-[#9ca3af]">Схема</label>
                <Select value={tac.formation} onChange={(e) => applyFormation(e.target.value as Formation)}>
                  {FORMATION_LIST.map((f) => (
                    <option key={f} value={f}>{f} — {FORMATIONS[f].label}</option>
                  ))}
                </Select>
              </div>
              <div>
                <label className="mb-1 block text-[11px] text-[#9ca3af]">Стиль игры</label>
                <Select value={tac.style} onChange={(e) => patch({ style: e.target.value as PlayStyle })}>
                  {STYLE_LIST.map((st) => (
                    <option key={st} value={st}>{STYLES[st].label}</option>
                  ))}
                </Select>
              </div>
            </div>

            {/* поле */}
            <div className="mt-3 rounded-xl border border-[#232b36] bg-gradient-to-b from-[#16241c] to-[#122018] p-3">
              {[...lines].reverse().map((line, i) => (
                <div key={i} className="mb-2 flex flex-wrap justify-center gap-1.5 last:mb-0">
                  {line.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => clickStarter(p.id)}
                      className={cn(
                        "rounded-lg border px-2 py-1 text-[11px] transition-all",
                        pending === p.id
                          ? "border-[#fbbf24] bg-[#fbbf24]/20 text-white"
                          : "border-[#2e4a3a] bg-[#1a2a20] text-[#c9e8d8] hover:border-[#4ade80]"
                      )}
                      title={`${p.position} · OVR ${p.overall}`}
                    >
                      {p.name.split(" ").pop()}
                      <span className="ml-1 font-mono text-[#4ade80]">{p.overall}</span>
                    </button>
                  ))}
                </div>
              ))}
            </div>
            <p className="mt-2 text-[11px] text-[#6b7280]">
              Кликните игрока в составе, затем другого игрока (в составе или на скамейке) — они поменяются местами.
            </p>
          </Panel>

          <TacticTextEditor
            value={tac.textTactic}
            onSave={(txt) => {
              const next = { ...tac, textTactic: txt };
              setTac(next);
              slot.tactics[teamId] = next;
              onChanged();
            }}
          />

          <Panel className="bg-[#182029]">
            <PanelHead title="Роли" />
            <div className="grid gap-2 sm:grid-cols-2">
              {([
                ["captain", "Капитан"],
                ["penaltyTaker", "Пенальтист"],
                ["cornerTaker", "Угловые"],
                ["freeKickTaker", "Штрафные"],
              ] as const).map(([key, label]) => (
                <div key={key}>
                  <label className="mb-1 block text-[11px] text-[#9ca3af]">{label}</label>
                  <Select value={tac[key]} onChange={(e) => patch({ [key]: e.target.value } as Partial<TeamTactics>)}>
                    {starters.map((p) => (
                      <option key={p.id} value={p.id}>{p.name} ({POS_LABEL[p.position]})</option>
                    ))}
                  </Select>
                </div>
              ))}
            </div>
          </Panel>
        </div>

        {/* ── Состав ── */}
        <Panel className="bg-[#182029]">
          <div className="mb-2 flex items-center justify-between">
            <PanelHead title="Стартовый состав · {starters.length}/11" />
            <Btn onClick={() => patch({ starters: autoStarters(team, tac.formation) })} icon={<Shuffle size={14} />}>
              Авто
            </Btn>
          </div>
          <div className="max-h-[260px] overflow-y-auto pr-1">
            {starters.map((p) => (
              <button
                key={p.id}
                onClick={() => clickStarter(p.id)}
                className={cn(
                  "flex w-full items-center gap-2 rounded-lg border-b border-[#232b36] px-1 py-1.5 text-left text-sm transition-colors",
                  pending === p.id ? "bg-[#fbbf24]/15" : "hover:bg-[#232b36]/60"
                )}
              >
                <PosBadge pos={p.position} />
                <span className="min-w-0 flex-1 truncate">
                  {p.name}
                  {p.id === tac.captain && <span className="ml-1 rounded bg-[#4ade80]/20 px-1 text-[9px] font-bold text-[#4ade80]">К</span>}
                  {p.id === tac.penaltyTaker && <span className="ml-1 rounded bg-[#fbbf24]/20 px-1 text-[9px] font-bold text-[#fbbf24]">П</span>}
                  {loanMap.has(p.id) && (
                    <span
                      className="ml-1 rounded bg-[#a78bfa]/20 px-1 text-[9px] font-bold text-[#a78bfa]"
                      title={`В аренде из «${slot.teams[loanMap.get(p.id)!.parentId]?.name ?? "?"}» · ${loanUntilLabel(loanMap.get(p.id)!, slot.seasonNumber)}`}
                    >
                      аренда
                    </span>
                  )}
                </span>
                <span className="w-8 text-center font-mono text-[11px] text-[#9ca3af]">{p.age}</span>
                <span className="w-9 text-center font-mono text-sm font-bold text-[#4ade80]">{p.overall}</span>
                {p.injury && <span title={`${p.injury.label}, ${p.injury.daysLeft} дн.`}>🚑</span>}
                {onEditPlayer && (
                  <span onClick={(e) => { e.stopPropagation(); onEditPlayer(p.id); }}
                    className="rounded p-1 text-[#6b7280] hover:text-[#60a5fa]" title="Редактировать">
                    <Pencil size={12} />
                  </span>
                )}
              </button>
            ))}
          </div>

          <div className="mt-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#9ca3af]">
            <Users size={13} /> Запас · {bench.length}
          </div>
          <div className="mt-1 max-h-[260px] overflow-y-auto pr-1">
            {bench.map((p) => (
              <div
                key={p.id}
                className={cn(
                  "flex items-center gap-2 border-b border-[#232b36] py-1.5 text-sm",
                  pending === p.id && "bg-[#fbbf24]/15"
                )}
              >
                <button onClick={() => clickBench(p.id)} className="flex min-w-0 flex-1 items-center gap-2 text-left">
                  <PosBadge pos={p.position} />
                  <span className="min-w-0 flex-1 truncate text-[#cbd5e1]">
                    {p.name}
                    {loanMap.has(p.id) && (
                      <span
                        className="ml-1 rounded bg-[#a78bfa]/20 px-1 text-[9px] font-bold text-[#a78bfa]"
                        title={`В аренде из «${slot.teams[loanMap.get(p.id)!.parentId]?.name ?? "?"}» · ${loanUntilLabel(loanMap.get(p.id)!, slot.seasonNumber)}`}
                      >
                        аренда
                      </span>
                    )}
                  </span>
                  <span className="w-8 text-center font-mono text-[11px] text-[#6b7280]">{p.age}</span>
                  <span className="w-9 text-center font-mono text-xs">{p.overall}</span>
                  <span className="hidden w-12 text-right font-mono text-[10px] text-[#6b7280] sm:block">£{marketValue(p)}M</span>
                </button>
                {onEditPlayer && (
                  <button
                    onClick={() => onEditPlayer(p.id)}
                    title="Редактировать игрока"
                    className="rounded p-1 text-[#6b7280] transition-colors hover:bg-[#232b36] hover:text-[#60a5fa]"
                  >
                    <Pencil size={12} />
                  </button>
                )}
                <button
                  onClick={() => release(p.id)}
                  disabled={loanMap.has(p.id)}
                  title={loanMap.has(p.id) ? "Игрок в аренде — освободить нельзя" : "Отправить в свободные агенты"}
                  className="rounded p-1 text-[#6b7280] transition-colors hover:bg-[#3a2020] hover:text-[#f87171] disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-[#6b7280]"
                >
                  <UserMinus size={13} />
                </button>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}

// ─── Вкладка «Тактики»: все клубы разом ──────────────────────────────────────

export function TacticsView({ slot, onChanged, onOpenClub }: { slot: Slot; onChanged: () => void; onOpenClub: (id: string) => void }) {
  const [scope, setScope] = useState<"PL" | "ALL">("PL");
  const clubs = Object.values(slot.teams)
    .filter((t) => (scope === "PL" ? (t.tier ?? "PL") === "PL" : true))
    .sort((a, b) => b.reputation - a.reputation);

  const set = (id: string, patch: Partial<TeamTactics>) => {
    const cur = slot.tactics[id];
    const next = { ...cur, ...patch };
    if (patch.formation) next.starters = autoStarters(slot.teams[id], patch.formation);
    slot.tactics[id] = next;
    onChanged();
  };

  const resetAll = () => {
    for (const t of clubs) slot.tactics[t.id] = defaultTactics(t);
    onChanged();
  };

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="flex gap-1 rounded-xl bg-[#0f1419] p-1">
          {([["PL", "АПЛ"], ["ALL", "Все клубы"]] as const).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setScope(id)}
              className={cn(
                "rounded-lg px-3 py-1.5 text-xs font-medium transition-colors",
                scope === id ? "bg-[#2a3140] text-[#4ade80]" : "text-[#9ca3af] hover:text-[#e5e7eb]"
              )}
            >
              {label}
            </button>
          ))}
        </div>
        <Btn className="ml-auto" onClick={resetAll} icon={<RotateCcw size={14} />}>Сбросить всё к дефолту</Btn>
      </div>

      <div className="max-h-[560px] overflow-y-auto pr-1">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-[10px] uppercase tracking-wider text-[#6b7280]">
              <th className="py-1.5 text-left font-medium">Клуб</th>
              <th className="w-28 text-left font-medium">Схема</th>
              <th className="w-36 text-left font-medium">Стиль</th>
              <th className="w-24 text-left font-medium">План</th>
              <th className="hidden text-left font-medium sm:table-cell">Стартовый состав (сила)</th>
              <th className="w-20" />
            </tr>
          </thead>
          <tbody>
            {clubs.map((t) => {
              const tac = slot.tactics[t.id];
              const xi = tac.starters.map((id) => t.players.find((p) => p.id === id)).filter(Boolean) as Player[];
              const avg = xi.length ? Math.round(xi.reduce((s, p) => s + p.overall, 0) / xi.length) : 0;
              return (
                <tr key={t.id} className="border-b border-[#232b36] hover:bg-[#232b36]/40">
                  <td className="py-1.5">
                    <span className="flex items-center gap-2">
                      <Crest name="" color={t.color} size={8} />
                      <span className="truncate font-medium">{t.name}</span>
                    </span>
                  </td>
                  <td className="py-1 pr-2">
                    <Select
                      value={tac.formation}
                      onChange={(e) => set(t.id, { formation: e.target.value as Formation })}
                      className="px-2 py-1 text-xs"
                    >
                      {FORMATION_LIST.map((f) => <option key={f} value={f}>{f}</option>)}
                    </Select>
                  </td>
                  <td className="py-1 pr-2">
                    <Select
                      value={tac.style}
                      onChange={(e) => set(t.id, { style: e.target.value as PlayStyle })}
                      className="px-2 py-1 text-xs"
                    >
                      {STYLE_LIST.map((st) => <option key={st} value={st}>{STYLES[st].label}</option>)}
                    </Select>
                  </td>
                  <td className="py-1.5">
                    {(() => {
                      const an = analyzeTactic(tac.textTactic);
                      if (!an.score) return <span className="text-[10.5px] text-[#4b5563]">нет плана</span>;
                      const c = an.score >= 85 ? "#4ade80" : an.score >= 70 ? "#86efac" : an.score >= 55 ? "#fbbf24" : an.score >= 40 ? "#fb923c" : "#f87171";
                      return (
                        <span className="flex items-center gap-1">
                          <span className="h-1 w-10 overflow-hidden rounded-full bg-[#0f1419]">
                            <span className="block h-full rounded-full" style={{ width: `${an.score}%`, background: c }} />
                          </span>
                          <span className="font-mono text-[10.5px] font-bold" style={{ color: c }}>{an.score}</span>
                        </span>
                      );
                    })()}
                  </td>
                  <td className="hidden py-1.5 text-xs text-[#9ca3af] sm:table-cell">
                    <span className="font-mono text-[#4ade80]">{avg}</span>{" "}
                    <span className="text-[#6b7280]">ср. OVR · {xi.length}/11</span>
                  </td>
                  <td className="py-1 text-right">
                    <Btn onClick={() => onOpenClub(t.id)} className="px-2.5 py-1 text-xs">Изменить</Btn>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
