// ─── Вкладка «Трансферы»: поиск игрока → переход или аренда в другой клуб ────
import { useMemo, useState } from "react";
import {
  ArrowLeftRight, AlertTriangle, Lock, History, UserPlus, Wallet, Search, X, Wand2,
  CalendarClock, RotateCcw, Hourglass,
} from "lucide-react";
import type { Player, Slot } from "../types";
import {
  executeLoan, executeTransfer, isWindowOpen, loanEndFor, loansByPlayer, loanUntilLabel,
  LOAN_DURATION_LABELS, marketValue, suggestLoanFee, terminateLoan, validateLoan,
  validateTransfer, windowLabel,
  type LoanMonths, type LoanPlan, type TransferPlan,
} from "../engine/transfers";
import { fmtDay, LEAGUE_CFG } from "../engine/season";
import { Btn, Crest, Input, Panel, PanelHead, PosBadge, Select, Tabs, ratingClass } from "./bits";
import { cn } from "../utils/cn";

interface Found {
  player: Player;
  teamId: string | null;      // null = свободный агент
  teamName: string;
  teamShort: string;
  teamColor: string;
  league: string;
}

/** Бейдж типа записи в истории сделок */
function kindBadge(kind: string): { label: string; cls: string } {
  switch (kind) {
    case "swap": return { label: "ОБМЕН", cls: "bg-[#60a5fa]/15 text-[#60a5fa]" };
    case "free": return { label: "СВОБ.", cls: "bg-[#fbbf24]/15 text-[#fbbf24]" };
    case "loan": return { label: "АРЕНДА", cls: "bg-[#a78bfa]/15 text-[#a78bfa]" };
    case "loan_return": return { label: "ВОЗВРАТ", cls: "bg-[#94a3b8]/15 text-[#94a3b8]" };
    default: return { label: "ТРАНСФЕР", cls: "bg-[#4ade80]/15 text-[#4ade80]" };
  }
}

const MONTHS: LoanMonths[] = [6, 12, 24];

export function TransfersView({ slot, onChanged }: { slot: Slot; onChanged: () => void }) {
  const [tab, setTab] = useState<"transfer" | "loan" | "history">("transfer");
  const [query, setQuery] = useState("");
  const [posFilter, setPosFilter] = useState<"ALL" | "GK" | "DF" | "MF" | "FW">("ALL");
  const [picked, setPicked] = useState<Found | null>(null);
  const [toId, setToId] = useState("");
  const [fee, setFee] = useState(0);
  const [months, setMonths] = useState<LoanMonths>(12);
  const [flash, setFlash] = useState<string | null>(null);

  const loans = slot.loans ?? [];
  const loanByPlayer = useMemo(() => loansByPlayer(slot), [slot]);

  const clubs = useMemo(
    () => Object.values(slot.teams)
      .filter((t) => t.league)
      .sort((a, b) => (a.league! < b.league! ? -1 : a.league! > b.league! ? 1 : b.reputation - a.reputation)),
    [slot]
  );

  // ── Поиск игрока по имени/фамилии среди всех клубов и свободных агентов ──
  const results = useMemo<Found[]>(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return [];
    const out: Found[] = [];
    const match = (name: string) => {
      const n = name.toLowerCase();
      // совпадение по началу имени, фамилии или любой части
      return n.includes(q) || n.split(/[\s-]/).some((part) => part.startsWith(q));
    };
    for (const t of Object.values(slot.teams)) {
      if (!t.league) continue;
      for (const p of t.players) {
        if (!match(p.name)) continue;
        if (posFilter !== "ALL" && p.position !== posFilter) continue;
        out.push({
          player: p, teamId: t.id, teamName: t.name, teamShort: t.shortName,
          teamColor: t.color, league: LEAGUE_CFG[t.league!].short,
        });
      }
    }
    for (const p of slot.freeAgents) {
      if (!match(p.name)) continue;
      if (posFilter !== "ALL" && p.position !== posFilter) continue;
      out.push({
        player: p, teamId: null, teamName: "Свободный агент", teamShort: "СА",
        teamColor: "#4b5563", league: "—",
      });
    }
    // сортируем: точное начало имени выше, затем по классу
    return out
      .sort((a, b) => {
        const aStart = a.player.name.toLowerCase().startsWith(q) ? 0 : 1;
        const bStart = b.player.name.toLowerCase().startsWith(q) ? 0 : 1;
        return aStart - bStart || b.player.overall - a.player.overall;
      })
      .slice(0, 40);
  }, [query, posFilter, slot]);

  const say = (m: string) => { setFlash(m); setTimeout(() => setFlash(null), 2600); };

  // ── Трансфер ──
  const plan: TransferPlan | null = tab === "transfer" && picked && toId
    ? { fromId: picked.teamId, toId, playersOut: [picked.player.id], playersBack: [], fee }
    : null;
  const check = plan ? validateTransfer(slot, plan) : null;

  // ── Аренда ──
  const loanPlan: LoanPlan | null = tab === "loan" && picked?.teamId && toId
    ? { parentId: picked.teamId, hostId: toId, playerId: picked.player.id, months, fee }
    : null;
  const loanCheck = loanPlan ? validateLoan(slot, loanPlan) : null;
  const loanEnd = loanEndFor(slot.seasonNumber, slot.currentDate, months);

  const windowOpen = isWindowOpen(slot.currentDate);
  const target = toId ? slot.teams[toId] : null;

  const choose = (f: Found) => {
    setPicked(f);
    setToId("");
    setFee(tab === "loan"
      ? suggestLoanFee(f.player, months)
      : Math.round(marketValue(f.player) * 10) / 10);
  };

  const setDuration = (m: LoanMonths) => {
    setMonths(m);
    if (picked) setFee(suggestLoanFee(picked.player, m));
  };

  const resetDeal = () => {
    setPicked(null);
    setToId("");
    setFee(0);
    setQuery("");
  };

  const doTransfer = () => {
    if (!plan) return;
    try {
      const rec = executeTransfer(slot, plan);
      const name = rec.playerNames.join(", ");
      const to = slot.teams[plan.toId]?.name;
      resetDeal();
      onChanged();
      say(`${name} → ${to}`);
    } catch (e) {
      say(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const doLoan = () => {
    if (!loanPlan) return;
    try {
      const ln = executeLoan(slot, loanPlan);
      const to = slot.teams[ln.hostId]?.name;
      const label = loanUntilLabel(ln, slot.seasonNumber);
      resetDeal();
      onChanged();
      say(`Аренда: ${ln.playerName} → ${to} · ${LOAN_DURATION_LABELS[ln.months]}, ${label}`);
    } catch (e) {
      say(e instanceof Error ? e.message : "Ошибка");
    }
  };

  const recall = (loanId: string) => {
    const ln = terminateLoan(slot, loanId);
    onChanged();
    if (ln) say(`${ln.playerName} досрочно вернулся в «${slot.teams[ln.parentId]?.name ?? "свой клуб"}»`);
  };

  // игрок уже в аренде — с ним нельзя совершать сделки
  const pickedLoan = picked ? loanByPlayer.get(picked.player.id) : undefined;

  return (
    <div>
      <div className="mb-2 flex flex-wrap items-center gap-1.5">
        <Tabs value={tab} onChange={setTab} items={[
          { id: "transfer" as const, label: "Трансфер" },
          { id: "loan" as const, label: "Аренда", count: loans.length },
          { id: "history" as const, label: "История", count: slot.transfers.length },
        ]} />
        <span className={cn(
          "ml-auto flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-medium",
          windowOpen ? "bg-[#4ade80]/15 text-[#4ade80]" : "bg-[#fbbf24]/15 text-[#fbbf24]"
        )}>
          {windowOpen ? <UserPlus size={12} /> : <Lock size={12} />}
          {windowLabel(slot.currentDate)}
        </span>
      </div>

      {tab === "history" ? (
        <div className="max-h-[calc(100vh-215px)] overflow-y-auto">
          {!slot.transfers.length && <p className="py-8 text-center text-[12px] text-[#6b7280]">Сделок пока нет</p>}
          {slot.transfers.map((t) => {
            const b = kindBadge(t.kind);
            return (
              <div key={t.id} className="flex flex-wrap items-center gap-2 border-b border-[#232b36] py-2 text-[12.5px]">
                <span className="w-20 shrink-0 text-[11px] text-[#6b7280]">{fmtDay(t.date)}</span>
                <span className={cn("rounded px-1.5 py-0.5 text-[9px] font-bold", b.cls)}>{b.label}</span>
                <span className="min-w-0 flex-1 truncate font-medium">{t.playerNames.join(", ")}</span>
                <span className="flex items-center gap-1.5 text-[11.5px] text-[#9ca3af]">
                  {t.fromId ? slot.teams[t.fromId]?.shortName ?? "—" : "Св. агенты"}
                  <ArrowLeftRight size={11} className="text-[#6b7280]" />
                  {t.toId === "free_agents" ? "Св. агенты" : slot.teams[t.toId]?.shortName}
                </span>
                <span className="w-16 text-right font-mono text-[11.5px] text-[#4ade80]">
                  {t.fee ? `£${t.fee}M` : "—"}
                </span>
              </div>
            );
          })}
        </div>
      ) : (
        <>
          <div className="grid gap-2 lg:grid-cols-[1.1fr_1fr]">
            {/* ── Шаг 1: поиск игрока ── */}
            <Panel>
              <PanelHead
                title={<span className="flex items-center gap-1.5"><Search size={12} /> Шаг 1 · найдите игрока</span>}
                right={<span className="text-[10.5px] text-[#6b7280]">{results.length ? `${results.length} совпад.` : ""}</span>}
              />
              <div className="mb-1.5 flex items-center gap-1.5 rounded-md border border-[#2f3847] bg-[#0f1419] px-2 py-1.5">
                <Search size={14} className="shrink-0 text-[#6b7280]" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Имя или фамилия — например «Холанд», «Saka», «Мбаппе»…"
                  autoFocus
                  className="w-full bg-transparent text-[13px] outline-none placeholder:text-[#4b5563]"
                />
                {query && (
                  <button onClick={() => setQuery("")} className="shrink-0 rounded p-0.5 text-[#6b7280] hover:text-[#e5e7eb]">
                    <X size={13} />
                  </button>
                )}
              </div>
              <Tabs
                className="mb-1.5"
                value={posFilter}
                onChange={setPosFilter}
                items={[
                  { id: "ALL" as const, label: "Все" }, { id: "GK" as const, label: "ВР" },
                  { id: "DF" as const, label: "ЗЩ" }, { id: "MF" as const, label: "ПЗ" }, { id: "FW" as const, label: "НП" },
                ]}
              />

              <div className="max-h-[calc(100vh-330px)] min-h-[160px] overflow-y-auto rounded-md border border-[#2a3140] bg-[#182029]">
                {query.trim().length < 2 && (
                  <p className="px-3 py-8 text-center text-[12px] leading-relaxed text-[#6b7280]">
                    Начните вводить имя игрока.<br />
                    Поиск идёт по всем клубам всех лиг и по свободным агентам.
                  </p>
                )}
                {query.trim().length >= 2 && !results.length && (
                  <p className="px-3 py-8 text-center text-[12px] text-[#6b7280]">Игрок не найден</p>
                )}
                {results.map((f) => {
                  const on = picked?.player.id === f.player.id;
                  const loan = loanByPlayer.get(f.player.id);
                  // в режиме аренды свободного агента отдать нельзя — только подписать
                  const disabled = !!loan || (tab === "loan" && !f.teamId);
                  return (
                    <button
                      key={f.player.id}
                      onClick={() => !disabled && choose(f)}
                      disabled={disabled}
                      className={cn(
                        "flex w-full items-center gap-2 border-b border-[#232b36] px-2 py-1.5 text-left text-[12.5px] transition-colors last:border-0",
                        on ? "bg-[#4ade80]/15" : disabled ? "cursor-not-allowed opacity-55" : "hover:bg-[#2a3140]"
                      )}
                    >
                      <PosBadge pos={f.player.position} />
                      <span className="min-w-0 flex-1 truncate font-medium">
                        {f.player.name}
                        {f.player.injury && <span title={`${f.player.injury.label}, ${f.player.injury.daysLeft} дн.`}> 🚑</span>}
                      </span>
                      {loan && (
                        <span
                          className="shrink-0 rounded bg-[#a78bfa]/15 px-1.5 py-0.5 text-[9px] font-bold text-[#a78bfa]"
                          title={`В аренде из «${slot.teams[loan.parentId]?.name ?? "?"}» · ${loanUntilLabel(loan, slot.seasonNumber)}`}
                        >
                          АРЕНДА
                        </span>
                      )}
                      {!loan && !f.teamId && tab === "loan" && (
                        <span className="shrink-0 rounded bg-[#4b5563]/30 px-1.5 py-0.5 text-[9px] font-bold text-[#9ca3af]" title="Свободного агента можно только подписать (вкладка «Трансфер»)">
                          СА
                        </span>
                      )}
                      <span className="hidden w-7 shrink-0 text-center font-mono text-[10.5px] text-[#6b7280] sm:block">
                        {f.player.age}
                      </span>
                      <Crest name={f.teamName} color={f.teamColor} size={14} />
                      <span className="w-14 shrink-0 truncate text-[10.5px] text-[#9ca3af]">{f.teamShort}</span>
                      <span className="m-hide hidden w-12 shrink-0 text-[9.5px] text-[#4b5563] lg:block">{f.league}</span>
                      <span className="w-8 shrink-0 text-center font-mono text-[12px] font-bold text-[#4ade80]">
                        {f.player.overall}
                      </span>
                      <span className="w-12 shrink-0 text-right font-mono text-[10.5px] text-[#9ca3af]">
                        £{marketValue(f.player)}M
                      </span>
                    </button>
                  );
                })}
              </div>
            </Panel>

            {/* ── Шаг 2: новый клуб ── */}
            <Panel>
              <PanelHead title={
                <span className="flex items-center gap-1.5">
                  {tab === "loan" ? <CalendarClock size={12} /> : <ArrowLeftRight size={12} />}
                  Шаг 2 · {tab === "loan" ? "клуб аренды" : "новый клуб"}
                </span>
              } />

              {!picked ? (
                <div className="flex h-40 flex-col items-center justify-center gap-2 text-center text-[12px] text-[#6b7280]">
                  <UserPlus size={22} className="text-[#2f3847]" />
                  Сначала выберите игрока в списке слева
                </div>
              ) : (
                <>
                  {/* карточка выбранного */}
                  <div className="mb-2 rounded-md border border-[#2a3140] bg-[#182029] p-2.5">
                    <div className="flex items-center gap-2">
                      <PosBadge pos={picked.player.position} />
                      <span className="min-w-0 flex-1 truncate text-[14px] font-bold">{picked.player.name}</span>
                      {pickedLoan && (
                        <span className="rounded bg-[#a78bfa]/15 px-1.5 py-0.5 text-[9px] font-bold text-[#a78bfa]">АРЕНДА</span>
                      )}
                      <span className="rounded bg-[#4ade80]/15 px-1.5 py-0.5 font-mono text-[12px] font-bold text-[#4ade80]">
                        {picked.player.overall}
                      </span>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-[#9ca3af]">
                      <span className="flex items-center gap-1">
                        <Crest name={picked.teamName} color={picked.teamColor} size={12} /> {picked.teamName}
                      </span>
                      <span>{picked.player.age} лет</span>
                      <span>{picked.player.nationality}</span>
                      {picked.player.stats.apps > 0 && (
                        <span className={cn("rounded px-1 font-mono", ratingClass(picked.player.stats.avgRating))}>
                          {picked.player.stats.avgRating.toFixed(2)}
                        </span>
                      )}
                      <span>{picked.player.stats.goals}г {picked.player.stats.assists}п</span>
                    </div>
                    {pickedLoan && (
                      <p className="mt-1.5 flex items-center gap-1.5 text-[11px] text-[#a78bfa]">
                        <CalendarClock size={11} />
                        В аренде из «{slot.teams[pickedLoan.parentId]?.name}» · {loanUntilLabel(pickedLoan, slot.seasonNumber)}.
                        Сделки с ним заблокированы до конца аренды.
                      </p>
                    )}
                  </div>

                  <label className="mb-1 block text-[11px] text-[#9ca3af]">
                    {tab === "loan" ? "Куда отправляем в аренду" : "Куда переходит"}
                  </label>
                  <Select value={toId} onChange={(e) => setToId(e.target.value)} className="w-full" disabled={!!pickedLoan}>
                    <option value="">— выберите клуб —</option>
                    {clubs.filter((t) => t.id !== picked.teamId).map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} · {LEAGUE_CFG[t.league!].short}
                      </option>
                    ))}
                  </Select>

                  {target && (
                    <div className="mt-1.5 flex items-center gap-2 rounded-md border border-[#2a3140] bg-[#182029] px-2 py-1.5 text-[11px] text-[#9ca3af]">
                      <Crest name={target.name} color={target.color} size={14} />
                      <span className="min-w-0 flex-1 truncate">{target.name}</span>
                      <span className="flex items-center gap-1"><Wallet size={11} /> £{target.budget}M</span>
                      <span>{target.players.length} игр.</span>
                    </div>
                  )}

                  {/* ── Выбор срока аренды ── */}
                  {tab === "loan" && (
                    <div className="mt-2">
                      <label className="mb-1 block text-[11px] text-[#9ca3af]">Срок аренды</label>
                      <div className="grid grid-cols-3 gap-1">
                        {MONTHS.map((m) => {
                          const end = loanEndFor(slot.seasonNumber, slot.currentDate, m);
                          const on = months === m;
                          return (
                            <button
                              key={m}
                              onClick={() => setDuration(m)}
                              className={cn(
                                "rounded-md border px-1.5 py-1.5 text-center transition-colors",
                                on
                                  ? "border-[#a78bfa] bg-[#a78bfa]/15 text-[#d6c8ff]"
                                  : "border-[#2f3847] bg-[#0f1419] text-[#9ca3af] hover:border-[#a78bfa]/60 hover:text-[#e5e7eb]"
                              )}
                            >
                              <span className="block text-[12px] font-bold">{LOAN_DURATION_LABELS[m]}</span>
                              <span className="block text-[9.5px] opacity-80">
                                {loanUntilLabel(end, slot.seasonNumber)}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div className="mt-2 flex items-end gap-1.5">
                    <label className="flex-1">
                      <span className="mb-1 block text-[11px] text-[#9ca3af]">
                        {tab === "loan" ? "Сумма аренды, £M — платит клуб аренды" : "Сумма сделки, £M"}
                      </span>
                      <Input
                        type="number" step={0.5} value={fee}
                        onChange={(e) => setFee(Number(e.target.value) || 0)}
                        className="w-full text-center font-mono"
                      />
                    </label>
                    <Btn
                      onClick={() => setFee(tab === "loan"
                        ? suggestLoanFee(picked.player, months)
                        : Math.round(marketValue(picked.player) * 10) / 10)}
                      icon={<Wand2 size={12} />}
                    >
                      По рынку
                    </Btn>
                    <Btn onClick={() => setFee(0)}>Бесплатно</Btn>
                  </div>

                  {tab === "loan" && target && (
                    <p className="mt-1.5 flex items-center gap-1.5 text-[10.5px] text-[#6b7280]">
                      <Hourglass size={11} className="shrink-0 text-[#a78bfa]" />
                      {picked.player.name} вернётся в «{picked.teamName}» {loanUntilLabel(loanEnd, slot.seasonNumber)} — автоматически.
                    </p>
                  )}

                  {(tab === "transfer" ? check : loanCheck) && !!(tab === "transfer" ? check : loanCheck)!.errors.length && (
                    <ul className="mt-2 space-y-1">
                      {(tab === "transfer" ? check : loanCheck)!.errors.map((e, i) => (
                        <li key={i} className="flex items-center gap-1.5 text-[11.5px] text-[#f87171]">
                          <AlertTriangle size={12} /> {e}
                        </li>
                      ))}
                    </ul>
                  )}
                  {(tab === "transfer" ? check : loanCheck) && !!(tab === "transfer" ? check : loanCheck)!.warnings.length && (
                    <ul className="mt-1 space-y-1">
                      {(tab === "transfer" ? check : loanCheck)!.warnings.map((w, i) => (
                        <li key={i} className="flex items-center gap-1.5 text-[11.5px] text-[#fbbf24]">
                          <AlertTriangle size={12} /> {w}
                        </li>
                      ))}
                    </ul>
                  )}

                  <div className="mt-2 flex items-center gap-2">
                    {tab === "loan" ? (
                      <Btn
                        variant="primary" className="flex-1" disabled={!loanCheck?.ok} onClick={doLoan}
                        icon={<CalendarClock size={14} />}
                      >
                        {toId ? `Отправить в аренду в ${slot.teams[toId]?.shortName ?? "клуб"}` : "Выберите клуб"}
                      </Btn>
                    ) : (
                      <Btn
                        variant="primary" className="flex-1" disabled={!check?.ok} onClick={doTransfer}
                        icon={<ArrowLeftRight size={14} />}
                      >
                        {toId ? `Перевести в ${slot.teams[toId]?.shortName ?? "клуб"}` : "Выберите клуб"}
                      </Btn>
                    )}
                    <Btn onClick={resetDeal}>Отмена</Btn>
                  </div>

                  <p className="mt-2 flex items-center gap-1.5 text-[10.5px] leading-relaxed text-[#4b5563]">
                    <History size={11} className="shrink-0" />
                    {tab === "loan"
                      ? "Проверки: трансферное окно, минимум 11 игроков у владельца, бюджет клуба аренды. По окончании срока игрок автоматически вернётся домой."
                      : "Проверки: минимум 11 игроков у прежнего клуба, бюджет покупателя, трансферное окно. Составы и тактики обеих команд обновятся автоматически."}
                  </p>
                </>
              )}
            </Panel>
          </div>

          {/* ── Активные аренды ── */}
          {tab === "loan" && (
            <Panel className="mt-2">
              <PanelHead
                title={<span className="flex items-center gap-1.5"><CalendarClock size={12} /> Активные аренды</span>}
                right={<span className="text-[10.5px] text-[#6b7280]">{loans.length || "нет"}</span>}
              />
              {!loans.length ? (
                <p className="py-6 text-center text-[12px] leading-relaxed text-[#6b7280]">
                  Активных аренд нет.<br />
                  Оформите первую: найдите игрока, выберите клуб, срок и сумму аренды.
                </p>
              ) : (
                <div className="max-h-[300px] overflow-y-auto">
                  {loans.map((ln) => {
                    const parent = slot.teams[ln.parentId];
                    const host = slot.teams[ln.hostId];
                    const live = host?.players.find((p) => p.id === ln.playerId);
                    return (
                      <div key={ln.id} className="flex flex-wrap items-center gap-2 border-b border-[#232b36] py-1.5 text-[12px] last:border-0">
                        {live && <PosBadge pos={live.position} />}
                        <span className="min-w-0 w-36 truncate font-medium">{ln.playerName}</span>
                        {live && (
                          <span className="rounded bg-[#4ade80]/15 px-1 font-mono text-[10.5px] font-bold text-[#4ade80]">{live.overall}</span>
                        )}
                        <span className="flex min-w-0 flex-1 items-center gap-1.5 text-[11px] text-[#9ca3af]">
                          {parent && <Crest name={parent.name} color={parent.color} size={13} />}
                          <span className="truncate">{parent?.shortName ?? "?"}</span>
                          <ArrowLeftRight size={11} className="shrink-0 text-[#6b7280]" />
                          {host && <Crest name={host.name} color={host.color} size={13} />}
                          <span className="truncate">{host?.shortName ?? "?"}</span>
                        </span>
                        <span className="rounded bg-[#a78bfa]/15 px-1.5 py-0.5 text-[9.5px] font-bold text-[#a78bfa]">
                          {LOAN_DURATION_LABELS[ln.months]}
                        </span>
                        <span className="w-28 text-[10.5px] text-[#9ca3af]">{loanUntilLabel(ln, slot.seasonNumber)}</span>
                        <span className="w-14 text-right font-mono text-[10.5px] text-[#4ade80]">
                          {ln.fee ? `£${ln.fee}M` : "—"}
                        </span>
                        <Btn sm onClick={() => recall(ln.id)} icon={<RotateCcw size={11} />} title="Досрочно вернуть игрока в клуб-владелец">
                          Отозвать
                        </Btn>
                      </div>
                    );
                  })}
                </div>
              )}
            </Panel>
          )}
        </>
      )}

      {flash && (
        <div className="fixed bottom-16 left-1/2 z-50 -translate-x-1/2 rounded-md border border-[#4ade80]/40 bg-[#1e2530] px-3 py-1.5 text-[12.5px] shadow-xl md:bottom-5">
          {flash}
        </div>
      )}
    </div>
  );
}
