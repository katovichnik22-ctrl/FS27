// ─── Ручная установка счёта матча ───────────────────────────────────────────
import { useState } from "react";
import { Wand2, X, AlertTriangle } from "lucide-react";
import type { Fixture, Slot } from "../types";
import { COMP_NAME, fmtDay, setFixtureScore, stageLabel } from "../engine/season";
import { Btn, Crest, Input } from "./bits";
import { cn } from "../utils/cn";

const QUICK: [number, number][] = [[1, 0], [2, 0], [2, 1], [1, 1], [0, 0], [0, 1], [1, 2], [3, 1]];

export function ScoreEditor({
  slot, fixture, onClose, onApplied,
}: { slot: Slot; fixture: Fixture; onClose: () => void; onApplied: (f: Fixture) => void }) {
  const [h, setH] = useState(fixture.result?.h ?? 0);
  const [a, setA] = useState(fixture.result?.a ?? 0);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const home = slot.teams[fixture.homeId];
  const away = slot.teams[fixture.awayId];

  const apply = () => {
    setBusy(true);
    setErr(null);
    setTimeout(() => {
      const r = setFixtureScore(slot, fixture.id, h, a);
      setBusy(false);
      if (!r.ok) { setErr(r.error ?? "Ошибка"); return; }
      onApplied(fixture);
      onClose();
    }, 20);
  };

  const Stepper = ({ v, set, color }: { v: number; set: (n: number) => void; color: string }) => (
    <div className="flex flex-col items-center gap-1">
      <button onClick={() => set(Math.min(20, v + 1))}
        className="h-6 w-10 rounded bg-[#232b36] text-[13px] leading-none hover:bg-[#2f3847]">▲</button>
      <Input type="number" min={0} max={20} value={v}
        onChange={(e) => set(Math.max(0, Math.min(20, Number(e.target.value) || 0)))}
        className="w-14 text-center font-mono text-xl font-black" style={{ color }} />
      <button onClick={() => set(Math.max(0, v - 1))}
        className="h-6 w-10 rounded bg-[#232b36] text-[13px] leading-none hover:bg-[#2f3847]">▼</button>
    </div>
  );

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/75 p-3" onClick={onClose}>
      <div className="fs-fade w-full max-w-lg rounded-lg border border-[#2a3140] bg-[#1e2530] shadow-2xl"
        onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 border-b border-[#2a3140] px-3 py-2">
          <Wand2 size={14} className="text-[#fbbf24]" />
          <h3 className="text-[13px] font-bold">Задать счёт матча</h3>
          <button onClick={onClose} className="ml-auto rounded px-2 py-0.5 text-[#9ca3af] hover:bg-[#232b36]">
            <X size={14} />
          </button>
        </div>

        <div className="p-3">
          <div className="mb-1 text-center text-[10.5px] text-[#6b7280]">
            {COMP_NAME[fixture.comp]} · {stageLabel(fixture)} · {fmtDay(fixture.date)}
          </div>

          <div className="flex items-center justify-center gap-3 py-2">
            <div className="flex min-w-0 flex-1 flex-col items-center gap-1">
              <Crest name={home.name} color={home.color} size={26} />
              <span className="truncate text-center text-[12px] font-semibold">{home.name}</span>
            </div>
            <Stepper v={h} set={setH} color="#4ade80" />
            <span className="pb-6 text-xl font-black text-[#4b5563]">:</span>
            <Stepper v={a} set={setA} color="#60a5fa" />
            <div className="flex min-w-0 flex-1 flex-col items-center gap-1">
              <Crest name={away.name} color={away.color} size={26} />
              <span className="truncate text-center text-[12px] font-semibold">{away.name}</span>
            </div>
          </div>

          <div className="mt-2 flex flex-wrap justify-center gap-1">
            {QUICK.map(([qh, qa]) => (
              <button key={`${qh}-${qa}`} onClick={() => { setH(qh); setA(qa); }}
                className={cn("rounded border px-2 py-0.5 font-mono text-[11px] transition-colors",
                  h === qh && a === qa
                    ? "border-[#3b82f6] bg-[#3b82f6]/15 text-[#60a5fa]"
                    : "border-[#2f3847] text-[#9ca3af] hover:border-[#3b82f6]")}>
                {qh}:{qa}
              </button>
            ))}
            <button onClick={() => { setH(a); setA(h); }}
              className="rounded border border-[#2f3847] px-2 py-0.5 text-[11px] text-[#9ca3af] hover:border-[#fbbf24] hover:text-[#fbbf24]">
              ⇄ зеркально
            </button>
          </div>

          <div className="mt-3 rounded border border-[#2a3140] bg-[#182029] p-2 text-[11px] leading-relaxed text-[#9ca3af]">
            Матч будет <b className="text-[#e5e7eb]">пересимулирован под этот счёт</b>: движок подберёт авторов голов,
            ассистентов, статистику, xG и рейтинги игроков. Таблицы и бомбардиры пересчитаются автоматически.
            {fixture.played && <> Прежний результат и его вклад в статистику будут корректно отменены.</>}
          </div>

          {err && (
            <p className="mt-2 flex items-center gap-1.5 text-[11.5px] text-[#f87171]">
              <AlertTriangle size={12} /> {err}
            </p>
          )}

          <div className="mt-3 flex justify-end gap-2">
            <Btn onClick={onClose}>Отмена</Btn>
            <Btn variant="primary" onClick={apply} disabled={busy} icon={<Wand2 size={13} />}>
              {busy ? "Пересимуляция…" : `Применить ${h}:${a}`}
            </Btn>
          </div>
        </div>
      </div>
    </div>
  );
}
