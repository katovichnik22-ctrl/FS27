// ─── Ручная настройка участников еврокубков ─────────────────────────────────
import { useMemo, useState } from "react";
import { RotateCcw, Check, X, AlertTriangle, Trophy } from "lucide-react";
import type { LeagueId, Team } from "../types";
import { autoEuroTeams, LEAGUE_CFG } from "../engine/season";
import { Btn, Crest, Panel, PanelHead, Select, Tabs } from "./bits";
void PanelHead;
import { cn } from "../utils/cn";

interface Props {
  teams: Record<string, Team>;
  leagues: LeagueId[];
  /** порядок клубов по итогам прошлого сезона (для автоподбора) */
  standings?: Record<string, string[]>;
  initialUcl?: string[];
  initialUel?: string[];
  initialUecl?: string[];
  seasonLabel: string;
  autoDefault?: boolean;
  dropToUelDefault?: boolean;
  promotionDefault?: boolean;
  showPromotion?: boolean;
  confirmLabel: string;
  onConfirm: (r: { ucl: string[]; uel: string[]; uecl: string[]; auto: boolean; dropToUel: boolean; autoPromotion: boolean }) => void;
  onCancel: () => void;
}

export function EuroSetup({
  teams, leagues, standings, initialUcl, initialUel, initialUecl, seasonLabel,
  autoDefault = true, dropToUelDefault = true, promotionDefault = true, showPromotion = true,
  confirmLabel, onConfirm, onCancel,
}: Props) {
  const auto = useMemo(() => autoEuroTeams(teams, leagues, standings), [teams, leagues, standings]);
  const [useAuto, setUseAuto] = useState(autoDefault);
  const [dropToUel, setDropToUel] = useState(dropToUelDefault);
  const [autoPromotion, setAutoPromotion] = useState(promotionDefault);
  const [ucl, setUcl] = useState<string[]>(() => pad(initialUcl?.length === 36 ? initialUcl : auto.ucl));
  const [uel, setUel] = useState<string[]>(() =>
    pad(initialUel?.length === 36 ? initialUel : auto.uel.filter((id) => !auto.ucl.includes(id)))
  );
  const [uecl, setUecl] = useState<string[]>(() =>
    pad(initialUecl?.length === 36
      ? initialUecl
      : auto.uecl.filter((id) => !auto.ucl.includes(id) && !auto.uel.includes(id)))
  );
  const [tab, setTab] = useState<"UCL" | "UEL" | "UECL">("UCL");

  function pad(list: string[]): string[] {
    const out = [...list].slice(0, 36);
    while (out.length < 36) out.push("");
    return out;
  }

  const allClubs = useMemo(
    () => Object.values(teams)
      .filter((t) => t.league || t.tier === "EU")
      .sort((a, b) => (a.league ? 0 : 1) - (b.league ? 0 : 1) || b.reputation - a.reputation),
    [teams]
  );

  const list = tab === "UCL" ? ucl : tab === "UEL" ? uel : uecl;
  const setList = tab === "UCL" ? setUcl : tab === "UEL" ? setUel : setUecl;
  const other = tab === "UCL" ? [...uel, ...uecl] : tab === "UEL" ? [...ucl, ...uecl] : [...ucl, ...uel];

  const dupes = useMemo(() => {
    const seen = new Set<string>();
    const d = new Set<string>();
    for (const id of list) {
      if (!id) continue;
      if (seen.has(id)) d.add(id);
      seen.add(id);
    }
    return d;
  }, [list]);

  const crossDupes = useMemo(() => new Set(list.filter((id) => id && other.includes(id))), [list, other]);
  const empty = list.filter((id) => !id).length;
  const valid = !dupes.size && !crossDupes.size && !empty
    && ucl.every(Boolean) && uel.every(Boolean) && uecl.every(Boolean)
    && new Set(ucl).size === 36 && new Set(uel).size === 36 && new Set(uecl).size === 36;

  const resetAuto = () => {
    setUcl(pad(auto.ucl));
    setUel(pad(auto.uel.filter((id) => !auto.ucl.includes(id))));
    setUecl(pad(auto.uecl.filter((id) => !auto.ucl.includes(id) && !auto.uel.includes(id))));
  };

  const autoSlots = useMemo(() => {
    // сколько слотов заполнены автоматически по итогам лиг
    let n = 0;
    for (const lid of leagues) {
      const c = LEAGUE_CFG[lid];
      n += tab === "UCL" ? c.ucl : tab === "UEL" ? c.uel : c.uecl;
    }
    return n;
  }, [leagues, tab]);

  return (
    <div className="mx-auto max-w-5xl p-3">
      <div className="mb-3 text-center">
        <div className="flex items-center justify-center gap-2 text-[11px] uppercase tracking-widest text-[#9ca3af]">
          <Trophy size={13} className="text-[#fbbf24]" /> Настройка еврокубков
        </div>
        <h1 className="text-xl font-black">{seasonLabel}</h1>
      </div>

      <Panel className="mb-2">
        <div className="flex flex-wrap items-center gap-4">
          <label className="flex cursor-pointer items-center gap-2 text-[12.5px]">
            <input type="checkbox" checked={useAuto} onChange={(e) => { setUseAuto(e.target.checked); if (e.target.checked) resetAuto(); }}
              className="h-4 w-4 accent-[#4ade80]" />
            Автоматический выбор участников еврокубков
          </label>
          <label className="flex cursor-pointer items-center gap-2 text-[12.5px]">
            <input type="checkbox" checked={dropToUel} onChange={(e) => setDropToUel(e.target.checked)} className="h-4 w-4 accent-[#3b82f6]" />
            Вылетевшие из ЛЧ продолжают в ЛЕ
          </label>
          {showPromotion && (
            <label className="flex cursor-pointer items-center gap-2 text-[12.5px]">
              <input type="checkbox" checked={!autoPromotion} onChange={(e) => setAutoPromotion(!e.target.checked)} className="h-4 w-4 accent-[#fbbf24]" />
              Оставить составы лиг без изменений (без вылетов)
            </label>
          )}
          <span className="ml-auto text-[11px] text-[#6b7280]">
            {useAuto ? "Ручной редактор заблокирован" : `${autoSlots} слотов заполнено автоматически, остальные — вручную`}
          </span>
        </div>
      </Panel>

      <Panel>
        <div className="mb-2 flex flex-wrap items-center gap-2">
          <Tabs value={tab} onChange={setTab} items={[
            { id: "UCL" as const, label: "Лига чемпионов", count: ucl.filter(Boolean).length },
            { id: "UEL" as const, label: "Лига Европы", count: uel.filter(Boolean).length },
            { id: "UECL" as const, label: "Лига конференций", count: uecl.filter(Boolean).length },
          ]} />
          <Btn className="ml-auto" onClick={resetAuto} icon={<RotateCcw size={13} />} disabled={useAuto}>Сбросить к авто</Btn>
        </div>

        {(!!dupes.size || !!crossDupes.size || !!empty) && (
          <div className="mb-2 flex items-center gap-1.5 rounded-md border border-[#ef4444]/40 bg-[#ef4444]/10 px-2 py-1 text-[11.5px] text-[#f87171]">
            <AlertTriangle size={12} />
            {!!empty && `Не заполнено слотов: ${empty}. `}
            {!!dupes.size && `Повторы внутри турнира: ${dupes.size}. `}
            {!!crossDupes.size && `Клуб уже в другом турнире: ${crossDupes.size}.`}
          </div>
        )}

        <div className="grid max-h-[54vh] gap-1 overflow-y-auto pr-1 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((id, i) => {
            const t = id ? teams[id] : null;
            const bad = (id && (dupes.has(id) || crossDupes.has(id))) || !id;
            const isAutoSlot = i < autoSlots;
            return (
              <div key={i} className={cn(
                "flex items-center gap-1.5 rounded-md border px-1.5 py-1",
                bad ? "border-[#ef4444]/50 bg-[#ef4444]/5" : "border-[#2a3140] bg-[#182029]"
              )}>
                <span className={cn("w-5 shrink-0 text-center font-mono text-[10px]", isAutoSlot ? "text-[#4ade80]" : "text-[#6b7280]")}>
                  {i + 1}
                </span>
                {t && <Crest name={t.name} color={t.color} size={14} />}
                <Select
                  value={id}
                  disabled={useAuto}
                  onChange={(e) => { const v = e.target.value; setList(list.map((x, k) => (k === i ? v : x))); }}
                  className="min-w-0 flex-1 truncate border-0 bg-transparent px-1 py-0.5 text-[11.5px] disabled:opacity-70"
                >
                  <option value="">— пусто —</option>
                  {allClubs.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.league ? `· ${LEAGUE_CFG[c.league].short}` : `· ${c.country}`}
                    </option>
                  ))}
                </Select>
              </div>
            );
          })}
        </div>
        <p className="mt-2 text-[10.5px] text-[#6b7280]">
          Зелёные номера — слоты, заполненные по итогам чемпионатов ({leagues.map((l) => LEAGUE_CFG[l].short).join(", ")}).
          Остальные добраны из клубов мирового пула — их можно менять вручную.
        </p>
      </Panel>

      <div className="mt-3 flex flex-wrap justify-center gap-2">
        <Btn variant="primary" icon={<Check size={14} />} disabled={!valid}
          onClick={() => onConfirm({ ucl, uel, uecl, auto: useAuto, dropToUel, autoPromotion })}>
          {confirmLabel}
        </Btn>
        <Btn variant="outline" icon={<X size={14} />} onClick={onCancel}>Отмена</Btn>
      </div>
      {!valid && <p className="mt-1.5 text-center text-[11px] text-[#f87171]">Заполните все 36 слотов в каждом из трёх турниров без повторов</p>}
    </div>
  );
}
