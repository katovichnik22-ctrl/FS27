// ─── Главное меню, настройки, о проекте ──────────────────────────────────────
import { useState } from "react";
import { cn } from "../utils/cn";
import {
  Zap, CalendarPlus, FolderOpen, Settings, Info, ArrowLeft,
  Shield, Database, Dices, Trash2, Cpu, Smartphone,
} from "lucide-react";
import { Panel, Btn, PanelHead, Select } from "./bits";
import { MAIN_DB } from "../data/db";
import { loadSettings, saveSettings, setMobileMode, listSlots, deleteSlot, type AppSettings } from "../engine/storage";

export type MenuTarget = "quick" | "newSeason" | "saves" | "settings" | "about";

const MENU_ITEMS: { id: MenuTarget; title: string; desc: string; icon: typeof Zap; accent?: boolean }[] = [
  { id: "quick", title: "Быстрый матч", desc: "Две команды, поминутная симуляция. Не влияет на базу и слоты.", icon: Zap, accent: true },
  { id: "newSeason", title: "Создать сезон", desc: "Premier League, La Liga, Ligue 1, еврокубки и 4 кубка.", icon: CalendarPlus },
  { id: "saves", title: "Загрузить сезон", desc: "Слоты сохранений: продолжить, экспорт, импорт, удаление.", icon: FolderOpen },
  { id: "settings", title: "Настройки", desc: "Скорость трансляции и параметры приложения.", icon: Settings },
  { id: "about", title: "О симуляторе", desc: "Движок, данные и модель рейтингов.", icon: Info },
];

export function MainMenu({ slots, onNavigate }: { slots: number; onNavigate: (t: MenuTarget) => void }) {
  const [mobile, setMobile] = useState(loadSettings().mobileMode);
  const playerCount = Object.values(MAIN_DB).reduce((a, t) => a + t.players.length, 0);
  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col justify-center px-4 py-10">
      <div className="mb-10 text-center">
        <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-[#2a3140] bg-[#1e2530] px-4 py-1.5 text-xs text-[#9ca3af]">
          <span className="h-1.5 w-1.5 rounded-full bg-[#4ade80]" />
          Сезон 2026/27 · PL · La Liga · Ligue 1
        </div>
        <h1 className="text-5xl font-black tracking-tight text-white sm:text-7xl">
          FS<span className="text-[#4ade80]">26</span>
        </h1>
        <p className="mt-2 text-sm text-[#9ca3af] sm:text-base">
          Симулятор футбола: три лиги, еврокубки и кубки — целиком под вашим управлением
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {MENU_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`group rounded-2xl border p-5 text-left transition-all duration-200 hover:-translate-y-0.5 ${
              item.accent
                ? "border-[#4ade80]/40 bg-[#4ade80]/10 hover:border-[#4ade80] sm:col-span-2"
                : "border-[#2a3140] bg-[#1e2530] hover:border-[#2f3847] hover:bg-[#282828]"
            }`}
          >
            <div className="flex items-center gap-3">
              <span className={`rounded-xl p-2.5 transition-colors ${item.accent ? "bg-[#4ade80] text-[#06281a]" : "bg-[#0f1419] text-[#4ade80] group-hover:bg-[#4ade80] group-hover:text-[#06281a]"}`}>
                <item.icon size={20} />
              </span>
              <div className="min-w-0">
                <div className="font-semibold text-white">{item.title}</div>
                <div className="truncate text-xs text-[#9ca3af]">{item.desc}</div>
              </div>
              {item.id === "saves" && slots > 0 && (
                <span className="ml-auto rounded-full bg-[#4ade80]/15 px-2.5 py-1 font-mono text-xs font-bold text-[#4ade80]">{slots}</span>
              )}
            </div>
          </button>
        ))}
      </div>

      <button
        onClick={() => { const next = setMobileMode(!mobile); setMobile(next.mobileMode); }}
        className={cn(
          "mt-3 flex w-full items-center gap-3 rounded-2xl border p-4 text-left transition-all duration-200 hover:-translate-y-0.5",
          mobile
            ? "border-[#4ade80]/60 bg-[#4ade80]/10"
            : "border-[#2a3140] bg-[#1e2530] hover:border-[#3b82f6]"
        )}
      >
        <span className={cn("rounded-xl p-2.5", mobile ? "bg-[#4ade80] text-[#06281a]" : "bg-[#0f1419] text-[#3b82f6]")}>
          <Smartphone size={20} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block font-semibold text-white">Для телефона</span>
          <span className="block text-xs text-[#9ca3af]">
            {mobile
              ? "Включено: крупные кнопки, нижняя навигация, компактные таблицы"
              : "Адаптировать интерфейс под смартфон: большие тапы и упрощённые экраны"}
          </span>
        </span>
        <span className={cn(
          "relative h-6 w-11 shrink-0 rounded-full transition-colors",
          mobile ? "bg-[#4ade80]" : "bg-[#2f3847]"
        )}>
          <span className={cn(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all",
            mobile ? "left-[22px]" : "left-0.5"
          )} />
        </span>
      </button>

      <div className="mt-10 flex flex-wrap items-center justify-center gap-4 text-xs text-[#6b7280]">
        <span className="flex items-center gap-1.5"><Shield size={13} className="text-[#4ade80]" /> 58 клубов 3 лиг</span>
        <span className="flex items-center gap-1.5"><Database size={13} className="text-[#4ade80]" /> {playerCount}+ игроков</span>
        <span className="flex items-center gap-1.5"><Dices size={13} className="text-[#4ade80]" /> seed-рандом</span>
      </div>
    </div>
  );
}

function BackBtn({ onClick }: { onClick: () => void }) {
  return <Btn onClick={onClick} icon={<ArrowLeft size={15} />}>Назад</Btn>;
}

export function SettingsScreen({ onBack }: { onBack: () => void }) {
  const [s, setS] = useState<AppSettings>(loadSettings());
  const update = (patch: Partial<AppSettings>) => {
    const next = { ...s, ...patch };
    setS(next);
    saveSettings(next);
  };
  const [confirmWipe, setConfirmWipe] = useState(false);
  return (
    <div className="mx-auto w-full max-w-2xl px-4 py-8">
      <BackBtn onClick={onBack} />
      <div className="mt-4">
        <Panel>
          <PanelHead title="Настройки" />
          <div className="space-y-4">
            <div>
              <label className="mb-1.5 block text-xs text-[#9ca3af]">Скорость трансляции по умолчанию</label>
              <Select value={s.defaultSpeed} onChange={(e) => update({ defaultSpeed: Number(e.target.value) })}>
                <option value={150}>Спокойная (x1)</option>
                <option value={60}>Быстрая (x4)</option>
                <option value={18}>Очень быстрая (x16)</option>
              </Select>
            </div>
            <label className="flex cursor-pointer items-center justify-between rounded-xl border border-[#2a3140] px-4 py-3 text-sm">
              <span>
                Мобильный режим
                <span className="block text-xs text-[#9ca3af]">крупные кнопки, нижняя навигация, компактные таблицы</span>
              </span>
              <input
                type="checkbox"
                checked={s.mobileMode}
                onChange={(e) => { update({ mobileMode: e.target.checked }); setMobileMode(e.target.checked); }}
                className="h-4 w-4 accent-[#4ade80]"
              />
            </label>
            <label className="flex cursor-pointer items-center justify-between rounded-xl border border-[#2a3140] px-4 py-3 text-sm">
              <span>Мгновенный результат по умолчанию</span>
              <input
                type="checkbox"
                checked={s.skipBroadcast}
                onChange={(e) => update({ skipBroadcast: e.target.checked })}
                className="h-4 w-4 accent-[#4ade80]"
              />
            </label>
            <div className="rounded-xl border border-[#2a3140] bg-[#182029] p-4">
              <div className="mb-3 text-xs font-semibold uppercase tracking-widest text-[#4ade80]">
                Подпись для копирования
              </div>
              <p className="mb-3 text-[11px] leading-relaxed text-[#9ca3af]">
                Эти значения подставляются в тексты кнопок «Скопировать» на экране матча,
                в табло тура и в таблицу чемпионата.
              </p>
              <div className="space-y-3">
                <div>
                  <label className="mb-1.5 block text-xs text-[#9ca3af]">Название лиги</label>
                  <input
                    type="text"
                    value={s.leagueName}
                    onChange={(e) => update({ leagueName: e.target.value })}
                    placeholder="Premier League"
                    className="w-full rounded-md border border-[#2f3847] bg-[#0f1419] px-3 py-2 text-sm text-[#e5e7eb] outline-none focus:border-[#4ade80]"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-xs text-[#9ca3af]">Хэштег лиги</label>
                  <input
                    type="text"
                    value={s.leagueHashtag}
                    onChange={(e) => update({ leagueHashtag: e.target.value })}
                    placeholder="#PremierLeague"
                    className="w-full rounded-md border border-[#2f3847] bg-[#0f1419] px-3 py-2 text-sm text-[#e5e7eb] outline-none focus:border-[#4ade80]"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-xs text-[#9ca3af]">Номер текущего тура</label>
                  <input
                    type="number"
                    min={1}
                    value={s.matchdayNumber}
                    onChange={(e) => update({ matchdayNumber: Math.max(1, Number(e.target.value) || 1) })}
                    className="w-24 rounded-md border border-[#2f3847] bg-[#0f1419] px-3 py-2 text-sm text-[#e5e7eb] outline-none focus:border-[#4ade80]"
                  />
                </div>
              </div>
            </div>
            <div className="rounded-xl border border-[#331010] bg-[#331010]/10 p-4">
              <div className="mb-2 text-xs font-semibold uppercase tracking-widest text-[#f87171]">Опасная зона</div>
              {!confirmWipe ? (
                <Btn variant="danger" icon={<Trash2 size={15} />} onClick={() => setConfirmWipe(true)}>
                  Удалить все слоты сохранений
                </Btn>
              ) : (
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm text-[#f87171]">Точно удалить {listSlots().length} слот(ов)?</span>
                  <Btn variant="danger" onClick={() => { for (const m of listSlots()) deleteSlot(m.slotId); setConfirmWipe(false); onBack(); }}>
                    Да, удалить
                  </Btn>
                  <Btn onClick={() => setConfirmWipe(false)}>Отмена</Btn>
                </div>
              )}
            </div>
          </div>
        </Panel>
      </div>
    </div>
  );
}

export function AboutScreen({ onBack }: { onBack: () => void }) {
  const teams = Object.keys(MAIN_DB).length;
  const players = Object.values(MAIN_DB).reduce((a, t) => a + t.players.length, 0);
  return (
    <div className="mx-auto w-full max-w-2xl px-4 py-8">
      <BackBtn onClick={onBack} />
      <div className="mt-4 space-y-4">
        <Panel>
          <PanelHead title="О симуляторе" />
          <div className="space-y-3 text-sm leading-relaxed text-[#cbd5e1]">
            <p>
              <b className="text-white">FS26</b> — браузерный симулятор футбольных матчей в духе классических
              match-simulator'ов. Матч разыгрывается поминутно: удары, xG, сейвы, штанги, фолы,
              карточки, травмы и замены от усталости.
            </p>
            <p>
              Вы не тренер одного клуба, а <b className="text-[#4ade80]">оператор всей лиги</b>: настраиваете
              составы, схемы и стиль любой команды, проводите трансферы между любыми клубами,
              правите календарь и симулируете дни, туры или весь сезон.
            </p>
          </div>
        </Panel>
        <Panel>
          <PanelHead title="Движок" />
          <ul className="space-y-2 text-sm text-[#cbd5e1]">
            <li className="flex gap-2"><Cpu size={16} className="mt-0.5 shrink-0 text-[#4ade80]" /> Поминутная модель «удар → xG → гол», конверсия равна качеству момента</li>
            <li className="flex gap-2"><Dices size={16} className="mt-0.5 shrink-0 text-[#4ade80]" /> seedable PRNG mulberry32 — воспроизводимость и «пенальти-реплеи»</li>
            <li className="flex gap-2"><Shield size={16} className="mt-0.5 shrink-0 text-[#4ade80]" /> Сила команд: вратарь 15% / защита 30% / полузащита 30% / атака 25%, форма и фитнес</li>
            <li className="flex gap-2"><Database size={16} className="mt-0.5 shrink-0 text-[#4ade80]" /> {teams} клубов АПЛ, {players} игроков + клубы Европы и низших лиг Англии</li>
            <li className="flex gap-2"><Shield size={16} className="mt-0.5 shrink-0 text-[#4ade80]" /> Схемы (4-4-2 … 3-4-3) и стили (атака/баланс/оборона) влияют на силу команд в симуляции</li>
          </ul>
        </Panel>
        <p className="text-center text-xs text-[#4b5563]">Локальное приложение · без внешних API · данные только в вашем браузере</p>
      </div>
    </div>
  );
}
