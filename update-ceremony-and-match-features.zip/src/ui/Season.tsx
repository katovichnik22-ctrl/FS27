// ─── Экран сезона: сайдбар + шапка + разделы ───────────────────────────────
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  LayoutDashboard, CalendarDays, Table2, Users, ArrowLeftRight, CalendarClock,
  ClipboardList, BarChart3, Medal, Play, Trophy, Save, Download,
  Zap, LayoutGrid, UserCog, Home, Menu as MenuIcon,
  TrendingUp, TrendingDown, Award,
} from "lucide-react";
import type { Fixture, LeagueId, MatchResult, PromotionChange, SeasonReport, Slot } from "../types";
import type { CupComp } from "../engine/season";
import { Btn, Crest, Panel, PanelHead, Tabs } from "./bits";
import { cn } from "../utils/cn";
import {
  advanceDay, advanceToEndOfSeason, applyResult,
  COMP_NAME, fmtDay, LEAGUE_CFG, playoffsSettled, progressPromotionPlayoffs,
  settlePromotionPlayoffs, simulateFixture,
} from "../engine/season";
import { finishSeason } from "../engine/ratings";
import { buildCeremony, type SeasonCeremony } from "../engine/awards";
import { exportSlot, loadSlot, saveSlot, startNextSeason } from "../engine/storage";
import { MatchView } from "./MatchView";
import {
  CupView, EuroView, LeagueTable, MatchesView, OverviewView, StatsView, slotCups, slotLeagues,
} from "./SeasonPanels";
import { ClubCard, ClubsView, TacticsView } from "./ClubsView";
import { TransfersView } from "./TransfersView";
import { ScheduleView } from "./ScheduleView";
import { SimPanel } from "./SimPanel";
import { RoundView } from "./RoundView";
import { PlayerEditor } from "./PlayerEditor";
import { ScoreEditor } from "./ScoreEditor";
import { CeremonyView } from "./Ceremony";
import { PlayoffsView } from "./Playoffs";
import { copyText } from "../utils/copy";

type Section = "overview" | "sim" | "round" | "matches" | "tables" | "clubs" | "transfers" | "editor" | "tactics" | "stats" | "cups" | "playoffs" | "schedule";

const NAV: { id: Section; label: string; icon: typeof LayoutDashboard; key: string }[] = [
  { id: "overview", label: "Обзор", icon: LayoutDashboard, key: "1" },
  { id: "sim", label: "Симуляция", icon: Zap, key: "2" },
  { id: "round", label: "Тур", icon: LayoutGrid, key: "3" },
  { id: "matches", label: "Матчи", icon: CalendarDays, key: "4" },
  { id: "tables", label: "Таблицы", icon: Table2, key: "5" },
  { id: "clubs", label: "Клубы", icon: Users, key: "6" },
  { id: "transfers", label: "Трансферы", icon: ArrowLeftRight, key: "7" },
  { id: "editor", label: "Редактор игроков", icon: UserCog, key: "8" },
  { id: "tactics", label: "Тактики", icon: ClipboardList, key: "9" },
  { id: "stats", label: "Статистика", icon: BarChart3, key: "0" },
  { id: "cups", label: "Кубки", icon: Medal, key: "-" },
  { id: "schedule", label: "Календарь", icon: CalendarClock, key: "=" },
];

export function SeasonScreen({ slotId, onExit }: { slotId: string; onExit: () => void }) {
  const slotRef = useRef<Slot | null>(loadSlot(slotId));
  const [, force] = useState(0);
  const rerender = useCallback(() => force((n) => n + 1), []);
  const [sec, setSec] = useState<Section>("overview");
  const [live, setLive] = useState<{ fixture: Fixture; result: MatchResult } | null>(null);
  const [review, setReview] = useState<{ fixture: Fixture; result: MatchResult } | null>(null);
  const [report, setReport] = useState<SeasonReport | null>(null);
  const [ceremony, setCeremony] = useState<SeasonCeremony | null>(null);
  const [interlude, setInterlude] = useState<{ season: number; changes: PromotionChange[] } | null>(null);
  const [editing, setEditing] = useState<Fixture | null>(null);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [tableTab, setTableTab] = useState<LeagueId | "UCL" | "UEL" | "UECL">("PL");
  const [cupTab, setCupTab] = useState<CupComp>("FA");
  const [openClub, setOpenClub] = useState<string | null>(null);
  const [simTo, setSimTo] = useState("");
  const [navOpen, setNavOpen] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [exportJson, setExportJson] = useState("");

  const slot = slotRef.current;

  /** Навигация: раздел «Плей-офф» появляется, когда в слоте задействован плей-офф повышения */
  const NAV_ITEMS = useMemo(() => {
    const items = [...NAV];
    if (slot?.season.playoffs?.length)
      items.splice(11, 0, { id: "playoffs" as Section, label: "Плей-офф", icon: Medal, key: "p" });
    return items;
  }, [slot?.season.playoffs?.length]);

  useEffect(() => {
    if (!slot) return;
    if (slot.season.finished && slot.history.length && slot.history[slot.history.length - 1].seasonNumber === slot.seasonNumber)
      setReport(slot.history[slot.history.length - 1]);
    if (!simTo) setSimTo(slot.currentDate);
  }, [slot, simTo]);

  const commit = useCallback(() => {
    if (!slot) return;
    saveSlot(slot);
    rerender();
  }, [slot, rerender]);

  const flash = (m: string) => { setToast(m); setTimeout(() => setToast(null), 2200); };

  const run = useCallback((fn: () => void) => {
    setBusy(true);
    setTimeout(() => { fn(); commit(); setBusy(false); }, 10);
  }, [commit]);

  const simDay = useCallback(() => {
    if (!slot || slot.season.finished) return;
    run(() => { const d = advanceDay(slot); flash(d.fixtures.length ? `Сыграно матчей: ${d.fixtures.length}` : "Матчей не было"); });
  }, [slot, run]);

  /** Отчёт сезона: не пересчитываем повторно, если он уже есть в истории */
  const ensureReport = useCallback((s: Slot): SeasonReport => {
    const last = s.history[s.history.length - 1];
    return last && last.seasonNumber === s.seasonNumber ? last : finishSeason(s);
  }, []);

  /** Церемония наград (Золотой мяч и номинации) — открывается в конце сезона */
  const openCeremony = useCallback(() => {
    if (!slot) return;
    run(() => {
      ensureReport(slot);
      setCeremony(buildCeremony(slot));
    });
  }, [slot, run, ensureReport]);

  /** Итоги сезона: не пересчитываем повторно, если отчёт уже есть в истории */
  const openReport = useCallback(() => {
    if (!slot) return;
    const last = slot.history[slot.history.length - 1];
    if (last && last.seasonNumber === slot.seasonNumber) { setReport(last); return; }
    run(() => setReport(finishSeason(slot)));
  }, [slot, run]);

  /** Доигрывает все матчи плей-офф повышения */
  const simAllPlayoffs = useCallback(() => {
    if (!slot) return;
    run(() => { settlePromotionPlayoffs(slot); flash("Плей-офф доигран"); });
  }, [slot, run]);

  /**
   * Запуск следующего сезона: составы стареют, работают вылеты/повышения
   * (включая плей-офф) и возвраты из аренды, строится новый календарь.
   * Раньше кнопка лишь закрывала экран итогов — сезон не менялся.
   */
  const nextSeason = useCallback(() => {
    if (!slot) return;
    setBusy(true);
    setTimeout(() => {
      // отчёт обязателен: он фиксирует итоговые таблицы для повышений
      const last = slot.history[slot.history.length - 1];
      if (!last || last.seasonNumber !== slot.seasonNumber) finishSeason(slot);
      // если пользователь пропустил постсезонный плей-офф, он доиграется автоматически
      const poSkipped = !!slot.season.playoffs?.length && !playoffsSettled(slot);
      const next = startNextSeason(slot);
      slotRef.current = next;
      setReport(null);
      setCeremony(null);
      setSec("overview");
      setOpenClub(null);
      setSimTo(next.currentDate);
      setInterlude({ season: next.seasonNumber, changes: next.lastPromotions ?? [] });
      setBusy(false);
      rerender();
      if (poSkipped) flash("Плей-офф доигран автоматически");
    }, 10);
  }, [slot, rerender]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA") return;
      if (e.key === "Escape") { setReview(null); setNavOpen(false); setEditing(null); return; }
      if (live || review || report || ceremony || editing) return;
      if (e.code === "Space") { e.preventDefault(); simDay(); return; }
      const navItem = NAV_ITEMS.find((n) => n.key === e.key);
      if (navItem) { setSec(navItem.id); setOpenClub(null); }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [simDay, live, review, report, ceremony, editing, NAV_ITEMS]);

  if (!slot) {
    return (
      <div className="mx-auto max-w-lg p-6">
        <Btn onClick={onExit} icon={<Home size={14} />}>В меню</Btn>
        <Panel className="mt-3 text-center text-[12.5px] text-[#9ca3af]">Слот не найден.</Panel>
      </div>
    );
  }

  const seasonOver = slot.season.finished;
  const leagues = slotLeagues(slot);
  const cups = slotCups(slot);

  const watchMatch = (f: Fixture) => {
    if (f.played) { setReview({ fixture: f, result: simulateFixture(slot, f) }); return; }
    setBusy(true);
    setTimeout(() => {
      const res = simulateFixture(slot, f);
      applyResult(slot, f, res);
      saveSlot(slot);
      setLive({ fixture: f, result: res });
      setBusy(false);
    }, 10);
  };

  const closeLive = () => { setLive(null); saveSlot(slot); rerender(); };

  const doExport = () => {
    try {
      const json = exportSlot(slot.slotId);
      if (!json) { flash("Слот не найден"); return; }
      const name = `fs26_season${slot.seasonNumber}_${slot.slotId.slice(-4)}.json`;
      const mb = (json.length / 1024 / 1024).toFixed(1);
      const blob = new Blob([json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = name; a.target = "_self"; a.rel = "noopener";
      document.body.appendChild(a); a.click();
      setTimeout(() => { try { document.body.removeChild(a); } catch { /* */ } URL.revokeObjectURL(url); }, 5000);
      setExportJson(json);
      flash(`Скачивание «${name}» (${mb} МБ)`);
      setTimeout(() => setShowExport(true), 1500);
    } catch (e) { flash(`Ошибка: ${e instanceof Error ? e.message : "неизвестная"}`); setExportJson(""); setShowExport(true); }
  };

  if (live) {
    return (
      <MatchView
        result={live.result} teams={slot.teams} onClose={closeLive} closeLabel="Продолжить сезон"
        fixture={live.fixture} slot={slot}
        standings={<LeagueTable slot={slot} league={(slot.teams[live.fixture.homeId].league ?? "PL") as LeagueId} compact />}
      />
    );
  }
  if (review) {
    return (
      <MatchView result={review.result} teams={slot.teams} instant onClose={() => setReview(null)}
        closeLabel="Закрыть" overlay manual={!!review.fixture.result?.manual} fixture={review.fixture} slot={slot}
        onEditScore={() => { const f = review.fixture; setReview(null); setEditing(f); }} />
    );
  }
  if (ceremony) {
    return (
      <CeremonyView
        slot={slot}
        ceremony={ceremony}
        onContinue={() => {
          setCeremony(null);
          const last = slot.history[slot.history.length - 1];
          if (last && last.seasonNumber === slot.seasonNumber) setReport(last);
        }}
      />
    );
  }
  if (report) {
    return <ReportScreen slot={slot} report={report} busy={busy}
      onNextSeason={nextSeason}
      onAwards={() => { setReport(null); openCeremony(); }}
      onPlayoffs={slot.season.playoffs?.length ? () => { setReport(null); setSec("playoffs"); } : undefined}
      playoffsPending={!playoffsSettled(slot)}
      onExit={() => { saveSlot(slot); onExit(); }} />;
  }
  if (interlude) {
    return <InterludeScreen slot={slot} season={interlude.season} changes={interlude.changes}
      onContinue={() => setInterlude(null)} />;
  }

  const Nav = (
    <nav className="flex flex-col gap-0.5">
      {NAV_ITEMS.map((n) => (
        <button key={n.id} onClick={() => { setSec(n.id); setOpenClub(null); setNavOpen(false); }}
          className={cn("group relative flex items-center gap-2.5 rounded-md px-2.5 py-[7px] text-left text-[12.5px] transition-colors",
            sec === n.id ? "bg-[#3b82f6]/12 font-semibold text-[#60a5fa]" : "text-[#9ca3af] hover:bg-[#232b36] hover:text-[#e5e7eb]")}
          title={`${n.label} (${n.key})`}>
          {sec === n.id && <span className="absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r bg-[#3b82f6]" />}
          <n.icon size={15} className="shrink-0" />
          <span className="hidden truncate lg:inline">{n.label}</span>
          {n.id === "playoffs" && !playoffsSettled(slot) && (
            <span className="ml-auto hidden h-1.5 w-1.5 rounded-full bg-[#fbbf24] lg:inline-block" />
          )}
        </button>
      ))}
    </nav>
  );

  return (
    <div className="min-h-dvh bg-[#0f1419] text-[#e5e7eb] antialiased">
      {/* Шапка */}
      <header className="sticky top-0 z-30 border-b border-[#2a3140] bg-[#1a1f2e]/95 backdrop-blur">
        <div className="flex flex-wrap items-center gap-2 px-2.5 py-1.5">
          <button className="rounded p-1 text-[#9ca3af] hover:bg-[#232b36] md:hidden" onClick={() => setNavOpen((v) => !v)}><MenuIcon size={17} /></button>
          <button onClick={() => { saveSlot(slot); onExit(); }} className="flex items-center gap-1.5 text-[14px] font-black tracking-tight"><span>⚽</span><span>FS<span className="text-[#4ade80]">26</span></span></button>
          <div className="mx-auto flex items-center gap-2 rounded-md border border-[#2a3140] bg-[#0f1419] px-2.5 py-1">
            <CalendarDays size={13} className="text-[#3b82f6]" />
            <span className="font-mono text-[12.5px]">{fmtDay(slot.currentDate)}</span>
          </div>
          {seasonOver ? (
            <>
              <Btn variant="warn" onClick={openCeremony} icon={<Award size={13} />} disabled={busy}>Церемония ЗМ</Btn>
              <Btn variant="blue" onClick={openReport} icon={<Trophy size={13} />} disabled={busy}>Итоги</Btn>
              {!!slot.season.playoffs?.length && (
                <Btn variant={playoffsSettled(slot) ? "ghost" : "danger"} onClick={() => setSec("playoffs")} icon={<Medal size={13} />} disabled={busy}>
                  Плей-офф{playoffsSettled(slot) ? "" : ` (${slot.season.fixtures.filter((f) => f.comp === "PPO" && !f.played).length})`}
                </Btn>
              )}
              <Btn variant="primary" onClick={nextSeason} icon={<Play size={13} />} disabled={busy}>Новый сезон</Btn>
            </>
          ) : (
            <>
              <Btn variant="primary" onClick={simDay} disabled={busy} icon={<Play size={12} />}>День</Btn>
              <Btn variant="danger" disabled={busy} icon={<Trophy size={12} />} onClick={() => run(() => { advanceToEndOfSeason(slot); flash("Сезон сыгран"); })}>До конца</Btn>
            </>
          )}
        </div>
      </header>

      {/* Панель быстрых действий */}
      <div className="sticky top-[42px] z-[19] flex flex-wrap items-center gap-1.5 border-b border-[#2a3140] bg-[#1a1f2e] px-2.5 py-1.5">
        <Btn sm onClick={() => { saveSlot(slot); flash("Сохранено"); }} icon={<Save size={12} />}>Сохранить</Btn>
        <Btn sm variant="blue" onClick={doExport} icon={<Download size={12} />}>📥 Скачать сезон</Btn>
      </div>

      <div className="flex">
        <aside className="fs-sidebar sticky top-[76px] z-20 hidden h-[calc(100dvh-76px)] w-[52px] shrink-0 border-r border-[#2a3140] bg-[#1a1f2e] p-1.5 md:block lg:w-[200px] lg:p-2">{Nav}</aside>
        {navOpen && (<div className="fixed inset-0 z-40 bg-black/60 lg:hidden" onClick={() => setNavOpen(false)}><div className="w-56 bg-[#1a1f2e] p-2 pt-3" onClick={(e) => e.stopPropagation()}>{Nav}</div></div>)}

        <main className="fs-fade min-w-0 flex-1 p-2 pb-16 md:pb-2">
          {sec === "overview" && <OverviewView slot={slot} onMatch={watchMatch} onClub={(id) => { setSec("clubs"); setOpenClub(id); }} onEditScore={setEditing} />}
          {sec === "sim" && <SimPanel slot={slot} onChanged={commit} onFlash={flash} busy={busy} setBusy={setBusy} />}
          {sec === "round" && <RoundView slot={slot} onMatch={watchMatch} />}
          {sec === "matches" && <MatchesView slot={slot} onMatch={watchMatch} onEditScore={setEditing} />}
          {sec === "playoffs" && (
            <Panel>
              <PlayoffsView slot={slot} busy={busy} onMatch={watchMatch} onEditScore={setEditing} onSimAll={simAllPlayoffs} />
            </Panel>
          )}
          {sec === "tables" && (
            <Panel>
              <Tabs className="mb-2 w-fit" value={tableTab} onChange={setTableTab}
                items={[...leagues.map((l) => ({ id: l, label: LEAGUE_CFG[l].name })), { id: "UCL" as const, label: "UCL" }, { id: "UEL" as const, label: "UEL" }, { id: "UECL" as const, label: "UECL" }]} />
              {tableTab === "UCL" || tableTab === "UEL" || tableTab === "UECL"
                ? <EuroView slot={slot} comp={tableTab} onClub={(id) => { setSec("clubs"); setOpenClub(id); }} />
                : <LeagueTable slot={slot} league={tableTab} onClub={(id) => { setSec("clubs"); setOpenClub(id); }} />}
            </Panel>
          )}
          {sec === "clubs" && (<Panel>{openClub ? <ClubCard slot={slot} teamId={openClub} onBack={() => setOpenClub(null)} onChanged={commit} /> : <ClubsView slot={slot} onOpen={setOpenClub} />}</Panel>)}
          {sec === "transfers" && <Panel><TransfersView slot={slot} onChanged={commit} /></Panel>}
          {sec === "editor" && <PlayerEditor slot={slot} onChanged={commit} />}
          {sec === "tactics" && <Panel><TacticsView slot={slot} onChanged={commit} onOpenClub={(id) => { setSec("clubs"); setOpenClub(id); }} /></Panel>}
          {sec === "stats" && <StatsView slot={slot} />}
          {sec === "cups" && (<Panel>
            <Tabs className="mb-2 w-fit" value={cupTab} onChange={setCupTab} items={cups.map((id) => ({ id, label: COMP_NAME[id] }))} />
            {cups.length > 0 && <CupView slot={slot} comp={cups.includes(cupTab) ? cupTab : cups[0]} onMatch={watchMatch} onEditScore={setEditing} />}
          </Panel>)}
          {sec === "schedule" && <Panel><ScheduleView slot={slot} onChanged={commit} /></Panel>}
        </main>
      </div>

      {/* Модалка экспорта */}
      {showExport && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-4" onClick={() => setShowExport(false)}>
          <div className="fs-fade w-full max-w-md rounded-lg border border-[#2a3140] bg-[#1e2530] p-4 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-2 flex items-center gap-2"><Download size={16} className="text-[#60a5fa]" /><h3 className="text-[14px] font-bold">Файл сезона</h3>
              <button onClick={() => setShowExport(false)} className="ml-auto rounded px-2 py-1 text-[#9ca3af] hover:bg-[#232b36]">✕</button></div>
            <p className="mb-3 text-[12px] leading-relaxed text-[#9ca3af]">Если скачивание не началось — скопируйте данные и отправьте другу.</p>
            <div className="mb-3 rounded-md border border-[#2f3847] bg-[#0f1419] p-3 text-center font-mono text-[12px] text-[#9ca3af]">
              📋 JSON готов ({(exportJson.length / 1024 / 1024).toFixed(1)} МБ)
            </div>
            <div className="flex justify-center gap-2">
              <Btn variant="primary" onClick={async () => { if (exportJson && await copyText(exportJson)) { flash("Скопировано"); setShowExport(false); } }} icon={<Download size={14} />}>Скопировать</Btn>
              <Btn onClick={() => setShowExport(false)}>Закрыть</Btn>
            </div>
          </div>
        </div>
      )}

      {/* Редактор счёта матча (включая плей-офф повышения) */}
      {editing && (
        <ScoreEditor
          slot={slot}
          fixture={editing}
          onClose={() => setEditing(null)}
          onApplied={() => {
            // правка счёта могла поменять победителя финала плей-офф
            progressPromotionPlayoffs(slot);
            saveSlot(slot);
            flash("Счёт применён");
            rerender();
          }}
        />
      )}

      {toast && (<div className="fixed bottom-16 left-1/2 z-50 -translate-x-1/2 rounded-md border border-[#4ade80]/40 bg-[#1e2530] px-3 py-1.5 text-[12px] shadow-xl md:bottom-5">{toast}</div>)}
    </div>
  );
}

// ─── Итоги сезона ────────────────────────────────────────────────────────────
function ReportScreen({ slot, report, onNextSeason, onExit, busy, onAwards, onPlayoffs, playoffsPending }: {
  slot: Slot; report: SeasonReport; onNextSeason: () => void; onExit: () => void; busy?: boolean;
  onAwards?: () => void; onPlayoffs?: () => void; playoffsPending?: boolean;
}) {
  const rLeagues = report.leagues?.length ? report.leagues : [];
  const [tab, setTab] = useState<LeagueId>(rLeagues[0] ?? "PL");
  const cupList = (["UCL", "UEL", "UECL", "FA", "EFL", "CDR", "CDF", "DFB", "CIT", "TCP", "KSC", "TUC", "BCB", "DTC", "GRC", "UKC", "PLC", "SCC", "SWC"] as const).filter((c) => report.champions[c]);
  const awards = report.awardsByLeague?.[tab] ?? report.awards;

  return (
    <div className="mx-auto max-w-4xl p-3">
      <div className="mb-3 text-center">
        <div className="text-[10.5px] uppercase tracking-widest text-[#6b7280]">Итоги сезона {report.seasonNumber}</div>
        <h1 className="text-2xl font-black">2026/27</h1>
      </div>
      <div className="grid gap-2 md:grid-cols-2">
        <Panel><PanelHead title="Чемпионы лиг" icon={<Trophy size={12} />} />
          {rLeagues.map((lid) => (<div key={lid} className="flex items-center justify-between border-b border-[#232b36] py-1 text-[12.5px] last:border-0"><span className="text-[#9ca3a3]">{LEAGUE_CFG[lid].name}</span><span className="flex items-center gap-1.5 font-semibold">{report.champions[LEAGUE_CFG[lid].comp] && <Crest name={slot.teams[report.champions[LEAGUE_CFG[lid].comp]!]?.name ?? "?"} color={slot.teams[report.champions[LEAGUE_CFG[lid].comp]!]?.color ?? "#555"} size={14} />}{slot.teams[report.champions[LEAGUE_CFG[lid].comp]!]?.name ?? "—"}</span></div>))}
        </Panel>
        <Panel><PanelHead title="Кубковые трофеи" icon={<Medal size={12} />} />
          {cupList.map((c) => (<div key={c} className="flex items-center justify-between border-b border-[#232b36] py-1 text-[12.5px] last:border-0"><span className="text-[#9ca3af]">{COMP_NAME[c]}</span><span className="font-semibold">{slot.teams[report.champions[c]!]?.name ?? "—"}</span></div>))}
        </Panel>
        <Panel className="md:col-span-2">
          <Tabs className="mb-2 w-fit" value={tab} onChange={setTab} items={rLeagues.map((l) => ({ id: l, label: LEAGUE_CFG[l].name }))} />
          <div className="grid gap-3 md:grid-cols-2">
            <div><PanelHead title="Личные награды" />
              {([["Golden Boot", awards?.goldenBoot], ["Playmaker", awards?.playmaker], ["Golden Glove", awards?.goldenGlove]] as const).map(([label, a]) => (
                <div key={label} className="flex items-center justify-between border-b border-[#232b36] py-1 text-[12.5px] last:border-0"><span className="text-[#fbbf24]">{label}</span><span className="min-w-0 flex-1 truncate px-2 text-right">{a?.name ?? "—"}</span><b className="font-mono text-[#4ade80]">{a ? `${a.value}` : ""}</b></div>))}
            </div>
            <div><PanelHead title="Итоговая таблица" />
              <div className="max-h-52 overflow-y-auto">{(report.finalTables?.[tab] ?? report.finalTable ?? []).map((r) => (<div key={r.teamId} className="flex items-center gap-1.5 border-b border-[#232b36] py-0.5 text-[12px]"><span className="w-5 font-mono text-[10.5px] text-[#6b7280]">{r.pos}</span><Crest name={slot.teams[r.teamId]?.name ?? "?"} color={slot.teams[r.teamId]?.color ?? "#555"} size={13} /><span className="min-w-0 flex-1 truncate">{slot.teams[r.teamId]?.name}</span><b className="font-mono">{r.pts}</b></div>))}</div>
            </div>
          </div>
        </Panel>
        <Panel><PanelHead title={<span className="text-[#4ade80]">Прогресс рейтингов</span>} icon={<TrendingUp size={12} />} />
          {report.improved.map((c) => (<div key={c.playerId} className="flex items-center gap-1.5 border-b border-[#232b36] py-1 text-[12px]"><Crest name={slot.teams[c.teamId]?.name ?? "?"} color={slot.teams[c.teamId]?.color ?? "#555"} size={13} /><span className="min-w-0 flex-1 truncate">{c.name}</span><span className="font-mono text-[11.5px]">{c.oldOverall}→<b className="text-[#4ade80]">{c.newOverall}</b></span><span className="w-7 text-right font-mono text-[11px] font-bold text-[#4ade80]">+{c.delta}</span></div>))}
        </Panel>
        <Panel><PanelHead title={<span className="text-[#f87171]">Регресс рейтингов</span>} icon={<TrendingDown size={12} />} />
          {report.declined.map((c) => (<div key={c.playerId} className="flex items-center gap-1.5 border-b border-[#232b36] py-1 text-[12px]"><Crest name={slot.teams[c.teamId]?.name ?? "?"} color={slot.teams[c.teamId]?.color ?? "#555"} size={13} /><span className="min-w-0 flex-1 truncate">{c.name}</span><span className="font-mono text-[11.5px]">{c.oldOverall}→<b className="text-[#f87171]">{c.newOverall}</b></span><span className="w-7 text-right font-mono text-[11px] font-bold text-[#f87171]">{c.delta}</span></div>))}
        </Panel>
      </div>
      <div className="mt-3 flex flex-wrap justify-center gap-2">
        {onAwards && (
          <Btn variant="warn" onClick={onAwards} icon={<Award size={14} />}>Церемония наград</Btn>
        )}
        {onPlayoffs && (
          <Btn variant={playoffsPending ? "danger" : "ghost"} onClick={onPlayoffs} icon={<Medal size={14} />}>
            Плей-офф повышения{playoffsPending ? "" : " (доигран)"}
          </Btn>
        )}
        <Btn variant="primary" onClick={onNextSeason} disabled={busy} icon={<Play size={14} />}>
          {busy ? "Готовим сезон…" : `Начать сезон ${report.seasonNumber + 1}`}
        </Btn>
        <Btn variant="outline" onClick={onExit} icon={<Save size={14} />}>Сохранить и выйти</Btn>
      </div>
      <p className="mt-2 text-center text-[11px] text-[#6b7280]">
        В межсезонье: игроки стареют, работают вылеты и повышения (включая плей-офф),
        возвращаются арендованные футболисты и строится новый календарь.
      </p>
    </div>
  );
}

// ─── Межсезонье: кто вылетел, кто поднялся, сетка плей-офф ───────────────────
export function InterludeScreen({
  slot, season, changes, onContinue,
}: { slot: Slot; season: number; changes: PromotionChange[]; onContinue: () => void }) {
  const name = (id: string) => slot.teams[id]?.name ?? id;
  const short = (id: string) => slot.teams[id]?.shortName ?? "—";
  const loanReturns = (slot.transfers ?? []).filter((t) => t.kind === "loan_return");
  const lowerName = (c: PromotionChange) =>
    c.lower && LEAGUE_CFG[c.lower as LeagueId] ? LEAGUE_CFG[c.lower as LeagueId].name : "низший дивизион";

  return (
    <div className="mx-auto max-w-3xl p-3">
      <div className="mb-3 text-center">
        <div className="text-[10.5px] uppercase tracking-widest text-[#6b7280]">Межсезонье</div>
        <h1 className="text-2xl font-black">Сезон {season} начинается</h1>
        <p className="mt-1 text-[12px] text-[#9ca3af]">
          Составы обновлены, статистика обнулена, календарь построен заново.
        </p>
      </div>

      <div className="space-y-2">
        {!changes.length && (
          <Panel>
            <p className="py-4 text-center text-[12.5px] leading-relaxed text-[#9ca3af]">
              Составы лиг остались прежними — повышения отключены в настройках слота
              либо для них не хватает клубов низших дивизионов.
            </p>
          </Panel>
        )}

        {changes.map((c) => (
          <Panel key={c.league}>
            <PanelHead
              title={<span className="flex items-center gap-1.5">{LEAGUE_CFG[c.league]?.name ?? c.league} · обмен с «{lowerName(c)}»</span>}
              icon={<TrendingUp size={12} />}
            />
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#f87171]">
                  <TrendingDown size={12} /> Вылетели
                </div>
                {c.relegated.map((r) => (
                  <div key={r.id} className="flex items-center gap-1.5 border-b border-[#232b36] py-1 text-[12.5px] last:border-0">
                    <Crest name={r.name} color={slot.teams[r.id]?.color ?? "#555"} size={14} />
                    <span className="min-w-0 flex-1 truncate">{r.name}</span>
                  </div>
                ))}
                {!c.relegated.length && <p className="py-1 text-[12px] text-[#6b7280]">—</p>}
              </div>
              <div>
                <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#4ade80]">
                  <TrendingUp size={12} /> Поднялись
                </div>
                {c.promoted.map((r) => {
                  const viaPlayoff = c.playoffPromoted?.some((p) => p.id === r.id);
                  return (
                    <div key={r.id} className="flex items-center gap-1.5 border-b border-[#232b36] py-1 text-[12.5px] last:border-0">
                      <Crest name={r.name} color={slot.teams[r.id]?.color ?? "#555"} size={14} />
                      <span className="min-w-0 flex-1 truncate">{r.name}</span>
                      {viaPlayoff && (
                        <span className="shrink-0 rounded bg-[#fbbf24]/15 px-1.5 py-0.5 text-[9px] font-bold text-[#fbbf24]">
                          ПЛЕЙ-ОФФ
                        </span>
                      )}
                    </div>
                  );
                })}
                {!c.promoted.length && <p className="py-1 text-[12px] text-[#6b7280]">—</p>}
              </div>
            </div>

            {c.playoff && (
              <div className="mt-2 rounded-md border border-[#fbbf24]/30 bg-[#fbbf24]/5 p-2">
                <div className="mb-1 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-[#fbbf24]">
                  <Trophy size={12} /> Плей-офф за повышение
                </div>
                {c.playoff.semis.map((s, i) => (
                  <div key={i} className="flex items-center gap-2 py-0.5 text-[12px]">
                    <span className="w-16 shrink-0 text-[10px] text-[#6b7280]">Полуфинал</span>
                    <span className="min-w-0 flex-1 truncate text-right">{name(s.homeId)}</span>
                    <span className="shrink-0 rounded bg-[#0f1419] px-1.5 font-mono text-[11.5px]">{s.score}</span>
                    <span className="min-w-0 flex-1 truncate">{name(s.awayId)}</span>
                  </div>
                ))}
                {c.playoff.final && (
                  <div className="mt-0.5 flex items-center gap-2 border-t border-[#fbbf24]/20 pt-1 text-[12.5px] font-semibold">
                    <span className="w-16 shrink-0 text-[10px] uppercase text-[#fbbf24]">Финал</span>
                    <span className="min-w-0 flex-1 truncate text-right">{short(c.playoff.final.homeId)}</span>
                    <span className="shrink-0 rounded bg-[#0f1419] px-1.5 font-mono text-[12px] text-[#fbbf24]">{c.playoff.final.score}</span>
                    <span className="min-w-0 flex-1 truncate">{short(c.playoff.final.awayId)}</span>
                  </div>
                )}
                <p className="mt-1 text-[11px] text-[#9ca3af]">
                  Путёвку выиграл <b className="text-[#4ade80]">{name(c.playoff.winner)}</b>
                </p>
              </div>
            )}
          </Panel>
        ))}

        {!!loanReturns.length && (
          <Panel>
            <PanelHead title="Вернулись из аренды" icon={<Users size={12} />} />
            <div className="max-h-44 overflow-y-auto">
              {loanReturns.map((t) => (
                <div key={t.id} className="flex items-center gap-2 border-b border-[#232b36] py-1 text-[12px] last:border-0">
                  <span className="min-w-0 flex-1 truncate">{t.playerNames.join(", ")}</span>
                  <span className="flex items-center gap-1.5 text-[11px] text-[#9ca3af]">
                    {t.fromId ? short(t.fromId) : "—"}
                    <ArrowLeftRight size={11} className="text-[#6b7280]" />
                    {short(t.toId)}
                  </span>
                </div>
              ))}
            </div>
          </Panel>
        )}
      </div>

      <div className="mt-3 flex justify-center">
        <Btn variant="primary" onClick={onContinue} icon={<Play size={14} />}>К сезону {season}</Btn>
      </div>
    </div>
  );
}
