// ─── Вкладка «Расписание»: редактор календаря ────────────────────────────────
import { useMemo, useState } from "react";
import { CalendarClock, ChevronUp, ChevronDown, Plus, Trash2, RefreshCw, AlertTriangle, CheckCircle2 } from "lucide-react";
import type { Slot } from "../types";
import {
  addFriendly, COMP_NAME, COMP_SHORT, fmtDay, moveFixture, regenerateLeague, removeFixture,
  shiftMatchday, stageLabel, validateSchedule,
} from "../engine/season";
import { Btn, Panel, PanelHead, Select, Crest } from "./bits";
import { cn } from "../utils/cn";

export function ScheduleView({ slot, onChanged }: { slot: Slot; onChanged: () => void }) {
  const [comp, setComp] = useState<"PL" | "LL" | "FL1" | "ALL">("PL");
  const [flash, setFlash] = useState<string | null>(null);
  const [newHome, setNewHome] = useState("arsenal");
  const [newAway, setNewAway] = useState("chelsea");
  const [newDate, setNewDate] = useState(slot.currentDate);

  const say = (m: string) => { setFlash(m); setTimeout(() => setFlash(null), 2200); onChanged(); };

  const issues = useMemo(() => validateSchedule(slot.season.fixtures, slot.teams), [slot, slot.currentDate, flash]);
  const issueByFixture = useMemo(() => {
    const m = new Map<string, string[]>();
    for (const i of issues) {
      if (!m.has(i.fixtureId)) m.set(i.fixtureId, []);
      m.get(i.fixtureId)!.push(i.text);
    }
    return m;
  }, [issues]);

  const groups = useMemo(() => {
    const list = slot.season.fixtures.filter((f) => (comp === "ALL" ? true : f.comp === comp || f.comp === "FR"));
    const m = new Map<string, typeof list>();
    for (const f of list) {
      const key = (f.comp === "PL" || f.comp === "LL" || f.comp === "FL1") ? `${COMP_SHORT[f.comp]} · тур ${String(f.matchday).padStart(2, "0")}` : f.comp === "FR" ? "Товарищеские" : `${COMP_NAME[f.comp]} · ${stageLabel(f)}`;
      if (!m.has(key)) m.set(key, []);
      m.get(key)!.push(f);
    }
    return [...m.entries()].sort((a, b) => {
      const da = a[1][0].date, db = b[1][0].date;
      return da < db ? -1 : da > db ? 1 : 0;
    });
  }, [slot, comp, slot.currentDate, flash]);

  const clubs = Object.values(slot.teams).sort((a, b) => b.reputation - a.reputation);
  const curLeague = (comp === "ALL" ? "PL" : comp) as "PL" | "LL" | "FL1";
  const plStarted = slot.season.fixtures.some((f) => f.comp === curLeague && f.played);

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="flex gap-1 rounded-xl bg-[#0f1419] p-1">
          {([["PL", "Premier League"], ["LL", "La Liga"], ["FL1", "Ligue 1"], ["ALL", "Все турниры"]] as const).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setComp(id)}
              className={cn(
                "rounded-lg px-3 py-1.5 text-xs font-medium transition-colors",
                comp === id ? "bg-[#2a3140] text-[#4ade80]" : "text-[#9ca3af] hover:text-[#e5e7eb]"
              )}
            >
              {label}
            </button>
          ))}
        </div>
        <span className={cn(
          "ml-auto flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px]",
          issues.some((i) => i.level === "error")
            ? "bg-[#ef4444]/15 text-[#f87171]"
            : issues.length ? "bg-[#fbbf24]/15 text-[#fbbf24]" : "bg-[#4ade80]/15 text-[#4ade80]"
        )}>
          {issues.length ? <AlertTriangle size={12} /> : <CheckCircle2 size={12} />}
          {issues.length ? `Замечаний: ${issues.length}` : "Конфликтов нет"}
        </span>
        <Btn
          onClick={() => say(regenerateLeague(slot, curLeague) ? "Расписание перегенерировано" : "Сезон уже начался — жеребьёвку нельзя переиграть")}
          disabled={plStarted}
          icon={<RefreshCw size={14} />}
          title={plStarted ? "Доступно только до первого матча АПЛ" : "Новая жеребьёвка"}
        >
          Перегенерировать
        </Btn>
      </div>

      {/* добавление товарищеского */}
      <Panel className="mb-3 bg-[#182029]">
        <PanelHead title="Добавить товарищеский матч" />
        <div className="grid gap-2 sm:grid-cols-[1fr_1fr_140px_auto]">
          <Select value={newHome} onChange={(e) => setNewHome(e.target.value)}>
            {clubs.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </Select>
          <Select value={newAway} onChange={(e) => setNewAway(e.target.value)}>
            {clubs.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </Select>
          <input
            type="date"
            value={newDate}
            min={slot.currentDate}
            onChange={(e) => setNewDate(e.target.value)}
            className="rounded-xl border border-[#2f3847] bg-[#0f1419] px-3 py-2 text-sm outline-none focus:border-[#4ade80]"
          />
          <Btn
            variant="primary"
            icon={<Plus size={15} />}
            disabled={newHome === newAway}
            onClick={() => { addFriendly(slot, newHome, newAway, newDate); say("Товарищеский добавлен"); }}
          >
            Добавить
          </Btn>
        </div>
      </Panel>

      <div className="max-h-[520px] space-y-3 overflow-y-auto pr-1">
        {groups.map(([title, fxs]) => {
          const isLg = fxs[0].comp === "PL" || fxs[0].comp === "LL" || fxs[0].comp === "FL1";
          const md = isLg ? fxs[0].matchday : null;
          const locked = fxs.every((f) => f.played);
          return (
            <div key={title}>
              <div className="mb-1 flex items-center gap-2">
                <span className="text-[11px] font-semibold uppercase tracking-widest text-[#9ca3af]">{title}</span>
                <span className="text-[10px] text-[#6b7280]">{fmtDay(fxs[0].date)}</span>
                {md !== null && !locked && (
                  <span className="ml-auto flex gap-1">
                    <button
                      onClick={() => { shiftMatchday(slot, md, -7, fxs[0].comp); say(`Тур ${md} сдвинут на неделю раньше`); }}
                      className="rounded-md bg-[#0f1419] p-1 text-[#9ca3af] transition-colors hover:text-[#4ade80]"
                      title="Тур на неделю раньше"
                    >
                      <ChevronUp size={13} />
                    </button>
                    <button
                      onClick={() => { shiftMatchday(slot, md, 7, fxs[0].comp); say(`Тур ${md} сдвинут на неделю позже`); }}
                      className="rounded-md bg-[#0f1419] p-1 text-[#9ca3af] transition-colors hover:text-[#4ade80]"
                      title="Тур на неделю позже"
                    >
                      <ChevronDown size={13} />
                    </button>
                  </span>
                )}
              </div>
              <div className="rounded-xl border border-[#232b36] bg-[#182029] px-2">
                {fxs.map((f) => {
                  const probs = issueByFixture.get(f.id);
                  return (
                    <div key={f.id} className="flex flex-wrap items-center gap-2 border-b border-[#232b36] py-1.5 text-sm last:border-0">
                      <span className="flex min-w-0 flex-1 items-center justify-end gap-1.5">
                        <span className="truncate">{slot.teams[f.homeId]?.shortName}</span>
                        <Crest name="" color={slot.teams[f.homeId]?.color ?? "#888"} size={7} />
                      </span>
                      <span className="w-12 shrink-0 text-center font-mono text-xs">
                        {f.result ? <b>{f.result.h}:{f.result.a}</b> : <span className="text-[#6b7280]">— : —</span>}
                      </span>
                      <span className="flex min-w-0 flex-1 items-center gap-1.5">
                        <Crest name="" color={slot.teams[f.awayId]?.color ?? "#888"} size={7} />
                        <span className="truncate">{slot.teams[f.awayId]?.shortName}</span>
                      </span>
                      {f.played ? (
                        <span className="w-[130px] shrink-0 text-right text-[11px] text-[#6b7280]">{fmtDay(f.date)} · сыгран</span>
                      ) : (
                        <span className="flex shrink-0 items-center gap-1">
                          <input
                            type="date"
                            value={f.date}
                            onChange={(e) => { moveFixture(slot, f.id, e.target.value); say("Дата матча изменена"); }}
                            className="rounded-lg border border-[#2f3847] bg-[#0f1419] px-2 py-1 font-mono text-[11px] outline-none focus:border-[#4ade80]"
                          />
                          {f.comp === "FR" && (
                            <button
                              onClick={() => { removeFixture(slot, f.id); say("Матч удалён"); }}
                              className="rounded p-1 text-[#6b7280] transition-colors hover:text-[#f87171]"
                              title="Удалить"
                            >
                              <Trash2 size={13} />
                            </button>
                          )}
                        </span>
                      )}
                      {probs && (
                        <span className="w-full text-[10px] text-[#fbbf24]">
                          <AlertTriangle size={10} className="mr-1 inline" />{probs.join(" · ")}
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      <p className="mt-3 flex items-center gap-1.5 text-[11px] text-[#6b7280]">
        <CalendarClock size={12} /> Изменения календаря сохраняются сразу. Проверка: без двух матчей в день и минимум 3 дня отдыха между турами АПЛ.
      </p>

      {flash && (
        <div className="fixed bottom-5 left-1/2 z-50 -translate-x-1/2 rounded-xl border border-[#4ade80]/40 bg-[#1e2530] px-4 py-2.5 text-sm shadow-2xl">
          {flash}
        </div>
      )}
    </div>
  );
}
