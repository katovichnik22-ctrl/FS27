// ─── Форматирование и копирование результатов в буфер обмена ───────────────
// Единый текстовый формат для матча, тура и таблицы. Используется кнопками
// «Скопировать» в MatchView, «Матчи → По турам» и LeagueTable.

import type { Fixture, MatchResult, Slot, TableRow } from "../types";
import type { AppSettings } from "../engine/storage";
import { LEAGUE_CFG } from "../engine/season";

/** Минута → "23'" / "90+3'" */
export function fmtMin(m: number): string {
  return m <= 90 ? `${m}'` : `90+${m - 90}'`;
}

/** Безопасное копирование в буфер с фолбэком для http/старых браузеров */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* переходим к фолбэку */
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}

// ─── Матч ────────────────────────────────────────────────────────────────────

/**
 * Текст отчёта о матче:
 * ⚽ Команда А 2:1 Команда Б
 * 🏟 Стадион
 * 23' Автор (ассист)
 * 67' Автор
 * 📊 владение · удары · xG
 * 🏆 Игрок матча 8.4
 * #PremierLeague · тур 5
 */
export function matchReportText(
  result: MatchResult,
  fixture: Fixture | null,
  slot: Slot,
  settings: AppSettings
): string {
  const lines: string[] = [];

  // строка 1 — счёт
  lines.push(`⚽ ${result.homeName} ${result.homeScore}:${result.awayScore} ${result.awayName}`);

  // строка 2 — стадия/стадион
  const stadium = slot.teams[fixture?.homeId ?? result.homeId]?.stadium;
  if (stadium) lines.push(`🏟 ${stadium}`);

  // голы построчно
  const goalEvents = result.events.filter((e) => e.type === "goal" || e.type === "penalty");
  for (const e of goalEvents) {
    const scorer = slot.teams[e.teamId ?? ""]?.players.find((p) => p.id === e.playerId);
    if (!scorer) continue;
    const assist = e.assistId
      ? slot.teams[e.teamId ?? ""]?.players.find((p) => p.id === e.assistId)
      : null;
    const mark = e.type === "penalty" ? " (пен.)" : "";
    lines.push(
      `${fmtMin(e.minute)} ${scorer.name}${mark}${assist ? ` (${assist.name})` : ""}`
    );
  }
  if (result.pens && (result.pens.h > 0 || result.pens.a > 0)) {
    lines.push(`🥅 по пенальти ${result.pens.h}:${result.pens.a}`);
  }

  // статистика
  const st = result.stats;
  lines.push(
    `📊 владение ${st.possessionH}:${st.possessionA} · удары ${st.shotsH}:${st.shotsA} · xG ${st.xgH.toFixed(2)}:${st.xgA.toFixed(2)}`
  );

  // игрок матча
  const motm = slot.teams[result.homeId]?.players.find((p) => p.id === result.motm) ??
    slot.teams[result.awayId]?.players.find((p) => p.id === result.motm);
  if (motm) {
    const rating = result.playerRatings[result.motm];
    if (rating !== undefined) lines.push(`🏆 ${motm.name} — ${rating.toFixed(1)}`);
  }

  // хэштег лиги + тур
  lines.push(leagueLine(fixture, settings));
  return lines.join("\n");
}

// ─── Табло тура (стиль BBC Sport) ───────────────────────────────────────────

/**
 * Компактное табло одного тура:
 * 🏆 Premier League · тур 5
 * 12.09 Астон Вилла 2:1 Брайтон (Уоткинс 23', Мален 67')
 */
export function matchdayText(
  fixtures: Fixture[],
  slot: Slot,
  settings: AppSettings
): string {
  if (!fixtures.length) return "";
  const first = fixtures[0];
  const lines: string[] = [];

  const head = first.comp === "PL"
    ? settings.leagueName
    : LEAGUE_CFG[first.comp as keyof typeof LEAGUE_CFG]?.name ?? first.comp;
  lines.push(`🏆 ${head} · тур ${first.matchday}`);

  const sorted = [...fixtures].sort((a, b) =>
    a.date < b.date ? -1 : a.date > b.date ? 1 : 0
  );

  for (const f of sorted) {
    const d = `${f.date.slice(8, 10)}.${f.date.slice(5, 7)}`;
    const home = slot.teams[f.homeId]?.shortName ?? "?";
    const away = slot.teams[f.awayId]?.shortName ?? "?";
    const score = f.result ? `${f.result.h}:${f.result.a}` : "—:—";

    // авторы голов в скобках
    let scorers = "";
    if (f.result?.scorers?.length) {
      const parts = f.result.scorers.map((s) => {
        const pl = slot.teams[s.t]?.players.find((p) => p.id === s.p);
        return pl ? `${pl.name.split(" ").pop()} ${fmtMin(s.m)}` : null;
      });
      const clean = parts.filter(Boolean);
      if (clean.length) scorers = ` (${clean.join(", ")})`;
    }
    lines.push(`${d} ${home} ${score} ${away}${scorers}`);
  }

  lines.push(leagueLine(first, settings));
  return lines.join("\n");
}

// ─── Таблица (моноширинно, выравнивание пробелами) ─────────────────────────

/** Таблица как моноширинный текст: # · команда · И · О */
export function tableText(rows: TableRow[], slot: Slot, title?: string): string {
  if (!rows.length) return "";
  const lines: string[] = [];
  if (title) lines.push(`🏆 ${title}`);
  lines.push("Поз  Команда                И   О");
  lines.push("─────────────────────────────────");

  const pos = String(rows.length).padStart(2);
  const nameW = Math.max(...rows.map((r) => (slot.teams[r.teamId]?.name ?? "").length), 8);
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const name = (slot.teams[r.teamId]?.name ?? "?").padEnd(nameW);
    lines.push(
      `${String(i + 1).padStart(pos.length)}   ${name} ${String(r.p).padStart(2)} ${String(r.pts).padStart(3)}`
    );
  }
  return lines.join("\n");
}

// ─── Вспомогательное ─────────────────────────────────────────────────────────

/** Хэштег лиги + номер тура. Для не-PL берёт тир из фикстуры. */
function leagueLine(fixture: Fixture | null, settings: AppSettings): string {
  const md = fixture?.matchday || settings.matchdayNumber;
  const tag = settings.leagueHashtag || "#PremierLeague";
  return `${tag} · тур ${md}`;
}
