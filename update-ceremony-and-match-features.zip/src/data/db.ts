// ─── Сборка MAIN_DB (неизменяемая главная база) ──────────────────────────────
import type { LeagueId, Player, Team } from "../types";
import { TEAMS_A, type PRow, type TeamRow } from "./teamsA";
import { TEAMS_B } from "./teamsB";
import { TEAMS_LL } from "./laliga";
import { TEAMS_FL1 } from "./ligue1";
import { TEAMS_BL } from "./bundesliga";
import { TEAMS_SA } from "./seriea";
import { TEAMS_POR } from "./portugal";
import { TEAMS_SAU } from "./saudi";
import { TEAMS_CHA } from "./championship";
import { TEAMS_TUR } from "./turkiye";
import { TEAMS_BEL } from "./belgium";
import { TEAMS_NED } from "./netherlands";
import { TEAMS_GRE } from "./greece";
import { TEAMS_UKR } from "./ukraine";
import { TEAMS_POL } from "./poland";
import { TEAMS_SCO } from "./scotland";
import { TEAMS_SUI } from "./switzerland";

function buildPlayer(row: PRow, teamId: string, idx: number): Player {
  const [name, position, age, nationality, attack, defense, overall, gk] = row;
  return {
    id: `${teamId}_p${idx}`,
    name,
    position,
    age,
    nationality,
    attack,
    defense,
    goalkeeping: gk ?? (position === "GK" ? overall : 5),
    overall,
    form: 1.0,
    fitness: 100,
    morale: 72,
    stats: {
      apps: 0, goals: 0, assists: 0, cleanSheets: 0, yellow: 0, red: 0, saves: 0,
      conceded: 0, errors: 0, keyPasses: 0, tackles: 0, minutes: 0,
      shots: 0, shotsOnTarget: 0, xg: 0, interceptions: 0, fouls: 0, offsides: 0, dribbles: 0, motm: 0,
      plApps: 0, plGoals: 0, plAssists: 0, plCleanSheets: 0, ratingSum: 0, avgRating: 0,
    },
  };
}

const LEAGUE_META = [
  { id: "PL" as const, rows: [...TEAMS_A, ...TEAMS_B], country: "ENG", name: "Premier League", short: "PL" },
  { id: "LL" as const, rows: TEAMS_LL, country: "ESP", name: "La Liga", short: "LaLiga" },
  { id: "FL1" as const, rows: TEAMS_FL1, country: "FRA", name: "Ligue 1", short: "Ligue 1" },
  { id: "BL" as const, rows: TEAMS_BL, country: "GER", name: "Bundesliga", short: "Bundesliga" },
  { id: "SA" as const, rows: TEAMS_SA, country: "ITA", name: "Serie A", short: "Serie A" },
  { id: "PT" as const, rows: TEAMS_POR, country: "POR", name: "Liga Portugal", short: "Liga PT" },
  { id: "SPL" as const, rows: TEAMS_SAU, country: "KSA", name: "Saudi Pro League", short: "Saudi PL" },
  { id: "CHA" as const, rows: TEAMS_CHA, country: "ENG", name: "EFL Championship", short: "Champ." },
  { id: "TUR" as const, rows: TEAMS_TUR, country: "TUR", name: "Süper Lig", short: "Süper Lig" },
  { id: "BEL" as const, rows: TEAMS_BEL, country: "BEL", name: "Belgian Pro League", short: "Pro League" },
  { id: "NED" as const, rows: TEAMS_NED, country: "NED", name: "Eredivisie", short: "Eredivisie" },
  { id: "GRE" as const, rows: TEAMS_GRE, country: "GRE", name: "Super League Greece", short: "Super League" },
  { id: "UKR" as const, rows: TEAMS_UKR, country: "UKR", name: "Ukrainian Premier League", short: "UPL" },
  { id: "POL" as const, rows: TEAMS_POL, country: "POL", name: "Ekstraklasa", short: "Ekstraklasa" },
  { id: "SCO" as const, rows: TEAMS_SCO, country: "SCO", name: "Scottish Premiership", short: "Premiership" },
  { id: "SUI" as const, rows: TEAMS_SUI, country: "SUI", name: "Swiss Super League", short: "Super League" },
];

export const LEAGUES = LEAGUE_META.map(({ id, country, name, short }) => ({ id, country, name, short }));

function buildTeams(): Record<string, Team> {
  const out: Record<string, Team> = {};
  const all: { t: TeamRow; league: LeagueId; country: string }[] = [];
  for (const meta of LEAGUE_META) for (const t of meta.rows) all.push({ t, league: meta.id, country: meta.country });
  for (const { t, league, country } of all) {
    out[t.id] = {
      league,
      country,
      tier: league,
      id: t.id,
      name: t.name,
      shortName: t.short,
      color: t.color,
      attack: t.att,
      midfield: t.mid,
      defense: t.def,
      goalkeeping: t.gk,
      reputation: t.rep,
      budget: t.budget,
      stadium: t.stadium,
      players: t.players.map((p, i) => buildPlayer(p, t.id, i)),
    };
  }
  return out;
}

/** Клубы конкретной лиги из главной базы */
export function leagueTeams(league: LeagueId): Team[] {
  return Object.values(MAIN_DB).filter((t) => t.league === league);
}

/** Глубокая заморозка — MAIN_DB недоступна для записи из любого места кода */
function deepFreeze<T>(obj: T): T {
  if (obj && typeof obj === "object") {
    Object.freeze(obj);
    for (const v of Object.values(obj)) deepFreeze(v);
  }
  return obj;
}

/** Глубокая копия (снимает заморозку) */
export function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

/** Главная база данных. ТОЛЬКО ДЛЯ ЧТЕНИЯ. Сезоны копируют её в свой слот. */
export const MAIN_DB: Record<string, Team> = deepFreeze(buildTeams());

export const TEAM_LIST: Team[] = Object.values(MAIN_DB);

export function getTeam(id: string): Team {
  const t = MAIN_DB[id];
  if (!t) throw new Error(`Unknown team: ${id}`);
  return t;
}
