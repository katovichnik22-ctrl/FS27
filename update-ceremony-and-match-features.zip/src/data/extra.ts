// ─── Клубы вне АПЛ: Европа (для ЛЧ/ЛЕ) и низшие лиги Англии (для кубков) ────
// У этих клубов нет реальных составов — только клубные рейтинги, а состав
// генерируется процедурно (детерминированно по seed слота).
import type { Player, Position, Team } from "../types";
import { makeRng } from "../engine/rng";

// [name, short, country, attack, midfield, defense, gk, reputation, color]
type ERow = [string, string, string, number, number, number, number, number, string];

export const EURO_CLUBS: ERow[] = [
  ["RB Salzburg", "RBS", "AUT", 75, 75, 73, 75, 72, "#CE1720"],
  ["Sturm Graz", "STG", "AUT", 73, 73, 72, 73, 67, "#000000"],
  ["Slavia Praha", "SLA", "CZE", 74, 74, 73, 75, 70, "#D7141A"],
  ["Sparta Praha", "SPA", "CZE", 73, 73, 72, 73, 69, "#8E1B2E"],
  ["Young Boys", "YB", "SUI", 73, 72, 71, 72, 67, "#FFF200"],
  ["FC Copenhagen", "FCK", "DEN", 73, 72, 72, 73, 68, "#002D62"],
  ["Midtjylland", "FCM", "DEN", 73, 73, 71, 72, 67, "#000000"],
  ["Bodø/Glimt", "BOD", "NOR", 75, 74, 71, 72, 70, "#FFD500"],
  ["Malmö FF", "MFF", "SWE", 71, 71, 70, 71, 64, "#87CEEB"],
  ["Dinamo Zagreb", "DIN", "CRO", 73, 72, 71, 72, 68, "#0067B1"],
  ["Crvena Zvezda", "CZV", "SRB", 73, 72, 71, 72, 68, "#DA291C"],
  ["FCSB", "FCS", "ROU", 70, 70, 69, 70, 62, "#0033A0"],
  ["Maccabi Tel Aviv", "MTA", "ISR", 71, 70, 69, 70, 63, "#FFD700"],
  ["Pafos FC", "PAF", "CYP", 70, 70, 69, 70, 61, "#003399"],
  ["Kairat Almaty", "KAI", "KAZ", 68, 68, 67, 68, 58, "#FFD100"],
  ["Slovan Bratislava", "SLB", "SVK", 69, 69, 68, 69, 60, "#0055A4"],
  ["Ferencváros", "FTC", "HUN", 71, 71, 70, 70, 63, "#008751"],
  // Реальные клубы стран, чьи лиги могут быть не выбраны — добор для еврокубков
  ["PAOK Salonika", "PAO2", "GRE", 74, 73, 72, 73, 72, "#000000"],
  ["Aris Salonika", "ARI2", "GRE", 71, 70, 69, 70, 68, "#FFE400"],
  ["Royal Antwerp", "ANT2", "BEL", 74, 73, 72, 73, 73, "#D4002A"],
  ["Standard Liege", "STL2", "BEL", 74, 73, 72, 73, 73, "#E30613"],
  ["Rakow Czestochowa", "RAK2", "POL", 71, 70, 69, 70, 70, "#E30613"],
  ["Jagiellonia", "JAG2", "POL", 71, 70, 69, 70, 70, "#FFE400"],
  ["Heart of Midlothian", "HEA2", "SCO", 71, 70, 69, 70, 70, "#7A263A"],
  ["Malmo FF", "MFF2", "SWE", 72, 71, 70, 71, 71, "#87CEEB"],
  ["Omonia Nicosia", "OMO2", "CYP", 71, 70, 69, 70, 70, "#008751"],
  ["Qarabag FK", "QAR2", "AZE", 72, 71, 70, 71, 71, "#000000"],
  ["Vojvodina", "VOJ", "SRB", 69, 69, 68, 69, 58, "#DA291C"],
  ["Rijeka", "RIJ", "CRO", 71, 70, 69, 70, 62, "#FFFFFF"],
  ["Osijek", "OSI", "CRO", 69, 69, 68, 69, 58, "#0067B1"],
  ["Cukaricki", "CUK", "SRB", 69, 68, 67, 68, 56, "#000000"],
  ["Larissa", "LAR2", "GRE", 68, 68, 67, 68, 55, "#E30613"],
  ["KAA Gent", "GNT2", "BEL", 74, 73, 72, 73, 73, "#0055A5"],
  ["Lech Poznan", "LCH2", "POL", 73, 72, 71, 72, 72, "#0055A5"],
  ["FC St Gallen", "STG2", "SUI", 71, 70, 69, 70, 70, "#008000"],
  ["Djurgardens IF", "DIF3", "SWE", 72, 71, 70, 71, 71, "#0067B1"],
  ["Brondby IF", "BIF3", "DEN", 72, 71, 70, 71, 71, "#FFE400"],
  ["Apoel Nicosia", "APO", "CYP", 71, 70, 69, 70, 70, "#0067B1"],
  ["Hapoel Beer Sheva", "HBS2", "ISR", 71, 70, 69, 70, 70, "#DA291C"],
  ["Sivasspor", "SIV", "TUR", 71, 70, 69, 70, 68, "#E30613"],
  ["Widzew Lodz", "WID2", "POL", 69, 68, 67, 68, 68, "#E30613"],
  ["FC Zurich", "FCZ2", "SUI", 72, 71, 70, 71, 71, "#0055A5"],
  ["Dinamo Zagreb", "DIN", "CRO", 73, 72, 71, 72, 68, "#0067B1"],
  ["Hajduk Split", "HAJ", "CRO", 70, 70, 69, 70, 61, "#0067B1"],
  ["Crvena Zvezda", "CZV", "SRB", 73, 72, 71, 72, 68, "#DA291C"],
  ["Partizan", "PAR4", "SRB", 71, 70, 69, 70, 62, "#000000"],
  ["Olympiacos Volos", "OLV", "GRE", 68, 68, 67, 68, 50, "#E30613"],
  ["PAOK Salonika", "PAO2", "GRE", 74, 73, 72, 73, 72, "#000000"],
  ["Olympiacos EU2", "OLY2", "GRE", 76, 75, 74, 75, 75, "#E30613"],
  ["Rapid Wien", "SCR", "AUT", 70, 70, 69, 70, 62, "#009F3C"],
  ["LASK", "LASK", "AUT", 69, 69, 68, 69, 59, "#000000"],
  ["Viktoria Plzeň", "PLZ", "CZE", 72, 71, 70, 72, 65, "#0067B1"],
  ["Baník Ostrava", "BAN", "CZE", 68, 68, 67, 68, 55, "#0067B1"],
  ["Rakow", "RAK", "POL", 71, 70, 69, 70, 62, "#E4002B"],
  ["Jagiellonia", "JAG", "POL", 69, 69, 68, 69, 58, "#FFE400"],
  ["Hajduk Split", "HAJ", "CRO", 70, 70, 69, 70, 61, "#0067B1"],
  ["Rijeka", "RIJ", "CRO", 69, 69, 68, 69, 58, "#FFFFFF"],
  ["Partizan", "PAR", "SRB", 71, 70, 69, 70, 62, "#000000"],
  ["Ludogorets", "LUD", "BUL", 70, 70, 69, 70, 60, "#009B48"],
  ["Universitatea Craiova", "UCV", "ROU", 68, 68, 67, 68, 55, "#0067B1"],
  ["CFR Cluj", "CFR", "ROU", 69, 69, 68, 69, 57, "#7B1B26"],
  ["Shelbourne", "SHE", "IRL", 65, 65, 65, 66, 48, "#DA291C"],
  ["Shamrock Rovers", "SHR", "IRL", 66, 66, 65, 66, 50, "#009B48"],
  ["Larne", "LAR", "NIR", 63, 63, 63, 64, 44, "#E4002B"],
  ["The New Saints", "TNS", "WAL", 63, 63, 63, 64, 44, "#00833E"],
  ["Lincoln Red Imps", "LIN", "GIB", 61, 61, 61, 62, 40, "#DA291C"],
  ["Brann", "BRN", "NOR", 70, 70, 69, 70, 60, "#DA291C"],
  ["Rosenborg", "RBK", "NOR", 69, 69, 68, 69, 58, "#FFFFFF"],
  ["Häcken", "HAC", "SWE", 69, 69, 68, 69, 57, "#FFE400"],
  ["Djurgården", "DIF", "SWE", 70, 70, 69, 70, 60, "#0067B1"],
  ["Brøndby", "BIF", "DEN", 70, 70, 69, 70, 60, "#FFE400"],
  ["Silkeborg", "SIF", "DEN", 67, 67, 66, 67, 53, "#009B48"],
  ["HJK Helsinki", "HJK", "FIN", 66, 66, 65, 66, 50, "#0067B1"],
  ["Lugano", "LUG", "SUI", 68, 68, 67, 68, 55, "#000000"],
  ["Zrinjski", "ZRI", "BIH", 63, 63, 63, 64, 44, "#DA291C"],
  ["Astana", "AST", "KAZ", 66, 66, 65, 66, 50, "#FFE400"],
  ["Qarabağ", "QAR", "AZE", 71, 71, 70, 71, 63, "#000000"],
  ["Hapoel Beer Sheva", "HBS", "ISR", 68, 68, 67, 68, 55, "#DA291C"],
  ["Omonia", "OMO", "CYP", 67, 67, 66, 67, 52, "#008751"],
  ["APOEL", "APO", "CYP", 68, 68, 67, 68, 54, "#0067B1"],
  ["Olimpija Ljubljana", "OLI", "SVN", 65, 65, 64, 65, 48, "#008751"],
  ["Dinamo Minsk", "DMI", "BLR", 64, 64, 63, 64, 45, "#0067B1"],
  ["Petrocub", "PET", "MDA", 61, 61, 61, 62, 39, "#FFE400"],
  ["Virtus", "VIR", "SMR", 58, 58, 58, 59, 32, "#000000"],
  ["Differdange", "DIF2", "LUX", 60, 60, 60, 61, 36, "#DA291C"],
  ["Vikingur", "VIK", "FRO", 60, 60, 60, 61, 36, "#0067B1"],
  ["Breidablik", "BRE2", "ISL", 63, 63, 62, 63, 43, "#008751"],
  ["Sheriff Tiraspol", "SHT", "MDA", 64, 64, 63, 64, 45, "#FFE400"],
  ["Dinamo Tbilisi", "DTB", "GEO", 62, 62, 62, 63, 41, "#0067B1"],
  ["Ballkani", "BAL", "KOS", 61, 61, 61, 62, 39, "#DA291C"],
  ["Struga", "STR2", "MKD", 60, 60, 60, 61, 36, "#DA291C"],
  ["Paksi", "PAK", "HUN", 63, 63, 62, 63, 43, "#008751"],
  ["Puskás Akadémia", "PUS", "HUN", 65, 65, 64, 65, 47, "#0067B1"],
  ["Slovan Liberec", "SLL", "CZE", 66, 66, 65, 66, 50, "#0067B1"],
  ["Molde", "MOL", "NOR", 69, 69, 68, 69, 58, "#0067B1"],
  ["Elfsborg", "ELF", "SWE", 68, 68, 67, 68, 55, "#FFE400"],
  ["Nordsjælland", "FCN2", "DEN", 68, 68, 67, 68, 55, "#FFE400"],
];

// Английские клубы вне АПЛ: [name, short, tier, attack, mid, def, gk, rep, color]
type NRow = [string, string, "CH" | "L1", number, number, number, number, number, string];

export const ENG_LOWER: NRow[] = [
  ["Oxford United", "OXF", "CH", 64, 64, 64, 65, 48, "#FFE400"],
  ["Sheffield Wednesday", "SHW", "CH", 65, 65, 65, 65, 51, "#0066B3"],
  ["Luton Town", "LUT", "L1", 64, 64, 64, 65, 48, "#F78F1E"],
  ["Plymouth Argyle", "PLY", "L1", 62, 62, 62, 63, 44, "#1B7A43"],
  ["Reading", "RDG", "L1", 62, 62, 62, 63, 45, "#004494"],
  ["Barnsley", "BAR", "L1", 61, 61, 61, 62, 42, "#E4232C"],
  ["Huddersfield Town", "HUD", "L1", 62, 62, 61, 62, 44, "#0E63AD"],
  ["Wigan Athletic", "WIG", "L1", 61, 61, 61, 61, 42, "#1D59AF"],
  ["Peterborough United", "PET", "L1", 60, 60, 59, 60, 39, "#0057B8"],
  ["Blackpool", "BLK", "L1", 60, 60, 60, 60, 40, "#F68712"],
  ["Stevenage", "STE", "L1", 59, 59, 60, 60, 37, "#E4232C"],
  ["Northampton Town", "NOR", "L1", 58, 58, 58, 59, 35, "#7C2529"],
  ["Rotherham United", "ROT", "L1", 59, 59, 59, 59, 37, "#DD1E3E"],
  ["Shrewsbury Town", "SHR", "L1", 57, 57, 57, 58, 33, "#0055A4"],
  ["Bradford City", "BRD", "L1", 59, 59, 58, 59, 37, "#8A2432"],
  ["Notts County", "NTC", "L1", 58, 58, 57, 58, 34, "#000000"],
  ["Salford City", "SAL", "L1", 57, 57, 57, 57, 33, "#DA291C"],
  ["Walsall", "WAL", "L1", 57, 57, 57, 58, 33, "#E4232C"],
  ["Mansfield Town", "MAN", "L1", 58, 58, 57, 58, 34, "#FFD700"],
  ["Sheffield Wednesday", "SHW", "L1", 65, 65, 65, 65, 51, "#0066B3"],
  ["Huddersfield Town", "HUD", "L1", 64, 64, 63, 64, 47, "#0E63AD"],
  ["Leicester City", "LEI", "L1", 68, 68, 67, 68, 58, "#003090"],
  ["Oxford United", "OXF", "L1", 63, 63, 63, 64, 46, "#FFE400"],
  ["Wigan Athletic", "WIG", "L1", 61, 61, 61, 62, 42, "#1D59AF"],
  ["Cambridge United", "CAM", "L1", 59, 59, 59, 60, 36, "#FFE400"],
  ["Bromley", "BRO", "L1", 58, 58, 58, 59, 34, "#FFFFFF"],
  ["Burton Albion", "BTN", "L1", 59, 59, 59, 59, 35, "#FFE400"],
  ["Leyton Orient", "LEY", "L1", 61, 61, 61, 62, 40, "#DA291C"],
  ["Milton Keynes Dons", "MKD", "L1", 59, 59, 59, 60, 36, "#FFFFFF"],
  ["Wycombe Wanderers", "WYC", "L1", 61, 61, 61, 61, 40, "#0055A5"],
  ["Doncaster Rovers", "DON", "L1", 60, 60, 60, 61, 38, "#DA291C"],
];

// ─── Генерация имён ──────────────────────────────────────────────────────────

const FIRST: Record<string, string[]> = {
  ESP: ["Álvaro", "Sergio", "Iker", "Pablo", "Marcos", "Javier", "Diego", "Rubén", "Adrián", "Hugo", "Iván", "Carlos"],
  ITA: ["Matteo", "Lorenzo", "Andrea", "Federico", "Alessandro", "Giacomo", "Nicolò", "Davide", "Simone", "Marco"],
  GER: ["Lukas", "Jonas", "Maximilian", "Felix", "Niklas", "Tim", "Leon", "Julian", "Florian", "Marius"],
  FRA: ["Théo", "Hugo", "Lucas", "Enzo", "Nathan", "Maxime", "Clément", "Yanis", "Kylian", "Rayan"],
  POR: ["João", "Rúben", "Tiago", "Bruno", "Diogo", "Gonçalo", "Rafael", "André", "Nuno", "Fábio"],
  NED: ["Daan", "Sem", "Lars", "Thijs", "Bram", "Joost", "Rick", "Stijn", "Jesse", "Koen"],
  ENG: ["Jack", "Harry", "Ollie", "Callum", "Ethan", "Louie", "Tommy", "Ryan", "Jamie", "Charlie", "Alfie", "Kieran"],
  BRA: ["Lucas", "Gabriel", "Rafael", "Matheus", "Vinícius", "Bruno", "Thiago", "Caio", "Léo", "Douglas"],
  GEN: ["Alex", "Nikola", "Marko", "Andrei", "Viktor", "Dmytro", "Omar", "Kenji", "Stefan", "Adam", "Emre", "Luka"],
};

const LAST: Record<string, string[]> = {
  ESP: ["García", "Fernández", "López", "Martínez", "Sánchez", "Romero", "Torres", "Navarro", "Iglesias", "Cabrera"],
  ITA: ["Rossi", "Conti", "Barella", "Marchetti", "Ferrari", "Bernardi", "Greco", "Lombardi", "Moretti", "Vitale"],
  GER: ["Müller", "Schneider", "Weber", "Wagner", "Becker", "Hoffmann", "Krüger", "Richter", "Neumann", "Bauer"],
  FRA: ["Dubois", "Moreau", "Laurent", "Fontaine", "Girard", "Bernard", "Mercier", "Renard", "Chevalier", "Perrin"],
  POR: ["Silva", "Santos", "Ferreira", "Pereira", "Costa", "Almeida", "Carvalho", "Ribeiro", "Moreira", "Teixeira"],
  NED: ["de Jong", "van Dijk", "Bakker", "Visser", "Smit", "de Boer", "Mulder", "Jansen", "van Leeuwen", "Kuipers"],
  ENG: ["Baker", "Fletcher", "Hughes", "Turner", "Walsh", "Barnes", "Doyle", "Harper", "Nichols", "Sutton", "Pearce", "Reid"],
  BRA: ["Silva", "Souza", "Oliveira", "Costa", "Almeida", "Ramos", "Barbosa", "Carvalho", "Pinto", "Moraes"],
  GEN: ["Petrović", "Kovač", "Popescu", "Ivanov", "Hassan", "Yilmaz", "Nowak", "Novák", "Horváth", "Andersen", "Larsen", "Lindgren"],
};

const COUNTRY_MIX: Record<string, string[]> = {
  ESP: ["ESP", "ESP", "ESP", "BRA", "FRA"],
  ITA: ["ITA", "ITA", "ITA", "BRA", "FRA"],
  GER: ["GER", "GER", "GER", "FRA", "GEN"],
  FRA: ["FRA", "FRA", "FRA", "BRA", "GEN"],
  POR: ["POR", "POR", "POR", "BRA", "GEN"],
  NED: ["NED", "NED", "NED", "BRA", "GEN"],
  ENG: ["ENG", "ENG", "ENG", "GEN", "BRA"],
};

function nameFor(rng: ReturnType<typeof makeRng>, country: string, taken?: Set<string>): { name: string; nat: string } {
  const mix = COUNTRY_MIX[country] ?? ["GEN", "GEN", country in FIRST ? country : "GEN", "BRA", "ENG"];
  const nat = rng.pick(mix);
  const f = FIRST[nat] ?? FIRST.GEN;
  const l = LAST[nat] ?? LAST.GEN;
  let name = `${rng.pick(f)} ${rng.pick(l)}`;
  // если имя уже занято реальным игроком лиги — подбираем другое
  if (taken?.has(name)) {
    // больше попыток — почти всегда находим свободное имя без суффиксов
    for (let attempt = 0; attempt < 200 && taken.has(name); attempt++) {
      name = `${rng.pick(f)} ${rng.pick(l)}`;
    }
    if (taken.has(name)) name = `${name} ${String.fromCharCode(65 + rng.int(0, 25))}.`;
  }
  return { name, nat };
}

// Состав приближен к реальным клубам: иначе у процедурных команд не хватало
// защитников и глубины, оборона проседала и счета раздувались.
const SQUAD_SHAPE: [Position, number][] = [["GK", 2], ["DF", 7], ["MF", 6], ["FW", 4]];

/** Процедурный состав под клубные рейтинги (17 игроков) */
export function generateSquad(team: Omit<Team, "players">, seed: number, used?: Set<string>): Player[] {
  const rng = makeRng(seed);
  const taken = used ?? new Set<string>();
  const players: Player[] = [];
  let i = 0;
  for (const [pos, count] of SQUAD_SHAPE) {
    // Базовый уровень линии. Оборону слегка подтягиваем к среднему уровню клуба:
    // в реальных составах защита не отстаёт от атаки так сильно, как в рейтингах.
    const overallTeam = (team.attack + team.midfield + team.defense) / 3;
    const base =
      pos === "GK" ? team.goalkeeping
      : pos === "DF" ? team.defense * 0.55 + overallTeam * 0.45
      : pos === "MF" ? team.midfield
      : team.attack;
    for (let k = 0; k < count; k++) {
      // первые в линии — сильнее (основа), дальше запас; спад мягче,
      // чтобы глубина состава не обваливалась после замен и травм
      const nStart = pos === "GK" ? 1 : pos === "DF" ? 4 : pos === "MF" ? 3 : 3;
      const drop = k < nStart ? k * 0.8 : 2.5 + (k - nStart) * 1.6;
      const overall = Math.max(40, Math.min(99, Math.round(base - drop + rng.range(-2, 2.5))));
      const { name, nat } = nameFor(rng, team.country ?? "ENG", taken);
      taken.add(name);
      const attack =
        pos === "FW" ? overall + rng.int(-1, 2)
        : pos === "MF" ? overall - rng.int(2, 8)
        : pos === "DF" ? overall - rng.int(20, 32)
        : rng.int(15, 28);
      const defense =
        pos === "DF" ? overall + rng.int(-1, 2)
        : pos === "MF" ? overall - rng.int(3, 9)
        : pos === "FW" ? overall - rng.int(25, 35)
        : rng.int(35, 50);
      players.push({
        id: `${team.id}_g${i++}`,
        name,
        position: pos,
        age: rng.int(19, 34),
        nationality: nat,
        attack: Math.max(20, Math.min(99, attack)),
        defense: Math.max(20, Math.min(99, defense)),
        goalkeeping: pos === "GK" ? overall : rng.int(4, 12),
        overall,
        form: 1,
        fitness: 100,
        morale: 70,
        stats: {
          apps: 0, goals: 0, assists: 0, cleanSheets: 0, yellow: 0, red: 0, saves: 0,
          conceded: 0, errors: 0, keyPasses: 0, tackles: 0, minutes: 0,
      shots: 0, shotsOnTarget: 0, xg: 0, interceptions: 0, fouls: 0, offsides: 0, dribbles: 0, motm: 0,
      plApps: 0, plGoals: 0, plAssists: 0, plCleanSheets: 0, ratingSum: 0, avgRating: 0,
        },
      });
    }
  }
  return players;
}

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
}

/** Все дополнительные клубы (Европа + низшие лиги Англии) с составами */
export function buildExtraTeams(seed: number, occupiedNames?: Set<string>, realClubNames?: Set<string>): Record<string, Team> {
  const out: Record<string, Team> = {};
  // имена, уже занятые реальными лигами — их нужно обойти, чтобы не создавать дублей
  const used = occupiedNames ?? new Set<string>();
  // клубы, которые уже существуют как полноценные лиги — их процедурные копии не нужны
  const skipClubs = realClubNames ?? new Set<string>();
  for (const [name, short, country, att, mid, def, gk, rep, color] of EURO_CLUBS) {
    if (country === "XXX") continue; // технические строки
    // клуб уже существует как реальная лига — пропускаем
    if (skipClubs.has(name.toLowerCase())) continue;
    const id = `eu_${slugify(name)}`;
    const base = {
      id, name, shortName: short, color, country, tier: "EU" as const,
      attack: att, midfield: mid, defense: def, goalkeeping: gk,
      reputation: rep, budget: Math.round(rep * 3.2), stadium: `${name} Stadium`,
    };
    out[id] = { ...base, players: generateSquad(base, seed ^ hash(id), used) };
  }
  const TIER2: Record<string, "ES2" | "FR2" | "DE2" | "IT2" | "PT2" | "SA2" | "TR2" | "BE2" | "NE2" | "GR2" | "UA2"> = {
    ESP: "ES2", FRA: "FR2", GER: "DE2", ITA: "IT2", POR: "PT2", KSA: "SA2", TUR: "TR2", BEL: "BE2",
    NED: "NE2", GRE: "GR2", UKR: "UA2",
  };
  for (const [name, short, country, att, mid, def, gk, rep, color] of
       [...ESP_LOWER, ...FRA_LOWER, ...GER_LOWER, ...ITA_LOWER, ...POR_LOWER, ...SAU_LOWER, ...TUR_LOWER, ...BEL_LOWER, ...NED_LOWER, ...GRE_LOWER, ...UKR_LOWER]) {
    const id = `${country.toLowerCase()}_${slugify(name)}`;
    const base = {
      id, name, shortName: short, color, country, tier: TIER2[country],
      attack: att, midfield: mid, defense: def, goalkeeping: gk,
      reputation: rep, budget: Math.round(rep * 0.9), stadium: `${name} Stadium`,
    };
    out[id] = { ...base, players: generateSquad(base, seed ^ hash(id), used) };
  }
  for (const [name, short, tier, att, mid, def, gk, rep, color] of ENG_LOWER) {
    const id = `en_${slugify(name)}`;
    const base = {
      id, name, shortName: short, color, country: "ENG", tier,
      attack: att, midfield: mid, defense: def, goalkeeping: gk,
      reputation: rep, budget: Math.round(rep * 1.1), stadium: `${name} Stadium`,
    };
    out[id] = { ...base, players: generateSquad(base, seed ^ hash(id), used) };
  }
  return out;
}

// ─── Клубы второго эшелона Испании и Франции (для кубков) ───────────────────

type LRow = [string, string, string, number, number, number, number, number, string];

export const ESP_LOWER: LRow[] = [
  ["Real Zaragoza", "ZAR", "ESP", 67, 67, 67, 68, 55, "#0067B1"],
  ["Sporting Gijón", "SPG", "ESP", 68, 68, 67, 68, 55, "#E30613"],
  ["Real Valladolid", "VLL", "ESP", 68, 68, 67, 68, 56, "#7B2182"],
  ["UD Las Palmas", "LPA", "ESP", 69, 69, 68, 69, 58, "#FFE400"],
  ["Real Oviedo", "OVI", "ESP", 67, 67, 67, 68, 55, "#0033A0"],
  ["Granada CF", "GRA", "ESP", 68, 68, 67, 68, 56, "#E30613"],
  ["Cádiz CF", "CAD", "ESP", 67, 67, 67, 67, 54, "#FFE400"],
  ["CD Mirandés", "MIR", "ESP", 64, 64, 64, 65, 48, "#E30613"],
  ["SD Huesca", "HUE", "ESP", 64, 64, 64, 65, 48, "#004494"],
  ["Albacete", "ALB", "ESP", 63, 63, 63, 64, 46, "#FFFFFF"],
  ["Burgos CF", "BUR", "ESP", 63, 63, 64, 64, 46, "#FFFFFF"],
  ["Eibar", "EIB", "ESP", 65, 65, 65, 66, 50, "#A6192E"],
  ["Castellón", "CAS", "ESP", 63, 63, 63, 63, 45, "#000000"],
  ["Córdoba CF", "COR", "ESP", 62, 62, 62, 63, 44, "#008A45"],
];

export const GER_LOWER: LRow[] = [
  ["Schalke 04", "S04", "GER", 68, 68, 68, 69, 62, "#004D9D"],
  ["Hertha BSC", "BSC", "GER", 68, 68, 67, 68, 60, "#005CA9"],
  ["Fortuna Düsseldorf", "F95", "GER", 66, 66, 66, 67, 55, "#DA291C"],
  ["1. FC Nürnberg", "FCN", "GER", 65, 65, 65, 66, 54, "#8B0E04"],
  ["Karlsruher SC", "KSC", "GER", 65, 65, 65, 65, 52, "#0055A4"],
  ["Hannover 96", "H96", "GER", 66, 66, 65, 66, 54, "#00963F"],
  ["SV Darmstadt 98", "SVD", "GER", 64, 64, 64, 65, 50, "#004B9E"],
  ["SC Paderborn", "SCP", "GER", 65, 65, 64, 65, 51, "#004B9E"],
  ["Holstein Kiel", "KSV", "GER", 65, 65, 64, 65, 52, "#0049A8"],
  ["Eintracht Braunschweig", "BTSV", "GER", 62, 62, 62, 63, 46, "#FFE400"],
  ["SV Elversberg", "SVE", "GER", 64, 64, 63, 64, 48, "#000000"],
  ["Greuther Fürth", "SGF", "GER", 62, 62, 62, 62, 45, "#009D4F"],
  ["1. FC Magdeburg", "FCM", "GER", 63, 63, 63, 64, 47, "#00963F"],
  ["Arminia Bielefeld", "DSC", "GER", 63, 63, 62, 63, 46, "#004C9E"],
  ["VfL Bochum", "BOC", "GER", 64, 64, 64, 65, 50, "#005CA9"],
  ["Preußen Münster", "SCP2", "GER", 61, 61, 61, 62, 42, "#008A45"],
];

export const ITA_LOWER: LRow[] = [
  ["Sampdoria", "SAM", "ITA", 66, 66, 66, 67, 58, "#1B5AA8"],
  ["Palermo", "PAL", "ITA", 67, 67, 66, 67, 56, "#F49AC2"],
  ["Venezia", "VEN", "ITA", 67, 67, 66, 67, 56, "#F58220"],
  ["Empoli", "EMP", "ITA", 66, 66, 66, 67, 55, "#00579C"],
  ["Monza", "MON", "ITA", 67, 67, 66, 67, 57, "#DA291C"],
  ["Spezia", "SPE", "ITA", 65, 65, 65, 66, 52, "#000000"],
  ["Bari", "BAR", "ITA", 64, 64, 64, 65, 50, "#DA291C"],
  ["Catanzaro", "CAT", "ITA", 63, 63, 63, 64, 47, "#FFE400"],
  ["Modena", "MOD", "ITA", 64, 64, 63, 64, 48, "#FFE400"],
  ["Cesena", "CES", "ITA", 63, 63, 63, 63, 46, "#FFFFFF"],
  ["Reggiana", "REG", "ITA", 62, 62, 62, 63, 44, "#8B1A1A"],
  ["Frosinone", "FRO", "ITA", 64, 64, 63, 64, 48, "#FFE400"],
];

export const NED_LOWER: LRow[] = [
  ["FC Volendam", "VOL2", "NED", 61, 61, 61, 62, 40, "#E30613"],
  ["NAC Breda", "NAC", "NED", 63, 63, 62, 63, 44, "#FFE400"],
  ["Heracles", "HER", "NED", 62, 62, 61, 62, 42, "#000000"],
  ["PEC Zwolle", "PEC", "NED", 63, 63, 62, 63, 43, "#0055A5"],
  ["De Graafschap", "GRA2", "NED", 60, 60, 60, 61, 38, "#E30613"],
  ["MVV Maastricht", "MVV", "NED", 59, 59, 59, 60, 36, "#E30613"],
  ["Roda JC", "ROD", "NED", 61, 61, 60, 61, 40, "#FFE400"],
  ["Emmen", "EMM", "NED", 60, 60, 59, 60, 38, "#E30613"],
];

export const GRE_LOWER: LRow[] = [
  ["Panserraikos", "PAN3", "GRE", 60, 60, 60, 61, 40, "#E30613"],
  ["OFI Crete B", "OFI2", "GRE", 60, 60, 59, 60, 38, "#000000"],
  ["AEL", "AEL", "GRE", 61, 61, 60, 61, 41, "#800080"],
  ["Panionios", "PNI", "GRE", 60, 60, 60, 60, 39, "#E30613"],
];

export const UKR_LOWER: LRow[] = [
  ["Chornomorets B", "CHO2", "UKR", 58, 58, 58, 59, 36, "#0055A5"],
  ["Metalist Kharkiv", "MET", "UKR", 61, 61, 60, 61, 42, "#FFE400"],
  ["FK Uzhhorod", "UZH", "UKR", 59, 59, 58, 59, 37, "#E30613"],
];

export const TUR_LOWER: LRow[] = [
  ["Bandırmaspor", "BAN", "TUR", 62, 62, 62, 63, 44, "#E30613"],
  ["Şanlıurfaspor", "SAN", "TUR", 61, 61, 61, 62, 42, "#FFE400"],
  ["Ümraniyespor", "UMR", "TUR", 62, 62, 61, 62, 43, "#E30613"],
  ["Boluspor", "BOL2", "TUR", 61, 61, 61, 62, 42, "#E30613"],
  ["Erokspor", "ERO", "TUR", 62, 62, 61, 62, 43, "#000000"],
  ["Manisa FK", "MAN2", "TUR", 61, 61, 61, 61, 41, "#E30613"],
  ["Fatih Karagümrük", "KAR", "TUR", 64, 64, 63, 64, 47, "#E30613"],
  ["Adana Demirspor", "ADS", "TUR", 63, 63, 62, 63, 45, "#0055A5"],
  ["Pendikspor", "PEN2", "TUR", 60, 60, 60, 61, 40, "#E30613"],
  ["Sakaryaspor", "SAK", "TUR", 60, 60, 60, 61, 40, "#000000"],
  ["Ankara Keçiörengücü", "KEC", "TUR", 60, 60, 60, 60, 39, "#E30613"],
  ["Iğdır FK", "IGD", "TUR", 59, 59, 59, 60, 38, "#E30613"],
];

export const BEL_LOWER: LRow[] = [
  ["Zulte Waregem B", "ZWB", "BEL", 62, 62, 62, 63, 44, "#0055A5"],
  ["Beveren", "BEV", "BEL", 62, 62, 62, 62, 43, "#FFE400"],
  ["KRC Mechelen", "KRM", "BEL", 61, 61, 61, 62, 42, "#FFE400"],
  ["Lokeren-Temse", "LOK", "BEL", 60, 60, 60, 61, 40, "#E30613"],
  ["RAAL La Louvière B", "RLL2", "BEL", 60, 60, 60, 60, 39, "#0055A5"],
  ["Francs Borains", "FRA2", "BEL", 60, 60, 60, 60, 39, "#E30613"],
  ["Olympic Charleroi", "OLY2", "BEL", 59, 59, 59, 60, 38, "#000000"],
  ["KMSK Deinze", "DEI", "BEL", 60, 60, 59, 60, 39, "#0055A5"],
  ["SK Beveren", "SKB", "BEL", 59, 59, 59, 60, 38, "#FFE400"],
  ["Club NXT", "NXT", "BEL", 58, 58, 58, 59, 36, "#005EB8"],
  ["RWDM", "RWD", "BEL", 61, 61, 60, 61, 41, "#E30613"],
  ["Virton", "VIR2", "BEL", 58, 58, 58, 58, 35, "#E30613"],
];

export const POR_LOWER: LRow[] = [
  ["Vitória Setúbal", "VSE", "POR", 64, 64, 64, 65, 48, "#008751"],
  ["Académica", "ACA", "POR", 63, 63, 63, 64, 45, "#000000"],
  ["Leixões", "LEI", "POR", 64, 64, 63, 64, 46, "#E30613"],
  ["Penafiel", "PEN", "POR", 63, 63, 63, 63, 44, "#E30613"],
  ["Tondela", "TON", "POR", 65, 65, 64, 65, 50, "#FFE400"],
  ["Paços de Ferreira", "PAC", "POR", 65, 65, 64, 65, 50, "#FFE400"],
  ["Farense", "FAR", "POR", 64, 64, 64, 64, 47, "#000000"],
  ["Chaves", "CHA", "POR", 64, 64, 63, 64, 46, "#0055A5"],
  ["Portimonense", "POR2", "POR", 64, 64, 63, 64, 46, "#000000"],
  ["Feirense", "FEI", "POR", 63, 63, 63, 63, 44, "#E30613"],
  ["União de Leiria", "UDL", "POR", 62, 62, 62, 63, 42, "#0055A5"],
  ["Torreense", "TOR2", "POR", 62, 62, 62, 62, 41, "#008751"],
];

export const SAU_LOWER: LRow[] = [
  ["Al-Wehda", "WEH", "KSA", 65, 65, 65, 66, 50, "#E30613"],
  ["Al-Raed", "RAE", "KSA", 64, 64, 64, 65, 48, "#FFE400"],
  ["Al-Okhdood", "OKH", "KSA", 63, 63, 63, 64, 45, "#008751"],
  ["Al-Batin", "BAT", "KSA", 63, 63, 63, 63, 44, "#0055A5"],
  ["Al-Najma", "NAJ", "KSA", 64, 64, 63, 64, 46, "#E30613"],
  ["Al-Orobah", "ORO", "KSA", 63, 63, 63, 64, 45, "#008751"],
  ["Al-Jabalain", "JAB", "KSA", 62, 62, 62, 63, 42, "#FFE400"],
  ["Al-Ula", "ULA", "KSA", 62, 62, 62, 62, 41, "#0055A5"],
  ["Jeddah Club", "JED", "KSA", 63, 63, 62, 63, 43, "#000000"],
  ["Al-Adalah", "ADA", "KSA", 62, 62, 62, 62, 41, "#008751"],
  ["Al-Zulfi", "ZUL", "KSA", 61, 61, 61, 62, 39, "#E30613"],
  ["Al-Arabi SC", "ARB", "KSA", 61, 61, 61, 62, 39, "#FFFFFF"],
];

export const FRA_LOWER: LRow[] = [
  ["FC Nantes", "FCN", "FRA", 69, 69, 69, 70, 60, "#FCD303"],
  ["Montpellier HSC", "MHSC", "FRA", 67, 67, 67, 68, 56, "#F58220"],
  ["Stade de Reims", "SDR", "FRA", 68, 68, 68, 69, 57, "#E30613"],
  ["AS Saint-Étienne", "ASSE", "FRA", 69, 69, 68, 69, 59, "#00843D"],
  ["Girondins Bordeaux", "GDB", "FRA", 65, 65, 65, 66, 52, "#00006B"],
  ["EA Guingamp", "EAG", "FRA", 64, 64, 64, 65, 48, "#E30613"],
  ["Grenoble Foot", "GF38", "FRA", 63, 63, 63, 64, 45, "#0067B1"],
  ["Amiens SC", "ASC", "FRA", 63, 63, 63, 64, 45, "#FFFFFF"],
  ["Clermont Foot", "CF63", "FRA", 64, 64, 64, 64, 47, "#C8102E"],
  ["Pau FC", "PAU", "FRA", 62, 62, 62, 63, 43, "#F58220"],
  ["Rodez AF", "RAF", "FRA", 61, 61, 62, 62, 41, "#A6192E"],
  ["USL Dunkerque", "USLD", "FRA", 63, 63, 63, 63, 44, "#0067B1"],
  ["Red Star FC", "RS93", "FRA", 62, 62, 62, 62, 42, "#008A45"],
  ["Laval", "LAV", "FRA", 61, 61, 61, 62, 40, "#F58220"],
];

// ─── Свободные агенты (пул без клуба) ────────────────────────────────────────

/** Пул свободных агентов: ветераны и молодые таланты без контракта */
export function makeFreeAgents(seed: number, count = 24): Player[] {
  const rng = makeRng(seed ^ 0x5eedfa);
  const out: Player[] = [];
  const shape: Position[] = ["GK", "GK", "DF", "DF", "DF", "DF", "DF", "MF", "MF", "MF", "MF", "MF", "FW", "FW", "FW", "FW"];
  for (let i = 0; i < count; i++) {
    const pos = shape[i % shape.length];
    const veteran = rng.chance(0.55);
    const overall = veteran ? rng.int(68, 80) : rng.int(62, 74);
    const age = veteran ? rng.int(31, 37) : rng.int(18, 22);
    const country = rng.pick(["ENG", "ENG", "FRA", "ESP", "BRA", "GER", "ITA", "NED", "POR", "GEN"]);
    const { name, nat } = nameFor(rng, country);
    out.push({
      id: `fa_${seed.toString(36)}_${i}`,
      name,
      position: pos,
      age,
      nationality: nat,
      attack: pos === "FW" ? overall : pos === "MF" ? overall - rng.int(2, 7) : pos === "DF" ? overall - rng.int(20, 30) : rng.int(15, 25),
      defense: pos === "DF" ? overall : pos === "MF" ? overall - rng.int(3, 8) : pos === "FW" ? overall - rng.int(25, 32) : rng.int(35, 48),
      goalkeeping: pos === "GK" ? overall : rng.int(4, 12),
      overall,
      form: 1,
      fitness: 100,
      morale: 65,
      stats: {
        apps: 0, goals: 0, assists: 0, cleanSheets: 0, yellow: 0, red: 0, saves: 0,
        conceded: 0, errors: 0, keyPasses: 0, tackles: 0, minutes: 0,
      shots: 0, shotsOnTarget: 0, xg: 0, interceptions: 0, fouls: 0, offsides: 0, dribbles: 0, motm: 0,
        plApps: 0, plGoals: 0, plAssists: 0, plCleanSheets: 0, ratingSum: 0, avgRating: 0,
      },
    });
  }
  return out;
}
