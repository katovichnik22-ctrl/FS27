// ─── Корневой компонент: маршрутизация экранов ───────────────────────────────
import { useEffect, useState } from "react";
import { MainMenu, SettingsScreen, AboutScreen, type MenuTarget } from "./ui/Menu";
import { QuickMatch } from "./ui/QuickMatch";
import { NewSeason, SavesList } from "./ui/Saves";
import { SeasonScreen } from "./ui/Season";
import { applyMobileMode, listSlots, loadSettings } from "./engine/storage";

type View =
  | { v: "menu" }
  | { v: "quick" }
  | { v: "newSeason" }
  | { v: "saves" }
  | { v: "season"; slotId: string }
  | { v: "settings" }
  | { v: "about" };

export default function App() {
  const [view, setView] = useState<View>({ v: "menu" });
  const [slotsVersion, setSlotsVersion] = useState(0);

  // мобильный режим применяется к <html> при запуске и живёт между сессиями
  useEffect(() => { applyMobileMode(loadSettings().mobileMode); }, []);
  const bump = () => setSlotsVersion((n) => n + 1);

  const go = (t: MenuTarget) => {
    if (t === "quick") setView({ v: "quick" });
    else if (t === "newSeason") setView({ v: "newSeason" });
    else if (t === "saves") setView({ v: "saves" });
    else if (t === "settings") setView({ v: "settings" });
    else setView({ v: "about" });
  };

  const toMenu = () => {
    bump();
    setView({ v: "menu" });
  };

  return (
    <div className="min-h-dvh bg-[#1a1a1a] text-[#e0e0e0] antialiased">
      {view.v === "menu" && <MainMenu key={slotsVersion} slots={listSlots().length} onNavigate={go} />}
      {view.v === "quick" && <QuickMatch onMenu={toMenu} />}
      {view.v === "newSeason" && (
        <NewSeason
          onCreated={(slot) => { bump(); setView({ v: "season", slotId: slot.slotId }); }}
          onBack={toMenu}
        />
      )}
      {view.v === "saves" && <SavesList onOpen={(slotId) => setView({ v: "season", slotId })} onBack={toMenu} />}
      {view.v === "season" && <SeasonScreen key={view.slotId} slotId={view.slotId} onExit={toMenu} />}
      {view.v === "settings" && <SettingsScreen onBack={toMenu} />}
      {view.v === "about" && <AboutScreen onBack={toMenu} />}
    </div>
  );
}
