// ─── Общие типы симулятора ───────────────────────────────────────────────────

export type Position = "GK" | "DF" | "MF" | "FW";

export interface PlayerStats {
  apps: number;
  goals: number;
  assists: number;
  cleanSheets: number;
  yellow: number;
  red: number;
  saves: number;
  conceded: number;
  errors: number;
  keyPasses: number;
  tackles: number;
  minutes: number;
  shots: number;
  shotsOnTarget: number;
  xg: number;
  interceptions: number;
  fouls: number;
  offsides: number;
  dribbles: number;
  motm: number;
  plApps: number;
  plGoals: number;
  plAssists: number;
  plCleanSheets: number;
  ratingSum: number; // для расчёта avgRating
  avgRating: number; // ratingSum / apps
}

export type PlayerRole =
  | "GK" | "SW"
  | "CB" | "LB" | "RB" | "LWB" | "RWB"
  | "DM" | "CM" | "BBM" | "AM" | "LM" | "RM"
  | "LW" | "RW" | "SS" | "CF" | "TM" | "PF";

export interface Injury {
  type: "light" | "medium" | "severe";
  daysLeft: number;
  label: string;
}

export interface Player {
  id: string;
  name: string;
  position: Position;
  role?: PlayerRole;
  number?: number;
  age: number;
  nationality: string;
  potential?: number;
  value?: number;   // млн £
  wage?: number;    // тыс £/нед
  contractUntil?: string; // YYYY-MM-DD
  injury?: Injury | null;
  attack: number; // 0-99
  defense: number; // 0-99
  goalkeeping: number; // 0-99 (существенно только для GK)
  overall: number; // 0-99
  form: number; // 0.85–1.15
  fitness: number; // 0-100
  morale: number; // 0-100
  stats: PlayerStats;
}

export interface Team {
  id: string; // "man_city"
  name: string;
  shortName: string; // 3 буквы
  color: string; // клубный цвет для UI
  country?: string; // ENG / ESP / FRA / …
  /** уровень: топ-лиги (PL/LL/FL1), низшие дивизионы, прочая Европа */
  tier?: LeagueId | "CH" | "L1" | "ES2" | "FR2" | "DE2" | "IT2" | "PT2" | "SA2" | "TR2" | "BE2" | "NE2" | "GR2" | "UA2" | "PO2" | "SC2" | "SW2" | "EU";
  /** к какой из трёх симулируемых лиг относится клуб */
  league?: LeagueId;
  attack: number;
  midfield: number;
  defense: number;
  goalkeeping: number;
  reputation: number; // 0-100
  budget: number; // млн £
  stadium: string;
  players: Player[];
}

// ─── Движок матча ────────────────────────────────────────────────────────────

export type EventType =
  | "kickoff" | "goal" | "own_goal" | "post" | "save" | "miss" | "block"
  | "yellow" | "red" | "second_yellow" | "penalty" | "penalty_miss"
  | "injury" | "sub" | "offside" | "corner" | "ht" | "ft";

export interface MatchEvent {
  minute: number;
  type: EventType;
  teamId?: string;
  playerId?: string;
  assistId?: string;
  playerOutId?: string;
  playerInId?: string;
  note?: string;
  xg?: number;
  /** для сейвов: насколько сложный (0-1) */
  quality?: number;
}

export interface MinuteDelta {
  shotsH: number; shotsA: number;
  sotH: number; sotA: number;
  corH: number; corA: number;
  foulsH: number; foulsA: number;
  xgH: number; xgA: number;
  offH: number; offA: number;
  possH: number; possA: number;
}

export interface MinuteLog {
  minute: number;
  events: MatchEvent[];
  delta: MinuteDelta;
}

export interface MatchStats {
  possessionH: number; possessionA: number;
  shotsH: number; shotsA: number;
  sotH: number; sotA: number;
  cornersH: number; cornersA: number;
  foulsH: number; foulsA: number;
  yellowH: number; yellowA: number;
  redH: number; redA: number;
  savesH: number; savesA: number;
  xgH: number; xgA: number;
  offsidesH: number; offsidesA: number;
  penaltiesH: number; penaltiesA: number;
  passesH: number; passesA: number;
  passAccH: number; passAccA: number;
  bigChancesH: number; bigChancesA: number;
}

export interface MatchOptions {
  seed?: number;
  neutral?: boolean;
  /** кубковый матч: при ничьей пробивается серия пенальти */
  penaltiesOnDraw?: boolean;
  /** тактика хозяев/гостей: схема, стиль, стартовый состав */
  homeTactics?: TeamTactics;
  awayTactics?: TeamTactics;
  /** принудительный счёт: движок подгоняет ход матча под заданный результат */
  forceScore?: { h: number; a: number };
}

// ─── Тактика ─────────────────────────────────────────────────────────────────

export type Formation = "4-4-2" | "4-3-3" | "3-5-2" | "4-2-3-1" | "5-3-2" | "4-5-1" | "3-4-3";
export type PlayStyle = "attacking" | "balanced" | "defensive";

export interface TeamTactics {
  formation: Formation;
  style: PlayStyle;
  /** текстовый план на матч — движок оценивает его качество */
  textTactic?: string;
  starters: string[]; // 11 player ids
  captain: string;
  penaltyTaker: string;
  cornerTaker: string;
  freeKickTaker: string;
}

// ─── Трансферы ───────────────────────────────────────────────────────────────

export interface TransferRecord {
  id: string;
  date: string; // YYYY-MM-DD
  fromId: string | null; // null = свободный агент
  toId: string;
  playerIds: string[];
  playerNames: string[];
  fee: number; // млн £
  kind: "transfer" | "swap" | "free" | "loan" | "loan_return";
}

// ─── Аренды ──────────────────────────────────────────────────────────────────

/** Активная аренда: игрок играет за hostId, но принадлежит parentId */
export interface LoanRecord {
  id: string;
  playerId: string;
  playerName: string;
  parentId: string;   // клуб-владелец
  hostId: string;     // клуб аренды
  startDate: string;  // YYYY-MM-DD
  /** Дата возврата в календаре сезона: конец зимнего окна («1 января»)
   *  или конец сезона («1 июля») */
  endDate: string;
  /** номер сезона, в котором аренда завершается */
  endSeason: number;
  months: 6 | 12 | 24;
  fee: number; // млн £ — выплачено принимающим клубом владельцу
}

/** Вклад игрока в конкретном матче (для сезонной статистики) */
export interface PlayerMatchLine {
  goals: number;
  assists: number;
  saves: number;
  yellow: number;
  red: number;
  errors: number;
  keyPasses: number;
  tackles: number;
  interceptions: number;
  shots: number;
  shotsOnTarget: number;
  xg: number;
  dribbles: number;
  fouls: number;
  offsides: number;
  passes: number;
  passesOk: number;
  minutes: number;
  conceded: number;
  cleanSheet: boolean;
  teamId: string;
  rating: number;
}

export interface MatchResult {
  seed: number;
  homeId: string; awayId: string;
  homeName: string; awayName: string;
  homeShort: string; awayShort: string;
  homeColor: string; awayColor: string;
  homeScore: number; awayScore: number;
  totalMinutes: number;
  minutes: MinuteLog[];
  events: MatchEvent[];
  stats: MatchStats;
  playerRatings: Record<string, number>;
  playerMatchStats: Record<string, PlayerMatchLine>;
  /** топ-3 игрока матча по рейтингу */
  topPerformers: { playerId: string; teamId: string; rating: number }[];
  weather: "clear" | "rain" | "snow" | "wind";
  injuries: { playerId: string; teamId: string; type: "light" | "medium" | "severe"; days: number }[];
  lineups: Record<string, Player[]>;
  /** фактическая скамейка на момент матча */
  benches: Record<string, Player[]>;
  motm: string;
  /** серия пенальти (кубки): null если не было */
  pens: { h: number; a: number } | null;
}

// ─── Сезон, турниры, календарь ───────────────────────────────────────────────

export type LeagueId = "PL" | "LL" | "FL1" | "BL" | "SA" | "PT" | "SPL" | "CHA" | "TUR" | "BEL" | "NED" | "GRE" | "UKR" | "POL" | "SCO" | "SUI";
export type Competition =
  | "PL" | "LL" | "FL1" | "BL" | "SA" | "PT" | "SPL" | "CHA" | "TUR" | "BEL"
  | "NED" | "GRE" | "UKR" | "POL" | "SCO" | "SUI"  // чемпионаты
  | "UCL" | "UEL" | "UECL"        // еврокубки
  | "FA" | "EFL" | "CDR" | "CDF" | "DFB" | "CIT" | "TCP" | "KSC" | "TUC" | "BCB"
  | "DTC" | "GRC" | "UKC" | "PLC" | "SCC" | "SWC"  // кубки
  | "PPO"                         // плей-офф повышения (постсезон)
  | "FR";                         // товарищеский

export interface FixtureResult {
  h: number;
  a: number;
  pensH?: number;
  pensA?: number;
  /** счёт задан вручную пользователем */
  manual?: boolean;
  /** снапшот стартовых составов на момент игры — для детального повтора */
  lineupSnap?: Record<string, { id: string; name: string; position: string; attack: number; defense: number; goalkeeping: number; overall: number; age: number; fitness: number; morale: number; form: number; nationality: string }[]>;
  /** снапшот скамейки на момент матча */
  benchSnap?: Record<string, { id: string; name: string; position: string; attack: number; defense: number; goalkeeping: number; overall: number; age: number; fitness: number; morale: number; form: number; nationality: string }[]>;
  seed: number;
  scorers: { m: number; t: string; p: string; a?: string }[];
  /** построчная статистика игроков для раздела «Тур» */
  lines?: Record<string, { rating: number; goals: number; assists: number; minutes: number }>;
}

export interface Fixture {
  id: string;
  comp: Competition;
  stage: string; // "MD1".."MD38" | "LP1".."LP8" | "PO"|"R16"|"QF"|"SF"|"F" | "R64"...
  matchday: number;
  date: string; // YYYY-MM-DD
  homeId: string;
  awayId: string;
  neutral: boolean;
  tieId?: string; // для двухматчевых пар
  played: boolean;
  result: FixtureResult | null;
}

export interface Tie {
  id: string;
  comp: Competition;
  stage: string;
  aId: string;
  bId: string;
  legs: string[]; // fixture ids
  winnerId?: string;
  aggA?: number;
  aggB?: number;
}

export interface EuroState {
  participants: string[];
  pots: string[][];
  stage: "LP" | "PO" | "R16" | "QF" | "SF" | "F" | "DONE";
  ties: Tie[];
  eliminated: string[];
  winner?: string;
}

export interface CupState {
  participants: string[];
  stage: string; // текущий раунд
  rounds: { stage: string; fixtureIds: string[] }[];
  alive: string[];
  winner?: string;
}

export interface RatingChange {
  playerId: string;
  name: string;
  teamId: string;
  teamName: string;
  position: Position;
  age: number;
  oldOverall: number;
  newOverall: number;
  delta: number;
  avgRating: number;
  apps: number;
  minutes: number;
  goals: number;
  assists: number;
  reason: string;
}

export interface SeasonAwards {
  goldenBoot?: { playerId: string; name: string; teamName: string; value: number };
  playmaker?: { playerId: string; name: string; teamName: string; value: number };
  goldenGlove?: { playerId: string; name: string; teamName: string; value: number };
}

export interface PromotionChange {
  league: LeagueId;
  /** нижняя лига пары (куда уходят вылетевшие) */
  lower?: LeagueId | string;
  relegated: { id: string; name: string }[];
  promoted: { id: string; name: string }[];
  /** клубы, поднявшиеся через плей-офф (а не напрямую) */
  playoffPromoted?: { id: string; name: string }[];
  /** сетка плей-офф повышения: полуфиналы и финал со счётом */
  playoff?: {
    semis: { homeId: string; awayId: string; score: string }[];
    final: { homeId: string; awayId: string; score: string } | null;
    winner: string;
  } | null;
}

/** Связь двух лиг по повышению/вылету (АПЛ ↔ Чемпионшип) */
export interface LeagueLink {
  upper: LeagueId;
  lower: LeagueId;
}

/**
 * Плей-офф повышения одной связанной пары лиг (3-е–6-е места нижней).
 * Матчи — обычные фикстуры с comp "PPO" в season.fixtures: их можно
 * смотреть как полноценную карточку матча и менять счёт вручную.
 */
export interface PromotionPlayoff {
  id: string;
  upper: LeagueId;
  lower: LeagueId;
  /** id двух полуфинальных фикстур (3 vs 6 и 4 vs 5) */
  semiIds: string[];
  /** id финала — появляется, когда сыграны оба полуфинала */
  finalId?: string;
  /** победитель финала — обладатель путёвки */
  winner?: string;
  done: boolean;
}

export interface SeasonReport {
  seasonNumber: number;
  champions: Partial<Record<Competition, string>>;
  awards: SeasonAwards; // награды Премьер-Лиги (совместимость)
  awardsByLeague: Record<LeagueId, SeasonAwards>;
  finalTables: Record<LeagueId, { teamId: string; pos: number; pts: number }[]>;
  improved: RatingChange[];
  declined: RatingChange[];
  all: RatingChange[];
  finalTable: { teamId: string; pos: number; pts: number }[];
  leagues: LeagueId[];
}

export interface SeasonState {
  startDate: string;
  fixtures: Fixture[];
  ucl: EuroState;
  uel: EuroState;
  uecl: EuroState;  // Лига конференций
  fa: CupState;
  efl: CupState;
  cdr: CupState;  // Copa del Rey
  cdf: CupState;  // Coupe de France
  dfb: CupState;  // DFB-Pokal
  cit: CupState;  // Coppa Italia
  tcp: CupState;  // Taça de Portugal
  ksc: CupState;  // King's Cup
  tuc: CupState;  // Turkish Cup
  bcb: CupState;  // Belgian Cup
  dtc: CupState;  // Dutch Cup (KNVB)
  grc: CupState;  // Greek Cup
  ukc: CupState;  // Ukrainian Cup
  plc: CupState;  // Polish Cup
  scc: CupState;  // Scottish Cup
  swc: CupState;  // Swiss Cup
  finished: boolean;
  champions: Partial<Record<Competition, string>>;
  /** плей-офф повышения (создаются после завершения сезона) */
  playoffs?: PromotionPlayoff[];
}

// ─── Слоты сохранений ────────────────────────────────────────────────────────

export interface Slot {
  slotId: string;
  createdAt: string;
  seasonNumber: number;
  currentDate: string; // YYYY-MM-DD
  seed: number;
  /** какие чемпионаты симулируются в этом слоте */
  selectedLeagues: LeagueId[];
  /** составы еврокубков (36 id каждый) — авто или заданы вручную */
  uclTeams: string[];
  uelTeams: string[];
  ueclTeams: string[];
  /** связанные лиги с реальным повышением/вылетом (АПЛ ↔ Чемпионшип) */
  linkedLeagues: LeagueLink[];
  /** плей-офф повышения: 3-е–6-е места нижней лиги разыгрывают третью путёвку */
  promotionPlayoff: boolean;
  /** настройки перехода к следующему сезону */
  euroAuto: boolean;
  euroDropToUel: boolean;
  autoPromotion: boolean;
  previousSeasonResults?: Record<string, string[]>; // league → порядок клубов
  /** итоги последнего межсезонья: кто вылетел, кто поднялся, сетка плей-офф */
  lastPromotions?: PromotionChange[];
  teams: Record<string, Team>; // копия базы + клубы турниров
  tactics: Record<string, TeamTactics>; // схема/стиль/состав каждого клуба
  transfers: TransferRecord[]; // история трансферов сезона
  loans: LoanRecord[]; // активные аренды (переживают смену сезона)
  freeAgents: Player[]; // свободные агенты
  season: SeasonState;
  history: SeasonReport[];
}

export interface SlotMeta {
  slotId: string;
  createdAt: string;
  seasonNumber: number;
  currentDate: string;
  finished: boolean;
  matchesPlayed: number;
  matchesTotal: number;
  leagues: LeagueId[];
}

// ─── Таблицы ─────────────────────────────────────────────────────────────────

export interface TableRow {
  teamId: string;
  p: number; w: number; d: number; l: number;
  gf: number; ga: number; gd: number; pts: number;
  form: string[]; // последние 5: W/D/L
}
