// ─── Пересчёт рейтингов по итогам сезона (все игроки выбранных лиг) ──────────
import type { LeagueId, Player, RatingChange, SeasonAwards, SeasonReport, Slot, Team } from "../types";
import { buildTable, leaderboard, LEAGUE_CFG, LEAGUE_IDS, planPromotionPlayoffs } from "./season";

const BASELINE = 6.5;
const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

function ageFactor(age: number): number {
  if (age < 23) return 2.5;
  if (age <= 29) return 1.5;
  if (age <= 33) return 0.8;
  return 0.3;
}

/** Максимальный рост и спад по возрасту */
function deltaBounds(age: number, guaranteed: number): [number, number] {
  const hi = age < 23 ? 5 : age <= 29 ? 3 : age <= 33 ? 2 : 1;
  const lo = age < 23 ? -4 : age <= 29 ? -4 : -3;
  // гарантированный бонус не режется возрастным лимитом
  return [lo, Math.max(hi, guaranteed)];
}

/** Показатель сезона по позиции игрока */
export function performanceScore(p: Player): number {
  const s = p.stats;
  if (!s.apps) return BASELINE - 0.4;
  const perApp = (v: number) => v / Math.max(1, s.apps);
  switch (p.position) {
    case "FW":
      return s.avgRating + s.goals * 0.03 + s.assists * 0.02;
    case "MF":
      return s.avgRating + s.goals * 0.02 + s.assists * 0.03 + s.keyPasses * 0.01;
    case "DF":
      return s.avgRating + s.cleanSheets * 0.1 - perApp(s.conceded) * 0.02 * s.apps * 0.1 - s.errors * 0.15;
    case "GK":
    default: {
      // Вратари: показатели считаем ЗА МАТЧ, а не суммой за сезон.
      // Раньше «сухие» давали cleanSheets * 0.15, и любой основной вратарь
      // с 12-15 «сухарями» получал гарантированные +2/+3 каждый сезон.
      const apps = Math.max(1, s.apps);
      const csRate = s.cleanSheets / apps;   // доля сухих матчей (0..1)
      const savesPm = s.saves / apps;        // сейвы за матч
      const concPm = s.conceded / apps;      // пропущенные за матч
      return s.avgRating
        + (csRate - 0.25) * 1.4              // 25% сухих — нейтрально, 50% — +0.35
        + Math.min(0.25, savesPm * 0.05)     // вратарь-трудяга: до +0.25
        - Math.max(0, concPm - 1.2) * 0.4;   // много пропускает — минус
    }
  }
}

export interface UpdateResult {
  improved: RatingChange[];
  declined: RatingChange[];
  all: RatingChange[];
}

/**
 * Пересчитывает рейтинги ВСЕХ игроков выбранных лиг.
 * Игроки без практики получают лёгкий регресс, звёзды сезона — гарантированный плюс.
 */
export function updateRatings(slot: Slot, leaguesArg?: LeagueId[]): UpdateResult {
  const leagues = leaguesArg?.length ? leaguesArg : slot.selectedLeagues?.length ? slot.selectedLeagues : LEAGUE_IDS;
  const all: RatingChange[] = [];

  for (const team of Object.values(slot.teams) as Team[]) {
    const lg = team.league;
    if (!lg || !leagues.includes(lg)) continue;

    for (const p of team.players) {
      const s = p.stats;
      const score = performanceScore(p);
      let delta = (score - BASELINE) * ageFactor(p.age);
      const reasons: string[] = [];
      // порог, ниже которого нельзя опустить рост при особых достижениях
      const guaranteedMin =
        s.apps >= 5 && s.avgRating > 8.0 ? 2
        : p.position === "GK" && s.apps >= 20 && s.cleanSheets / Math.max(1, s.apps) >= 0.45 ? 1
        : p.position === "DF" && s.cleanSheets >= 14 ? 1 : 0;

      // ── модификаторы ──
      // потенциал ограничивает рост
      const potential = p.potential ?? Math.min(99, p.overall + (p.age < 23 ? 8 : p.age < 27 ? 4 : 1));
      if (delta > 0 && p.overall >= potential) {
        delta = Math.min(delta, 0.4);
        reasons.push("достигнут потолок");
      }
      // возрастной спад
      if (p.age >= 33 && delta > -0.2) {
        delta -= 0.6;
        reasons.push("возрастной спад");
      }
      // мало практики
      if (s.apps <= 3) {
        delta = Math.min(delta, -1);
        reasons.push(p.injury ? "сезон пропущен из-за травмы" : "без игровой практики");
      } else if (s.apps < 10) {
        delta = Math.min(delta, 1);
        reasons.push("мало игрового времени");
      }

      // ── гарантированные пороги (применяются последними) ──
      if (s.apps >= 5 && s.avgRating < 5.5) {
        delta = Math.min(delta, -1);
        reasons.push("провальный сезон");
      }
      if (s.apps >= 5 && s.avgRating > 8.0) {
        delta = Math.max(delta, 2);
        reasons.push("выдающийся сезон");
      }
      if (p.position === "GK" && s.apps >= 20 && s.cleanSheets / Math.max(1, s.apps) >= 0.45) {
        delta = Math.max(delta, 1);
        reasons.push(`сухой в ${s.cleanSheets} из ${s.apps} матчей`);
      }
      if (p.position === "DF" && s.cleanSheets >= 14) {
        delta = Math.max(delta, 1);
        reasons.push("надёжная оборона");
      }

      const [lo, hi] = deltaBounds(p.age, guaranteedMin);
      // вратари растут медленнее полевых: +3 — потолок даже для молодой звезды,
      // +2 — для игрока в расцвете. Иначе основные вратари получали +2/+3 ежегодно.
      const hiCap = p.position === "GK" ? Math.min(hi, p.age < 23 ? 3 : 2) : hi;
      delta = clamp(delta, lo, hiCap);

      const oldOverall = p.overall;
      const newOverall = Math.round(clamp(oldOverall + delta, 40, 99));
      const realDelta = newOverall - oldOverall;

      if (realDelta !== 0) {
        const k = realDelta;
        if (p.position === "GK") {
          p.goalkeeping = Math.round(clamp(p.goalkeeping + k, 40, 99));
          p.defense = Math.round(clamp(p.defense + k * 0.3, 20, 99));
        } else if (p.position === "DF") {
          p.defense = Math.round(clamp(p.defense + k, 30, 99));
          p.attack = Math.round(clamp(p.attack + k * 0.5, 20, 99));
        } else if (p.position === "MF") {
          p.attack = Math.round(clamp(p.attack + k * 0.8, 20, 99));
          p.defense = Math.round(clamp(p.defense + k * 0.6, 20, 99));
        } else {
          p.attack = Math.round(clamp(p.attack + k, 30, 99));
          p.defense = Math.round(clamp(p.defense + k * 0.3, 15, 99));
        }
      }
      p.overall = newOverall;
      if (!p.potential || p.potential < newOverall) p.potential = newOverall;

      if (!reasons.length) {
        reasons.push(
          realDelta > 0 ? "прогресс по статистике" : realDelta < 0 ? "спад по статистике" : "без изменений"
        );
      }

      all.push({
        playerId: p.id, name: p.name, teamId: team.id, teamName: team.name,
        position: p.position, age: p.age,
        oldOverall, newOverall, delta: realDelta,
        avgRating: s.avgRating, apps: s.apps, minutes: s.minutes,
        goals: s.goals, assists: s.assists,
        reason: reasons.join(", "),
      });
    }
  }

  const rated = all.filter((c) => c.apps >= 3);
  const improved = [...rated].sort((a, b) => b.delta - a.delta || b.avgRating - a.avgRating).slice(0, 20);
  const declined = [...rated].sort((a, b) => a.delta - b.delta || a.avgRating - b.avgRating).slice(0, 20);
  return { improved, declined, all };
}

function award(list: ReturnType<typeof leaderboard>) {
  const top = list[0];
  return top ? { playerId: top.playerId, name: top.name, teamName: top.teamName, value: top.value } : undefined;
}

/** Полный отчёт по сезону + применение новых рейтингов */
export function finishSeason(slot: Slot): SeasonReport {
  const leagues = slot.selectedLeagues?.length ? slot.selectedLeagues : LEAGUE_IDS;
  const awardsByLeague = {} as Record<LeagueId, SeasonAwards>;
  const finalTables = {} as Record<LeagueId, { teamId: string; pos: number; pts: number }[]>;

  for (const lid of leagues) {
    awardsByLeague[lid] = {
      goldenBoot: award(leaderboard(slot, "goals", lid, 1)),
      playmaker: award(leaderboard(slot, "assists", lid, 1)),
      goldenGlove: award(leaderboard(slot, "cleanSheets", lid, 1)),
    };
    const ids = Object.values(slot.teams).filter((t) => t.league === lid).map((t) => t.id);
    finalTables[lid] = buildTable(slot.season.fixtures, ids, LEAGUE_CFG[lid].comp)
      .map((r, i) => ({ teamId: r.teamId, pos: i + 1, pts: r.pts }));
  }

  const { improved, declined, all } = updateRatings(slot, leagues);

  const report: SeasonReport = {
    seasonNumber: slot.seasonNumber,
    champions: { ...slot.season.champions },
    awards: awardsByLeague[leagues[0]],
    awardsByLeague,
    finalTables,
    improved,
    declined,
    all,
    finalTable: finalTables[leagues[0]],
    leagues,
  };
  slot.history.push(report);
  slot.season.finished = true;

  slot.previousSeasonResults = {};
  for (const lid of leagues) slot.previousSeasonResults[lid] = finalTables[lid].map((r) => r.teamId);
  // постсезон: планируем матчи плей-офф повышения (идемпотентно)
  planPromotionPlayoffs(slot);
  return report;
}

/** Отчёт об изменениях рейтингов в CSV */
export function ratingsToCsv(changes: RatingChange[]): string {
  const head = "Игрок;Клуб;Поз;Возраст;Матчи;Минуты;Голы;Пасы;Рейтинг;Было;Стало;Дельта;Причина";
  const rows = changes.map((c) =>
    [c.name, c.teamName, c.position, c.age, c.apps, c.minutes, c.goals, c.assists,
     c.avgRating.toFixed(2), c.oldOverall, c.newOverall, (c.delta > 0 ? "+" : "") + c.delta, c.reason]
      .join(";")
  );
  return [head, ...rows].join("\n");
}
