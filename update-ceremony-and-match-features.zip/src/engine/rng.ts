// ─── Воспроизводимый PRNG (mulberry32) ───────────────────────────────────────
// Один и тот же seed → одна и та же последовательность → одинаковый матч.

export type Rng = () => number;

export function mulberry32(seed: number): Rng {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function makeRng(seed: number) {
  const next = mulberry32(seed);
  return {
    next, // 0..1
    range: (min: number, max: number) => min + next() * (max - min),
    int: (min: number, max: number) => Math.floor(min + next() * (max - min + 1)),
    chance: (p: number) => next() < p,
    pick<T>(arr: T[]): T {
      return arr[Math.floor(next() * arr.length)];
    },
    /** взвешенный выбор: items + функция веса */
    weighted<T>(items: T[], weight: (item: T) => number): T {
      let total = 0;
      for (const it of items) total += Math.max(0, weight(it));
      if (total <= 0) return items[Math.floor(next() * items.length)];
      let roll = next() * total;
      for (const it of items) {
        roll -= Math.max(0, weight(it));
        if (roll <= 0) return it;
      }
      return items[items.length - 1];
    },
  };
}

export type RngApi = ReturnType<typeof makeRng>;
