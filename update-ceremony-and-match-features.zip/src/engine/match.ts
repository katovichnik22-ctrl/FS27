// ─── Движок матча в стиле Football Manager ───────────────────────────────────
// Поминутная модель владения: каждая минута — цепочка индивидуальных действий
// (пас → дриблинг → удар / отбор / перехват / фол). xG считается по дистанции,
// углу, давлению защитников и классу бьющего. Движок НИКОГДА не мутирует
// входные команды: все вклады пишутся в локальные структуры.

import type {
  MatchEvent, MatchOptions, MatchResult, MatchStats, MinuteDelta, MinuteLog,
  Player, PlayerMatchLine, Team, TeamTactics,
} from "../types";

declare module "../types" {
  interface MatchOptions {
    /** снапшот стартовых составов (для воспроизведения после изменения качества игроков) */
    lineupsCache?: Record<string, { id: string; attack: number; defense: number; goalkeeping: number; overall: number; age: number; fitness: number; morale: number; form: number; position: Player["position"]; name: string; nationality: string }[]>;
    /** снапшот скамейки — чтобы замены при повторе были те же */
    benchCache?: Record<string, { id: string; attack: number; defense: number; goalkeeping: number; overall: number; age: number; fitness: number; morale: number; form: number; position: Player["position"]; name: string; nationality: string }[]>;
  }
}
import { makeRng } from "./rng";
import { FORMATIONS, tacticAnalysis, tacticMultipliers } from "./tactics";

// ─── Вспомогательное ─────────────────────────────────────────────────────────

const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 70);
const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

/** Позиционные веса: кто чаще получает мяч в атакующей фазе */
const TOUCH_W: Record<string, number> = { GK: 0.35, DF: 1.0, MF: 1.8, FW: 1.5 };
/** Кто чаще оказывается в завершающей стадии */
const SHOOT_W: Record<string, number> = { GK: 0.01, DF: 0.25, MF: 1.2, FW: 4.0 };
const ASSIST_W: Record<string, number> = { GK: 0.02, DF: 0.5, MF: 2.2, FW: 1.5 };
/** Интенсивность работы по позициям (усталость) */
const WORK: Record<string, number> = { GK: 0.35, DF: 0.85, MF: 1.15, FW: 1.0 };

export type Weather = "clear" | "rain" | "snow" | "wind";
const WEATHER_EFFECT: Record<Weather, { pass: number; shot: number; gk: number }> = {
  clear: { pass: 1.0, shot: 1.0, gk: 1.0 },
  rain: { pass: 0.96, shot: 0.97, gk: 0.95 },
  snow: { pass: 0.92, shot: 0.93, gk: 0.93 },
  wind: { pass: 0.95, shot: 0.94, gk: 0.97 },
};

/** Стартовый XI: заданный тактикой состав, иначе — сильнейшие по классу и свежести */
export function pickLineup(team: Team, tactics?: TeamTactics): Player[] {
  const healthy = (p: Player) => !p.injury || p.injury.daysLeft <= 0;
  if (tactics?.starters?.length) {
    const byId = new Map(team.players.map((p) => [p.id, p]));
    const xi = tactics.starters.map((id) => byId.get(id)).filter((p): p is Player => !!p && healthy(p));
    if (xi.length >= 11) return xi.slice(0, 11);
    const rest = team.players.filter((p) => healthy(p) && !xi.includes(p)).sort((a, b) => b.overall - a.overall);
    return [...xi, ...rest].slice(0, 11);
  }
  return autoLineup(team);
}

function autoLineup(team: Team): Player[] {
  const healthy = team.players.filter((p) => !p.injury || p.injury.daysLeft <= 0);
  // состав определяется классом игроков — чутьё на запасных не входит в рандом,
  // поэтому матч воспроизводим даже при изменении свежести/формы после игры
  const byOvr = [...(healthy.length >= 11 ? healthy : team.players)].sort((a, b) => {
    const d = b.overall - a.overall;
    return d !== 0 ? d : a.id < b.id ? -1 : 1;
  });
  const take = (pos: string, n: number) => byOvr.filter((p) => p.position === pos).slice(0, n);
  const xi = [...take("GK", 1), ...take("DF", 4), ...take("MF", 3), ...take("FW", 3)];
  for (const p of byOvr) {
    if (xi.length >= 11) break;
    if (!xi.includes(p) && p.position !== "GK") xi.push(p);
  }
  return xi.slice(0, 11);
}

function emptyDelta(): MinuteDelta {
  return {
    shotsH: 0, shotsA: 0, sotH: 0, sotA: 0, corH: 0, corA: 0,
    foulsH: 0, foulsA: 0, xgH: 0, xgA: 0, offH: 0, offA: 0, possH: 0, possA: 0,
  };
}

// ─── Состояния ───────────────────────────────────────────────────────────────

interface SimPlayer {
  p: Player;
  stamina: number;   // 0-100 внутри матча
  out: "none" | "red" | "injury";
  minutes: number;
  yellow: boolean;
}

interface Line {
  goals: number; assists: number; saves: number; yellow: number; red: number;
  errors: number; keyPasses: number; tackles: number; interceptions: number;
  shots: number; sot: number; xg: number; dribbles: number; fouls: number;
  offsides: number; passes: number; passesOk: number; minutes: number;
  teamId: string;
}

const blankLine = (teamId: string): Line => ({
  goals: 0, assists: 0, saves: 0, yellow: 0, red: 0, errors: 0, keyPasses: 0,
  tackles: 0, interceptions: 0, shots: 0, sot: 0, xg: 0, dribbles: 0, fouls: 0,
  offsides: 0, passes: 0, passesOk: 0, minutes: 0, teamId,
});

interface Side {
  team: Team;
  /** фактический стартовый XI и скамейка на момент матча (для снапшота) */
  startXI: Player[];
  startBench: Player[];
  tac?: TeamTactics;
  xi: SimPlayer[];
  bench: Player[];
  subsUsed: number;
  reds: number;
  conceded: number;
  goalsFor: number;
  /** множители схемы и стиля */
  mAtk: number; mDef: number; mMid: number;
  /** доля атак через центр (3-5-2 — центр, 4-3-3 — фланги) */
  central: number;
  home: boolean;
  /** эффекты текстового плана */
  press: number;      // −1…1
  counter: number;    // 0…1
  setPiece: number;   // 0…1
  discipline: number; // 0…1
  planScore: number;  // 0…100
}

// ─── Основная функция ────────────────────────────────────────────────────────

export function simulateMatch(homeTeam: Team, awayTeam: Team, opts: MatchOptions = {}): MatchResult {
  const seed = opts.seed ?? Math.floor(Math.random() * 2 ** 31);
  const rng = makeRng(seed);
  const neutral = opts.neutral ?? false;

  const weather: Weather = rng.next() < 0.7 ? "clear" : rng.next() < 0.5 ? "rain" : rng.next() < 0.5 ? "wind" : "snow";
  const wx = WEATHER_EFFECT[weather];

  const lines: Record<string, Line> = {};
  const injuries: MatchResult["injuries"] = [];

  const mkSide = (team: Team, tac: TeamTactics | undefined, home: boolean): Side => {
    // lineupCache: снапшот составов ДО матча — воспроизводимость не зависит
    // от свежести/формы, накопленных после игры (только от RNG-потока)
    // Snapshot-first: если есть кэш, устанавливаем не только старт, но и
    // атрибуты из момента матча (сила не «плывёт» при изменении формы/морали).
    const cache = opts.lineupsCache?.[team.id];
    let xiPlayers: Player[];
    if (cache?.length) {
      xiPlayers = cache.map((sp) => {
        const full = team.players.find((p) => p.id === sp.id) ?? sp;
        return {
          ...(full as Player),
          attack: sp.attack, defense: sp.defense, goalkeeping: sp.goalkeeping, overall: sp.overall,
          age: sp.age, fitness: sp.fitness, morale: sp.morale, form: sp.form,
          injury: null,
        };
      });
    } else {
      xiPlayers = pickLineup(team, tac);
    }
    const ids = new Set(xiPlayers.map((p) => p.id));
    const mul = tacticMultipliers(tac);
    const txt = tacticAnalysis(tac);
    const shape = FORMATIONS[tac?.formation ?? "4-3-3"];
    // центральность атак: много полузащитников и мало защитников → игра через центр
    const central = clamp(0.35 + (shape.mf - 4) * 0.08 + (3 - shape.df) * 0.05, 0.25, 0.7);
    for (const p of xiPlayers) lines[p.id] = blankLine(team.id);
    const benchList = cache?.length
      ? (opts.benchCache?.[team.id] ?? []).map((sp) => {
          const full = team.players.find((p) => p.id === sp.id);
          return full
            ? ({ ...full, attack: sp.attack, defense: sp.defense, goalkeeping: sp.goalkeeping,
                 overall: sp.overall, age: sp.age, fitness: sp.fitness, morale: sp.morale,
                 form: sp.form, injury: null } as Player)
            : (sp as unknown as Player);
        })
      : team.players
          .filter((p) => !ids.has(p.id) && (!p.injury || p.injury.daysLeft <= 0))
          .sort((a, b) => (b.overall - a.overall) || (a.id < b.id ? -1 : 1))
          .slice(0, 9);
    return {
      team, tac,
      startXI: xiPlayers,
      startBench: benchList,
      xi: xiPlayers.map((p) => ({ p, stamina: clamp(p.fitness, 20, 100), out: "none", minutes: 0, yellow: false })),
      bench: benchList,
      subsUsed: 0, reds: 0, conceded: 0, goalsFor: 0,
      mAtk: mul.atk, mDef: mul.def, mMid: mul.mid,
      central, home,
      press: txt?.pressBias ?? 0,
      counter: txt?.counterBias ?? 0,
      setPiece: txt?.setPieceBias ?? 0,
      discipline: txt?.disciplineBias ?? 0,
      planScore: txt?.score ?? 0,
    };
  };

  const H = mkSide(homeTeam, opts.homeTactics, true);
  const A = mkSide(awayTeam, opts.awayTactics, false);

  // ── Принудительный счёт: цель по голам для каждой стороны ──
  const force = opts.forceScore ?? null;
  const targetOf = (s: Side) => (force ? (s.home ? force.h : force.a) : null);
  /** Можно ли ещё забивать этой команде */
  const needsGoal = (s: Side) => {
    const t = targetOf(s);
    return t === null ? null : t - s.goalsFor;
  };

  const active = (s: Side) => s.xi.filter((x) => x.out === "none");
  const gkOf = (s: Side) => active(s).find((x) => x.p.position === "GK") ?? active(s)[0];

  /** «Сила на текущей минуте» с учётом формы, морали и усталости */
  const eff = (sp: SimPlayer, kind: "atk" | "def") => {
    const base = kind === "atk" ? sp.p.attack : sp.p.defense;
    const fatigue = sp.stamina < 40 ? 0.8 : sp.stamina < 60 ? 0.9 : sp.stamina < 80 ? 0.97 : 1.0;
    // Мораль — вспомогательный фактор (±3%), а не решающий. Раньше размах ±6%
    // запускал спираль: поражение от гранда в Европе рушило мораль, команда
    // слабела и валилась в лиге. Класс игроков должен решать.
    const morale = 0.965 + (sp.p.morale / 100) * 0.06;
    return base * sp.p.form * fatigue * morale;
  };

  const teamPower = (s: Side, kind: "atk" | "def" | "mid") => {
    const act = active(s);
    if (!act.length) return 50;
    if (kind === "mid") {
      const mf = act.filter((x) => x.p.position === "MF");
      return avg((mf.length ? mf : act).map((x) => eff(x, "atk") * 0.5 + eff(x, "def") * 0.5)) * s.mMid;
    }
    if (kind === "atk") {
      const fw = act.filter((x) => x.p.position === "FW");
      const mf = act.filter((x) => x.p.position === "MF");
      return (avg(fw.map((x) => eff(x, "atk"))) * 0.55 + avg(mf.map((x) => eff(x, "atk"))) * 0.45) * s.mAtk;
    }
    const df = act.filter((x) => x.p.position === "DF");
    const mf = act.filter((x) => x.p.position === "MF");
    const gk = gkOf(s);
    return (avg(df.map((x) => eff(x, "def"))) * 0.55 + avg(mf.map((x) => eff(x, "def"))) * 0.2 +
      (gk?.p.goalkeeping ?? 70) * 0.25) * s.mDef;
  };

  // ─── Статистика матча ──
  const stats: MatchStats = {
    possessionH: 0, possessionA: 0, shotsH: 0, shotsA: 0, sotH: 0, sotA: 0,
    cornersH: 0, cornersA: 0, foulsH: 0, foulsA: 0, yellowH: 0, yellowA: 0,
    redH: 0, redA: 0, savesH: 0, savesA: 0, xgH: 0, xgA: 0,
    offsidesH: 0, offsidesA: 0, penaltiesH: 0, penaltiesA: 0,
    passesH: 0, passesA: 0, passAccH: 0, passAccA: 0, bigChancesH: 0, bigChancesA: 0,
  };

  const minutes: MinuteLog[] = [];
  const flatEvents: MatchEvent[] = [];
  let minute = 0;
  let possTicksH = 0, possTicksA = 0;

  const push = (log: MatchEvent[], ev: MatchEvent) => { log.push(ev); flatEvents.push(ev); };

  // ─── Выбор игрока ──
  const pickBy = (s: Side, weights: Record<string, number>, bonus: (x: SimPlayer) => number = () => 1) => {
    const pool = active(s);
    if (!pool.length) return null;
    return rng.weighted(pool, (x) => (weights[x.p.position] ?? 1) * bonus(x) * (0.5 + 0.5 * x.stamina / 100));
  };

  // ─── Расчёт xG ──
  function computeXg(shooter: SimPlayer, att: Side, def: Side, kind: "open" | "counter" | "header" | "setpiece" | "penalty") {
    if (kind === "penalty") return 0.78;
    // дистанция: форварды бьют ближе, защитники — издалека
    const posBias = shooter.p.position === "FW" ? 0 : shooter.p.position === "MF" ? 5 : 10;
    const distance = clamp(6 + Math.pow(rng.next(), 0.8) * 17 + posBias, 5, 34);
    const angle = rng.range(0.3, 1.0); // 1 = по центру ворот
    const setBonus = kind === "setpiece" || kind === "header" ? 1 + att.setPiece * 0.3 : 1;
    const base = (kind === "counter" ? 0.44 : kind === "header" ? 0.24 : kind === "setpiece" ? 0.155 : 0.34) * setBonus;
    const distanceFactor = Math.exp(-0.072 * (distance - 6));
    const angleFactor = 0.5 + 0.5 * angle;
    // давление защиты: чем сильнее оборона соперника, тем меньше свободы
    let pressure = clamp(1.42 - teamPower(def, "def") / 200, 0.72, 1.2);
    if (kind === "setpiece" || kind === "header") pressure *= 1 - def.setPiece * 0.16;
    const skill = 0.72 + (eff(shooter, "atk") / 100) * 0.42;
    const xg = base * distanceFactor * angleFactor * pressure * skill * wx.shot;
    return clamp(xg, 0.012, 0.88);
  }

  /** Перепасовка в середине поля — наполняет статистику передач */
  function buildUp(att: Side, def: Side, delta: MinuteDelta) {
    const isHome = att.home;
    const n = rng.int(3, 8);
    for (let i = 0; i < n; i++) {
      const p = pickBy(att, TOUCH_W);
      if (!p) return;
      const l = (lines[p.p.id] ??= blankLine(att.team.id));
      l.passes++;
      if (isHome) stats.passesH++; else stats.passesA++;
      const ok = rng.chance(clamp(0.74 + (p.p.overall - 72) * 0.004 * wx.pass, 0.5, 0.95));
      if (ok) {
        l.passesOk++;
        if (isHome) stats.passAccH++; else stats.passAccA++;
      } else {
        const st = pickBy(def, { GK: 0.05, DF: 1.3, MF: 1.5, FW: 0.5 });
        if (st) {
          const dl = (lines[st.p.id] ??= blankLine(def.team.id));
          if (rng.chance(0.45)) dl.tackles++; else dl.interceptions++;
        }
        return;
      }
    }
    void delta;
  }

  // ─── Один эпизод владения ──
  /**
   * Срезка атаки при крупном счёте. Чем меньше разрыв в классе команд, тем
   * жёстче глушим: разгром равного соперника — редкость, разгром слабого —
   * закономерность. Так 6:2 в матче Фиорентина — Барселона больше не случится,
   * а Ман Сити — Халл 5:0 останется возможным.
   */
  const powerGapH = (teamPower(H, "atk") + teamPower(H, "def")) - (teamPower(A, "atk") + teamPower(A, "def"));
  const leadFactor = (lead: number, gap: number) => {
    if (lead < 2) return 1;
    // Жёсткий потолок: при 4+ голах превосходства темп резко падает.
    // Реальная статистика: матчи с разницей 5+ — около 2.5% всех игр.
    if (lead >= 5) return 0.04;
    if (lead === 4) return 0.10;
    // насколько перевес «заслужен» классом: 0 — равные, 1 — пропасть
    const justified = clamp(gap / 24, 0, 1);
    const base = lead >= 3 ? 0.26 : 0.62;
    // сильный против слабого почти не сбавляет, равный — заметно бережёт игру
    return clamp(base + justified * (0.88 - base), 0.12, 0.90);
  };

  function possession(att: Side, def: Side, evLog: MatchEvent[], delta: MinuteDelta) {
    const isHome = att.home;
    // разница в счёте × разрыв в классе: лидирующая команда реже доводит до ворот
    const lead = att.goalsFor - def.goalsFor;
    const gap = isHome ? powerGapH : -powerGapH;
    const leadK = leadFactor(lead, gap);
    const line = (id: string) => (lines[id] ??= blankLine(att.team.id));

    // 1) розыгрыш: серия пасов, каждый может быть перехвачен
    let carrier = pickBy(att, TOUCH_W);
    if (!carrier) return;
    const passesToShot = rng.int(1, 4);
    let creator: SimPlayer | null = null;

    for (let i = 0; i < passesToShot; i++) {
      const passQ = (eff(carrier, "atk") * 0.5 + carrier.p.overall * 0.5) * wx.pass * att.mMid / 100;
      const pressQ = teamPower(def, "def") / 100;
      const ok = rng.chance(clamp(0.62 + (passQ - pressQ) * 0.42, 0.35, 0.93));
      line(carrier.p.id).passes++;
      if (isHome) stats.passesH++; else stats.passesA++;
      if (!ok) {
        // перехват или отбор соперника
        // высокий прессинг из плана — отбор чаще выше по полю
        const pressW = def.press > 0
          ? { GK: 0.05, DF: 1.2, MF: 1.6, FW: 0.4 + def.press * 0.9 }
          : { GK: 0.05, DF: 1.6, MF: 1.4, FW: 0.4 };
        const stealer = pickBy(def, pressW, (x) => eff(x, "def") / 70);
        if (stealer) {
          const l = (lines[stealer.p.id] ??= blankLine(def.team.id));
          if (rng.chance(0.55)) { l.tackles++; } else { l.interceptions++; }
        }
        return;
      }
      line(carrier.p.id).passesOk++;
      if (isHome) stats.passAccH++; else stats.passAccA++;

      // дриблинг
      if (rng.chance(0.22)) {
        const dribOk = rng.chance(clamp(0.35 + (eff(carrier, "atk") - teamPower(def, "def")) / 160, 0.15, 0.8));
        if (dribOk) line(carrier.p.id).dribbles++;
        else {
          const stealer = pickBy(def, { GK: 0.05, DF: 1.8, MF: 1.2, FW: 0.3 }, (x) => eff(x, "def") / 70);
          if (stealer) (lines[stealer.p.id] ??= blankLine(def.team.id)).tackles++;
          return;
        }
      }

      creator = carrier;
      const next = pickBy(att, i >= passesToShot - 2 ? SHOOT_W : TOUCH_W);
      if (next) carrier = next;
    }

    // 2) офсайд
    if (rng.chance(0.07)) {
      line(carrier.p.id).offsides++;
      if (isHome) { delta.offH++; stats.offsidesH++; } else { delta.offA++; stats.offsidesA++; }
      push(evLog, { minute, type: "offside", teamId: att.team.id, playerId: carrier.p.id });
      return;
    }

    // 3) фол соперника в опасной зоне → пенальти или штрафной
    if (rng.chance(0.05)) {
      const fouler = pickBy(def, { GK: 0.1, DF: 1.8, MF: 1.1, FW: 0.3 });
      if (fouler) {
        (lines[fouler.p.id] ??= blankLine(def.team.id)).fouls++;
        if (isHome) { delta.foulsA++; stats.foulsA++; } else { delta.foulsH++; stats.foulsH++; }
        if (rng.chance(0.085)) {
          // ПЕНАЛЬТИ
          if (isHome) stats.penaltiesH++; else stats.penaltiesA++;
          const takerId = att.tac?.penaltyTaker;
          const taker = active(att).find((x) => x.p.id === takerId) ?? pickBy(att, SHOOT_W)!;
          const gk = gkOf(def);
          const needPen = needsGoal(att);
          const scored = needPen !== null
            ? needPen > 0
            : rng.chance(clamp(0.79 + (eff(taker, "atk") - 80) * 0.003 - ((gk?.p.goalkeeping ?? 70) - 80) * 0.0035, 0.55, 0.92));
          line(taker.p.id).shots++;
          line(taker.p.id).xg += 0.78;
          if (isHome) { delta.shotsH++; delta.xgH += 0.78; stats.shotsH++; stats.bigChancesH++; }
          else { delta.shotsA++; delta.xgA += 0.78; stats.shotsA++; stats.bigChancesA++; }
          if (scored) {
            line(taker.p.id).goals++;
            line(taker.p.id).sot++;
            att.goalsFor++; def.conceded++;
            if (isHome) { delta.sotH++; stats.sotH++; } else { delta.sotA++; stats.sotA++; }
            push(evLog, { minute, type: "penalty", teamId: att.team.id, playerId: taker.p.id, xg: 0.78 });
          } else {
            if (gk) {
              (lines[gk.p.id] ??= blankLine(def.team.id)).saves++;
              if (isHome) stats.savesA++; else stats.savesH++;
            }
            push(evLog, { minute, type: "penalty_miss", teamId: att.team.id, playerId: taker.p.id, xg: 0.78 });
          }
          return;
        }
        // карточка за фол
        cardCheck(def, fouler, evLog, isHome);
        if (rng.chance(0.25)) shoot(att, def, carrier, creator, "setpiece", evLog, delta);
        return;
      }
    }

    // 4) удар (разгромы самоглушатся: лидирующая команда реже добирается до финиша)
    if (!force && !rng.chance(leadK)) return;
    const counterP = clamp(0.14 + att.counter * 0.22, 0.1, 0.42);
    const kind: "open" | "counter" | "header" = rng.chance(counterP) ? "counter" : rng.chance(0.18) ? "header" : "open";
    shoot(att, def, carrier, creator, kind, evLog, delta);
  }

  // ─── Удар ──
  function shoot(
    att: Side, def: Side, shooter: SimPlayer, creator: SimPlayer | null,
    kind: "open" | "counter" | "header" | "setpiece", evLog: MatchEvent[], delta: MinuteDelta
  ) {
    const isHome = att.home;
    const line = (id: string, tid: string) => (lines[id] ??= blankLine(tid));
    const xg = computeXg(shooter, att, def, kind);
    const sl = line(shooter.p.id, att.team.id);
    sl.shots++;
    sl.xg = Math.round((sl.xg + xg) * 1000) / 1000;
    if (isHome) { delta.shotsH++; delta.xgH += xg; stats.shotsH++; }
    else { delta.shotsA++; delta.xgA += xg; stats.shotsA++; }
    if (xg >= 0.3) { if (isHome) stats.bigChancesH++; else stats.bigChancesA++; }
    if (creator && creator !== shooter) line(creator.p.id, att.team.id).keyPasses++;

    const gk = gkOf(def);
    const gkSkill = ((gk?.p.goalkeeping ?? 70) / 100) * wx.gk;
    // вратарь отбивает: goalkeeping / (xG×100 + goalkeeping)
    const onTargetP = clamp(0.33 + xg * 0.9, 0.25, 0.85);
    const onTarget = rng.chance(onTargetP);

    if (!onTarget) {
      if (rng.chance(0.09)) {
        push(evLog, { minute, type: "post", teamId: att.team.id, playerId: shooter.p.id, xg });
      } else if (xg > 0.25 && rng.chance(0.5)) {
        push(evLog, { minute, type: "miss", teamId: att.team.id, playerId: shooter.p.id, xg });
      } else if (rng.chance(0.3)) {
        if (isHome) { delta.corH++; stats.cornersH++; } else { delta.corA++; stats.cornersA++; }
      }
      return;
    }

    sl.sot++;
    if (isHome) { delta.sotH++; stats.sotH++; } else { delta.sotA++; stats.sotA++; }

    // целевая конверсия удара в створ ≈ xG / P(в створ), скорректированная классом вратаря
    const scoreIfOnTarget = clamp(xg / Math.max(0.2, onTargetP), 0.04, 0.88);
    const gkAdj = clamp(1 + (0.78 - gkSkill) * 0.9, 0.78, 1.25);
    let saveProb = clamp(1 - scoreIfOnTarget * gkAdj, 0.05, 0.95);

    // ── подгонка под заданный счёт ──
    const need = needsGoal(att);
    if (need !== null) {
      if (need <= 0) {
        saveProb = 1; // лимит исчерпан — гола не будет
      } else {
        // чем меньше остаётся времени на нужные голы, тем выше конверсия
        const left = Math.max(1, totalMinutesPlanned - minute);
        const urgency = clamp(need / (left / 11), 0.12, 1);
        saveProb = Math.min(saveProb, 1 - urgency);
      }
    }

    if (!rng.chance(saveProb)) {
      // ГОЛ
      sl.goals++;
      att.goalsFor++; def.conceded++;
      let assistId: string | undefined;
      if (creator && creator !== shooter && rng.chance(0.72)) {
        line(creator.p.id, att.team.id).assists++;
        assistId = creator.p.id;
      } else if (rng.chance(0.4)) {
        const helper = pickBy(att, ASSIST_W, (x) => (x === shooter ? 0 : 1));
        if (helper) { line(helper.p.id, att.team.id).assists++; assistId = helper.p.id; }
      }
      // ошибка защитника при лёгком голе
      if (xg < 0.2 && rng.chance(0.25)) {
        const defs = active(def).filter((x) => x.p.position === "DF" || x.p.position === "GK");
        if (defs.length) line(rng.pick(defs).p.id, def.team.id).errors++;
      }
      push(evLog, { minute, type: "goal", teamId: att.team.id, playerId: shooter.p.id, assistId, xg });
      return;
    }

    // СЕЙВ
    if (gk) {
      line(gk.p.id, def.team.id).saves++;
      if (isHome) stats.savesA++; else stats.savesH++;
      if (xg > 0.18 || rng.chance(0.3)) {
        push(evLog, { minute, type: "save", teamId: def.team.id, playerId: gk.p.id, xg, quality: Math.round(xg * 100) / 100 });
      }
    }
    if (rng.chance(0.35)) { if (isHome) { delta.corH++; stats.cornersH++; } else { delta.corA++; stats.cornersA++; } }
  }

  // ─── Карточки ──
  function cardCheck(s: Side, sp: SimPlayer, evLog: MatchEvent[], opponentIsHome: boolean) {
    // дисциплина из плана снижает риск карточки, агрессивный прессинг — повышает
    const aggression = (1 + (1 - sp.stamina / 100) * 0.5) * (1 - s.discipline * 0.35) * (1 + Math.max(0, s.press) * 0.12);
    if (rng.chance(0.14 * aggression)) {
      if (sp.yellow) {
        sp.out = "red"; s.reds++;
        s.xi = s.xi.filter((x) => x !== sp);
        (lines[sp.p.id] ??= blankLine(s.team.id)).red++;
        if (opponentIsHome) stats.redA++; else stats.redH++;
        push(evLog, { minute, type: "second_yellow", teamId: s.team.id, playerId: sp.p.id });
      } else {
        sp.yellow = true;
        (lines[sp.p.id] ??= blankLine(s.team.id)).yellow++;
        if (opponentIsHome) stats.yellowA++; else stats.yellowH++;
        push(evLog, { minute, type: "yellow", teamId: s.team.id, playerId: sp.p.id, note: rng.chance(0.15) ? "симуляция" : "грубая игра" });
      }
    } else if (rng.chance(0.006 * (1 - s.discipline * 0.4))) {
      // фол последней надежды
      sp.out = "red"; s.reds++;
      s.xi = s.xi.filter((x) => x !== sp);
      (lines[sp.p.id] ??= blankLine(s.team.id)).red++;
      if (opponentIsHome) stats.redA++; else stats.redH++;
      push(evLog, { minute, type: "red", teamId: s.team.id, playerId: sp.p.id, note: "фол последней надежды" });
    }
  }

  // ─── Замены ──
  function substitute(s: Side, out: SimPlayer, evLog: MatchEvent[], reason: "injury" | "fitness" | "tactical") {
    if (s.subsUsed >= 5 || !s.bench.length) {
      if (reason === "injury") { out.out = "injury"; s.xi = s.xi.filter((x) => x !== out); }
      return;
    }
    const same = s.bench.filter((b) => b.position === out.p.position);
    const pool = same.length ? same : s.bench.filter((b) => (out.p.position === "GK" ? true : b.position !== "GK"));
    if (!pool.length) {
      if (reason === "injury") { out.out = "injury"; s.xi = s.xi.filter((x) => x !== out); }
      return;
    }
    const inP = pool.reduce((a, b) => (b.overall > a.overall ? b : (b.overall === a.overall && b.id < a.id ? b : a)));
    s.bench = s.bench.filter((b) => b !== inP);
    s.xi = s.xi.filter((x) => x !== out);
    s.xi.push({ p: inP, stamina: clamp(inP.fitness, 30, 100), out: "none", minutes: 0, yellow: false });
    s.subsUsed++;
    lines[inP.id] ??= blankLine(s.team.id);
    push(evLog, { minute, type: "sub", teamId: s.team.id, playerOutId: out.p.id, playerInId: inP.id, note: reason });
  }

  // ─── Цикл матча ──
  const added = rng.int(1, 6);
  const totalMinutes = 90 + added;
  const totalMinutesPlanned = totalMinutes;
  push(minutes.push({ minute: 0, events: [], delta: emptyDelta() }) ? minutes[0].events : [], { minute: 0, type: "kickoff" });

  for (minute = 1; minute <= totalMinutes; minute++) {
    const evLog: MatchEvent[] = [];
    const delta = emptyDelta();
    if (minute === 46) push(evLog, { minute: 45, type: "ht" });

    // усталость
    for (const s of [H, A]) {
      const intensity = s.mAtk > 1.02 ? 1.12 : s.mDef > 1.05 ? 0.92 : 1.0;
      for (const sp of active(s)) {
        sp.minutes++;
        (lines[sp.p.id] ??= blankLine(s.team.id)).minutes++;
        const ageK = sp.p.age >= 33 ? 1.3 : sp.p.age >= 30 ? 1.15 : sp.p.age <= 23 ? 0.92 : 1.0;
        const drain = (0.18 + rng.next() * 0.22) * (WORK[sp.p.position] ?? 1) * ageK * intensity;
        sp.stamina = Math.max(0, sp.stamina - drain);
      }
    }

    // борьба за владение: сильнее центр поля — чаще мяч
    const midH = teamPower(H, "mid") * (neutral ? 1 : 1.05) * 0.9 ** H.reds * (1 + H.press * 0.05 - A.press * 0.04);
    const midA = teamPower(A, "mid") * 0.9 ** A.reds * (1 + A.press * 0.05 - H.press * 0.04);
    const shareH = clamp(midH / (midH + midA), 0.25, 0.75);
    // 2-3 эпизода за минуту
    const episodes = rng.int(2, 3);
    for (let e = 0; e < episodes; e++) {
      const homeHas = rng.next() < shareH;
      if (homeHas) { possTicksH++; delta.possH++; } else { possTicksA++; delta.possA++; }
      // не каждое владение доходит до штрафной
      const att = homeHas ? H : A;
      const def = homeHas ? A : H;
      // Класс решает: степень 2.6 делает разницу в силе заметной по ходу сезона,
      // потолок поднят, чтобы гранды могли выражать превосходство над аутсайдерами.
      let reach = clamp(0.30 * (teamPower(att, "atk") / teamPower(def, "def")) ** 2.6 * (att.home && !neutral ? 1.06 : 1.0), 0.05, 0.62);
      if (force) {
        // нужен крупный счёт — даём команде больше выходов к воротам
        const need = Math.max(0, (targetOf(att) ?? 0) - att.goalsFor);
        reach = clamp(reach + need * 0.055, 0.06, 0.8);
      }
      if (rng.chance(reach)) possession(att, def, evLog, delta);
      else buildUp(att, def, delta); // перепасовка без выхода на удар
    }

    // фолы вне эпизодов
    for (const [s, oppHome] of [[H, false], [A, true]] as [Side, boolean][]) {
      if (!rng.chance(0.06)) continue;
      const fouler = pickBy(s, { GK: 0.1, DF: 1.4, MF: 1.4, FW: 0.6 });
      if (!fouler) continue;
      (lines[fouler.p.id] ??= blankLine(s.team.id)).fouls++;
      if (oppHome) { delta.foulsA++; stats.foulsA++; } else { delta.foulsH++; stats.foulsH++; }
      cardCheck(s, fouler, evLog, oppHome);
    }

    // травмы
    for (const s of [H, A]) {
      if (!rng.chance(0.0011)) continue;
      const pool = active(s);
      if (!pool.length) continue;
      const victim = rng.weighted(pool, (x) => (x.p.age >= 31 ? 1.5 : 1) * (x.stamina < 50 ? 1.6 : 1));
      const roll = rng.next();
      const type = roll < 0.6 ? "light" : roll < 0.9 ? "medium" : "severe";
      const days = type === "light" ? rng.int(7, 14) : type === "medium" ? rng.int(21, 42) : rng.int(90, 180);
      injuries.push({ playerId: victim.p.id, teamId: s.team.id, type, days });
      push(evLog, { minute, type: "injury", teamId: s.team.id, playerId: victim.p.id, note: `${days} дн.` });
      substitute(s, victim, evLog, "injury");
    }

    // замены по усталости и тактические
    if (minute >= 60) {
      for (const s of [H, A]) {
        if (s.subsUsed >= 5) continue;
        const tired = active(s).filter((x) => x.stamina < 55 && x.p.position !== "GK");
        if (tired.length && rng.chance(0.45)) substitute(s, rng.pick(tired), evLog, "fitness");
      }
    }
    if (minute >= 70) {
      for (const [s, own, opp] of [[H, H.goalsFor, A.goalsFor], [A, A.goalsFor, H.goalsFor]] as [Side, number, number][]) {
        if (s.subsUsed >= 5 || own >= opp) continue;
        const fw = s.bench.filter((b) => b.position === "FW");
        const worst = active(s).filter((x) => x.p.position === "MF" || x.p.position === "DF").sort((a, b) => a.stamina - b.stamina)[0];
        if (fw.length && worst && rng.chance(0.3)) substitute(s, worst, evLog, "tactical");
      }
    }

    if (minute === totalMinutes) push(evLog, { minute, type: "ft" });
    stats.xgH += delta.xgH;
    stats.xgA += delta.xgA;
    minutes.push({ minute, events: evLog, delta });
  }

  // ─── Гарантия заданного счёта: досеваем недостающие голы ──
  if (force) {
    for (const side of [H, A]) {
      const target = side.home ? force.h : force.a;
      let missing = target - side.goalsFor;
      if (missing <= 0) continue;
      const def = side.home ? A : H;
      const isHome = side.home;
      while (missing-- > 0) {
        // минута из второй половины логов — гол выглядит естественно в ленте
        const idx = rng.int(8, Math.max(9, minutes.length - 2));
        const log = minutes[idx];
        const m = log.minute || idx;
        const pool = side.xi.length ? side.xi : [];
        const scorer = pool.length
          ? rng.weighted(pool, (x) => Math.pow(x.p.attack / 60, 2.2) * (SHOOT_W[x.p.position] ?? 1))
          : null;
        if (!scorer) break;
        const helperPool = pool.filter((x) => x !== scorer);
        const helper = helperPool.length && rng.chance(0.65)
          ? rng.weighted(helperPool, (x) => x.p.attack * (ASSIST_W[x.p.position] ?? 1))
          : null;
        const sl = (lines[scorer.p.id] ??= blankLine(side.team.id));
        const xg = clamp(rng.range(0.14, 0.52), 0.05, 0.85);
        sl.goals++; sl.shots++; sl.sot++; sl.xg = Math.round((sl.xg + xg) * 1000) / 1000;
        if (helper) (lines[helper.p.id] ??= blankLine(side.team.id)).assists++;
        side.goalsFor++; def.conceded++;
        if (isHome) { stats.shotsH++; stats.sotH++; stats.xgH += xg; log.delta.shotsH++; log.delta.sotH++; log.delta.xgH += xg; }
        else { stats.shotsA++; stats.sotA++; stats.xgA += xg; log.delta.shotsA++; log.delta.sotA++; log.delta.xgA += xg; }
        const ev: MatchEvent = {
          minute: m, type: "goal", teamId: side.team.id,
          playerId: scorer.p.id, assistId: helper?.p.id, xg,
        };
        log.events.push(ev);
        flatEvents.push(ev);
      }
    }
    // события в ленте — по возрастанию минут
    flatEvents.sort((a, b) => a.minute - b.minute);
  }

  // ─── Владение и точность ──
  const totTicks = Math.max(1, possTicksH + possTicksA);
  stats.possessionH = Math.round((possTicksH / totTicks) * 100);
  stats.possessionA = 100 - stats.possessionH;
  stats.xgH = Math.round(stats.xgH * 100) / 100;
  stats.xgA = Math.round(stats.xgA * 100) / 100;
  stats.passAccH = stats.passesH ? Math.round((stats.passAccH / stats.passesH) * 100) : 0;
  stats.passAccA = stats.passesA ? Math.round((stats.passAccA / stats.passesA) * 100) : 0;

  // ─── Рейтинги игроков ──
  const playerRatings: Record<string, number> = {};
  const playerMatchStats: Record<string, PlayerMatchLine> = {};
  const sideOf = (teamId: string) => (teamId === H.team.id ? H : A);

  for (const [pid, l] of Object.entries(lines)) {
    if (!l.minutes) continue;
    const s = sideOf(l.teamId);
    const pl = s.team.players.find((p) => p.id === pid);
    if (!pl) continue;
    const share = clamp(l.minutes / 90, 0.15, 1);

    let r = 6.0 + rng.range(-0.25, 0.25);
    const goalBonus = pl.position === "FW" ? 1.0 : pl.position === "MF" ? 1.25 : 1.45;
    r += l.goals * goalBonus + (l.goals >= 2 ? 0.3 : 0) + (l.goals >= 3 ? 0.4 : 0);
    r += l.assists * 0.75;
    r += Math.min(0.5, l.keyPasses * 0.12);
    r += Math.min(0.45, (l.tackles + l.interceptions) * 0.06);
    r += Math.min(0.25, l.dribbles * 0.05);
    // качество завершения: много ударов без гола — минус
    if (l.shots >= 3 && l.goals === 0) r -= 0.25;
    // недооткрытый xG (забил больше ожидаемого)
    r += clamp((l.goals - l.xg) * 0.25, -0.4, 0.6);
    if (pl.position === "GK") {
      r += Math.min(1.0, l.saves * 0.18);
      r -= Math.min(1.6, s.conceded * 0.33);
      if (s.conceded === 0 && l.minutes >= 60) r += 0.7;
    } else if (pl.position === "DF") {
      if (s.conceded === 0 && l.minutes >= 60) r += 0.55;
      else r -= Math.min(1.2, s.conceded * 0.26);
    }
    r -= l.errors * 1.4;
    r -= l.yellow * 0.3;
    r -= l.red * 1.6;
    r -= Math.min(0.3, l.fouls * 0.06);
    // результат команды
    const diff = s.goalsFor - s.conceded;
    r += clamp(diff * 0.12, -0.45, 0.45);
    // мало сыграл — рейтинг ближе к базовому
    r = 6.2 + (r - 6.2) * (0.55 + 0.45 * share);

    const rating = clamp(Math.round(r * 10) / 10, 3.0, 10.0);
    playerRatings[pid] = rating;
    playerMatchStats[pid] = {
      goals: l.goals, assists: l.assists, saves: l.saves, yellow: l.yellow, red: l.red,
      errors: l.errors, keyPasses: l.keyPasses, tackles: l.tackles, interceptions: l.interceptions,
      shots: l.shots, shotsOnTarget: l.sot, xg: Math.round(l.xg * 100) / 100, dribbles: l.dribbles,
      fouls: l.fouls, offsides: l.offsides, passes: l.passes, passesOk: l.passesOk,
      minutes: l.minutes, conceded: s.conceded, cleanSheet: s.conceded === 0,
      teamId: l.teamId, rating,
    };
  }

  const ranked = Object.entries(playerRatings)
    .map(([playerId, rating]) => ({ playerId, rating, teamId: playerMatchStats[playerId].teamId }))
    .sort((a, b) => b.rating - a.rating);
  const topPerformers = ranked.slice(0, 3);
  const motm = ranked[0]?.playerId ?? "";

  // ─── Пенальти (кубки) ──
  let pens: { h: number; a: number } | null = null;
  if (opts.penaltiesOnDraw && H.goalsFor === A.goalsFor) {
    let ph = 0, pa = 0;
    const skill = (s: Side) => avg(active(s).map((x) => x.p.attack)) / 100;
    const gkS = (s: Side) => (gkOf(s)?.p.goalkeeping ?? 70) / 100;
    for (let i = 0; i < 5; i++) {
      if (rng.chance(0.62 + skill(H) * 0.25 - gkS(A) * 0.12)) ph++;
      if (rng.chance(0.62 + skill(A) * 0.25 - gkS(H) * 0.12)) pa++;
    }
    while (ph === pa) {
      if (rng.chance(0.68 + skill(H) * 0.2 - gkS(A) * 0.1)) ph++;
      if (rng.chance(0.68 + skill(A) * 0.2 - gkS(H) * 0.1)) pa++;
    }
    pens = { h: ph, a: pa };
  }

  // фактические составы этого матча (а не пересчёт по текущему состоянию клуба)
  const lineups: Record<string, Player[]> = {
    [homeTeam.id]: H.startXI.map((p) => ({ ...p, stats: { ...p.stats } })),
    [awayTeam.id]: A.startXI.map((p) => ({ ...p, stats: { ...p.stats } })),
  };
  const benches: Record<string, Player[]> = {
    [homeTeam.id]: H.startBench.map((p) => ({ ...p, stats: { ...p.stats } })),
    [awayTeam.id]: A.startBench.map((p) => ({ ...p, stats: { ...p.stats } })),
  };

  return {
    seed,
    homeId: homeTeam.id, awayId: awayTeam.id,
    homeName: homeTeam.name, awayName: awayTeam.name,
    homeShort: homeTeam.shortName, awayShort: awayTeam.shortName,
    homeColor: homeTeam.color, awayColor: awayTeam.color,
    homeScore: H.goalsFor, awayScore: A.goalsFor,
    totalMinutes, minutes, events: flatEvents, stats,
    playerRatings, playerMatchStats, topPerformers,
    weather, injuries, lineups, benches, motm, pens,
  };
}
