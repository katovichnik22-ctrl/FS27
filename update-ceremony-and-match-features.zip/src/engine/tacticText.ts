// ─── Текстовая тактика: разбор и оценка «крутости» ───────────────────────────
// Пользователь пишет план на матч словами, движок разбирает его на концепции,
// проверяет полноту, конкретику и непротиворечивость — и выдаёт модификаторы.
// Полностью детерминированно: один и тот же текст → один и тот же результат.

export type Phase = "buildup" | "attack" | "press" | "defense" | "transition" | "setpiece" | "mentality";

export interface Concept {
  id: string;
  label: string;
  phase: Phase;
  /** вклад в силу: атака / оборона / центр */
  atk: number;
  def: number;
  mid: number;
  words: string[];
}

/** Словарь футбольных концепций (рус + англ) */
export const CONCEPTS: Concept[] = [
  // ── Розыгрыш ──
  { id: "short_build", label: "Короткий розыгрыш от вратаря", phase: "buildup", atk: 0.6, def: 0.2, mid: 1.2,
    words: ["короткий розыгрыш", "розыгрыш от вратаря", "игра от обороны низом", "пас низом", "short build", "играем через пас"] },
  { id: "long_build", label: "Длинные передачи / прямая игра", phase: "buildup", atk: 0.9, def: 0.3, mid: -0.2,
    words: ["длинн", "заброс", "лонгбол", "прямая игра", "direct play", "вынос вперёд"] },
  { id: "third_man", label: "Игра в третьего", phase: "buildup", atk: 0.8, def: 0, mid: 1.0,
    words: ["в третьего", "третий игрок", "third man", "стенк", "забегани"] },
  { id: "overload", label: "Перегруз фланга / зоны", phase: "buildup", atk: 1.0, def: -0.2, mid: 0.8,
    words: ["перегруз", "overload", "численное большинство", "создаём большинство"] },
  { id: "inverted", label: "Инвертированные фулбеки", phase: "buildup", atk: 0.5, def: 0.4, mid: 1.1,
    words: ["инвертированн", "фулбек в центр", "смещается в центр", "inverted"] },

  // ── Атака ──
  { id: "width", label: "Игра в ширину, фланги", phase: "attack", atk: 1.0, def: -0.2, mid: 0.2,
    words: ["ширин", "фланг", "края", "вингер", "навес", "кросс", "width", "по бровке"] },
  { id: "half_space", label: "Полуфланги и зоны между линиями", phase: "attack", atk: 1.2, def: 0, mid: 0.6,
    words: ["полуфланг", "между линиями", "half-space", "хавспейс", "зона 14", "карман"] },
  { id: "runs", label: "Забегания за спину защитникам", phase: "attack", atk: 1.3, def: -0.2, mid: 0.2,
    words: ["за спину", "рывк", "открывани", "in behind", "разрез", "глубин"] },
  { id: "combo", label: "Комбинационная игра в штрафной", phase: "attack", atk: 1.1, def: 0, mid: 0.7,
    words: ["комбинац", "мелкий пас", "разыгрыва", "тики-така", "tiki", "стеночк"] },
  { id: "shoot", label: "Удары из-за штрафной", phase: "attack", atk: 0.6, def: 0, mid: 0.1,
    words: ["дальн", "из-за штрафной", "бьём", "удары издалека"] },
  { id: "target", label: "Игра на форварда-столба", phase: "attack", atk: 0.8, def: 0.1, mid: 0.2,
    words: ["столб", "таргетмен", "target man", "скидк", "цепляется"] },

  // ── Прессинг ──
  { id: "high_press", label: "Высокий прессинг", phase: "press", atk: 0.9, def: 0.5, mid: 0.9,
    words: ["высокий прессинг", "прессингу", "прессинг", "гегенпрессинг", "gegenpress", "high press", "давим"] },
  { id: "trigger", label: "Триггеры прессинга", phase: "press", atk: 0.5, def: 0.8, mid: 0.7,
    words: ["триггер", "сигнал к прессингу", "момент для отбора", "pressing trigger", "накрываем на приём"] },
  { id: "mid_block", label: "Средний блок", phase: "press", atk: 0.2, def: 0.9, mid: 0.8,
    words: ["средний блок", "mid block", "средняя линия обороны", "встречаем в центре"] },
  { id: "cover_shadow", label: "Перекрытие линии паса", phase: "press", atk: 0.2, def: 0.9, mid: 0.6,
    words: ["перекрыва", "тень", "cover shadow", "отрезаем пас", "закрываем центр"] },

  // ── Оборона ──
  { id: "low_block", label: "Низкий блок", phase: "defense", atk: -0.4, def: 1.4, mid: 0.2,
    words: ["низкий блок", "low block", "глубокая оборона", "автобус", "садимся низко", "обороняемся низко", "садимся глубоко"] },
  { id: "high_line", label: "Высокая линия обороны", phase: "defense", atk: 0.6, def: 0.5, mid: 0.6,
    words: ["высокая линия", "высокая оборона", "линия обороны высоко", "офсайдн", "high line"] },
  { id: "compact", label: "Компактность между линиями", phase: "defense", atk: 0, def: 1.2, mid: 0.7,
    words: ["компакт", "плотно", "узко", "сужаем", "compact", "малые расстояния"] },
  { id: "man_mark", label: "Персональная опека", phase: "defense", atk: 0, def: 1.0, mid: 0.3,
    words: ["персональн", "личная опека", "man-mark", "держим игрока", "по всему полю за"] },
  { id: "zonal", label: "Зонная оборона", phase: "defense", atk: 0, def: 1.0, mid: 0.4,
    words: ["зонн", "zonal", "разбираем зоны", "зона ответственности"] },
  { id: "double_team", label: "Сдваивание на фланге", phase: "defense", atk: 0, def: 0.9, mid: 0.4,
    words: ["сдваива", "вдвоём", "double", "страхует крайнего"] },

  // ── Переходы ──
  { id: "counter", label: "Быстрые контратаки", phase: "transition", atk: 1.4, def: 0.1, mid: 0.3,
    words: ["контратак", "counter", "быстрый выход", "переход в атаку", "на скорост", "вертикаль"] },
  { id: "counter_press", label: "Контрпрессинг после потери", phase: "transition", atk: 0.6, def: 0.9, mid: 1.0,
    words: ["после потери", "контрпрессинг", "counter-press", "мгновенный отбор", "5 секунд", "пять секунд"] },
  { id: "rest_def", label: "Страховка при атаке (rest defence)", phase: "transition", atk: 0, def: 1.1, mid: 0.6,
    words: ["страховк", "rest defence", "подстрахов", "остаются сзади", "не идут вперёд"] },
  { id: "slow_down", label: "Сбить темп после потери", phase: "transition", atk: 0.1, def: 0.7, mid: 0.6,
    words: ["сбить темп", "фол тактическ", "тактический фол", "откатываемся", "перестроен"] },

  // ── Стандарты ──
  { id: "set_att", label: "Стандарты в атаке", phase: "setpiece", atk: 0.8, def: 0, mid: 0.1,
    words: ["угловые", "штрафн", "стандарт", "corner", "подача в штрафную", "розыгрыш углового"] },
  { id: "set_def", label: "Оборона стандартов", phase: "setpiece", atk: 0, def: 0.9, mid: 0.1,
    words: ["обороне стандарт", "при угловых соперника", "защита стандартов", "при стандартах соперника"] },
  { id: "penalty", label: "Исполнители пенальти и штрафных", phase: "setpiece", atk: 0.5, def: 0, mid: 0.1,
    words: ["пенальти", "исполнитель", "бьёт штрафные", "penalty taker"] },

  // ── Ментальность / управление ──
  { id: "tempo", label: "Контроль темпа", phase: "mentality", atk: 0.4, def: 0.4, mid: 1.0,
    words: ["темп", "ритм", "ускоряем", "замедляем", "контроль игры", "держим мяч"] },
  { id: "game_state", label: "План на счёт по ходу матча", phase: "mentality", atk: 0.5, def: 0.6, mid: 0.5,
    words: ["если ведём", "если проигрываем", "при счёте", "во втором тайме", "после гола", "по ходу матча"] },
  { id: "subs", label: "План замен", phase: "mentality", atk: 0.4, def: 0.4, mid: 0.4,
    words: ["замен", "свеж", "с лавки", "выпускаем", "на 60 минуте", "на 70 минуте"] },
  { id: "discipline", label: "Дисциплина и карточки", phase: "mentality", atk: 0, def: 0.6, mid: 0.3,
    words: ["дисциплин", "без карточек", "не фолим", "аккуратно в отборе", "не рискуем"] },
  { id: "opponent", label: "Разбор соперника", phase: "mentality", atk: 0.5, def: 0.6, mid: 0.5,
    words: ["соперник", "их вингер", "слабое звено", "их опорн", "против их", "нейтрализ"] },
];

/** Пары взаимоисключающих идей */
const CONTRADICTIONS: [string, string, string][] = [
  ["high_press", "low_block", "высокий прессинг плохо сочетается с низким блоком"],
  ["high_line", "low_block", "высокая линия противоречит глубокой обороне"],
  ["short_build", "long_build", "короткий розыгрыш и длинные забросы исключают друг друга"],
  ["man_mark", "zonal", "персональная и зонная опека одновременно — размытый план"],
  ["counter", "tempo", "ставка на контратаки плохо сочетается с удержанием мяча"],
];

export interface TacticAnalysis {
  score: number;              // 0–100
  grade: string;              // текстовая оценка
  detected: { id: string; label: string; phase: Phase }[];
  phases: Phase[];            // раскрытые фазы
  issues: string[];           // замечания
  tips: string[];             // что добавить
  /** итоговые множители к силе (около 1.0) */
  atk: number;
  def: number;
  mid: number;
  /** поведенческие эффекты для движка */
  pressBias: number;          // −1…1 (низкий блок ↔ высокий прессинг)
  counterBias: number;        // 0…1 доля контратак
  setPieceBias: number;       // 0…1 качество стандартов
  disciplineBias: number;     // 0…1 снижение карточек
  words: number;
}

const PHASE_LABEL: Record<Phase, string> = {
  buildup: "начало атаки", attack: "финальная треть", press: "прессинг",
  defense: "оборона", transition: "переходные фазы", setpiece: "стандарты", mentality: "управление матчем",
};

const EMPTY: TacticAnalysis = {
  score: 0, grade: "Нет плана", detected: [], phases: [], issues: [], tips: [],
  atk: 1, def: 1, mid: 1, pressBias: 0, counterBias: 0, setPieceBias: 0, disciplineBias: 0, words: 0,
};

/** Разбор и оценка текстовой тактики */
export function analyzeTactic(text?: string | null): TacticAnalysis {
  const raw = (text ?? "").trim();
  if (raw.length < 15) return { ...EMPTY };

  const low = raw.toLowerCase().replace(/ё/g, "е");
  const words = low.split(/\s+/).filter(Boolean);
  const wordCount = words.length;

  // ── 1. Поиск концепций ──
  const detected: TacticAnalysis["detected"] = [];
  let atkSum = 0, defSum = 0, midSum = 0;
  for (const c of CONCEPTS) {
    const hit = c.words.some((w) => low.includes(w.toLowerCase().replace(/ё/g, "е")));
    if (!hit) continue;
    detected.push({ id: c.id, label: c.label, phase: c.phase });
    atkSum += c.atk;
    defSum += c.def;
    midSum += c.mid;
  }
  const ids = new Set(detected.map((d) => d.id));

  // ── 2. Покрытие фаз ──
  const phases = [...new Set(detected.map((d) => d.phase))];
  const coverage = phases.length / 7;

  // ── 3. Конкретика ──
  const numbers = (low.match(/\b\d{1,3}\b/g) ?? []).length;         // «линия на 40 метрах», «на 60-й минуте»
  const formations = (low.match(/\d-\d-\d(-\d)?/g) ?? []).length;   // «перестраиваемся в 4-2-3-1»
  const roleWords = ["вратар", "защитник", "опорн", "полузащит", "вингер", "форвард", "нападающ", "фулбек", "латерал", "центрбек"];
  const roles = roleWords.filter((w) => low.includes(w)).length;
  const specificity = Math.min(1, (numbers * 0.06 + formations * 0.2 + roles * 0.1));

  // ── 4. Глубина текста ──
  const sentences = raw.split(/[.!?;\n]+/).filter((s) => s.trim().length > 8).length;
  const lengthScore = wordCount < 25 ? wordCount / 25 : wordCount <= 260 ? 1 : Math.max(0.65, 1 - (wordCount - 260) / 900);
  const structure = Math.min(1, sentences / 6);

  // ── 5. Осмысленность (не спам одним словом) ──
  const unique = new Set(words.map((w) => w.replace(/[^a-zа-я0-9-]/g, ""))).size;
  const variety = Math.min(1, unique / Math.max(12, wordCount * 0.55));

  // ── 6. Противоречия ──
  let score_adaptiveBonus = 0;
  const issues: string[] = [];
  let contradictionPenalty = 0;
  // если план адаптивный («если ведём», «во втором тайме»), разные схемы поведения
  // в разных фазах матча — это не противоречие, а зрелость плана
  const adaptive = ids.has("game_state");
  for (const [a, b, msg] of CONTRADICTIONS) {
    if (!ids.has(a) || !ids.has(b)) continue;
    if (adaptive) continue;
    issues.push(msg);
    contradictionPenalty += 7;
  }
  if (adaptive && CONTRADICTIONS.some(([a, b]) => ids.has(a) && ids.has(b))) {
    // бонус за продуманную смену модели по ходу игры
    score_adaptiveBonus = 4;
  }
  if (wordCount < 25) issues.push("план слишком короткий — команда не поймёт задачи");
  if (variety < 0.45) issues.push("много повторов, мало конкретных указаний");
  if (wordCount > 420) issues.push("план перегружен — игроки запомнят не всё");

  // ── 7. Итоговый балл ──
  const conceptScore = Math.min(1, detected.length / 11);
  let score =
    score_adaptiveBonus +
    conceptScore * 34 +
    coverage * 26 +
    specificity * 14 +
    lengthScore * 10 +
    structure * 8 +
    variety * 8;
  score -= contradictionPenalty;
  score = Math.max(0, Math.min(100, Math.round(score)));

  // ── 8. Подсказки ──
  const tips: string[] = [];
  const missing = (Object.keys(PHASE_LABEL) as Phase[]).filter((p) => !phases.includes(p));
  for (const p of missing.slice(0, 3)) tips.push(`опишите ${PHASE_LABEL[p]}`);
  if (!numbers && !formations) tips.push("добавьте конкретику: минуты, метры, схему перестроения");
  if (!ids.has("opponent")) tips.push("укажите, как играть против сильных сторон соперника");

  // ── 9. Модификаторы силы ──
  // score 50 — нейтрально; 100 → около +7%, 0 → около −6%
  const power = (score - 50) / 50;                 // −1…1
  const magnitude = power >= 0 ? power * 0.06 : power * 0.05;
  const total = Math.abs(atkSum) + Math.abs(defSum) + Math.abs(midSum) || 1;
  // распределяем эффект согласно акцентам плана (минимум треть каждому)
  const share = (v: number) => 0.34 + 0.66 * (Math.max(0, v) / total) * 3;
  const atk = 1 + magnitude * Math.min(1.6, share(atkSum));
  const def = 1 + magnitude * Math.min(1.6, share(defSum));
  const mid = 1 + magnitude * Math.min(1.6, share(midSum));

  // ── 10. Поведенческие акценты ──
  const has = (id: string) => (ids.has(id) ? 1 : 0);
  const quality = score / 100;
  const pressBias = clamp01s(
    (has("high_press") * 0.6 + has("trigger") * 0.3 + has("counter_press") * 0.35 + has("high_line") * 0.25
      - has("low_block") * 0.9 - has("mid_block") * 0.3) * quality
  );
  const counterBias = Math.min(1, (has("counter") * 0.6 + has("runs") * 0.25 + has("long_build") * 0.2) * quality);
  const setPieceBias = Math.min(1, (has("set_att") * 0.5 + has("set_def") * 0.3 + has("penalty") * 0.3) * quality);
  const disciplineBias = Math.min(1, (has("discipline") * 0.7 + has("rest_def") * 0.2 + has("zonal") * 0.15) * quality);

  const grade =
    score >= 85 ? "Гениальный план" :
    score >= 70 ? "Отличная тактика" :
    score >= 55 ? "Хорошая тактика" :
    score >= 40 ? "Рабочий план" :
    score >= 25 ? "Сырой набросок" : "Слабый план";

  return {
    score, grade, detected, phases, issues, tips,
    atk: round3(atk), def: round3(def), mid: round3(mid),
    pressBias: round3(pressBias), counterBias: round3(counterBias),
    setPieceBias: round3(setPieceBias), disciplineBias: round3(disciplineBias),
    words: wordCount,
  };
}

const round3 = (v: number) => Math.round(v * 1000) / 1000;
const clamp01s = (v: number) => Math.max(-1, Math.min(1, v));

export const PHASE_NAMES = PHASE_LABEL;

/** Готовый шаблон — старт для пользователя */
export const TACTIC_TEMPLATE = `Начало атаки: разыгрываем от вратаря низом, опорный опускается между центральными защитниками, фулбеки поднимаются высоко по флангам.
Финальная треть: ищем полуфланги и зоны между линиями, вингеры идут в обводку, форвард делает рывки за спину защитникам под разрезающий пас.
Прессинг: высокий прессинг с триггером на приём мяча спиной к воротам, перекрываем линию паса на опорного, накрываем вдвоём у боковой.
Оборона: средний блок, компактно, расстояние между линиями не больше 15 метров, зонная опека в штрафной.
Переходы: после потери — контрпрессинг первые 5 секунд, два центральных остаются на страховке. При отборе — быстрая вертикальная контратака в три паса.
Стандарты: угловые подаём на дальнюю штангу, при угловых соперника обороняемся зонно, пенальти бьёт основной исполнитель.
Управление матчем: если ведём после 70 минуты — садимся ниже и сушим игру, выпускаем свежих защитников. Если проигрываем — добавляем форварда и играем шире. Против их быстрого вингера страхует опорный, в отборе аккуратно, без лишних карточек.`;
