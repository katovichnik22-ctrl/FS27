// ─── Церемония наград по итогам сезона (Золотой мяч и номинации) ────────────
import type { Competition, LeagueId, Player, Slot, Team } from "../types";
import { buildTable, LEAGUE_CFG, LEAGUE_IDS } from "./season";

export interface AwardNominee {
  playerId: string;
  name: string;
  teamId: string;
  teamName: string;
  position: string;
  age: number;
  nationality: string;
  overall: number;
  score: number;
  /** ключевые цифры сезона для карточки */
  line: string;
  apps: number;
  goals: number;
  assists: number;
  cleanSheets: number;
  rating: number;
  trophies: string[];
}

export interface ClubNominee {
  teamId: string;
  name: string;
  color: string;
  league: string;
  score: number;
  trophies: string[];
  line: string;
  pts: number;
  gd: number;
}

export interface SeasonCeremony {
  seasonNumber: number;
  /** Золотой мяч — лучший игрок сезона */
  ballonDor: AwardNominee | null;
  ballonDorTop: AwardNominee[];
  /** Лучший вратарь (Yashin Trophy) */
  bestGoalkeeper: AwardNominee | null;
  goalkeeperTop: AwardNominee[];
  /** Лучший молодой игрок до 21 (Kopa Trophy) */
  bestYoung: AwardNominee | null;
  youngTop: AwardNominee[];
  /** Лучший бомбардир сезона (Golden Boot) */
  topScorer: AwardNominee | null;
  scorerTop: AwardNominee[];
  /** Лучший клуб сезона */
  bestClub: ClubNominee | null;
  clubTop: ClubNominee[];
}

/** Вес трофея в рейтинге Золотого мяча.
 *  Как в реальности: Лига чемпионов решает почти всё, чемпионство — второй по
 *  значимости фактор, кубки — приятный довесок. Игрок из клуба без трофеев
 *  почти не выигрывает ЗМ, даже с выдающейся личной статистикой. */
const TROPHY_W: Partial<Record<Competition, number>> = {
  UCL: 55,
  PL: 30, LL: 30, SA: 27, BL: 26, FL1: 20,
  UEL: 18, UECL: 9,
  FA: 8, CDR: 8, DFB: 8, CIT: 8, CDF: 6, EFL: 5,
};

/** Бонус за «требл» и «дубль» — как в жизни, комбинация титулов решает */
function comboBonus(list: string[]): number {
  if (list.length >= 3) return 22;
  if (list.length === 2) return 10;
  return 0;
}

const COMP_TITLE: Partial<Record<Competition, string>> = {
  UCL: "Лига чемпионов", UEL: "Лига Европы", UECL: "Лига конференций",
  PL: "Премьер-Лига", LL: "Ла Лига", SA: "Серия А", BL: "Бундеслига", FL1: "Лига 1",
  FA: "Кубок Англии", EFL: "Кубок лиги", CDR: "Кубок Испании",
  CDF: "Кубок Франции", DFB: "Кубок Германии", CIT: "Кубок Италии",
};

function trophiesOf(slot: Slot, teamId: string): { list: string[]; weight: number } {
  const list: string[] = [];
  let weight = 0;
  for (const [comp, champ] of Object.entries(slot.season.champions) as [Competition, string][]) {
    if (champ !== teamId) continue;
    list.push(COMP_TITLE[comp] ?? comp);
    weight += TROPHY_W[comp] ?? 4;
  }
  return { list, weight: weight + comboBonus(list) };
}

/** Насколько игрок причастен к трофею: полный сезон — целиком, редкие выходы — частично */
function minutesShare(minutes: number): number {
  return Math.max(0.25, Math.min(1, minutes / 2200));
}

function mkNominee(p: Player, team: Team, score: number, line: string, trophies: string[]): AwardNominee {
  return {
    playerId: p.id, name: p.name, teamId: team.id, teamName: team.name,
    position: p.position, age: p.age, nationality: p.nationality, overall: p.overall,
    score: Math.round(score * 10) / 10, line,
    apps: p.stats.apps, goals: p.stats.goals, assists: p.stats.assists,
    cleanSheets: p.stats.cleanSheets, rating: p.stats.avgRating, trophies,
  };
}

/**
 * Подводит итоги сезона: считает баллы каждого игрока и клуба
 * и формирует список номинантов по пяти наградам.
 */
export function buildCeremony(slot: Slot): SeasonCeremony {
  const leagues: LeagueId[] = slot.selectedLeagues?.length ? slot.selectedLeagues : LEAGUE_IDS;

  // ── позиции клубов в своих лигах (для веса выступления) ──
  const clubPos = new Map<string, { pos: number; total: number; pts: number; gd: number; league: LeagueId }>();
  for (const lid of leagues) {
    const ids = Object.values(slot.teams).filter((t) => t.league === lid).map((t) => t.id);
    const table = buildTable(slot.season.fixtures, ids, LEAGUE_CFG[lid].comp);
    table.forEach((r, i) => clubPos.set(r.teamId, { pos: i + 1, total: table.length, pts: r.pts, gd: r.gd, league: lid }));
  }

  // ── еврокубковый путь: сколько матчей команда прошла ──
  const euroRuns = new Map<string, number>();
  for (const [comp, st] of [["UCL", slot.season.ucl], ["UEL", slot.season.uel], ["UECL", slot.season.uecl]] as const) {
    if (!st) continue;
    const base = comp === "UCL" ? 1 : comp === "UEL" ? 0.6 : 0.4;
    for (const f of slot.season.fixtures) {
      if (f.comp !== comp || !f.played) continue;
      for (const tid of [f.homeId, f.awayId]) euroRuns.set(tid, (euroRuns.get(tid) ?? 0) + base);
    }
  }

  const players: AwardNominee[] = [];
  const clubs: ClubNominee[] = [];

  for (const team of Object.values(slot.teams)) {
    if (!team.league || !leagues.includes(team.league)) continue;
    const tr = trophiesOf(slot, team.id);
    const cp = clubPos.get(team.id);
    const euro = euroRuns.get(team.id) ?? 0;

    // ── клуб ──
    if (cp) {
      const placeScore = ((cp.total - cp.pos + 1) / cp.total) * 40;
      const clubScore = placeScore + tr.weight * 3 + cp.pts * 0.25 + cp.gd * 0.2 + euro * 0.6;
      clubs.push({
        teamId: team.id, name: team.name, color: team.color,
        league: LEAGUE_CFG[cp.league].short, score: Math.round(clubScore * 10) / 10,
        trophies: tr.list,
        line: `${cp.pos}-е место · ${cp.pts} очк · РГ ${cp.gd > 0 ? "+" : ""}${cp.gd}`,
        pts: cp.pts, gd: cp.gd,
      });
    }

    // ── игроки ──
    for (const p of team.players) {
      const s = p.stats;
      if (s.apps < 8) continue;
      // Командный успех — половина веса награды: трофеи, место в лиге, путь в Европе.
      // Личная статистика без титулов почти никогда не побеждает.
      const titleWeight = tr.weight * minutesShare(s.minutes);
      const tablePart = cp ? ((cp.total - cp.pos + 1) / cp.total) * 14 : 0;
      const teamBonus = titleWeight + tablePart + euro * 0.9;
      const minutesK = Math.min(1, s.minutes / 1800); // полный сезон ≈ 20+ матчей

      // Золотой мяч: рейтинг + результативность + вклад + трофеи
      const attackOut = s.goals * 1.0 + s.assists * 0.7;
      const defensive = (s.tackles + s.interceptions) * 0.035 + s.cleanSheets * 0.5;
      const gkPart = p.position === "GK" ? s.saves * 0.05 + s.cleanSheets * 1.1 : 0;
      const bdScore =
        (s.avgRating - 6) * 24 * minutesK +
        attackOut * (p.position === "DF" ? 1.5 : p.position === "GK" ? 2 : 1) +
        defensive * (p.position === "DF" ? 1.4 : 1) +
        gkPart +
        s.motm * 1.6 +
        teamBonus;

      players.push(mkNominee(
        p, team, bdScore,
        p.position === "GK"
          ? `${s.apps} матч. · ${s.cleanSheets} сух. · ${s.saves} сейв. · рейт ${s.avgRating.toFixed(2)}`
          : `${s.apps} матч. · ${s.goals} гол. · ${s.assists} пас. · рейт ${s.avgRating.toFixed(2)}`,
        tr.list
      ));
    }
  }

  const byScore = (a: { score: number }, b: { score: number }) => b.score - a.score;
  const sortedPlayers = [...players].sort(byScore);
  const sortedClubs = [...clubs].sort(byScore);

  /** Шорт-лист награды: не больше 4 игроков от клуба — как в реальном голосовании,
   *  где список отражает весь сезон, а не только состав чемпиона. */
  const shortlist = (src: AwardNominee[], size: number, perClub = 4) => {
    const out: AwardNominee[] = [];
    const count = new Map<string, number>();
    for (const n of src) {
      if (out.length >= size) break;
      const c = count.get(n.teamId) ?? 0;
      if (c >= perClub) continue;
      count.set(n.teamId, c + 1);
      out.push(n);
    }
    // если не набрали (мало клубов) — добираем без ограничения
    for (const n of src) {
      if (out.length >= size) break;
      if (!out.includes(n)) out.push(n);
    }
    return out;
  };

  // ── Лучший вратарь ──
  // Награда за личное мастерство: сухие матчи, сейвы, надёжность, рейтинг.
  // Трофеи НЕ учитываются — кипер слабой команды с горой сейвов может победить.
  const gks = players
    .filter((n) => n.position === "GK")
    .map((n) => {
      const p = slot.teams[n.teamId].players.find((x) => x.id === n.playerId)!;
      const st = p.stats;
      const perApp = (v: number) => v / Math.max(1, st.apps);
      const volume = Math.min(1, st.apps / 25); // защита от «10 матчей и ушёл»
      const score =
        (st.avgRating - 6) * 34 * volume +
        st.cleanSheets * 3.4 +
        perApp(st.cleanSheets) * 26 +          // доля «сухарей» важнее их числа
        st.saves * 0.16 +
        perApp(st.saves) * 5 -                  // работал много — значит выручал
        perApp(st.conceded) * 16 -              // пропускаемость
        st.errors * 4;
      return { ...n, score: Math.round(score * 10) / 10 };
    })
    .sort(byScore);

  // ── Лучший молодой (до 21 включительно) ──
  // ── Лучший молодой игрок (до 21) ──
  // Оценивается личный вклад и игровое время, а не медали клуба.
  const young = shortlist(
    players
      .filter((n) => n.age <= 21)
      .map((n) => {
        const p = slot.teams[n.teamId].players.find((x) => x.id === n.playerId)!;
        const st = p.stats;
        const minutesK = Math.min(1, st.minutes / 1500);
        const attack = st.goals * 1.0 + st.assists * 0.75;
        const defensive = (st.tackles + st.interceptions) * 0.04 + st.cleanSheets * 0.45;
        const gkPart = p.position === "GK" ? st.saves * 0.06 + st.cleanSheets * 1.0 : 0;
        const score =
          (st.avgRating - 6) * 30 * minutesK +
          attack * (p.position === "DF" ? 1.6 : p.position === "GK" ? 2 : 1) +
          defensive * (p.position === "DF" ? 1.5 : 1) +
          gkPart +
          st.motm * 2 +
          minutesK * 10;                       // регулярная игра в столь юном возрасте — плюс
        return { ...n, score: Math.round(score * 10) / 10 };
      })
      .sort(byScore),
    5, 2
  );

  // ── Лучший бомбардир ──
  const scorers = players
    .map((n) => ({ ...n, score: n.goals * 10 + n.assists * 2 + (n.rating - 6) * 5 }))
    .filter((n) => n.goals > 0)
    .sort((a, b) => b.goals - a.goals || b.score - a.score)
    .slice(0, 15);

  return {
    seasonNumber: slot.seasonNumber,
    ballonDor: sortedPlayers[0] ?? null,
    ballonDorTop: shortlist(sortedPlayers, 15, 4),
    bestGoalkeeper: gks[0] ?? null,
    goalkeeperTop: gks.slice(0, 5),
    bestYoung: young[0] ?? null,
    youngTop: young,
    topScorer: scorers[0] ?? null,
    scorerTop: scorers,
    bestClub: sortedClubs[0] ?? null,
    clubTop: sortedClubs.slice(0, 15),
  };
}
