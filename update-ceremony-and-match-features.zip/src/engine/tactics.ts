// ─── Схемы, стили и стартовые составы всех клубов ────────────────────────────
// Пользователь — наблюдатель-редактор лиги: он настраивает тактику любого клуба.

import type { Player, Team, TeamTactics, Formation, PlayStyle } from "../types";
import { analyzeTactic, type TacticAnalysis } from "./tacticText";

export const FORMATIONS: Record<Formation, { df: number; mf: number; fw: number; atk: number; def: number; mid: number; label: string }> = {
  "4-4-2":   { df: 4, mf: 4, fw: 2, atk: 1.0,  def: 1.0,  mid: 1.0,  label: "Классический баланс" },
  "4-3-3":   { df: 4, mf: 3, fw: 3, atk: 1.1,  def: 0.95, mid: 1.05, label: "Атакующая ширина" },
  "3-5-2":   { df: 3, mf: 5, fw: 2, atk: 1.05, def: 0.95, mid: 1.15, label: "Контроль центра" },
  "4-2-3-1": { df: 4, mf: 5, fw: 1, atk: 1.05, def: 1.0,  mid: 1.1,  label: "Гибкая современная" },
  "5-3-2":   { df: 5, mf: 3, fw: 2, atk: 0.9,  def: 1.15, mid: 1.0,  label: "Оборонительный блок" },
  "4-5-1":   { df: 4, mf: 5, fw: 1, atk: 0.95, def: 1.05, mid: 1.1,  label: "Плотная середина" },
  "3-4-3":   { df: 3, mf: 4, fw: 3, atk: 1.15, def: 0.88, mid: 1.05, label: "Тотальная атака" },
};

export const FORMATION_LIST = Object.keys(FORMATIONS) as Formation[];

export const STYLES: Record<PlayStyle, { atk: number; def: number; label: string; short: string }> = {
  attacking:   { atk: 1.10, def: 0.90, label: "Атакующий", short: "АТК" },
  balanced:    { atk: 1.00, def: 1.00, label: "Сбалансированный", short: "БАЛ" },
  defensive:   { atk: 0.90, def: 1.10, label: "Оборонительный", short: "ОБР" },
};

export const STYLE_LIST = Object.keys(STYLES) as PlayStyle[];

/** Кэш разбора текстовых тактик (один и тот же текст — один результат) */
const textCache = new Map<string, TacticAnalysis>();

export function tacticAnalysis(t?: TeamTactics): TacticAnalysis | null {
  const txt = t?.textTactic?.trim();
  if (!txt || txt.length < 15) return null;
  let a = textCache.get(txt);
  if (!a) {
    a = analyzeTactic(txt);
    if (textCache.size > 300) textCache.clear();
    textCache.set(txt, a);
  }
  return a;
}

/** Итоговые множители силы команды: схема × стиль × качество текстового плана */
export function tacticMultipliers(t?: TeamTactics): { atk: number; def: number; mid: number } {
  const f = FORMATIONS[t?.formation ?? "4-3-3"];
  const s = STYLES[t?.style ?? "balanced"];
  const txt = tacticAnalysis(t);
  return {
    atk: f.atk * s.atk * (txt?.atk ?? 1),
    def: f.def * s.def * (txt?.def ?? 1),
    mid: f.mid * (txt?.mid ?? 1),
  };
}

/** Автовыбор стартового XI под схему (класс игрока × свежесть) */
export function autoStarters(team: Team, formation: Formation): string[] {
  const shape = FORMATIONS[formation];
  const score = (p: Player) => p.overall * (0.7 + 0.3 * Math.min(100, p.fitness) / 100);
  const pool = [...team.players].sort((a, b) => score(b) - score(a));
  const used = new Set<string>();
  const take = (pos: string, n: number) => {
    const out: string[] = [];
    for (const p of pool) {
      if (out.length >= n) break;
      if (p.position === pos && !used.has(p.id)) { out.push(p.id); used.add(p.id); }
    }
    return out;
  };
  const xi = [...take("GK", 1), ...take("DF", shape.df), ...take("MF", shape.mf), ...take("FW", shape.fw)];
  // добираем ближайшими по позиции, если состав неполный
  for (const p of pool) {
    if (xi.length >= 11) break;
    if (!used.has(p.id) && p.position !== "GK") { xi.push(p.id); used.add(p.id); }
  }
  return xi.slice(0, 11);
}

/** Тактика по умолчанию: схема по профилю клуба + авто-состав */
export function defaultTactics(team: Team): TeamTactics {
  const atkBias = team.attack - team.defense;
  const formation: Formation = atkBias >= 4 ? "4-3-3" : atkBias <= -4 ? "5-3-2" : "4-2-3-1";
  // по умолчанию почти все играют сбалансированно: стиль — инструмент пользователя
  const style: PlayStyle = atkBias >= 10 ? "attacking" : atkBias <= -10 ? "defensive" : "balanced";
  const starters = autoStarters(team, formation);
  const byOvr = [...team.players].sort((a, b) => b.overall - a.overall);
  const inXi = (pos?: string) =>
    byOvr.find((p) => starters.includes(p.id) && (!pos || p.position === pos))?.id ?? starters[0];
  const shooter = [...team.players]
    .filter((p) => starters.includes(p.id) && p.position !== "GK")
    .sort((a, b) => b.attack - a.attack)[0]?.id ?? starters[0];
  return {
    formation,
    style,
    starters,
    captain: inXi(),
    penaltyTaker: shooter,
    cornerTaker: inXi("MF") ?? shooter,
    freeKickTaker: shooter,
  };
}

export function buildAllTactics(teams: Record<string, Team>): Record<string, TeamTactics> {
  const out: Record<string, TeamTactics> = {};
  for (const t of Object.values(teams)) out[t.id] = defaultTactics(t);
  return out;
}

/** Валидирует состав: убирает ушедших игроков и дополняет до 11 */
export function sanitizeTactics(team: Team, t: TeamTactics | undefined): TeamTactics {
  if (!t) return defaultTactics(team);
  const ids = new Set(team.players.map((p) => p.id));
  let starters: string[] = t.starters.filter((id: string) => ids.has(id));
  if (starters.length < 11) {
    const auto = autoStarters(team, t.formation);
    for (const id of auto) {
      if (starters.length >= 11) break;
      if (!starters.includes(id)) starters.push(id);
    }
  }
  starters = starters.slice(0, 11);
  const fix = (id: string | undefined) => (id && starters.includes(id) ? id : starters[0]);
  return { ...t, starters, captain: fix(t.captain), penaltyTaker: fix(t.penaltyTaker), cornerTaker: fix(t.cornerTaker), freeKickTaker: fix(t.freeKickTaker) };
}

/** Раскладка XI по линиям для превью на поле */
export function linesOf(team: Team, t: TeamTactics): Player[][] {
  const byId = new Map(team.players.map((p) => [p.id, p]));
  const xi = t.starters.map((id: string) => byId.get(id)).filter(Boolean) as Player[];
  const gk = xi.filter((p) => p.position === "GK");
  const df = xi.filter((p) => p.position === "DF");
  const mf = xi.filter((p) => p.position === "MF");
  const fw = xi.filter((p) => p.position === "FW");
  return [gk, df, mf, fw].filter((l) => l.length);
}
