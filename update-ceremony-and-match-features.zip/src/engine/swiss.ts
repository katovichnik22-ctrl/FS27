// ─── Жеребьёвка общего этапа (Swiss model, 36 команд, 8 туров) ───────────────
// Структура гарантируется 1-факторизацией: 8 туров — 8 полных паросочетаний,
// значит каждая команда играет ровно 8 матчей с 8 разными соперниками,
// по одному матчу в тур. Ограничения (по 2 соперника из каждой корзины,
// не более 2 клубов из одной страны, без земляков) подгоняются отжигом.

import type { RngApi } from "./rng";

export interface SwissPair {
  homeId: string;
  awayId: string;
  matchday: number;
}

function shuffle<T>(arr: T[], rng: RngApi): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = rng.int(0, i);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Разбивка 36 команд на 4 корзины по 9 (по убыванию репутации) */
export function makePots(ordered: string[]): string[][] {
  const pots: string[][] = [[], [], [], []];
  ordered.forEach((id, i) => pots[Math.min(3, Math.floor(i / 9))].push(id));
  return pots;
}

/** Круговая 1-факторизация: n-1 туров по n/2 пар (индексы позиций) */
function factorize(n: number): [number, number][][] {
  const rounds: [number, number][][] = [];
  let rot = Array.from({ length: n - 1 }, (_, i) => i + 1);
  for (let r = 0; r < n - 1; r++) {
    const pairs: [number, number][] = [[0, rot[0]]];
    for (let k = 1; k < n / 2; k++) pairs.push([rot[k], rot[rot.length - k]]);
    rounds.push(pairs);
    rot = [rot[rot.length - 1], ...rot.slice(0, rot.length - 1)];
  }
  return rounds;
}

interface DrawCtx {
  potOf: Record<string, number>;
  country: Record<string, string>;
}

/** Штраф расписания: чем меньше, тем ближе к регламенту УЕФА */
function penalty(pairs: [string, string][], ctx: DrawCtx): number {
  const potCount: Record<string, number[]> = {};
  const cCount: Record<string, Record<string, number>> = {};
  let pen = 0;
  for (const [a, b] of pairs) {
    (potCount[a] ??= [0, 0, 0, 0])[ctx.potOf[b]]++;
    (potCount[b] ??= [0, 0, 0, 0])[ctx.potOf[a]]++;
    (cCount[a] ??= {})[ctx.country[b]] = ((cCount[a] ??= {})[ctx.country[b]] ?? 0) + 1;
    (cCount[b] ??= {})[ctx.country[a]] = ((cCount[b] ??= {})[ctx.country[a]] ?? 0) + 1;
    if (ctx.country[a] === ctx.country[b]) pen += 12; // земляки — грубое нарушение
  }
  for (const counts of Object.values(potCount)) for (const c of counts) pen += Math.abs(c - 2) * 3;
  for (const m of Object.values(cCount)) for (const c of Object.values(m)) if (c > 2) pen += (c - 2) * 6;
  return pen;
}

/** Расстановка хозяев: стремимся к 4 домашним матчам у каждого */
function orient(rounds: [string, string][][], rng: RngApi): SwissPair[] {
  const home: Record<string, number> = {};
  const away: Record<string, number> = {};
  const out: SwissPair[] = [];
  rounds.forEach((pairs, r) => {
    for (const [a, b] of shuffle(pairs, rng)) {
      const ha = home[a] ?? 0, hb = home[b] ?? 0;
      const aa = away[a] ?? 0, ab = away[b] ?? 0;
      // хозяин — тот, у кого меньше домашних (и больше выездных)
      const aHome = ha - aa < hb - ab || (ha - aa === hb - ab && rng.chance(0.5));
      const h = aHome ? a : b;
      const g = aHome ? b : a;
      home[h] = (home[h] ?? 0) + 1;
      away[g] = (away[g] ?? 0) + 1;
      out.push({ homeId: h, awayId: g, matchday: r + 1 });
    }
  });
  return out;
}

/** Полная жеребьёвка общего этапа: 36 команд → 144 матча в 8 турах */
export function drawSwiss(orderedByRep: string[], country: Record<string, string>, rng: RngApi): SwissPair[] {
  const n = orderedByRep.length;
  const pots = makePots(orderedByRep);
  const potOf: Record<string, number> = {};
  pots.forEach((pot, i) => pot.forEach((id) => (potOf[id] = i)));
  const ctx: DrawCtx = { potOf, country };

  const factors = factorize(n);
  // выбираем 8 туров из n-1 и случайную расстановку команд по позициям
  const pickRounds = () => shuffle(factors.map((_, i) => i), rng).slice(0, 8);
  let rounds = pickRounds();
  let labels = shuffle(orderedByRep, rng);

  const materialize = (lab: string[], rs: number[]): [string, string][][] =>
    rs.map((r) => factors[r].map(([i, j]) => [lab[i], lab[j]] as [string, string]));

  const flat = (m: [string, string][][]) => m.flat();
  let best = materialize(labels, rounds);
  let bestPen = penalty(flat(best), ctx);

  // отжиг: меняем местами команды на позициях, иногда пересобираем набор туров
  let temp = 8;
  for (let step = 0; step < 5000 && bestPen > 0; step++) {
    const cand = [...labels];
    const i = rng.int(0, n - 1);
    let j = rng.int(0, n - 1);
    while (j === i) j = rng.int(0, n - 1);
    [cand[i], cand[j]] = [cand[j], cand[i]];
    const candRounds = step % 700 === 699 ? pickRounds() : rounds;
    const m = materialize(cand, candRounds);
    const pen = penalty(flat(m), ctx);
    if (pen <= bestPen || rng.next() < Math.exp((bestPen - pen) / Math.max(0.4, temp))) {
      labels = cand;
      rounds = candRounds;
      if (pen < bestPen) { bestPen = pen; best = m; }
    }
    temp = Math.max(0.4, temp * 0.9995);
  }
  return orient(best, rng);
}
