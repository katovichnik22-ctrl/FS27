// ─── Трансферы: конструктор обменов между любыми клубами ─────────────────────
// Пользователь — наблюдатель лиги: он может передвинуть любого игрока
// в любой клуб (в рамках трансферного окна и проверок состава).

import type { LoanRecord, Player, Slot, Team, TransferRecord } from "../types";
import { sanitizeTactics } from "./tactics";

export const MIN_SQUAD = 11;

/** Пересчёт тактики и клубных рейтингов после изменения состава */
function retune(slot: Slot, t: Team): void {
  slot.tactics[t.id] = sanitizeTactics(t, slot.tactics[t.id]);
  const byPos = (pos: string) => t.players.filter((p) => p.position === pos).sort((a, b) => b.overall - a.overall);
  const avg = (arr: Player[], n: number) =>
    arr.length ? Math.round(arr.slice(0, n).reduce((s, p) => s + p.overall, 0) / Math.min(n, arr.length)) : 70;
  t.attack = avg(byPos("FW"), 3);
  t.midfield = avg(byPos("MF"), 3);
  t.defense = avg(byPos("DF"), 4);
  t.goalkeeping = avg(byPos("GK"), 1);
}

const genTrId = () => `tr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`;

/** Трансферные окна: 1 июля – 31 августа и 1 – 31 января */
export function isWindowOpen(date: string): boolean {
  const m = Number(date.slice(5, 7));
  return m === 7 || m === 8 || m === 1;
}

export function windowLabel(date: string): string {
  const m = Number(date.slice(5, 7));
  if (m === 7 || m === 8) return "Летнее окно открыто (1 июля – 31 августа)";
  if (m === 1) return "Зимнее окно открыто (1 – 31 января)";
  return "Окно закрыто · ближайшее: 1 января";
}

/**
 * Оценочная стоимость игрока (млн £).
 * Калибровано по реальным данным Transfermarkt 2026:
 * ovr 70 ≈ £2M, 75 ≈ £8M, 80 ≈ £20M, 85 ≈ £45M, 90 ≈ £90M, 95 ≈ £165M.
 * Возраст: молодые дороже, после 30 стоимость быстро падает.
 */
export function marketValue(p: Player): number {
  const base = Math.pow(Math.max(56, p.overall) - 55, 4.5) / 98500;
  const ageK =
    p.age <= 21 ? 1.3
    : p.age <= 26 ? 1.15
    : p.age <= 29 ? 1.0
    : p.age <= 32 ? 0.6
    : p.age <= 35 ? 0.3
    : 0.12;
  const v = base * ageK;
  const rounded = v >= 20 ? Math.round(v) : v >= 2 ? Math.round(v * 2) / 2 : Math.round(v * 10) / 10;
  return Math.max(0.2, Math.min(250, rounded));
}

export interface TransferPlan {
  fromId: string | null; // null = свободные агенты
  toId: string;
  playersOut: string[]; // id игроков, уходящих из fromId в toId
  playersBack: string[]; // id игроков, уходящих из toId в fromId (обмен)
  fee: number; // млн £, платит toId клубу fromId (может быть отрицательной)
}

export interface ValidationResult {
  ok: boolean;
  errors: string[];
  warnings: string[];
}

export function validateTransfer(slot: Slot, plan: TransferPlan): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const to = slot.teams[plan.toId];
  const from = plan.fromId ? slot.teams[plan.fromId] : null;

  if (!to) errors.push("Не выбран клуб-покупатель");
  if (plan.fromId && !from) errors.push("Клуб-продавец не найден");
  if (plan.fromId === plan.toId) errors.push("Нельзя совершить трансфер внутри одного клуба");
  if (!plan.playersOut.length && !plan.playersBack.length) errors.push("Не выбрано ни одного игрока");
  if (!isWindowOpen(slot.currentDate)) errors.push("Трансферное окно закрыто");

  if (to && from) {
    const fromAfter = from.players.length - plan.playersOut.length + plan.playersBack.length;
    const toAfter = to.players.length - plan.playersBack.length + plan.playersOut.length;
    if (fromAfter < MIN_SQUAD) errors.push(`У «${from.name}» останется ${fromAfter} игроков (минимум ${MIN_SQUAD})`);
    if (toAfter < MIN_SQUAD) errors.push(`У «${to.name}» останется ${toAfter} игроков (минимум ${MIN_SQUAD})`);
    // дубли
    for (const id of plan.playersOut) if (to.players.some((p) => p.id === id)) errors.push("Игрок уже есть в клубе-покупателе");
    for (const id of plan.playersBack) if (from.players.some((p) => p.id === id)) errors.push("Игрок уже есть в клубе-продавце");
  }

  // арендованных игроков продать/обменять нельзя — они принадлежат другому клубу
  for (const id of [...plan.playersOut, ...plan.playersBack]) {
    const ln = (slot.loans ?? []).find((l) => l.playerId === id);
    if (ln) errors.push(`Игрок в аренде из «${slot.teams[ln.parentId]?.name ?? "другого клуба"}» — сначала завершите аренду`);
  }
  if (to && !from) {
    const toAfter = to.players.length + plan.playersOut.length;
    if (toAfter < MIN_SQUAD) errors.push(`У «${to.name}» останется ${toAfter} игроков (минимум ${MIN_SQUAD})`);
  }

  if (to && plan.fee > 0) {
    if (plan.fee > to.budget) errors.push(`Бюджет «${to.name}» (£${to.budget}M) меньше суммы сделки £${plan.fee}M`);
    else if (plan.fee > to.budget * 0.75) warnings.push(`Сделка съест большую часть бюджета «${to.name}»`);
  }
  if (from && plan.fee < 0 && Math.abs(plan.fee) > from.budget) {
    errors.push(`Бюджет «${from.name}» не позволяет доплату £${Math.abs(plan.fee)}M`);
  }

  // подсказка по рыночной стоимости
  if (to && plan.playersOut.length) {
    const pool = from ? from.players : slot.freeAgents;
    const worth = plan.playersOut.reduce((s, id) => s + (pool.find((p) => p.id === id) ? marketValue(pool.find((p) => p.id === id)!) : 0), 0);
    const back = plan.playersBack.reduce((s, id) => s + (to.players.find((p) => p.id === id) ? marketValue(to.players.find((p) => p.id === id)!) : 0), 0);
    const fair = worth - back;
    if (plan.fee < fair * 0.4 && fair > 3) warnings.push(`Рыночная оценка сделки ≈ £${fair.toFixed(1)}M — сумма занижена`);
  }

  return { ok: errors.length === 0, errors, warnings };
}

/** Совершает трансфер: перемещает игроков, двигает бюджеты, чинит составы */
export function executeTransfer(slot: Slot, plan: TransferPlan): TransferRecord {
  const v = validateTransfer(slot, plan);
  if (!v.ok) throw new Error(v.errors[0]);

  const to = slot.teams[plan.toId];
  const from = plan.fromId ? slot.teams[plan.fromId] : null;
  const names: string[] = [];

  const move = (ids: string[], src: Player[], dst: Player[]) => {
    for (const id of ids) {
      const idx = src.findIndex((p) => p.id === id);
      if (idx === -1) continue;
      const [p] = src.splice(idx, 1);
      names.push(p.name);
      dst.push(p);
    }
  };

  if (from) {
    move(plan.playersOut, from.players, to.players);
    move(plan.playersBack, to.players, from.players);
    from.budget = Math.round((from.budget + plan.fee) * 10) / 10;
    to.budget = Math.round((to.budget - plan.fee) * 10) / 10;
  } else {
    move(plan.playersOut, slot.freeAgents, to.players);
    to.budget = Math.round((to.budget - Math.max(0, plan.fee)) * 10) / 10;
  }

  // состав и тактика клубов приводятся в порядок
  for (const t of [to, from].filter(Boolean) as (typeof to)[]) {
    slot.tactics[t.id] = sanitizeTactics(t, slot.tactics[t.id]);
    // клубные рейтинги пересчитываются под новый состав
    const byPos = (pos: string) => t.players.filter((p) => p.position === pos).sort((a, b) => b.overall - a.overall);
    const avg = (arr: Player[], n: number) =>
      arr.length ? Math.round(arr.slice(0, n).reduce((s, p) => s + p.overall, 0) / Math.min(n, arr.length)) : 70;
    t.attack = avg(byPos("FW"), 3);
    t.midfield = avg(byPos("MF"), 3);
    t.defense = avg(byPos("DF"), 4);
    t.goalkeeping = avg(byPos("GK"), 1);
  }

  const rec: TransferRecord = {
    id: `tr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
    date: slot.currentDate,
    fromId: plan.fromId,
    toId: plan.toId,
    playerIds: [...plan.playersOut, ...plan.playersBack],
    playerNames: names,
    fee: plan.fee,
    kind: !plan.fromId ? "free" : plan.playersBack.length ? "swap" : "transfer",
  };
  slot.transfers.unshift(rec);
  return rec;
}

/** Отправить игрока в свободные агенты (освободить) */
export function releasePlayer(slot: Slot, teamId: string, playerId: string): boolean {
  const team = slot.teams[teamId];
  if (!team || team.players.length <= MIN_SQUAD) return false;
  // арендованного игрока отпустить нельзя: он принадлежит другому клубу
  if ((slot.loans ?? []).some((l) => l.playerId === playerId)) return false;
  const idx = team.players.findIndex((p) => p.id === playerId);
  if (idx === -1) return false;
  const [p] = team.players.splice(idx, 1);
  slot.freeAgents.push(p);
  slot.tactics[teamId] = sanitizeTactics(team, slot.tactics[teamId]);
  slot.transfers.unshift({
    id: `tr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
    date: slot.currentDate,
    fromId: teamId,
    toId: "free_agents",
    playerIds: [p.id],
    playerNames: [p.name],
    fee: 0,
    kind: "free",
  });
  return true;
}

// ─── Аренды ───────────────────────────────────────────────────────────────────
// Игрок временно играет за другой клуб: владелец получает сумму аренды,
// а по окончании срока футболист автоматически возвращается домой.
// Календарь сезона повторяется каждый год, поэтому возврат привязан
// к номеру сезона (endSeason) и «точке возврата»: 1 января или 1 июля.

export type LoanMonths = 6 | 12 | 24;

export interface LoanPlan {
  parentId: string;  // клуб-владелец
  hostId: string;    // клуб аренды
  playerId: string;
  months: LoanMonths;
  fee: number;       // млн £, платит клуб аренды владельцу
}

/** Точка возврата в календаре сезона: зима (1 января) или лето (1 июля) */
const WINTER_END = "2027-01-01";
const SUMMER_END = "2027-07-01";

/** окно, в котором оформляется аренда */
export function loanWindow(date: string): "summer" | "winter" {
  return Number(date.slice(5, 7)) === 1 ? "winter" : "summer";
}

/** Дата и сезон окончания аренды, оформленной в сезоне startSeason */
export function loanEndFor(startSeason: number, startDate: string, months: LoanMonths): { endDate: string; endSeason: number } {
  const w = loanWindow(startDate) === "winter";
  if (months === 6)  return w ? { endDate: SUMMER_END, endSeason: startSeason }     : { endDate: WINTER_END, endSeason: startSeason };
  if (months === 12) return w ? { endDate: WINTER_END, endSeason: startSeason + 1 } : { endDate: SUMMER_END, endSeason: startSeason };
  return w                    ? { endDate: WINTER_END, endSeason: startSeason + 2 } : { endDate: SUMMER_END, endSeason: startSeason + 1 };
}

/** Подпись «до когда игрок в аренде» для UI */
export function loanUntilLabel(ln: { endDate: string; endSeason: number }, currentSeason: number): string {
  const winter = ln.endDate.slice(5, 7) === "01";
  const span = ln.endSeason - currentSeason;
  if (winter) return span <= 0 ? "до января" : span === 1 ? "до января след. сезона" : "до января через 2 сезона";
  return span <= 0 ? "до конца сезона" : "до конца след. сезона";
}

export const LOAN_DURATION_LABELS: Record<LoanMonths, string> = {
  6: "6 месяцев",
  12: "1 год",
  24: "2 года",
};

/** Рекомендованная сумма аренды: ~12% рыночной стоимости за год */
export function suggestLoanFee(p: Player, months: LoanMonths): number {
  const v = marketValue(p) * 0.12 * (months / 12);
  return Math.max(0.1, Math.round(v * 10) / 10);
}

/** Карта активных аренд: playerId → LoanRecord (для UI и проверок) */
export function loansByPlayer(slot: Slot): Map<string, LoanRecord> {
  const m = new Map<string, LoanRecord>();
  for (const ln of slot.loans ?? []) m.set(ln.playerId, ln);
  return m;
}

export function validateLoan(slot: Slot, plan: LoanPlan): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];
  const parent = slot.teams[plan.parentId];
  const host = slot.teams[plan.hostId];

  if (!parent) errors.push("Клуб-владелец не найден");
  if (!host) errors.push("Не выбран клуб аренды");
  if (plan.parentId === plan.hostId) errors.push("Нельзя отдать игрока в аренду в тот же клуб");
  if (!isWindowOpen(slot.currentDate)) errors.push("Трансферное окно закрыто");

  const player = parent?.players.find((p) => p.id === plan.playerId);
  if (parent && !player) errors.push("Игрок не найден в клубе-владельце");

  if (player) {
    if ((slot.loans ?? []).some((l) => l.playerId === player.id)) errors.push("Игрок уже находится в аренде");
    if (host && host.players.some((p) => p.id === player.id)) errors.push("Игрок уже есть в клубе аренды");
  }

  if (parent && player) {
    const after = parent.players.length - 1;
    if (after < MIN_SQUAD) errors.push(`У «${parent.name}» останется ${after} игроков (минимум ${MIN_SQUAD})`);
  }

  if (host && plan.fee > 0) {
    if (plan.fee > host.budget) errors.push(`Бюджет «${host.name}» (£${host.budget}M) меньше суммы аренды £${plan.fee}M`);
    else if (plan.fee > host.budget * 0.75) warnings.push(`Аренда съест большую часть бюджета «${host.name}»`);
  }

  if (player) {
    const fair = suggestLoanFee(player, plan.months);
    if (plan.fee < fair * 0.3 && fair > 1) warnings.push(`Оценка аренды ≈ £${fair}M — сумма занижена`);
  }

  return { ok: errors.length === 0, errors, warnings };
}

/** Оформить аренду: игрок уходит в клуб аренды, владелец получает сумму */
export function executeLoan(slot: Slot, plan: LoanPlan): LoanRecord {
  const v = validateLoan(slot, plan);
  if (!v.ok) throw new Error(v.errors[0]);

  const parent = slot.teams[plan.parentId];
  const host = slot.teams[plan.hostId];
  const idx = parent.players.findIndex((p) => p.id === plan.playerId);
  const [p] = parent.players.splice(idx, 1);
  host.players.push(p);

  parent.budget = Math.round((parent.budget + plan.fee) * 10) / 10;
  host.budget = Math.round((host.budget - plan.fee) * 10) / 10;
  retune(slot, parent);
  retune(slot, host);

  const { endDate, endSeason } = loanEndFor(slot.seasonNumber, slot.currentDate, plan.months);
  const ln: LoanRecord = {
    id: `ln_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
    playerId: p.id,
    playerName: p.name,
    parentId: parent.id,
    hostId: host.id,
    startDate: slot.currentDate,
    endDate,
    endSeason,
    months: plan.months,
    fee: plan.fee,
  };
  slot.loans = slot.loans ?? [];
  slot.loans.unshift(ln);
  slot.transfers.unshift({
    id: genTrId(),
    date: slot.currentDate,
    fromId: parent.id,
    toId: host.id,
    playerIds: [p.id],
    playerNames: [p.name],
    fee: plan.fee,
    kind: "loan",
  });
  return ln;
}

/** Вернуть игрока из аренды домой + запись в историю */
function applyLoanReturn(slot: Slot, ln: LoanRecord, date: string): void {
  const host = slot.teams[ln.hostId];
  const parent = slot.teams[ln.parentId];
  if (host && parent) {
    const idx = host.players.findIndex((p) => p.id === ln.playerId);
    if (idx !== -1) {
      const [p] = host.players.splice(idx, 1);
      parent.players.push(p);
    }
    retune(slot, host);
    retune(slot, parent);
  }
  slot.transfers.unshift({
    id: genTrId(),
    date,
    fromId: ln.hostId,
    toId: ln.parentId,
    playerIds: [ln.playerId],
    playerNames: [ln.playerName],
    fee: 0,
    kind: "loan_return",
  });
}

/**
 * Автоматический возврат аренд.
 * trigger "day"        — вызывается при смене даты: возвращает зимние аренды,
 *                        срок которых истёк в ЭТОМ сезоне (1 января);
 * trigger "newSeason"  — вызывается при старте нового сезона: возвращает всё,
 *                        что должно было завершиться раньше (летние аренды).
 */
export function processLoanReturns(slot: Slot, trigger: "day" | "newSeason" = "day"): LoanRecord[] {
  const loans = slot.loans ?? [];
  if (!loans.length) return [];
  const isWinter = (d: string) => d.slice(5, 7) === "01";
  const due = loans.filter((ln) =>
    trigger === "newSeason"
      ? ln.endSeason < slot.seasonNumber
      : isWinter(ln.endDate) && ln.endSeason === slot.seasonNumber && ln.endDate <= slot.currentDate
  );
  if (!due.length) return [];
  slot.loans = loans.filter((ln) => !due.includes(ln));
  for (const ln of due) applyLoanReturn(slot, ln, trigger === "day" ? slot.currentDate : ln.endDate);
  return due;
}

/** Досрочный отзыв игрока из аренды (вручную, в любой момент) */
export function terminateLoan(slot: Slot, loanId: string): LoanRecord | null {
  const loans = slot.loans ?? [];
  const ln = loans.find((l) => l.id === loanId);
  if (!ln) return null;
  slot.loans = loans.filter((l) => l.id !== loanId);
  applyLoanReturn(slot, ln, slot.currentDate);
  return ln;
}
