// ─── Сезон: расписание, турниры, календарь, применение результатов ──────────
import type {
  Competition, CupState, EuroState, Fixture, FixtureResult, LeagueId, MatchResult, Player, SeasonState, Slot, TableRow, Team, Tie,
} from "../types";
import { simulateMatch } from "./match";
import { makeRng, type RngApi } from "./rng";
import { drawSwiss } from "./swiss";
import { processLoanReturns } from "./transfers";

// ─── Даты ────────────────────────────────────────────────────────────────────

export const SEASON_START = "2026-08-15"; // первая суббота сезона

export function addDays(date: string, n: number): string {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}
export const cmpDate = (a: string, b: string) => (a < b ? -1 : a > b ? 1 : 0);
export function fmtDay(date: string): string {
  return new Date(`${date}T00:00:00Z`).toLocaleDateString("ru-RU", {
    day: "numeric", month: "short", weekday: "short", timeZone: "UTC",
  });
}
/** суббота недели w */
const sat = (w: number) => addDays(SEASON_START, w * 7);
/** воскресенье недели w */
const sun = (w: number) => addDays(SEASON_START, w * 7 + 1);
/** среда недели w */
const wed = (w: number) => addDays(SEASON_START, w * 7 + 4);

// Недели, занятые Кубком Англии (суббота) — АПЛ в эти выходные не играет
const FA_WEEKS = [13, 17, 21, 26, 32, 41];
// Еврокубки и кубки — по средам
const EURO_LP_WEEKS = [3, 5, 7, 9, 11, 14, 16, 18];
const EURO_KO_WEEKS: Record<string, number[]> = {
  PO: [25, 26], R16: [29, 30], QF: [33, 34], SF: [37, 38], F: [40],
};
const EFL_WEEKS = [1, 4, 8, 12, 20, 27];
const CDR_WEEKS = [6, 12, 22, 31, 39];               // Copa del Rey
const CDF_WEEKS = [10, 19, 24, 35, 36];
const DFB_WEEKS = [7, 15, 23, 30, 38];               // DFB-Pokal
const CIT_WEEKS = [8, 16, 25, 33, 40];
const TCP_WEEKS = [9, 18, 27, 34, 43];               // Taça de Portugal
const KSC_WEEKS = [11, 20, 28, 36, 44];              // King's Cup               // Coppa Italia              // Coupe de France
const PL_MIDWEEK = [2, 6];                            // добивочные туры АПЛ

export interface LeagueCfg {
  id: LeagueId;
  comp: Competition;
  name: string;
  short: string;
  country: string;
  teams: number;
  rounds: number;
  /** зоны: сколько мест в ЛЧ / ЛЕ / вылет */
  ucl: number; uel: number; uecl: number; drop: number;
  dates: string[];
}

function leagueDates(kind: "sat" | "sun", rounds: number, skipWeeks: number[], midweek: number[]): string[] {
  const out: { d: string; w: number }[] = [];
  for (const w of midweek) out.push({ d: wed(w), w: w + 0.5 });
  for (let w = 0; w < 46 && out.length < rounds; w++) {
    if (skipWeeks.includes(w)) continue;
    out.push({ d: kind === "sat" ? sat(w) : sun(w), w });
  }
  return out.sort((x, y) => x.w - y.w).slice(0, rounds).map((x) => x.d);
}

export const LEAGUE_CFG: Record<LeagueId, LeagueCfg> = {
  PL: {
    id: "PL", comp: "PL", name: "Premier League", short: "PL", country: "ENG",
    teams: 20, rounds: 38, ucl: 4, uel: 2, uecl: 1, drop: 3,
    dates: leagueDates("sat", 38, FA_WEEKS, PL_MIDWEEK),
  },
  LL: {
    id: "LL", comp: "LL", name: "La Liga", short: "LaLiga", country: "ESP",
    teams: 20, rounds: 38, ucl: 4, uel: 2, uecl: 1, drop: 3,
    dates: leagueDates("sun", 38, [13, 26], []),
  },
  FL1: {
    id: "FL1", comp: "FL1", name: "Ligue 1", short: "Ligue 1", country: "FRA",
    teams: 18, rounds: 34, ucl: 3, uel: 2, uecl: 1, drop: 2,
    dates: leagueDates("sun", 34, [13, 21, 26, 32], []),
  },
  BL: {
    id: "BL", comp: "BL", name: "Bundesliga", short: "Bundesliga", country: "GER",
    teams: 18, rounds: 34, ucl: 4, uel: 2, uecl: 1, drop: 2,
    dates: leagueDates("sat", 34, [13, 21, 26, 32], []),
  },
  SA: {
    id: "SA", comp: "SA", name: "Serie A", short: "Serie A", country: "ITA",
    teams: 20, rounds: 38, ucl: 4, uel: 2, uecl: 1, drop: 3,
    dates: leagueDates("sun", 38, [13, 26], []),
  },
  PT: {
    id: "PT", comp: "PT", name: "Liga Portugal", short: "Liga PT", country: "POR",
    teams: 18, rounds: 34, ucl: 2, uel: 1, uecl: 1, drop: 2,
    dates: leagueDates("sun", 34, [9, 18, 27, 34], []),
  },
  SPL: {
    id: "SPL", comp: "SPL", name: "Saudi Pro League", short: "Saudi PL", country: "KSA",
    teams: 18, rounds: 34, ucl: 0, uel: 0, uecl: 0, drop: 3,
    dates: leagueDates("sat", 34, [11, 20, 28, 36], []),
  },
  // Второй дивизион Англии: в еврокубки не попадает (ucl/uel/uecl = 0),
  // но играет в FA Cup и Кубке лиги вместе с клубами АПЛ.
  CHA: {
    id: "CHA", comp: "CHA", name: "EFL Championship", short: "Champ.", country: "ENG",
    teams: 24, rounds: 46, ucl: 0, uel: 0, uecl: 0, drop: 3,
    dates: leagueDates("sat", 46, [], [2, 6, 10, 15, 19, 24, 29, 35]),
  },
  TUR: {
    id: "TUR", comp: "TUR", name: "Süper Lig", short: "Süper Lig", country: "TUR",
    teams: 18, rounds: 34, ucl: 1, uel: 1, uecl: 1, drop: 3,
    dates: leagueDates("sun", 34, [8, 16, 24, 32], []),
  },
  BEL: {
    id: "BEL", comp: "BEL", name: "Belgian Pro League", short: "Pro League", country: "BEL",
    teams: 18, rounds: 34, ucl: 1, uel: 1, uecl: 1, drop: 2,
    dates: leagueDates("sun", 34, [9, 17, 25, 33], []),
  },
  NED: {
    id: "NED", comp: "NED", name: "Eredivisie", short: "Eredivisie", country: "NED",
    teams: 18, rounds: 34, ucl: 2, uel: 1, uecl: 1, drop: 2,
    dates: leagueDates("sun", 34, [8, 16, 24, 32], []),
  },
  GRE: {
    id: "GRE", comp: "GRE", name: "Super League Greece", short: "Super League", country: "GRE",
    teams: 14, rounds: 26, ucl: 2, uel: 1, uecl: 1, drop: 2,
    dates: leagueDates("sun", 26, [9, 18], []),
  },
  UKR: {
    id: "UKR", comp: "UKR", name: "Ukrainian Premier League", short: "UPL", country: "UKR",
    teams: 16, rounds: 30, ucl: 1, uel: 1, uecl: 1, drop: 2,
    dates: leagueDates("sun", 30, [10, 20], []),
  },
  POL: {
    id: "POL", comp: "POL", name: "Ekstraklasa", short: "Ekstraklasa", country: "POL",
    teams: 18, rounds: 34, ucl: 1, uel: 1, uecl: 1, drop: 3,
    dates: leagueDates("sun", 34, [9, 18, 27], []),
  },
  SCO: {
    id: "SCO", comp: "SCO", name: "Scottish Premiership", short: "Premiership", country: "SCO",
    teams: 12, rounds: 22, ucl: 1, uel: 1, uecl: 1, drop: 1,
    dates: leagueDates("sat", 22, [11], []),
  },
  SUI: {
    id: "SUI", comp: "SUI", name: "Swiss Super League", short: "Super League", country: "SUI",
    teams: 12, rounds: 22, ucl: 1, uel: 1, uecl: 1, drop: 2,
    dates: leagueDates("sun", 22, [11], []),
  },
};

/** Национальный кубок лиги */
export const LEAGUE_CUP: Record<LeagueId, { comp: Competition; weeks: number[]; size: number; tier: string }> = {
  PL: { comp: "FA", weeks: FA_WEEKS, size: 64, tier: "CH+L1" },  // +клубы Чемпионшипа, если лига выбрана
  LL: { comp: "CDR", weeks: CDR_WEEKS, size: 32, tier: "ES2" },
  FL1: { comp: "CDF", weeks: CDF_WEEKS, size: 32, tier: "FR2" },
  BL: { comp: "DFB", weeks: DFB_WEEKS, size: 32, tier: "DE2" },
  SA: { comp: "CIT", weeks: CIT_WEEKS, size: 32, tier: "IT2" },
  PT: { comp: "TCP", weeks: TCP_WEEKS, size: 32, tier: "PT2" },
  SPL: { comp: "KSC", weeks: KSC_WEEKS, size: 16, tier: "SA2" },
  // У Чемпионшипа нет своего кубка — его клубы уже участвуют в FA Cup и EFL Cup
  CHA: { comp: "FA", weeks: FA_WEEKS, size: 0, tier: "L1" },
  TUR: { comp: "TUC", weeks: [7, 15, 23, 31, 40], size: 16, tier: "TR2" },
  BEL: { comp: "BCB", weeks: [10, 19, 28, 36, 43], size: 16, tier: "BE2" },
  NED: { comp: "DTC", weeks: [9, 18, 27, 35, 42], size: 16, tier: "NE2" },
  GRE: { comp: "GRC", weeks: [11, 20, 29, 38], size: 12, tier: "GR2" },
  UKR: { comp: "UKC", weeks: [12, 21, 30, 39], size: 12, tier: "UA2" },
  POL: { comp: "PLC", weeks: [13, 22, 31, 40], size: 12, tier: "PO2" },
  SCO: { comp: "SCC", weeks: [14, 23, 32, 41], size: 10, tier: "SC2" },
  SUI: { comp: "SWC", weeks: [15, 24, 33, 42], size: 10, tier: "SW2" },
};

export const LEAGUE_IDS: LeagueId[] = ["PL", "CHA", "LL", "FL1", "BL", "SA", "PT", "SPL", "TUR", "BEL", "NED", "GRE", "UKR", "POL", "SCO", "SUI"];
export const isLeagueComp = (c: Competition): c is LeagueId => (LEAGUE_IDS as string[]).includes(c);

/** Совместимость с прежним кодом/тестами */
export const PL_DATES = LEAGUE_CFG.PL.dates;

export const COMP_NAME: Record<Competition, string> = {
  PL: "Premier League",
  LL: "La Liga",
  FL1: "Ligue 1",
  BL: "Bundesliga",
  SA: "Serie A",
  PT: "Liga Portugal",
  SPL: "Saudi Pro League",
  CHA: "EFL Championship",
  TUR: "Süper Lig",
  BEL: "Belgian Pro League",
  NED: "Eredivisie",
  GRE: "Super League Greece",
  UKR: "Ukrainian Premier League",
  POL: "Ekstraklasa",
  SCO: "Scottish Premiership",
  SUI: "Swiss Super League",
  UCL: "Лига чемпионов",
  UEL: "Лига Европы",
  UECL: "Лига конференций",
  FA: "FA Cup",
  EFL: "EFL Cup",
  CDR: "Copa del Rey",
  CDF: "Coupe de France",
  DFB: "DFB-Pokal",
  CIT: "Coppa Italia",
  TCP: "Кубок Португалии",
  KSC: "Кубок короля",
  TUC: "Кубок Турции",
  DTC: "Кубок Нидерландов",
  GRC: "Кубок Греции",
  UKC: "Кубок Украины",
  PLC: "Кубок Польши",
  SCC: "Кубок Шотландии",
  SWC: "Кубок Швейцарии",
  BCB: "Кубок Бельгии",
  FR: "Товарищеский",
};

export const COMP_SHORT: Record<Competition, string> = {
  PL: "PL", LL: "LaLiga", FL1: "L1", BL: "BL", SA: "SA", PT: "LigaPT", SPL: "SPL", CHA: "Champ", TUR: "SüperLig", BEL: "ProLg", NED: "Ered", GRE: "SLG", UKR: "UPL", POL: "Ekstra", SCO: "Scot", SUI: "Swiss", UCL: "UCL", UEL: "UEL", UECL: "UECL",
  FA: "FA", EFL: "EFL", CDR: "CDR", CDF: "CDF", DFB: "DFB", CIT: "CIT", TCP: "TaçaPT", KSC: "KSC", TUC: "TUR", BCB: "BEL", DTC: "KNVB", GRC: "GrCup", UKC: "UkrC", PLC: "PolC", SCC: "ScotC", SWC: "SwissC", FR: "ТМ",
};

export const STAGE_NAME: Record<string, string> = {
  PO: "Раунд плей-офф", R16: "1/8 финала", QF: "1/4 финала", SF: "1/2 финала", F: "Финал",
  R64: "1/32 финала", R32: "1/16 финала", R1: "Первый раунд",
};

export function stageLabel(f: { comp: Competition; stage: string; matchday: number }): string {
  if (f.comp === "FR") return "Товарищеский";
  if (isLeagueComp(f.comp)) return `${f.matchday}-й тур`;
  if (f.stage.startsWith("LP")) return `Общий этап · тур ${f.matchday}`;
  return STAGE_NAME[f.stage] ?? f.stage;
}

// ─── Расписание АПЛ (Berger tables) ──────────────────────────────────────────

export function generateFixtures(teamIds: string[], rng: RngApi, comp: Competition = "PL"): Omit<Fixture, "id" | "date">[] {
  const teams = [...teamIds];
  // перемешиваем, чтобы каждый сезон расписание было новым
  for (let i = teams.length - 1; i > 0; i--) {
    const j = rng.int(0, i);
    [teams[i], teams[j]] = [teams[j], teams[i]];
  }
  const n = teams.length;
  const rounds: [string, string][][] = [];
  const fixed = teams[0];
  let rot = teams.slice(1);
  for (let r = 0; r < n - 1; r++) {
    const pairs: [string, string][] = [];
    // Berger: чередование хозяев для «фиксированной» команды
    pairs.push(r % 2 === 0 ? [fixed, rot[0]] : [rot[0], fixed]);
    for (let k = 1; k < n / 2; k++) {
      const a = rot[k];
      const b = rot[rot.length - k];
      pairs.push(k % 2 === 0 ? [a, b] : [b, a]);
    }
    rounds.push(pairs);
    rot = [rot[rot.length - 1], ...rot.slice(0, rot.length - 1)];
  }
  const out: Omit<Fixture, "id" | "date">[] = [];
  rounds.forEach((pairs, i) => {
    for (const [h, a] of pairs)
      out.push({ comp, stage: `MD${i + 1}`, matchday: i + 1, homeId: h, awayId: a, neutral: false, played: false, result: null });
  });
  // второй круг — зеркально
  rounds.forEach((pairs, i) => {
    for (const [h, a] of pairs)
      out.push({ comp, stage: `MD${i + n}`, matchday: i + n, homeId: a, awayId: h, neutral: false, played: false, result: null });
  });
  return out;
}

// ─── Инициализация сезона ────────────────────────────────────────────────────

let fxCounter = 0;
const newFixtureId = () => `fx${(fxCounter++).toString(36)}_${Math.random().toString(36).slice(2, 6)}`;

function mkFixture(f: Omit<Fixture, "id">): Fixture {
  return { ...f, id: newFixtureId() };
}

export interface BuildOptions {
  /** какие чемпионаты симулировать (минимум один) */
  leagues?: LeagueId[];
  /** заранее заданные составы еврокубков (36 id); иначе — автоподбор */
  uclTeams?: string[];
  uelTeams?: string[];
  ueclTeams?: string[];
}

/** Автоподбор участников еврокубков: топ выбранных лиг + добор из пула Европы */
export function autoEuroTeams(
  teams: Record<string, Team>,
  leagues: LeagueId[],
  standings?: Record<string, string[]>
): { ucl: string[]; uel: string[]; uecl: string[] } {
  const repOf = (id: string) => teams[id]?.reputation ?? 0;
  const rankOf = (lid: LeagueId) => {
    const prev = standings?.[lid];
    const ids = Object.values(teams).filter((t) => t.league === lid).map((t) => t.id);
    if (prev?.length) {
      const known = prev.filter((id) => teams[id]?.league === lid);
      const rest = ids.filter((id) => !known.includes(id)).sort((x, y) => repOf(y) - repOf(x));
      return [...known, ...rest];
    }
    return ids.sort((x, y) => repOf(y) - repOf(x));
  };
  const ucl: string[] = [];
  const uel: string[] = [];
  const uecl: string[] = [];
  for (const lid of leagues) {
    const cfg = LEAGUE_CFG[lid];
    const rank = rankOf(lid);
    if (cfg.ucl) ucl.push(...rank.slice(0, cfg.ucl));
    if (cfg.uel) uel.push(...rank.slice(cfg.ucl, cfg.ucl + cfg.uel));
    if (cfg.uecl) uecl.push(...rank.slice(cfg.ucl + cfg.uel, cfg.ucl + cfg.uel + cfg.uecl));
  }
  // добор из «остального мира»: клубы Европы, не участвующие в симулируемых лигах
  // Добор: только клубы европейского пула и топ-лиг УЕФА, которые не симулируются.
  // Чемпионшип (2-й дивизион) и Саудовская лига в еврокубки не попадают никогда.
  const UEFA_LEAGUES: LeagueId[] = ["PL", "LL", "FL1", "BL", "SA", "PT", "TUR", "BEL", "NED", "GRE", "UKR", "POL", "SCO", "SUI"];
  const pool = Object.values(teams)
    .filter((t) => t.tier === "EU" || (t.league && UEFA_LEAGUES.includes(t.league) && !leagues.includes(t.league)))
    .map((t) => t.id)
    .sort((x, y) => repOf(y) - repOf(x));
  const used = new Set([...ucl, ...uel, ...uecl]);
  const fill = (list: string[], size: number) => {
    for (const id of pool) {
      if (list.length >= size) break;
      if (used.has(id)) continue;
      list.push(id);
      used.add(id);
    }
  };
  fill(ucl, 36);
  fill(uel, 36);
  fill(uecl, 36);
  return { ucl: ucl.slice(0, 36), uel: uel.slice(0, 36), uecl: uecl.slice(0, 36) };
}

export function buildSeason(
  teams: Record<string, Team>, seed: number, seasonNumber = 1, opts: BuildOptions = {}
): SeasonState {
  const rng = makeRng(seed);
  const leagues = (opts.leagues?.length ? opts.leagues : LEAGUE_IDS).filter((l) => LEAGUE_CFG[l]);
  const fixtures: Fixture[] = [];
  const all = Object.values(teams);
  const byTier = (t: string) => all.filter((x) => x.tier === t).map((x) => x.id);
  const repOf = (id: string) => teams[id].reputation;
  const sortRep = (ids: string[]) => [...ids].sort((x, y) => repOf(y) - repOf(x));

  // ── 1) Выбранные чемпионаты ──
  const leagueIds = {} as Record<LeagueId, string[]>;
  for (const lid of LEAGUE_IDS) leagueIds[lid] = [];
  for (const lid of leagues) {
    const ids = all.filter((t) => t.league === lid).map((t) => t.id);
    leagueIds[lid] = ids;
    const cfg = LEAGUE_CFG[lid];
    for (const f of generateFixtures(ids, rng, cfg.comp)) {
      const date = cfg.dates[f.matchday - 1] ?? cfg.dates[cfg.dates.length - 1];
      fixtures.push(mkFixture({ ...f, date }));
    }
  }

  // ── 2) Еврокубки ──
  const auto = autoEuroTeams(teams, leagues);
  const valid = (ids?: string[]) => (ids?.length === 36 && ids.every((id) => teams[id]) ? ids : null);
  const uclList = valid(opts.uclTeams) ?? auto.ucl;
  const uelList = valid(opts.uelTeams) ?? auto.uel.filter((id) => !uclList.includes(id)).slice(0, 36);
  const ueclList = valid(opts.ueclTeams)
    ?? auto.uecl.filter((id) => !uclList.includes(id) && !uelList.includes(id)).slice(0, 36);

  const mkEuro = (comp: "UCL" | "UEL" | "UECL", parts: string[]): EuroState => {
    const ordered = sortRep(parts);
    const country: Record<string, string> = {};
    for (const id of ordered) country[id] = teams[id].country ?? "ENG";
    for (const p of drawSwiss(ordered, country, rng))
      fixtures.push(mkFixture({
        comp, stage: `LP${p.matchday}`, matchday: p.matchday,
        date: wed(EURO_LP_WEEKS[p.matchday - 1]),
        homeId: p.homeId, awayId: p.awayId, neutral: false, played: false, result: null,
      }));
    const pots: string[][] = [[], [], [], []];
    ordered.forEach((id, i) => pots[Math.min(3, Math.floor(i / 9))].push(id));
    return { participants: ordered, pots, stage: "LP", ties: [], eliminated: [] };
  };
  const ucl = mkEuro("UCL", uclList);
  const uel = mkEuro("UEL", uelList);
  const uecl = mkEuro("UECL", ueclList);

  // ── 3) Национальные кубки (только для выбранных лиг) ──
  const emptyCup = (): CupState => ({ participants: [], stage: "DONE", rounds: [], alive: [], winner: undefined });
  const cups: Record<string, CupState> = {
    fa: emptyCup(), efl: emptyCup(), cdr: emptyCup(), cdf: emptyCup(),
    dfb: emptyCup(), cit: emptyCup(), tcp: emptyCup(), ksc: emptyCup(),
    tuc: emptyCup(), bcb: emptyCup(), dtc: emptyCup(), grc: emptyCup(), ukc: emptyCup(), plc: emptyCup(), scc: emptyCup(), swc: emptyCup(),
  };
  const KEY: Record<Competition, string> = {
    FA: "fa", EFL: "efl", CDR: "cdr", CDF: "cdf", DFB: "dfb", CIT: "cit", TCP: "tcp", KSC: "ksc", TUC: "tuc", BCB: "bcb", DTC: "dtc", GRC: "grc", UKC: "ukc", PLC: "plc", SCC: "scc", SWC: "swc",
  } as Record<Competition, string>;

  for (const lid of leagues) {
    const cup = LEAGUE_CUP[lid];
    if (!cup.size) continue; // у лиги нет собственного кубка (Чемпионшип играет в FA Cup)
    const tiers = cup.tier.split("+");
    // В FA Cup вместе с АПЛ заявляется весь Чемпионшип, если он симулируется
    const extra = cup.comp === "FA" ? leagueIds.CHA : [];
    const pool = shuffleIds(
      [...leagueIds[lid], ...extra, ...tiers.flatMap((t) => byTier(t))], rng
    ).slice(0, cup.size);
    if (pool.length < 4) continue;
    const size = Math.pow(2, Math.floor(Math.log2(pool.length)));
    const parts = pool.slice(0, size);
    const st: CupState = { participants: parts, stage: "", rounds: [], alive: parts };
    const stage = size === 64 ? "R64" : size === 32 ? "R32" : size === 16 ? "R16" : "QF";
    const day = cup.comp === "FA" ? sat(cup.weeks[0]) : wed(cup.weeks[0]);
    scheduleCupRound(fixtures, st, cup.comp as CupComp, stage, day, rng);
    cups[KEY[cup.comp]] = st;
  }

  // EFL Cup — если выбрана АПЛ или Чемпионшип
  if (leagues.includes("PL") || leagues.includes("CHA")) {
    const eflParts = shuffleIds([...leagueIds.PL, ...leagueIds.CHA, ...byTier("CH")], rng).slice(0, 44);
    const efl: CupState = { participants: eflParts, stage: "R1", rounds: [], alive: eflParts };
    const byRep = sortRep(eflParts);
    const byes = byRep.slice(0, 20);
    const playIn = shuffleIds(byRep.slice(20), rng);
    const r1Ids: string[] = [];
    for (let i = 0; i + 1 < playIn.length; i += 2) {
      const f = mkFixture({
        comp: "EFL", stage: "R1", matchday: 1, date: wed(EFL_WEEKS[0]),
        homeId: playIn[i], awayId: playIn[i + 1], neutral: false, played: false, result: null,
      });
      fixtures.push(f);
      r1Ids.push(f.id);
    }
    efl.rounds.push({ stage: "R1", fixtureIds: r1Ids });
    efl.alive = [...byes, ...playIn];
    cups.efl = efl;
  }

  void seasonNumber;
  return {
    startDate: SEASON_START,
    fixtures: fixtures.sort((a2, b2) => cmpDate(a2.date, b2.date)),
    ucl, uel, uecl,
    fa: cups.fa, efl: cups.efl, cdr: cups.cdr, cdf: cups.cdf, dfb: cups.dfb, cit: cups.cit,
    tcp: cups.tcp, ksc: cups.ksc, tuc: cups.tuc, bcb: cups.bcb,
    dtc: cups.dtc, grc: cups.grc, ukc: cups.ukc,
    plc: cups.plc, scc: cups.scc, swc: cups.swc,
    finished: false,
    champions: {},
  };
}

function shuffleIds(ids: string[], rng: RngApi): string[] {
  const a = [...ids];
  for (let i = a.length - 1; i > 0; i--) {
    const j = rng.int(0, i);
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Случайная жеребьёвка раунда кубка (один матч, финал — на нейтральном поле) */
function scheduleCupRound(
  fixtures: Fixture[], cup: CupState, comp: CupComp,
  stage: string, date: string, rng: RngApi
) {
  const pool = shuffleIds(cup.alive, rng);
  const ids: string[] = [];
  const isFinal = stage === "F";
  for (let i = 0; i + 1 < pool.length; i += 2) {
    const f = mkFixture({
      comp, stage, matchday: 1, date,
      homeId: pool[i], awayId: pool[i + 1], neutral: isFinal, played: false, result: null,
    });
    fixtures.push(f);
    ids.push(f.id);
  }
  cup.rounds.push({ stage, fixtureIds: ids });
  cup.stage = stage;
}

// ─── Таблицы ─────────────────────────────────────────────────────────────────

export function buildTable(fixtures: Fixture[], teamIds: string[], comp: Competition, stagePrefix?: string): TableRow[] {
  const rows: Record<string, TableRow> = {};
  for (const id of teamIds) rows[id] = { teamId: id, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, gd: 0, pts: 0, form: [] };
  for (const f of fixtures) {
    if (f.comp !== comp || !f.played || !f.result) continue;
    if (stagePrefix && !f.stage.startsWith(stagePrefix)) continue;
    const h = rows[f.homeId], a = rows[f.awayId];
    if (!h || !a) continue;
    const { h: gh, a: ga } = f.result;
    h.p++; a.p++;
    h.gf += gh; h.ga += ga; a.gf += ga; a.ga += gh;
    if (gh > ga) { h.w++; a.l++; h.pts += 3; h.form.push("W"); a.form.push("L"); }
    else if (gh < ga) { a.w++; h.l++; a.pts += 3; h.form.push("L"); a.form.push("W"); }
    else { h.d++; a.d++; h.pts++; a.pts++; h.form.push("D"); a.form.push("D"); }
  }
  return Object.values(rows)
    .map((r) => ({ ...r, gd: r.gf - r.ga, form: r.form.slice(-5) }))
    .sort((x, y) => y.pts - x.pts || y.gd - x.gd || y.gf - x.gf || x.teamId.localeCompare(y.teamId));
}

// ─── Симуляция и применение результата ───────────────────────────────────────

export function simulateFixture(slot: Slot, fixture: Fixture): MatchResult {
  const home = slot.teams[fixture.homeId];
  const away = slot.teams[fixture.awayId];
  // Already played → точно тот же поток рандома: seed сохранён в результате.
  // Так детальный просмотр всегда показывает реальный матч, даже если составы
  // изменились после игры (свежесть/форма/трансферы).
  const seed = fixture.played && fixture.result ? fixture.result.seed : (hashStr(fixture.id) ^ slot.seed) >>> 0;
  const isCupSingle =
    (fixture.comp === "FA" || fixture.comp === "EFL") ||
    (fixture.tieId !== undefined && fixture.stage !== "LP" && isSecondLeg(slot, fixture)) ||
    (fixture.comp !== "PL" && fixture.stage === "F");
  return simulateMatch(home, away, {
    seed,
    neutral: fixture.neutral,
    penaltiesOnDraw: isCupSingle,
    homeTactics: slot.tactics?.[home.id],
    awayTactics: slot.tactics?.[away.id],
    lineupsCache: fixture.result?.lineupSnap as unknown as Record<string, Player[]>,
    benchCache: fixture.result?.benchSnap as unknown as Record<string, Player[]>,
    // счёт задан вручную — повтор обязан показать именно его
    forceScore: fixture.result?.manual ? { h: fixture.result.h, a: fixture.result.a } : undefined,
  });
}

function isSecondLeg(slot: Slot, fixture: Fixture): boolean {
  if (!fixture.tieId) return false;
  const tie = [...slot.season.ucl.ties, ...slot.season.uel.ties, ...slot.season.uecl.ties].find((t) => t.id === fixture.tieId);
  return tie ? tie.legs[tie.legs.length - 1] === fixture.id : false;
}

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

/** Записывает результат в слот: счёт, статистика игроков, форма и фитнес */
export function applyResult(slot: Slot, fixture: Fixture, res: MatchResult) {
  fixture.played = true;
  // Снапшот фактических составов ЭТОГО матча (старт + скамейка).
  // Именно он обеспечивает точный повтор: состав и сила игроков не «плывут»
  // от последующих изменений формы, трансферов и правок в редакторе.
  const snapOf = (src: Record<string, Player[]>) =>
    Object.fromEntries(
      Object.entries(src).map(([tid, ps]) => [
        tid,
        ps.map((p) => ({
          id: p.id, name: p.name, position: p.position,
          attack: p.attack, defense: p.defense, goalkeeping: p.goalkeeping, overall: p.overall,
          age: p.age, fitness: p.fitness, morale: p.morale, form: p.form, nationality: p.nationality,
        })),
      ])
    );

  fixture.result = {
    h: res.homeScore,
    a: res.awayScore,
    seed: res.seed,
    pensH: res.pens?.h,
    pensA: res.pens?.a,
    lineupSnap: snapOf(res.lineups),
    benchSnap: snapOf(res.benches),
    scorers: res.events
      .filter((e) => e.type === "goal" || e.type === "penalty")
      .map((e) => ({ m: e.minute, t: e.teamId!, p: e.playerId!, a: e.assistId })),
    lines: Object.fromEntries(
      Object.entries(res.playerMatchStats).map(([pid, l]) => [
        pid,
        { rating: l.rating, goals: l.goals, assists: l.assists, minutes: l.minutes },
      ])
    ),
  };

  const isLeague = isLeagueComp(fixture.comp); // зачёт «в своём чемпионате»
  const injuryMap = new Map(res.injuries.map((i) => [i.playerId, i]));

  const bump = (teamId: string) => {
    const team = slot.teams[teamId];
    if (!team) return;
    for (const p of team.players) {
      // восстановление после травмы
      if (p.injury && p.injury.daysLeft > 0) {
        p.injury = { ...p.injury, daysLeft: Math.max(0, p.injury.daysLeft - 3) };
        if (p.injury.daysLeft === 0) p.injury = null;
      }
      const line = res.playerMatchStats[p.id];
      if (!line) continue; // не играл — восстановление уже начислено за день
      const rating = line.rating;
      const st = p.stats;
      st.apps++;
      st.minutes += line.minutes;
      st.goals += line.goals;
      st.assists += line.assists;
      st.saves += line.saves;
      st.yellow += line.yellow;
      st.red += line.red;
      st.errors += line.errors;
      st.keyPasses += line.keyPasses;
      st.tackles += line.tackles;
      st.interceptions += line.interceptions;
      st.shots += line.shots;
      st.shotsOnTarget += line.shotsOnTarget;
      st.xg = Math.round((st.xg + line.xg) * 100) / 100;
      st.dribbles += line.dribbles;
      st.fouls += line.fouls;
      st.offsides += line.offsides;
      st.conceded += line.conceded;
      if (p.id === res.motm) st.motm++;
      const cs = line.cleanSheet && (p.position === "GK" || p.position === "DF") && line.minutes >= 60;
      if (cs) st.cleanSheets++;
      if (isLeague) {
        st.plApps++;
        st.plGoals += line.goals;
        st.plAssists += line.assists;
        if (cs) st.plCleanSheets++;
      }
      st.ratingSum = Math.round((st.ratingSum + rating) * 10) / 10;
      st.avgRating = Math.round((st.ratingSum / st.apps) * 100) / 100;

      // Форма — отклонение от СОБСТВЕННОГО уровня игрока, а не от абсолютной планки.
      // Иначе защитники (их средний рейтинг структурно ниже) весь сезон падают
      // на дно формы, обороны разваливаются и счета раздуваются.
      const baseline = st.apps >= 5 ? st.avgRating : POS_BASE[p.position];
      const formStep = rating > baseline + 0.8 ? 0.05
        : rating < baseline - 0.8 ? -0.05
        : (rating - baseline) * 0.035;
      // мягкий возврат к 1.0 — форма не застревает в крайностях
      p.form = r3(clamp(p.form * 0.97 + 0.03 + formStep, 0.85, 1.15));
      // усталость и восстановление
      // Цена матча: полные 90 минут ≈ −19 свежести у полевого, −7 у вратаря.
      // При норме отдыха 3+ дня (≈+20) игрок выходит на следующий матч свежим,
      // при плотном графике через 2 дня накапливается усталость — как в жизни.
      p.fitness = r1(clamp(p.fitness - line.minutes * (p.position === "GK" ? 0.08 : 0.21), 15, 100));
      // мораль: личный рейтинг + результат команды
      const teamDiff = teamId === fixture.homeId ? res.homeScore - res.awayScore : res.awayScore - res.homeScore;
      // Мораль: сильная тяга к норме (70) + поправка на класс соперника.
      // Поражение от гранда бьёт по настроению слабее, чем от равного.
      const mBase = POS_BASE[p.position];
      const oppId = teamId === fixture.homeId ? fixture.awayId : fixture.homeId;
      const oppRep = slot.teams[oppId]?.reputation ?? 70;
      const ownRep = team.reputation;
      const expected = clamp((ownRep - oppRep) / 18, -1.2, 1.2); // ожидаемый исход
      const surprise = clamp(teamDiff - expected, -3, 3);
      p.morale = r1(clamp(p.morale * 0.88 + 8.4 + (rating - mBase) * 1.8 + surprise * 1.1, 25, 95));

      // травма, полученная в матче
      const inj = injuryMap.get(p.id);
      if (inj) {
        p.injury = {
          type: inj.type,
          daysLeft: inj.days,
          label: inj.type === "light" ? "лёгкая" : inj.type === "medium" ? "средняя" : "тяжёлая",
        };
        p.fitness = 0;
      }
    }
  };
  bump(fixture.homeId);
  bump(fixture.awayId);
}

const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
/** Типичный средний рейтинг по позиции — точка равновесия формы и морали */
const POS_BASE: Record<string, number> = { GK: 6.35, DF: 6.3, MF: 6.5, FW: 6.5 };

const r1 = (v: number) => Math.round(v * 10) / 10;
const r3 = (v: number) => Math.round(v * 1000) / 1000;

/**
 * Ежедневное восстановление. Раньше срабатывало только в дни без матчей во всём
 * мире — из-за этого клубы с еврокубками выгорали: их игроки теряли свежесть
 * каждый матч и почти не отдыхали. Теперь отдыхают все и каждый день.
 */
function recoverAll(slot: Slot, amount = 4.6) {
  for (const t of Object.values(slot.teams))
    for (const p of t.players) {
      if (p.injury && p.injury.daysLeft > 0) continue; // травмированные лечатся отдельно
      p.fitness = r1(Math.min(100, p.fitness + amount));
    }
}

// ─── Прогресс турниров ───────────────────────────────────────────────────────

function winnerOf(f: Fixture): string {
  const r = f.result!;
  if (r.h > r.a) return f.homeId;
  if (r.a > r.h) return f.awayId;
  return (r.pensH ?? 0) > (r.pensA ?? 0) ? f.homeId : f.awayId;
}

export type CupComp = "FA" | "EFL" | "CDR" | "CDF" | "DFB" | "CIT" | "TCP" | "KSC" | "TUC" | "BCB" | "DTC" | "GRC" | "UKC" | "PLC" | "SCC" | "SWC";
const CUP_STAGE_ORDER = ["R1", "R64", "R32", "R16", "QF", "SF", "F"];

function progressCups(slot: Slot, rng: RngApi) {
  const cups: [CupComp, CupState, number[], "sat" | "wed"][] = [
    ["FA", slot.season.fa, FA_WEEKS, "sat"],
    ["EFL", slot.season.efl, EFL_WEEKS, "wed"],
    ["CDR", slot.season.cdr, CDR_WEEKS, "wed"],
    ["CDF", slot.season.cdf, CDF_WEEKS, "wed"],
    ["DFB", slot.season.dfb, DFB_WEEKS, "wed"],
    ["CIT", slot.season.cit, CIT_WEEKS, "wed"],
    ["TCP", slot.season.tcp, TCP_WEEKS, "wed"],
    ["KSC", slot.season.ksc, KSC_WEEKS, "wed"],
    ["TUC", slot.season.tuc, [7, 15, 23, 31, 40], "wed"],
    ["BCB", slot.season.bcb, [10, 19, 28, 36, 43], "wed"],
    ["DTC", slot.season.dtc, [9, 18, 27, 35, 42], "wed"],
    ["GRC", slot.season.grc, [11, 20, 29, 38], "wed"],
    ["UKC", slot.season.ukc, [12, 21, 30, 39], "wed"],
    ["PLC", slot.season.plc, [13, 22, 31, 40], "wed"],
    ["SCC", slot.season.scc, [14, 23, 32, 41], "wed"],
    ["SWC", slot.season.swc, [15, 24, 33, 42], "wed"],
  ];
  for (const [comp, cup, weeks, day] of cups) {
    if (!cup || cup.winner || !cup.rounds.length) continue;
    const round = cup.rounds[cup.rounds.length - 1];
    const fxs = round.fixtureIds.map((id) => slot.season.fixtures.find((f) => f.id === id)!).filter(Boolean);
    if (!fxs.length || !fxs.every((f) => f.played)) continue;

    const winners = fxs.map(winnerOf);
    const byes = cup.alive.filter((id) => !fxs.some((f) => f.homeId === id || f.awayId === id));
    const next = [...winners, ...byes];
    cup.alive = next;
    if (next.length === 1) {
      cup.winner = next[0];
      slot.season.champions[comp] = next[0];
      continue;
    }
    const stage = next.length >= 32 ? "R32" : next.length >= 16 ? "R16" : next.length >= 8 ? "QF" : next.length >= 4 ? "SF" : "F";
    const idx = Math.max(0, CUP_STAGE_ORDER.indexOf(stage) - CUP_STAGE_ORDER.indexOf(cup.rounds[0].stage));
    const week = weeks[Math.min(idx, weeks.length - 1)];
    let date = day === "sat" ? sat(week) : wed(week);
    // раунд не может попасть на уже прошедший день (иначе матч никогда не сыграется)
    if (cmpDate(date, slot.currentDate) <= 0) date = addDays(slot.currentDate, 4);
    scheduleCupRound(slot.season.fixtures, cup, comp, stage, date, rng);
  }
}

function euroStateOf(slot: Slot, comp: "UCL" | "UEL" | "UECL"): EuroState {
  return comp === "UCL" ? slot.season.ucl : comp === "UEL" ? slot.season.uel : slot.season.uecl;
}

function euroTable(slot: Slot, comp: "UCL" | "UEL" | "UECL"): TableRow[] {
  const st = euroStateOf(slot, comp);
  return buildTable(slot.season.fixtures, st.participants, comp, "LP");
}

function addTie(slot: Slot, comp: "UCL" | "UEL" | "UECL", stage: string, aId: string, bId: string, weeks: number[]): Tie {
  // защита: если клуб не определён (например, таблица оказалась короче) — пропускаем пару
  if (!aId || !bId || !slot.teams[aId] || !slot.teams[bId]) {
    return { id: `tie_skip_${comp}_${stage}`, comp, stage, aId: aId || "?", bId: bId || "?", legs: [] };
  }
  const st = euroStateOf(slot, comp);
  const id = `tie_${comp}_${stage}_${aId}_${bId}`;
  const legs: string[] = [];
  if (stage === "F") {
    const f = mkFixture({
      comp, stage, matchday: 1, date: wed(weeks[0]), homeId: aId, awayId: bId,
      neutral: true, tieId: id, played: false, result: null,
    });
    slot.season.fixtures.push(f);
    legs.push(f.id);
  } else {
    const l1 = mkFixture({
      comp, stage, matchday: 1, date: wed(weeks[0]), homeId: aId, awayId: bId,
      neutral: false, tieId: id, played: false, result: null,
    });
    const l2 = mkFixture({
      comp, stage, matchday: 2, date: wed(weeks[1]), homeId: bId, awayId: aId,
      neutral: false, tieId: id, played: false, result: null,
    });
    slot.season.fixtures.push(l1, l2);
    legs.push(l1.id, l2.id);
  }
  const tie: Tie = { id, comp, stage, aId, bId, legs };
  st.ties.push(tie);
  return tie;
}

function progressEuro(slot: Slot, comp: "UCL" | "UEL" | "UECL") {
  const st = euroStateOf(slot, comp);
  if (st.stage === "DONE") return;
  const fixtures = slot.season.fixtures;

  if (st.stage === "LP") {
    const lp = fixtures.filter((f) => f.comp === comp && f.stage.startsWith("LP"));
    if (!lp.every((f) => f.played)) return;
    const table = euroTable(slot, comp);
    const top8 = table.slice(0, 8).map((r) => r.teamId);
    const po = table.slice(8, 24).map((r) => r.teamId).filter(Boolean);
    // если команд меньше ожидаемого (например, из-за наложения лиг) —
    // формируем пары только из реально доступных
    if (po.length < 16) {
      // добираем из числа вылетевших в ЛК/ЛЕ или просто сокращаем сетку
      const extra = table.slice(24).map((r) => r.teamId).filter(Boolean).slice(0, 16 - po.length);
      po.push(...extra);
    }
    st.eliminated.push(...table.slice(24).map((r) => r.teamId));
    // 9-16 принимают ответный матч против 17-24 (пара i: 9+i vs 24-i)
    for (let i = 0; i < 8; i++) addTie(slot, comp, "PO", po[8 + i], po[7 - i], EURO_KO_WEEKS.PO);
    st.stage = "PO";
    // порядок посева нужен для правильной сетки 1/8
    (st as EuroState & { seeded?: string[]; poOrder?: string[][] }).seeded = top8;
    (st as EuroState & { poOrder?: string[][] }).poOrder =
      Array.from({ length: 8 }, (_, i) => [po[8 + i], po[7 - i]]);
    return;
  }

  const stageTies = st.ties.filter((t) => t.stage === st.stage && !t.id.startsWith("tie_skip"));
  const done = stageTies.every((t) => t.legs.every((id) => fixtures.find((f) => f.id === id)!.played));
  if (!done || !stageTies.length) return;

  // подводим итоги пар
  for (const t of stageTies) {
    if (t.winnerId) continue;
    let ga = 0, gb = 0;
    for (const legId of t.legs) {
      const f = fixtures.find((x) => x.id === legId)!;
      const r = f.result!;
      if (f.homeId === t.aId) { ga += r.h; gb += r.a; } else { gb += r.h; ga += r.a; }
    }
    t.aggA = ga; t.aggB = gb;
    if (ga !== gb) t.winnerId = ga > gb ? t.aId : t.bId;
    else {
      const last = fixtures.find((x) => x.id === t.legs[t.legs.length - 1])!;
      const r = last.result!;
      if ((r.pensH ?? 0) !== (r.pensA ?? 0)) t.winnerId = (r.pensH ?? 0) > (r.pensA ?? 0) ? last.homeId : last.awayId;
      else t.winnerId = ga >= gb ? t.aId : t.bId;
    }
    st.eliminated.push(t.winnerId === t.aId ? t.bId : t.aId);
  }

  const winners = stageTies.map((t) => t.winnerId!);
  const order: Record<string, string> = { PO: "R16", R16: "QF", QF: "SF", SF: "F" };

  if (st.stage === "F") {
    st.winner = winners[0];
    st.stage = "DONE";
    slot.season.champions[comp] = winners[0];
    return;
  }

  const nextStage = order[st.stage];
  let pool: string[];
  if (st.stage === "PO") {
    // Классическая сетка УЕФА: топ-8 общего этапа НЕ встречаются между собой в 1/8.
    // Лучший сеяный играет со слабейшим прошедшим, и так далее.
    const seeded = (st as EuroState & { seeded?: string[] }).seeded ?? [];
    const order = (st as EuroState & { poOrder?: string[][] }).poOrder ?? [];
    // победители плей-офф в порядке своих пар (пара 0 — сильнейшая)
    const qualified = order.length
      ? order.map(([a, b]) => stageTies.find((t) => (t.aId === a && t.bId === b) || (t.aId === b && t.bId === a))?.winnerId)
          .filter((x): x is string => !!x)
      : winners;
    const pairs: [string, string][] = [];
    for (let i = 0; i < seeded.length; i++) {
      const opp = qualified[qualified.length - 1 - i];
      if (seeded[i] && opp) pairs.push([seeded[i], opp]);
    }
    // страховка: если что-то не сошлось, добираем оставшихся
    const used = new Set(pairs.flat());
    const rest = [...seeded, ...qualified].filter((id) => !used.has(id));
    for (let i = 0; i + 1 < rest.length; i += 2) pairs.push([rest[i], rest[i + 1]]);
    for (const [a, b] of pairs) addTie(slot, comp, nextStage, a, b, EURO_KO_WEEKS[nextStage]);
    st.stage = nextStage as EuroState["stage"];
    // порядок пар 1/8 задаёт сетку дальше (как в реальной жеребьёвке)
    (st as EuroState & { bracket?: string[] }).bracket = pairs.map(([a]) => a);
    return;
  }

  pool = winners;
  for (let i = 0; i + 1 < pool.length; i += 2) {
    addTie(slot, comp, nextStage, pool[i], pool[i + 1], EURO_KO_WEEKS[nextStage]);
  }
  st.stage = nextStage as EuroState["stage"];
}

// ─── Календарь ───────────────────────────────────────────────────────────────

export interface DayResult {
  date: string;
  fixtures: { fixture: Fixture; result: MatchResult }[];
}

/** Симулирует все матчи текущего дня и сдвигает дату */
export function advanceDay(slot: Slot, skipFixtureIds: string[] = []): DayResult {
  const date = slot.currentDate;
  // Матчи текущего дня. Если их нет, но остались «просроченные» (турниры
  // симулировались вразнобой через панель свободной симуляции) — доигрываем
  // ИХ ПО ОДНОЙ ДАТЕ за проход, чтобы игроки восстанавливались как обычно.
  const pending = slot.season.fixtures.filter((f) => !f.played && !skipFixtureIds.includes(f.id));
  let today = pending.filter((f) => f.date === date);
  if (!today.length) {
    const overdueDate = pending
      .filter((f) => cmpDate(f.date, date) < 0)
      .map((f) => f.date)
      .sort(cmpDate)[0];
    if (overdueDate) today = pending.filter((f) => f.date === overdueDate);
  }
  const out: DayResult = { date, fixtures: [] };
  for (const f of today) {
    const res = simulateFixture(slot, f);
    applyResult(slot, f, res);
    out.fixtures.push({ fixture: f, result: res });
  }
  // сначала общий отдых за прошедший день, потом нагрузка сегодняшних матчей
  recoverAll(slot);
  const rng = makeRng((slot.seed ^ hashStr(date)) >>> 0);
  progressEuro(slot, "UCL");
  progressEuro(slot, "UEL");
  progressEuro(slot, "UECL");
  progressCups(slot, rng);
  slot.currentDate = addDays(date, 1);
  // зимние аренды, срок которых истёк (возврат 1 января), — игроки едут домой
  processLoanReturns(slot);
  checkSeasonEnd(slot);
  return out;
}

/** Ближайшая дата, на которую назначены несыгранные матчи */
export function nextMatchDate(slot: Slot): string | null {
  const dates = slot.season.fixtures
    .filter((f) => !f.played && cmpDate(f.date, slot.currentDate) >= 0)
    .map((f) => f.date)
    .sort(cmpDate);
  return dates[0] ?? null;
}

/** Есть ли матчи сегодня */
export function fixturesOn(slot: Slot, date: string): Fixture[] {
  return slot.season.fixtures.filter((f) => f.date === date);
}

export function hasPendingFixtures(slot: Slot): boolean {
  return slot.season.fixtures.some((f) => !f.played);
}

/** Промотать до ближайшего игрового дня (не симулируя его) */
export function skipToNextMatchDay(slot: Slot, maxDays = 60): DayResult[] {
  const days: DayResult[] = [];
  const target = nextMatchDate(slot);
  if (!target) return days;
  let guard = 0;
  while (slot.currentDate < target && guard++ < maxDays) days.push(advanceDay(slot));
  return days;
}

/** Симулировать все матчи до конкретной даты включительно */
export function advanceToDate(slot: Slot, target: string, maxDays = 500): DayResult[] {
  const days: DayResult[] = [];
  let guard = 0;
  while (cmpDate(slot.currentDate, target) <= 0 && guard++ < maxDays) {
    days.push(advanceDay(slot));
    if (slot.season.finished) break;
  }
  return days;
}

/** Симулировать целиком ближайший несыгранный тур АПЛ */
export function advanceMatchday(slot: Slot, league: LeagueId = "PL", maxDays = 60): { matchday: number | null; days: DayResult[] } {
  const comp = LEAGUE_CFG[league].comp;
  const pending = slot.season.fixtures
    .filter((f) => f.comp === comp && !f.played)
    .sort((a, b) => cmpDate(a.date, b.date) || a.matchday - b.matchday)[0];
  if (!pending) return { matchday: null, days: [] };
  const md = pending.matchday;
  const last = slot.season.fixtures
    .filter((f) => f.comp === comp && f.matchday === md)
    .map((f) => f.date)
    .sort(cmpDate)
    .pop()!;
  return { matchday: md, days: advanceToDate(slot, last, maxDays) };
}

/** Симулирует остаток сезона (включая матчи игрока) и подводит итоги */
export function advanceToEndOfSeason(slot: Slot, maxDays = 500): void {
  for (let i = 0; i < maxDays && hasPendingFixtures(slot); i++) {
    const before = slot.season.fixtures.filter((f) => !f.played).length;
    advanceDay(slot);
    const after = slot.season.fixtures.filter((f) => !f.played).length;
    // Если день пустой — перепрыгиваем к ближайшей дате с матчами.
    // ВАЖНО: за пропущенные дни начисляем отдых, иначе клубы с плотным
    // календарём (еврокубки) выходят на матчи полуживыми.
    if (before === after) {
      const next = slot.season.fixtures
        .filter((f) => !f.played)
        .map((f) => f.date)
        .sort(cmpDate)[0];
      if (next && cmpDate(next, slot.currentDate) > 0) {
        const skipped = Math.max(0, Math.round(
          (new Date(`${next}T00:00:00Z`).getTime() - new Date(`${slot.currentDate}T00:00:00Z`).getTime()) / 86400000
        ));
        if (skipped > 0) recoverAll(slot, Math.min(14, skipped) * 4.6);
        slot.currentDate = next;
      }
    }
  }
  checkSeasonEnd(slot, true);
}

function checkSeasonEnd(slot: Slot, force = false) {
  if (slot.season.finished) return;
  const pending = slot.season.fixtures.some((f) => !f.played);
  if (pending && !force) return;
  // фиксируем порядок клубов для повышения/вылета и подбора еврокубков
  if (!slot.previousSeasonResults) slot.previousSeasonResults = {};
  for (const lid of slot.selectedLeagues ?? LEAGUE_IDS) {
    const ids = Object.values(slot.teams).filter((t) => t.league === lid).map((t) => t.id);
    if (!ids.length) continue;
    const table = buildTable(slot.season.fixtures, ids, LEAGUE_CFG[lid].comp);
    slot.previousSeasonResults[lid] = table.map((r) => r.teamId);
  }
  // чемпионы трёх лиг
  for (const lid of slot.selectedLeagues ?? LEAGUE_IDS) {
    const ids = Object.values(slot.teams).filter((t) => t.league === lid).map((t) => t.id);
    const table = buildTable(slot.season.fixtures, ids, LEAGUE_CFG[lid].comp);
    if (table[0]?.p) slot.season.champions[LEAGUE_CFG[lid].comp] = table[0].teamId;
  }
  slot.season.finished = true;
}

// ─── Сводная статистика игроков ──────────────────────────────────────────────

export interface StatLine {
  playerId: string; name: string; teamId: string; teamName: string;
  position: string; value: number; apps: number; secondary: number; rating: number;
}

export function leaderboard(
  slot: Slot,
  kind: "goals" | "assists" | "cleanSheets" | "rating",
  league: LeagueId | "ALL" = "PL",
  limit = 15
): StatLine[] {
  const rows: StatLine[] = [];
  for (const t of Object.values(slot.teams)) {
    if (league !== "ALL" && t.league !== league) continue;
    if (league === "ALL" && (!t.league || !(slot.selectedLeagues ?? LEAGUE_IDS).includes(t.league))) continue;
    for (const p of t.players) {
      const s = p.stats;
      if (!s.apps) continue;
      const value =
        kind === "goals" ? s.plGoals
        : kind === "assists" ? s.plAssists
        : kind === "cleanSheets" ? s.plCleanSheets
        : s.avgRating;
      if (kind === "cleanSheets" && p.position !== "GK") continue;
      if (kind === "rating" && s.apps < 8) continue;
      if (value <= 0) continue;
      rows.push({
        playerId: p.id, name: p.name, teamId: t.id, teamName: t.name, position: p.position,
        value, apps: s.plApps || s.apps,
        secondary: kind === "goals" ? s.plAssists : kind === "assists" ? s.plGoals : s.plApps,
        rating: s.avgRating,
      });
    }
  }
  return rows.sort((a, b) => b.value - a.value || b.rating - a.rating || a.apps - b.apps).slice(0, limit);
}

// ─── Редактор расписания ─────────────────────────────────────────────────────

export interface ScheduleIssue {
  fixtureId: string;
  level: "error" | "warn";
  text: string;
}

/** Проверка расписания: 2 матча в день и <3 дней отдыха между матчами АПЛ */
export function validateSchedule(fixtures: Fixture[], teams: Record<string, Team>): ScheduleIssue[] {
  const issues: ScheduleIssue[] = [];
  const byTeam = new Map<string, Fixture[]>();
  for (const f of fixtures) {
    for (const id of [f.homeId, f.awayId]) {
      if (!byTeam.has(id)) byTeam.set(id, []);
      byTeam.get(id)!.push(f);
    }
  }
  for (const [teamId, list] of byTeam) {
    const sorted = [...list].sort((a, b) => cmpDate(a.date, b.date));
    for (let i = 1; i < sorted.length; i++) {
      const prev = sorted[i - 1];
      const cur = sorted[i];
      const diff = Math.round(
        (new Date(`${cur.date}T00:00:00Z`).getTime() - new Date(`${prev.date}T00:00:00Z`).getTime()) / 86400000
      );
      const name = teams[teamId]?.shortName ?? teamId;
      if (diff === 0)
        issues.push({ fixtureId: cur.id, level: "error", text: `${name}: два матча в один день (${fmtDay(cur.date)})` });
      else if (diff < 3 && isLeagueComp(cur.comp) && isLeagueComp(prev.comp))
        issues.push({ fixtureId: cur.id, level: "warn", text: `${name}: только ${diff} дн. отдыха перед туром ${cur.matchday}` });
    }
  }
  return issues;
}

/** Перенос матча на другую дату */
export function moveFixture(slot: Slot, fixtureId: string, date: string): boolean {
  const f = slot.season.fixtures.find((x) => x.id === fixtureId);
  if (!f || f.played) return false;
  f.date = date;
  slot.season.fixtures.sort((a, b) => cmpDate(a.date, b.date));
  return true;
}

/** Сдвиг целого тура АПЛ на N дней */
export function shiftMatchday(slot: Slot, matchday: number, deltaDays: number, comp: Competition = "PL"): boolean {
  const list = slot.season.fixtures.filter((f) => f.comp === comp && f.matchday === matchday && !f.played);
  if (!list.length) return false;
  for (const f of list) f.date = addDays(f.date, deltaDays);
  slot.season.fixtures.sort((a, b) => cmpDate(a.date, b.date));
  return true;
}

/** Товарищеский матч в произвольную дату */
export function addFriendly(slot: Slot, homeId: string, awayId: string, date: string): Fixture {
  const f: Fixture = {
    id: `fr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 5)}`,
    comp: "FR",
    stage: "FRIENDLY",
    matchday: 0,
    date,
    homeId,
    awayId,
    neutral: false,
    played: false,
    result: null,
  };
  slot.season.fixtures.push(f);
  slot.season.fixtures.sort((a, b) => cmpDate(a.date, b.date));
  return f;
}

export function removeFixture(slot: Slot, fixtureId: string): boolean {
  const i = slot.season.fixtures.findIndex((f) => f.id === fixtureId && !f.played);
  if (i === -1) return false;
  slot.season.fixtures.splice(i, 1);
  return true;
}

/** Перегенерация расписания АПЛ (только несыгранная часть сезона недоступна —
 *  пересобирается весь турнир, поэтому доступно лишь до первого матча) */
export function regenerateLeague(slot: Slot, league: LeagueId): boolean {
  const cfg = LEAGUE_CFG[league];
  if (slot.season.fixtures.some((f) => f.comp === cfg.comp && f.played)) return false;
  const ids = Object.values(slot.teams).filter((t) => t.league === league).map((t) => t.id);
  slot.season.fixtures = slot.season.fixtures.filter((f) => f.comp !== cfg.comp);
  const rng = makeRng((slot.seed ^ Date.now()) >>> 0);
  const raw = generateFixtures(ids, rng, cfg.comp);
  for (const f of raw)
    slot.season.fixtures.push({
      ...f,
      id: `fx_${Math.random().toString(36).slice(2, 9)}`,
      date: cfg.dates[f.matchday - 1] ?? cfg.dates[cfg.dates.length - 1],
    });
  slot.season.fixtures.sort((a, b) => cmpDate(a.date, b.date));
  return true;
}

// ─── Ручное изменение счёта сыгранного/будущего матча ───────────────────────

/** Откатывает вклад матча в сезонную статистику игроков (точный, т.к. матч воспроизводим) */
export function revertResult(slot: Slot, fixture: Fixture, res: MatchResult) {
  const isLeague = isLeagueComp(fixture.comp);
  for (const teamId of [fixture.homeId, fixture.awayId]) {
    const team = slot.teams[teamId];
    if (!team) continue;
    for (const p of team.players) {
      const line = res.playerMatchStats[p.id];
      if (!line) continue;
      const st = p.stats;
      const rating = line.rating;
      st.apps = Math.max(0, st.apps - 1);
      st.minutes = Math.max(0, st.minutes - line.minutes);
      st.goals = Math.max(0, st.goals - line.goals);
      st.assists = Math.max(0, st.assists - line.assists);
      st.saves = Math.max(0, st.saves - line.saves);
      st.yellow = Math.max(0, st.yellow - line.yellow);
      st.red = Math.max(0, st.red - line.red);
      st.errors = Math.max(0, st.errors - line.errors);
      st.keyPasses = Math.max(0, st.keyPasses - line.keyPasses);
      st.tackles = Math.max(0, st.tackles - line.tackles);
      st.interceptions = Math.max(0, st.interceptions - line.interceptions);
      st.shots = Math.max(0, st.shots - line.shots);
      st.shotsOnTarget = Math.max(0, st.shotsOnTarget - line.shotsOnTarget);
      st.xg = Math.max(0, Math.round((st.xg - line.xg) * 100) / 100);
      st.dribbles = Math.max(0, st.dribbles - line.dribbles);
      st.fouls = Math.max(0, st.fouls - line.fouls);
      st.offsides = Math.max(0, st.offsides - line.offsides);
      st.conceded = Math.max(0, st.conceded - line.conceded);
      if (p.id === res.motm) st.motm = Math.max(0, st.motm - 1);
      const cs = line.cleanSheet && (p.position === "GK" || p.position === "DF") && line.minutes >= 60;
      if (cs) st.cleanSheets = Math.max(0, st.cleanSheets - 1);
      if (isLeague) {
        st.plApps = Math.max(0, st.plApps - 1);
        st.plGoals = Math.max(0, st.plGoals - line.goals);
        st.plAssists = Math.max(0, st.plAssists - line.assists);
        if (cs) st.plCleanSheets = Math.max(0, st.plCleanSheets - 1);
      }
      st.ratingSum = Math.max(0, Math.round((st.ratingSum - rating) * 10) / 10);
      st.avgRating = st.apps ? Math.round((st.ratingSum / st.apps) * 100) / 100 : 0;
      // обратная коррекция формы/свежести/морали (приближённая — значения клампятся)
      const formStep = rating > 7.5 ? 0.05 : rating < 6.0 ? -0.05 : (rating - 6.75) * 0.02;
      p.form = r3(clamp(p.form - formStep, 0.85, 1.15));
      p.fitness = r1(clamp(p.fitness + line.minutes * (p.position === "GK" ? 0.07 : 0.2) - 9, 15, 100));
      const teamDiff = teamId === fixture.homeId ? res.homeScore - res.awayScore : res.awayScore - res.homeScore;
      p.morale = r1(clamp(p.morale - (rating - 6.5) * 2.2 - teamDiff * 1.5, 15, 100));
    }
  }
}

export interface SetScoreResult {
  ok: boolean;
  error?: string;
  result?: MatchResult;
}

/**
 * Задать счёт матча вручную. Матч пересимулируется и подгоняется под результат:
 * авторы голов, статистика, рейтинги — всё пересчитывается заново.
 */
export function setFixtureScore(slot: Slot, fixtureId: string, h: number, a: number): SetScoreResult {
  const fixture = slot.season.fixtures.find((f) => f.id === fixtureId);
  if (!fixture) return { ok: false, error: "Матч не найден" };
  if (h < 0 || a < 0 || h > 20 || a > 20) return { ok: false, error: "Счёт должен быть от 0 до 20" };

  // 1) если матч уже сыгран — точно воспроизводим его и откатываем статистику
  if (fixture.played && fixture.result) {
    const old = simulateFixture(slot, fixture);
    revertResult(slot, fixture, old);
  }

  // 2) новая симуляция под заданный счёт
  const home = slot.teams[fixture.homeId];
  const away = slot.teams[fixture.awayId];
  const seed = (hashStr(fixture.id + `_m${h}_${a}`) ^ slot.seed) >>> 0;
  const isCupSingle =
    fixture.comp === "FA" || fixture.comp === "EFL" || fixture.comp === "CDR" ||
    fixture.comp === "CDF" || fixture.comp === "DFB" || fixture.comp === "CIT";
  const res = simulateMatch(home, away, {
    seed,
    neutral: fixture.neutral,
    penaltiesOnDraw: isCupSingle,
    homeTactics: slot.tactics?.[home.id],
    awayTactics: slot.tactics?.[away.id],
    forceScore: { h, a },
  });

  // 3) применяем как обычный результат
  fixture.played = false;
  fixture.result = null;
  applyResult(slot, fixture, res);
  const applied = fixture.result as FixtureResult | null;
  if (applied) applied.manual = true;
  slot.season.fixtures.sort((x, y) => cmpDate(x.date, y.date));
  return { ok: true, result: res };
}

// ─── Свободная симуляция по турнирам ────────────────────────────────────────
// Позволяет играть турниры независимо от календаря: например, прогнать все
// 38 туров АПЛ, не трогая еврокубки и кубки.

export interface RoundInfo {
  comp: Competition;
  /** ключ раунда: номер тура для лиг, стадия для кубков/еврокубков */
  key: string;
  label: string;
  fixtures: Fixture[];
  date: string;
}

const roundKeyOf = (f: Fixture) => (isLeagueComp(f.comp) || f.stage.startsWith("LP") ? String(f.matchday) : f.stage);

/** Ближайший несыгранный раунд турнира */
export function nextRound(slot: Slot, comp: Competition): RoundInfo | null {
  const pending = slot.season.fixtures
    .filter((f) => f.comp === comp && !f.played)
    .sort((a, b) => cmpDate(a.date, b.date) || a.matchday - b.matchday);
  if (!pending.length) return null;
  const first = pending[0];
  const key = roundKeyOf(first);
  const fixtures = pending.filter((f) => roundKeyOf(f) === key);
  return {
    comp,
    key,
    label: stageLabel(first),
    fixtures,
    date: fixtures.map((f) => f.date).sort(cmpDate)[0],
  };
}

/** Сколько раундов турнира уже сыграно и сколько осталось */
export function compProgress(slot: Slot, comp: Competition): { played: number; total: number; done: boolean; label: string } {
  const all = slot.season.fixtures.filter((f) => f.comp === comp);
  const keys = new Set(all.map(roundKeyOf));
  const playedKeys = new Set(all.filter((f) => f.played).map(roundKeyOf));
  const fullyPlayed = [...playedKeys].filter((k) => all.filter((f) => roundKeyOf(f) === k).every((f) => f.played));
  const champ = slot.season.champions[comp];
  const done = !all.some((f) => !f.played) && (isLeagueComp(comp) || !!champ);
  const nr = nextRound(slot, comp);
  return {
    played: fullyPlayed.length,
    total: isLeagueComp(comp) ? keys.size : Math.max(keys.size, fullyPlayed.length + (nr ? 1 : 0)),
    done,
    label: nr ? nr.label : champ ? "завершён" : "—",
  };
}

/** Симулирует один раунд конкретного турнира (календарь не двигается) */
export function simulateRound(slot: Slot, comp: Competition): { round: RoundInfo | null; results: { fixture: Fixture; result: MatchResult }[] } {
  const round = nextRound(slot, comp);
  if (!round) return { round: null, results: [] };

  // Отдых между турами: при свободной симуляции календарь не прокручивается
  // по дням, поэтому начисляем восстановление за прошедший интервал вручную —
  // иначе составы «сгорают» за пару туров.
  const gapDays = Math.max(
    1,
    Math.min(14, Math.round(
      (new Date(`${round.date}T00:00:00Z`).getTime() - new Date(`${slot.currentDate}T00:00:00Z`).getTime()) / 86400000
    ))
  );
  recoverAll(slot, gapDays * 4.6);

  const results: { fixture: Fixture; result: MatchResult }[] = [];
  for (const f of round.fixtures) {
    const res = simulateFixture(slot, f);
    applyResult(slot, f, res);
    results.push({ fixture: f, result: res });
  }
  // продвигаем сетки: кубки и еврокубки досоздают следующий раунд
  const rng = makeRng((slot.seed ^ hashStr(comp + round.key)) >>> 0);
  if (comp === "UCL" || comp === "UEL" || comp === "UECL") progressEuro(slot, comp);
  progressCups(slot, rng);
  // дата не отстаёт от сыгранного
  const last = round.fixtures.map((f) => f.date).sort(cmpDate).pop()!;
  if (cmpDate(slot.currentDate, last) < 0) slot.currentDate = last;
  checkSeasonEnd(slot);
  return { round, results };
}

/** Симулирует турнир целиком (все оставшиеся раунды) */
export function simulateWholeComp(slot: Slot, comp: Competition, maxRounds = 80): {
  rounds: number; matches: number; champion?: string;
} {
  let rounds = 0, matches = 0;
  for (let i = 0; i < maxRounds; i++) {
    const r = simulateRound(slot, comp);
    if (!r.round) break;
    rounds++;
    matches += r.results.length;
  }
  return { rounds, matches, champion: slot.season.champions[comp] };
}

/** Список турниров слота с прогрессом — для панели управления */
export function compsOverview(slot: Slot): {
  comp: Competition; name: string; short: string; played: number; total: number; done: boolean; next: string;
}[] {
  const present = new Set(slot.season.fixtures.map((f) => f.comp));
  const order: Competition[] = ["PL", "LL", "FL1", "BL", "SA", "PT", "SPL", "UCL", "UEL", "UECL", "FA", "EFL", "CDR", "CDF", "DFB", "CIT", "TCP", "KSC", "FR"];
  return order
    .filter((c) => present.has(c))
    .map((comp) => {
      const p = compProgress(slot, comp);
      return { comp, name: COMP_NAME[comp], short: COMP_SHORT[comp], played: p.played, total: p.total, done: p.done, next: p.label };
    });
}

// ─── Плей-офф повышения (Чемпионшип → АПЛ) ──────────────────────────────────
// 3-е, 4-е, 5-е и 6-е места нижней лиги разыгрывают третью путёвку наверх:
// полуфиналы в один матч (3 vs 6, 4 vs 5), затем финал на нейтральном поле.

export interface PlayoffResult {
  winner: string;
  semis: { homeId: string; awayId: string; score: string }[];
  final: { homeId: string; awayId: string; score: string } | null;
}

/** Победитель плей-офф повышения (краткая форма) */
export function simulatePromotionPlayoff(slot: Slot, contenders: string[]): string | null {
  return simulatePromotionPlayoffDetailed(slot, contenders)?.winner ?? null;
}

/**
 * Плей-офф повышения: 3-е vs 6-е и 4-е vs 5-е, победители — финал на нейтральном
 * поле. Возвращает полную картину (счета пар), чтобы показать её в межсезонье.
 */
export function simulatePromotionPlayoffDetailed(slot: Slot, contenders: string[]): PlayoffResult | null {
  if (contenders.length < 4) return contenders[0] ? { winner: contenders[0], semis: [], final: null } : null;
  const rng = makeRng((slot.seed ^ 0x9e3779b9 ^ slot.seasonNumber) >>> 0);

  const playOne = (aId: string, bId: string, neutral: boolean) => {
    const a = slot.teams[aId];
    const b = slot.teams[bId];
    if (!a || !b) return { winner: aId, score: "walkover" };
    // быстрая симуляция по силе составов — без полной поминутной модели,
    // чтобы плей-офф не влиял на свежесть игроков в новом сезоне
    const pow = (t: Team) => (t.attack + t.midfield + t.defense + t.goalkeeping) / 4 * (neutral ? 1 : 1.03);
    const pa = pow(a);
    const pb = pow(b);
    const diff = (pa - pb) / 12;
    let ga = 0, gb = 0;
    // до гола: у кого больше сила — тому больше шансов
    for (let i = 0; i < 4; i++) {
      if (rng.next() < 0.5 + diff * 0.1) ga++;
      if (rng.next() < 0.5 - diff * 0.1) gb++;
    }
    if (ga === gb) {
      // пенальти
      const sa = rng.next() < 0.5 + diff * 0.08;
      if (sa) ga++;
      else gb++;
    }
    return { winner: ga > gb ? aId : bId, score: `${ga}:${gb}` };
  };

  const [third, fourth, fifth, sixth] = contenders;
  const w1 = playOne(third, sixth, false);
  const w2 = playOne(fourth, fifth, false);
  const fin = playOne(w1.winner, w2.winner, true);
  return {
    winner: fin.winner,
    semis: [
      { homeId: third, awayId: sixth, score: w1.score },
      { homeId: fourth, awayId: fifth, score: w2.score },
    ],
    final: { homeId: w1.winner, awayId: w2.winner, score: fin.score },
  };
}
