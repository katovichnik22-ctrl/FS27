// ─── Система сохранений: слоты сезонов в LocalStorage ────────────────────────
// MAIN_DB — глобальная база только для чтения (быстрый матч её не меняет).
// Каждый сезон — отдельный слот с глубокой копией базы. Слоты независимы.

import type { LeagueId, LeagueLink, PromotionChange, Slot, SlotMeta, Team } from "../types";
import { MAIN_DB, deepClone } from "../data/db";
import { buildExtraTeams, makeFreeAgents } from "../data/extra";
import { autoEuroTeams, buildSeason, LEAGUE_CFG, LEAGUE_IDS, SEASON_START, simulatePromotionPlayoffDetailed } from "./season";
import { processLoanReturns } from "./transfers";
import { makeRng } from "./rng";
import { buildAllTactics, sanitizeTactics } from "./tactics";

const LS_KEY = "fs_slots";
const LS_SETTINGS = "fs_settings";

function readAll(): Record<string, Slot> {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, Slot>;
  } catch {
    return {};
  }
}

/** Пропускаем нулевые поля статистики — экономит ~25% объёма в localStorage */
function replacer(key: string, value: unknown) {
  if (value === 0 && ZERO_KEYS.has(key)) return undefined;
  return value;
}
const ZERO_KEYS = new Set([
  "apps", "goals", "assists", "cleanSheets", "yellow", "red", "saves", "conceded",
  "errors", "keyPasses", "tackles", "minutes", "plApps", "plGoals", "plAssists",
  "plCleanSheets", "ratingSum", "avgRating",
]);

const STAT_DEFAULTS = {
  apps: 0, goals: 0, assists: 0, cleanSheets: 0, yellow: 0, red: 0, saves: 0,
  conceded: 0, errors: 0, keyPasses: 0, tackles: 0, minutes: 0,
      shots: 0, shotsOnTarget: 0, xg: 0, interceptions: 0, fouls: 0, offsides: 0, dribbles: 0, motm: 0,
  plApps: 0, plGoals: 0, plAssists: 0, plCleanSheets: 0, ratingSum: 0, avgRating: 0,
};

/** Восстанавливает пропущенные нули после чтения */
function rehydrate(slot: Slot): Slot {
  for (const t of Object.values(slot.teams ?? {}))
    for (const p of t.players) p.stats = { ...STAT_DEFAULTS, ...p.stats };
  for (const p of slot.freeAgents ?? []) p.stats = { ...STAT_DEFAULTS, ...p.stats };
  slot.loans = slot.loans ?? []; // совместимость с сохранениями до аренд
  return slot;
}

function writeAll(data: Record<string, Slot>) {
  localStorage.setItem(LS_KEY, JSON.stringify(data, replacer));
}

function genId(): string {
  return `slot_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
}

/**
 * Собирает набор клубов для слота: выбранные лиги + Европа для еврокубков
 * + клубы низших дивизионов для кубков. «Лишние» топ-лиги не загружаются —
 * они не нужны и только занимают место в localStorage.
 */
export function buildWorld(seed: number, leagues: LeagueId[] = []): Record<string, Team> {
  // Клубы выбранных лиг уже есть в MAIN_DB — их процедурные копии из европула не нужны.
  const realNames = new Set<string>();
  const occupied = new Set<string>();
  for (const t of Object.values(MAIN_DB)) {
    realNames.add(t.name.toLowerCase());
    // собираем имена игроков ВСЕХ лиг: даже невыбранные участвуют в еврокубках
    for (const p of t.players) occupied.add(p.name);
  }
  const extra = buildExtraTeams(seed, occupied, realNames);
  const all = { ...(deepClone(MAIN_DB) as Record<string, Team>), ...extra };

  // какие клубы реально нужны
  const need = new Set<string>();
  // 1) клубы выбранных лиг
  for (const t of Object.values(all)) {
    if (t.league && leagues.includes(t.league)) need.add(t.id);
  }
  // 2) клубы для кубков выбранных лиг (вторые дивизионы той же страны)
  for (const lid of leagues) {
    const cup = CUP_TIER_OF[lid];
    if (!cup) continue;
    for (const t of Object.values(all)) if (t.tier === cup) need.add(t.id);
  }
  // 3) европейский пул для еврокубков (он всегда нужен)
  for (const t of Object.values(all)) if (t.tier === "EU") need.add(t.id);

  const out: Record<string, Team> = {};
  for (const id of need) if (all[id]) out[id] = all[id];
  return out;
}

/** Какой «второй дивизион» используется в кубке данной лиги */
const CUP_TIER_OF: Partial<Record<LeagueId, string>> = {
  PL: "L1", CHA: "L1", LL: "ES2", FL1: "FR2", BL: "DE2", SA: "IT2", PT: "PT2", SPL: "SA2", TUR: "TR2", BEL: "BE2", NED: "NE2", GRE: "GR2", UKR: "UA2", POL: "PO2", SCO: "SC2", SUI: "SW2",
};

export interface CreateOptions {
  leagues?: LeagueId[];
  uclTeams?: string[];
  uelTeams?: string[];
  ueclTeams?: string[];
  euroAuto?: boolean;
  euroDropToUel?: boolean;
  autoPromotion?: boolean;
  /** связанные лиги (АПЛ ↔ Чемпионшип): реальное повышение и вылет */
  linkedLeagues?: LeagueLink[];
  /** плей-офф повышения в связанных лигах */
  promotionPlayoff?: boolean;
  /** ручные бюджеты клубов (млн £) */
  budgets?: Record<string, number>;
}

/** Создать новый сезон-слот. Клуб НЕ выбирается: пользователь ведёт все лиги. */
export function createSlot(options: CreateOptions = {}): Slot {
  const seed = Math.floor(Math.random() * 2 ** 31);
  const teams = buildWorld(seed, options.leagues ?? LEAGUE_IDS);
  const leagues = options.leagues?.length ? options.leagues : LEAGUE_IDS;
  const auto = autoEuroTeams(teams, leagues);
  const ucl = options.uclTeams?.length === 36 ? options.uclTeams : auto.ucl;
  const uel = options.uelTeams?.length === 36 ? options.uelTeams : auto.uel.filter((id) => !ucl.includes(id));
  const uecl = options.ueclTeams?.length === 36
    ? options.ueclTeams
    : auto.uecl.filter((id) => !ucl.includes(id) && !uel.includes(id));
  const slot: Slot = {
    slotId: genId(),
    createdAt: new Date().toISOString(),
    seasonNumber: 1,
    currentDate: SEASON_START,
    seed,
    selectedLeagues: leagues,
    uclTeams: ucl,
    uelTeams: uel,
    ueclTeams: uecl,
    linkedLeagues: options.linkedLeagues ?? [],
    promotionPlayoff: options.promotionPlayoff ?? false,
    euroAuto: options.euroAuto ?? true,
    euroDropToUel: options.euroDropToUel ?? true,
    autoPromotion: options.autoPromotion ?? true,
    teams,
    tactics: buildAllTactics(teams),
    transfers: [],
    loans: [],
    freeAgents: makeFreeAgents(seed),
    season: buildSeason(teams, seed, 1, { leagues, uclTeams: ucl, uelTeams: uel, ueclTeams: uecl }),
    history: [],
  };
  // ручные бюджеты, заданные в визарде
  if (options.budgets) for (const [id, v] of Object.entries(options.budgets)) {
    if (slot.teams[id]) slot.teams[id].budget = v;
  }
  const all = readAll();
  all[slot.slotId] = slot;
  writeAll(all);
  return slot;
}

/** Вылеты и повышения между сезонами (3 или 2 клуба в зависимости от лиги) */
/**
 * Реальное повышение/вылет между СВЯЗАННЫМИ лигами (АПЛ ↔ Чемпионшип).
 * 3 худших верхней лиги вылетают, 2 лучших нижней поднимаются напрямую,
 * 3–6 места нижней разыгрывают третью путёвку в плей-офф.
 * Несвязанные лиги ведут себя как раньше (обмен со вторым дивизионом).
 */
export function applyPromotions(slot: Slot): PromotionChange[] {
  const out: PromotionChange[] = [];
  const results = slot.previousSeasonResults ?? {};
  const linked = slot.linkedLeagues ?? [];
  const handled = new Set<LeagueId>();

  const swap = (downId: string, upId: string, upper: LeagueId, lower: LeagueId) => {
    const down = slot.teams[downId];
    const up = slot.teams[upId];
    if (!down || !up) return;
    down.league = lower;
    down.tier = lower;
    up.league = upper;
    up.tier = upper;
    up.reputation = Math.min(100, up.reputation + 6);
    down.reputation = Math.max(20, down.reputation - 6);
  };

  // ── связанные пары ──
  for (const link of linked) {
    handled.add(link.upper);
    handled.add(link.lower);
    const upperOrder = results[link.upper];
    const lowerOrder = results[link.lower];
    if (!upperOrder?.length || !lowerOrder?.length) continue;

    const cfg = LEAGUE_CFG[link.upper];
    const relegated = upperOrder.slice(-cfg.drop);          // 3 худших
    const promoted: { id: string; name: string }[] = [];
    const playoffPromoted: { id: string; name: string }[] = [];

    // 2 лучших нижней — напрямую
    const direct = lowerOrder.slice(0, 2);
    for (const id of direct) promoted.push({ id, name: slot.teams[id]?.name ?? id });

    // плей-офф: 3–6 места
    let playoff: PromotionChange["playoff"] = null;
    if (slot.promotionPlayoff) {
      const res = simulatePromotionPlayoffDetailed(slot, lowerOrder.slice(2, 6));
      if (res) {
        playoff = { semis: res.semis, final: res.final, winner: res.winner };
        const winner = res.winner;
        playoffPromoted.push({ id: winner, name: slot.teams[winner]?.name ?? winner });
        promoted.push({ id: winner, name: slot.teams[winner]?.name ?? winner });
      }
    } else if (cfg.drop > 2) {
      // без плей-офф — третий поднимается по таблице
      const third = lowerOrder[2];
      if (third) promoted.push({ id: third, name: slot.teams[third]?.name ?? third });
    }

    // вылетевших может быть больше, чем поднявшихся (например, лиги разного размера)
    const upList = [...promoted.map((p) => p.id)];
    const n = Math.min(relegated.length, upList.length);
    const change: PromotionChange = {
      league: link.upper, lower: link.lower, relegated: [], promoted: [], playoffPromoted, playoff,
    };
    for (let i = 0; i < n; i++) {
      const downId = relegated[i];
      const upId = upList[i];
      change.relegated.push({ id: downId, name: slot.teams[downId]?.name ?? downId });
      change.promoted.push({ id: upId, name: slot.teams[upId]?.name ?? upId });
      swap(downId, upId, link.upper, link.lower);
    }
    // если вылетело больше, чем поднялось — лишние просто уходят вниз
    for (let i = n; i < relegated.length; i++) {
      const downId = relegated[i];
      const t = slot.teams[downId];
      if (!t) continue;
      change.relegated.push({ id: downId, name: t.name });
      t.league = link.lower;
      t.tier = link.lower;
      t.reputation = Math.max(20, t.reputation - 6);
    }
    out.push(change);
  }

  // ── остальные лиги: прежняя логика обмена со вторым дивизионом ──
  // Но второй дивизион (CHA) сам по себе не повышается: без связи с верхней
  // лигой он просто остаётся на месте, как и просил пользователь.
  const SECOND_TIER: LeagueId[] = ["CHA"];
  for (const lid of (slot.selectedLeagues ?? LEAGUE_IDS).filter((l) => !handled.has(l))) {
    if (SECOND_TIER.includes(lid)) continue; // не даём Чемпионшипу меняться без связи
    const cfg = LEAGUE_CFG[lid];
    const order = results[lid];
    if (!order?.length) continue;
    const drop = order.slice(-cfg.drop);
    // Пул для повышения: основной второй дивизион, а если его клубов в слоте нет
    // (например, АПЛ без Чемпионшипа — тогда в мире только Лига 1), берём
    // запасной дивизион. Раньше из-за этого повышения молча не происходило.
    const tier = pickPromotionTier(slot, lid, cfg.drop);
    if (!tier) continue;
    // Дивизион не симулируется, таблицы нет — разыгрываем условный сезон:
    // сила клуба = репутация с разбросом, чтобы наверх выходили разные команды,
    // а вылетевшие не возвращались автоматически каждый год.
    const rng = makeRng((slot.seed ^ 0x51ed270b ^ (slot.seasonNumber * 2654435761)) >>> 0);
    const pool = Object.values(slot.teams)
      .filter((t) => t.tier === tier && !t.league)
      .map((t) => ({ team: t, strength: t.reputation * (0.72 + rng.next() * 0.62) }))
      .sort((a, b) => b.strength - a.strength)
      .slice(0, cfg.drop)
      .map((x) => x.team);
    if (pool.length < cfg.drop) continue;
    const change: PromotionChange = { league: lid, lower: tier, relegated: [], promoted: [] };
    for (let i = 0; i < cfg.drop; i++) {
      const downId = drop[i];
      const up = pool[i];
      const down = slot.teams[downId];
      if (!down || !up) continue;
      change.relegated.push({ id: downId, name: down.name });
      change.promoted.push({ id: up.id, name: up.name });
      // вниз — в несимулируемый дивизион (league снимается, клуб идёт в пул),
      // вверх — в лигу слота
      down.league = undefined;
      down.tier = tier as Team["tier"];
      down.reputation = Math.max(20, down.reputation - 8);
      up.league = lid;
      up.tier = lid;
      up.reputation = Math.min(100, up.reputation + 8);
    }
    out.push(change);
  }
  return out;
}

/** Есть ли в слоте достаточно свободных клубов нужного дивизиона */
function tierPoolSize(slot: Slot, tier: string): number {
  return Object.values(slot.teams).filter((t) => t.tier === tier && !t.league).length;
}

/**
 * Дивизион, из которого поднимаются клубы. Для АПЛ это Чемпионшип (CH), но если
 * его клубы не загружены в слот, используем Лигу 1 (L1) — она всегда есть,
 * потому что нужна для кубков.
 */
function pickPromotionTier(slot: Slot, lid: LeagueId, need: number): string | null {
  const chain = [LEAGUE_CUP_TIER[lid], ...(PROMOTION_FALLBACK[lid] ?? [])];
  for (const tier of chain) if (tier && tierPoolSize(slot, tier) >= need) return tier;
  return null;
}

/** Запасные дивизионы, если основной второй дивизион не загружен в слот */
const PROMOTION_FALLBACK: Partial<Record<LeagueId, string[]>> = {
  PL: ["L1"],
  CHA: ["L1"],
};

const LEAGUE_CUP_TIER: Record<LeagueId, "CH" | "ES2" | "FR2" | "DE2" | "IT2" | "PT2" | "SA2" | "L1" | "TR2" | "BE2" | "NE2" | "GR2" | "UA2" | "PO2" | "SC2" | "SW2"> = {
  PL: "CH", LL: "ES2", FL1: "FR2", BL: "DE2", SA: "IT2", PT: "PT2", SPL: "SA2", CHA: "L1", TUR: "TR2", BEL: "BE2", NED: "NE2", GRE: "GR2", UKR: "UA2", POL: "PO2", SCO: "SC2", SUI: "SW2",
};

/** Новый сезон в том же слоте: составы стареют, статистика обнуляется */
export interface NextSeasonOptions {
  uclTeams?: string[];
  uelTeams?: string[];
  ueclTeams?: string[];
  autoPromotion?: boolean;
  euroAuto?: boolean;
  euroDropToUel?: boolean;
  linkedLeagues?: LeagueLink[];
  promotionPlayoff?: boolean;
}

export function startNextSeason(prev: Slot, opts: NextSeasonOptions = {}): Slot {
  const seed = (prev.seed * 1103515245 + 12345) >>> 0;
  const teams = deepClone(prev.teams) as Record<string, Team>;
  for (const t of Object.values(teams)) {
    for (const p of t.players) {
      p.age += 1;
      p.form = 1;
      p.fitness = 100;
      p.morale = 70;
      p.stats = {
        apps: 0, goals: 0, assists: 0, cleanSheets: 0, yellow: 0, red: 0, saves: 0,
        conceded: 0, errors: 0, keyPasses: 0, tackles: 0, minutes: 0,
      shots: 0, shotsOnTarget: 0, xg: 0, interceptions: 0, fouls: 0, offsides: 0, dribbles: 0, motm: 0,
      plApps: 0, plGoals: 0, plAssists: 0, plCleanSheets: 0, ratingSum: 0, avgRating: 0,
      };
    }
    // клубные рейтинги подтягиваются под обновлённые составы
    const byPos = (pos: string) => t.players.filter((p) => p.position === pos).sort((a, b) => b.overall - a.overall);
    const avg = (arr: { overall: number }[], n: number) =>
      arr.length ? Math.round(arr.slice(0, n).reduce((s, p) => s + p.overall, 0) / Math.min(n, arr.length)) : 70;
    t.attack = avg(byPos("FW"), 3);
    t.midfield = avg(byPos("MF"), 3);
    t.defense = avg(byPos("DF"), 4);
    t.goalkeeping = avg(byPos("GK"), 1);
    t.reputation = Math.max(20, Math.min(100, Math.round(t.reputation * 0.75 + ((t.attack + t.midfield + t.defense) / 3) * 0.25)));
  }
  const tactics: Record<string, typeof prev.tactics[string]> = {};
  for (const t of Object.values(teams)) tactics[t.id] = sanitizeTactics(t, prev.tactics?.[t.id]);
  const leagues = prev.selectedLeagues?.length ? prev.selectedLeagues : LEAGUE_IDS;
  const next: Slot = {
    ...prev,
    seasonNumber: prev.seasonNumber + 1,
    currentDate: SEASON_START,
    seed,
    teams,
    tactics,
    transfers: [],
    freeAgents: prev.freeAgents ?? [],
    autoPromotion: opts.autoPromotion ?? prev.autoPromotion ?? true,
    linkedLeagues: opts.linkedLeagues ?? prev.linkedLeagues ?? [],
    promotionPlayoff: opts.promotionPlayoff ?? prev.promotionPlayoff ?? false,
    euroAuto: opts.euroAuto ?? prev.euroAuto ?? true,
    euroDropToUel: opts.euroDropToUel ?? prev.euroDropToUel ?? true,
    previousSeasonResults: prev.previousSeasonResults,
    season: prev.season,
    history: prev.history,
  };
  next.loans = next.loans ?? [];
  // аренды, истёкшие летом: футболисты возвращаются в клубы-владельцы
  // (зимние возвраты случаются внутри сезона через advanceDay)
  const returned = processLoanReturns(next, "newSeason");
  // вылеты/повышения (если не отключены пользователем)
  next.lastPromotions = next.autoPromotion ? applyPromotions(next) : [];
  void returned;
  // составы еврокубков: ручной выбор или авто по итогам сезона
  const auto = autoEuroTeams(next.teams, leagues, next.previousSeasonResults);
  const okList = (ids?: string[]) => (ids?.length === 36 && ids.every((id) => next.teams[id]) ? ids : null);
  next.uclTeams = okList(opts.uclTeams) ?? auto.ucl;
  next.uelTeams = okList(opts.uelTeams) ?? auto.uel.filter((id) => !next.uclTeams.includes(id)).slice(0, 36);
  next.ueclTeams = okList(opts.ueclTeams)
    ?? auto.uecl.filter((id) => !next.uclTeams.includes(id) && !next.uelTeams.includes(id)).slice(0, 36);
  next.season = buildSeason(next.teams, seed, next.seasonNumber, {
    leagues, uclTeams: next.uclTeams, uelTeams: next.uelTeams, ueclTeams: next.ueclTeams,
  });
  // тактики для поднявшихся клубов
  for (const t of Object.values(next.teams)) if (!next.tactics[t.id]) next.tactics[t.id] = sanitizeTactics(t, undefined);
  saveSlot(next);
  return next;
}

export function loadSlot(slotId: string): Slot | null {
  const s = readAll()[slotId];
  return s ? rehydrate(s) : null;
}

/** Автосохранение — вызывается после каждого матча/дня сезона */
export function saveSlot(slot: Slot): void {
  const all = readAll();
  all[slot.slotId] = slot;
  try {
    writeAll(all);
  } catch {
    // переполнение localStorage — чистим самый старый слот и пробуем ещё раз
    const metas = listSlots();
    const oldest = metas[metas.length - 1];
    if (oldest && oldest.slotId !== slot.slotId) {
      delete all[oldest.slotId];
      try { writeAll(all); } catch { /* ignore */ }
    }
  }
}

export function listSlots(): SlotMeta[] {
  return Object.values(readAll())
    .map((s) => ({
      slotId: s.slotId,
      createdAt: s.createdAt,
      seasonNumber: s.seasonNumber,
      currentDate: s.currentDate,
      finished: !!s.season?.finished,
      matchesPlayed: s.season?.fixtures.filter((f) => f.played).length ?? 0,
      matchesTotal: s.season?.fixtures.length ?? 0,
      leagues: s.selectedLeagues ?? [],
    }))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function deleteSlot(slotId: string): void {
  const all = readAll();
  delete all[slotId];
  writeAll(all);
}

/** Экспорт слота в JSON-строку (бэкап/перенос между устройствами) */
export function exportSlot(slotId: string): string | null {
  const slot = loadSlot(slotId);
  return slot ? JSON.stringify(slot, replacer) : null;
}

/** Импорт слота из JSON-строки; при коллизии id — новый */
export function importSlot(json: string): Slot {
  const parsed = JSON.parse(json) as Slot;
  if (!parsed || typeof parsed !== "object" || !parsed.teams || !parsed.slotId) {
    throw new Error("Файл не похож на слот сохранения");
  }
  // совместимость со старыми сохранениями (были привязаны к клубу игрока)
  if (!parsed.tactics) parsed.tactics = buildAllTactics(parsed.teams);
  if (!parsed.selectedLeagues?.length) parsed.selectedLeagues = LEAGUE_IDS;
  parsed.uclTeams = parsed.uclTeams ?? [];
  parsed.uelTeams = parsed.uelTeams ?? [];
  parsed.ueclTeams = parsed.ueclTeams ?? [];
  parsed.euroAuto = parsed.euroAuto ?? true;
  parsed.euroDropToUel = parsed.euroDropToUel ?? true;
  parsed.autoPromotion = parsed.autoPromotion ?? true;
  parsed.linkedLeagues = parsed.linkedLeagues ?? [];
  parsed.promotionPlayoff = parsed.promotionPlayoff ?? false;
  parsed.transfers = parsed.transfers ?? [];
  parsed.loans = parsed.loans ?? [];
  parsed.freeAgents = parsed.freeAgents ?? [];
  const all = readAll();
  if (all[parsed.slotId]) parsed.slotId = genId();
  parsed.createdAt = parsed.createdAt || new Date().toISOString();
  parsed.history = parsed.history ?? [];
  rehydrate(parsed);
  all[parsed.slotId] = parsed;
  writeAll(all);
  return parsed;
}

// ─── Настройки приложения ────────────────────────────────────────────────────

export interface AppSettings {
  defaultSpeed: number;
  skipBroadcast: boolean;
  /** мобильный режим: крупные элементы, упрощённые таблицы, нижняя навигация */
  mobileMode: boolean;
  /** название лиги — подставляется в копируемые тексты (заголовки) */
  leagueName: string;
  /** хэштег лиги — последняя строка копируемых текстов */
  leagueHashtag: string;
  /** номер текущего тура — подставляется в копируемые тексты */
  matchdayNumber: number;
}

const DEFAULT_SETTINGS: AppSettings = {
  defaultSpeed: 90,
  skipBroadcast: false,
  // по умолчанию включаем на узких экранах
  mobileMode: typeof window !== "undefined" && window.innerWidth <= 820,
  leagueName: "Premier League",
  leagueHashtag: "#PremierLeague",
  matchdayNumber: 1,
};

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(LS_SETTINGS);
    if (!raw) return { ...DEFAULT_SETTINGS };
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<AppSettings>) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(s: AppSettings): void {
  localStorage.setItem(LS_SETTINGS, JSON.stringify(s));
  applyMobileMode(s.mobileMode);
}

/** Переключает мобильный режим: класс на <html> + запись в настройки */
export function setMobileMode(on: boolean): AppSettings {
  const next = { ...loadSettings(), mobileMode: on };
  saveSettings(next);
  return next;
}

/** Навешивает/снимает класс мобильного режима на документ */
export function applyMobileMode(on: boolean): void {
  if (typeof document === "undefined") return;
  document.documentElement.classList.toggle("fs-mobile", on);
  const vp = document.querySelector('meta[name="viewport"]');
  if (vp) vp.setAttribute("content", on
    ? "width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover"
    : "width=device-width, initial-scale=1");
}
